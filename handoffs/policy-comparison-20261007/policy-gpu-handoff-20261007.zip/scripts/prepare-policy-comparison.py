"""Verify the frozen policy/cohort and prepare fresh matching inputs; no inference."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "runtime/fpy-v6-pinned/src"))
sys.path.append(str(ROOT / ".openai-deps"))
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.comparison_policy import ComparisonPolicy, sha256
from local_slm_lab.v5_eval import build_call_plan, digest, now
from local_slm_lab.v5_prompts import build_v5_extractor_instructions, build_v5_extractor_input


def prepare(policy_directory):
    policy = ComparisonPolicy(policy_directory)
    cases = [json.loads(line) for line in (policy_directory / "primary-natural.jsonl").read_text(encoding="utf-8").splitlines()]
    schema = load_schema()
    plan = build_call_plan(cases, schema)
    lock = json.loads((policy_directory / "freeze-manifest.json").read_text(encoding="utf-8"))
    gold_contexts = [[c["key"], digest(c["context"]), digest(c["expected"])] for c in plan]
    if digest(gold_contexts) != lock["context_gold_sha256"]:
        raise ValueError("Reviewed call plan differs from freeze")
    for case in cases:
        for turn in case["turns"]:
            admission = policy.parse(json.dumps(turn["gold_extraction"]), "extract")
            if not admission.admitted:
                raise ValueError("Gold violates shared admission policy")
    return {"prepared_at_utc": now(), "status": "inputs_verified_not_executed", "policy_version": policy.version,
            "policy_manifest_sha256": policy.fingerprint, "cases_sha256": sha256(policy_directory / "primary-natural.jsonl"),
            "scenarios": len(cases), "calls_per_arm_per_track": len(plan),
            "tracks": ["component_gold_context", "rollout_own_predicted_context_fixed_user_script"],
            "required_arms": ["stock_Qwen3.5-2B", "v5_LoRA", "v6_LoRA", "OpenAI_F_gpt-5-mini-2025-08-07"],
            "optional_separate_arms": ["OpenAI_A", "OpenAI_B_one_structural_retry", "OpenAI_J"],
            "base_revision": "15852e8c16360a2fea060d615a32b45270f8a8fc",
            "prompt_instructions_sha256": digest(build_v5_extractor_instructions()),
            "ordered_component_prompts_sha256": digest([[c["key"], build_v5_extractor_input(c["context"]["message"], c["state"], schema)] for c in plan]),
            "context_gold_sha256": digest(gold_contexts), "ordered_keys_sha256": digest([c["key"] for c in plan]),
            "script_sha256": sha256(Path(__file__)), "api_calls_made": 0, "new_model_inferences": 0,
            "independent_human_review": False, "sealed_final_accessed": False,
            "execution": "Use PolicyOpenAIProvider/PolicyTransformersProvider + evaluate_with_policy; assert matched_primary_records before paired bootstrap. Existing historical runners intentionally still use their old protocol.",
            "fresh_inference_required": "62 of 93 component contexts changed after gold review; do not reuse cached old-policy retries or rollout trajectories as fresh results."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--policy", type=Path, default=ROOT / "evaluation/comparison-policy-20261006")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = prepare(args.policy.resolve())
    if args.output:
        if args.output.exists():
            raise FileExistsError("Use a new preparation filename")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(result, indent=2))
