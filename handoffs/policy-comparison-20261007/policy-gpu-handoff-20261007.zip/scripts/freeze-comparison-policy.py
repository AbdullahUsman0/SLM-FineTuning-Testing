"""Freeze an agent-reviewed DEVELOPMENT cohort; never open final/test labels.

The adjudications below were made against utterances and pinned slot definitions.
This is posthoc review, not independent human annotation or new held-out evidence.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "runtime/fpy-v6-pinned/src"))
sys.path.append(str(ROOT / ".openai-deps"))
from forecasting_assistant.domain import models
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.v5_eval import build_call_plan, digest, now, sha256, validate_scenarios

SOURCE = ROOT / "evaluation/v6-matched-20261005/natural.jsonl"
SOURCE_SHA = "88824a03b4f29196e6ed827e73b9edda6a1caf4c2b13ec7eea3d5b367bcbfb19"
OUT = ROOT / "evaluation/comparison-policy-20261006"
POLICY_VERSION = "closed-schema-pydantic-once-20261006-1"
EXCLUDED = "natural-v6-20261005/weather/03"

RUBRIC = """# Annotation rubric — development review 2026-10-06

Reviewer: Codex agent. Review is AFTER model predictions existed. It is not
independent human review. Read only original user turns and pinned slot definitions
when deciding changes. Do not infer gold from model responses or optimize for a model.

## Rules, fixed before a new comparison

- R1: `problem_statement` means “What must be predicted”; `target_description`
  means “Domain meaning of the target”. An explicit prediction request naming a
  meaningful target supports BOTH slots. Use the same exact target noun phrase
  for both; include modifiers that identify the target. Evidence may support
  more than one slot. Do not invent a column identifier from that phrase.
- R2: New explicit facts and replacement corrections have status `provided`.
  `confirmed` requires an explicit affirmation of an existing/proposed value;
  “change to 8 days” is a replacement, not confirmation. Keep value/status F1
  primary; report value-only accuracy separately if later desired.
- R3: A correction replaces only its named requirement, sets correction_detected
  true, and does not repeat unchanged prior state. An unresolved contradiction
  is different from an explicit replacement. None of these 32 correction turns
  leaves the new horizon unresolved.
- R4: “I do not know / not decided / leave unset” supplies no candidate value.
  It is not `dont_care`, null, or a guessed default. Emit no update here. Do not
  infer timezone, seasonality, interval levels or credentials. These unknown
  slots were unset in the prior gold state; this rubric does not define deletion
  of a previously known value, which needs separate future cases.
- R5: `frequency` is native observation cadence; `prediction_frequency` is
  forecast refresh cadence; `output_granularity` is requested output resolution.
  Require wording sufficient to distinguish them. “Forecast peak wind speed,
  every hour” does not establish native observations. Flag, do not guess.
- R6: `source_mode=upload` needs explicit upload/uploaded wording in this cohort.
  Merely naming a file format establishes file_format, not the access mode.
  File format does not reveal a filename, columns or credentials. Column names
  need explicit identifiers. No implicit “single_series” or “point” defaults.
- R7: Free-text target and unit labels use exact stated wording; no paraphrases,
  case folding, synonym/unit conversions, or financial advice is added. Preserve
  CPI index vs inflation, price vs return, spot vs futures, and raw vs adjusted.
  A derived target name does not itself request an aggregation operation.
- R8: Durations use {periods:number,unit:singular}; daily=1 day, monthly=1 month,
  quarterly=1 quarter. Do not equate calendar months/quarters with fixed day counts.
- R9: Evidence is a nonempty exact substring of the CURRENT user turn. Prior
  state and assistant text are context, not new evidence. Whole current-message
  evidence is permitted but span-specific evidence is preferred for new labels.
- R10: A task/target statement does not supply a business goal or decision.
  Those slots require an explicit purpose or action supported by the forecast.

## Scope and decisions

All 96 turns in the natural 32-scenario diagnostic were reviewed. Each initial
turn has a missing problem_statement under R1. Added that label using the existing
explicit target phrase; existing correction statuses and unknown-turn abstentions
are retained. WEATHER/03 remains ambiguous on native frequency vs output cadence:
retain its historical proposal for audit but exclude the WHOLE scenario from the
new primary cohort until separately adjudicated. Thus primary=31 scenarios/93
extraction calls, with all four domains retained. No questions are scored in this
natural cohort. No original files, training labels or final labels were changed.

The original v5 synthetic/coverage cohort is outside this label review. Its old
scores cannot be combined with this revised cohort. Broader schema coverage and
fresh independent annotations are future work, not established by these 31 cases.

## Easy explanation

“Predict daily temperature for 7 days” names the prediction problem and target.
Both problem_statement and target_description get “temperature”; frequency=1 day,
horizon=7 days. It does not establish a CSV column named temperature or a goal.
“Actually use 10 days” changes only horizon, status provided, correction true.
“I do not know the timezone” leaves timezone unset.

Roman Urdu: Dono models ka jawab aik hi rule se check hoga. Agar user temperature
predict karne ko kahe to problem aur target dono maloom hain. “10 din kar dein”
sirf horizon ki correction hai. “Timezone nahi pata” par koi value nahi banani.
Jahan “har ghantay” ka matlab data ki frequency ya output ka time dono ho sakta
hai, us case ko abhi primary score se bahar rakha hai.
"""


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")


def write_lines(path, rows):
    path.write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n" for r in rows), encoding="utf-8", newline="\n")


def reviewed_cases(original):
    candidates, ledger, queue = [], [], []
    for case in original:
        revised = copy.deepcopy(case)
        revised["reviewer_status"] = "agent_reviewed_posthoc_independent_human_pending"
        revised["label_policy_version"] = POLICY_VERSION
        revised["primary_eligible"] = case["scenario_id"] != EXCLUDED
        for index, turn in enumerate(revised["turns"]):
            before = copy.deepcopy(turn["gold_extraction"])
            updates = turn["gold_extraction"]["updates"]
            if index == 0:
                target = next(u for u in updates if u["slot_id"] == "target_description")
                value = json.loads(target["candidate_value"])
                assert isinstance(value, str) and value in turn["message"]
                assert not any(u["slot_id"] == "problem_statement" for u in updates)
                updates.append(dict(slot_id="problem_statement", candidate_value=target["candidate_value"],
                                    status="provided", confidence=1.0, evidence_text=value))
                rules = ["R1", "R5", "R6", "R7", "R8", "R9", "R10"]
                rationale = "Explicit target answers what must be predicted as well as target meaning; add problem_statement. Other literal facts retained."
            elif index == 1:
                assert before["correction_detected"] and len(updates) == 1
                assert updates[0]["slot_id"] == "forecast_horizon" and updates[0]["status"] == "provided"
                rules, rationale = ["R2", "R3", "R8", "R9"], "Explicit replacement of horizon, not affirmative confirmation; keep provided and do not repeat other slots."
            else:
                assert not updates and not before["correction_detected"]
                rules, rationale = ["R4", "R9"], "Unknown optional values remain unset; keep empty updates, no dont_care or inferred default."
            for update in updates:
                assert update["evidence_text"] and update["evidence_text"] in turn["message"]
            unresolved = case["scenario_id"] == EXCLUDED and index == 0
            if unresolved:
                rationale += " Native frequency is not established by 'every hour'; exclude entire scenario pending adjudication."
                queue.append(dict(scenario_id=case["scenario_id"], turn=1, rule="R5", slot_id="frequency",
                                  message=turn["message"], disputed_gold=next(u for u in updates if u["slot_id"] == "frequency"),
                                  alternatives=["Requested output granularity", "Native observation cadence"],
                                  disposition="excluded_from_primary; do not guess", reviewer_type="agent"))
            ledger.append(dict(scenario_id=case["scenario_id"], turn=index + 1, reviewer_type="agent",
                               status="unresolved_excluded" if unresolved else "agent_adjudicated",
                               independent_human_review=False, rules=rules, rationale=rationale,
                               message_sha256=hashlib.sha256(turn["message"].encode()).hexdigest(),
                               before=before, after=copy.deepcopy(turn["gold_extraction"]), changed=before != turn["gold_extraction"]))
        candidates.append(revised)
    return candidates, ledger, queue


def freeze(output):
    if output.exists():
        raise FileExistsError("Policy already exists; verify it or create a new version/directory")
    if sha256(SOURCE) != SOURCE_SHA:
        raise ValueError("Original diagnostic cohort changed")
    original = [json.loads(line) for line in SOURCE.read_text(encoding="utf-8").splitlines() if line]
    assert len(original) == 32 and sum(len(c["turns"]) for c in original) == 96
    candidates, decisions, queue = reviewed_cases(original)
    primary = [c for c in candidates if c["primary_eligible"]]
    schema = load_schema()
    validate_scenarios(primary, schema)
    plans = build_call_plan(primary, schema)
    old_plans = {tuple(p["key"]): p for p in build_call_plan(original, schema)}
    contexts_changed = [p["key"] for p in plans if digest(p["context"]) != digest(old_plans[tuple(p["key"])]["context"])]
    lock = json.loads((ROOT / "research-checkpoints/v6-training-20261003/results/launch-config.json").read_text(encoding="utf-8"))
    package = Path(models.__file__).resolve().parents[1]
    actual = {"src/forecasting_assistant/" + p.relative_to(package).as_posix(): sha256(p) for p in sorted(package.rglob("*.py"))}
    if actual != lock["fpy_source_sha256"]:
        raise ValueError("Wrong fpy dependency source")
    output.mkdir(parents=True)
    for name in ("extractor-result.schema.json", "question-output.schema.json"):
        expected = {"extractor-result.schema.json": "93bfe76e70e824f6ca24101c92bdb5c6ff57eae2d89b9e31f658ed207cb5f9ef",
                    "question-output.schema.json": "1ef8d3a2c1d6913d891530b56ff621fbf93c5ba4f93695f4b3acee3207a8eea4"}[name]
        if sha256(ROOT / "evaluation/v5-structured-output/schemas" / name) != expected:
            raise ValueError("Canonical exported schema changed")
        shutil.copyfile(ROOT / "evaluation/v5-structured-output/schemas" / name, output / name)
    write_lines(output / "reviewed-candidates.jsonl", candidates)
    write_lines(output / "primary-natural.jsonl", primary)
    write_lines(output / "review-decisions.jsonl", decisions)
    write_lines(output / "adjudication-queue.jsonl", queue)
    (output / "ANNOTATION_RUBRIC.md").write_text(RUBRIC, encoding="utf-8", newline="\n")
    write_json(output / "slot-definitions.json", schema.model_dump(mode="json"))
    write_json(output / "policy.json", {
        "version": POLICY_VERSION, "applies_identically_to": ["OpenAI", "stock SLM", "fine-tuned SLM"],
        "wire": "One complete closed-schema JSON object; candidate_value is a string envelope, never a native object/number/list",
        "decode": "Exactly once: valid embedded JSON decoded; ordinary non-JSON text retained; no second pass, trimming, case folding or semantic repair",
        "literal_disambiguation": "Plain '2026', 'true', 'null' decode to number/bool/null; JSON-quote literal strings to preserve them. Same rule for all providers.",
        "reject": ["duplicate outer or embedded keys", "nonfinite outer or embedded numbers", "duplicate slot updates", "unknown slots/extra/missing fields", "coerced scalar types", "refusal", "incomplete response", "generation cap hit"],
        "separate_metrics": ["JSON syntax", "declared schema", "parser admission", "evidence grounding", "semantic slot/value/status correctness", "state transitions"],
        "semantic_validation": "Admission does not assert slot value types, evidence truth, correct status or grounded facts. Score semantic errors separately; no facts are supplied by the parser.",
        "primary_scoring": "Pinned v5 exact slot/value/status micro F1 excluding intent; JSON key order ignored, list order/types and exact free text preserved; invalid responses retain readable FP and incur all gold FN",
        "retry": "Primary comparison: one generation, no repair/retry. B is a separate one-structural-retry arm using this SAME admission policy, with extra time/calls counted; D requires a separately frozen probe contract.",
        "cohort": "primary-natural.jsonl; agent-reviewed posthoc development, 31 scenarios/93 extraction calls; not training or final test",
        "comparison_requirement": "Fresh requests on revised contexts with same prompts/schema/labels; policy and cohort hashes recorded by every arm. Never pair unmatched contexts or call posthoc cached responses prospective results.",
        "C": "Local XGrammar only; hosted F is its constrained-structure counterpart, not a measured XGrammar result"})
    manifest = {"policy_version": POLICY_VERSION, "frozen_at_utc": now(), "source_sha256": SOURCE_SHA,
                "source": SOURCE.relative_to(ROOT).as_posix(), "fpy_revision": lock["fpy_revision"],
                "fpy_source_sha256": actual, "parser_dependencies": {p: version(p) for p in ("pydantic", "jsonschema")},
                "review_scope": {"scenarios": 32, "turns": 96, "changed_initial_labels": 32,
                                 "primary_scenarios": len(primary), "primary_calls": len(plans), "excluded_scenarios": [EXCLUDED],
                                 "unresolved_issues": len(queue), "agent_review": True, "independent_human_review": False,
                                 "posthoc_after_predictions": True, "source_training_or_final_modified": False},
                "changed_context_keys": contexts_changed,
                "ordered_keys_sha256": digest([p["key"] for p in plans]),
                "context_gold_sha256": digest([[p["key"], digest(p["context"]), digest(p["expected"])] for p in plans]),
                "implementation_hash_encoding": "source bytes with CRLF converted to LF; artifact hashes remain raw bytes",
                "implementation_sha256": {name: hashlib.sha256((ROOT / name).read_bytes().replace(b"\r\n", b"\n")).hexdigest() for name in
                    ("local_slm_lab/comparison_policy.py", "local_slm_lab/policy_providers.py", "local_slm_lab/v5_eval.py", "local_slm_lab/v5_prompts.py", "local_slm_lab/slm_prompts.py", "local_slm_lab/peft_provider.py", "local_slm_lab/v5_provider.py", "local_slm_lab/openai_output_methods.py", "local_slm_lab/structured_output_providers.py", "scripts/freeze-comparison-policy.py")},
                "files_sha256": {p.name: sha256(p) for p in sorted(output.iterdir()) if p.is_file()},
                "api_calls_made": 0, "sealed_final_accessed": False}
    write_json(output / "freeze-manifest.json", manifest)
    from local_slm_lab.comparison_policy import ComparisonPolicy
    ComparisonPolicy(output)
    print(json.dumps({"frozen": True, "manifest_sha256": sha256(output / "freeze-manifest.json"), **manifest["review_scope"], "changed_context_calls": len(contexts_changed)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=OUT)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    if args.verify:
        from local_slm_lab.comparison_policy import ComparisonPolicy
        policy = ComparisonPolicy(args.output)
        print(json.dumps({"verified": True, "policy": policy.version, "manifest_sha256": policy.fingerprint}))
    else:
        freeze(args.output)
