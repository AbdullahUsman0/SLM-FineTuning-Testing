param(
    [string]$Python = 'D:\SLM\SLM-FineTuning-Testing\.venv\Scripts\python.exe',
    [ValidateSet('base','v5','v6')][string]$Arm = 'v6',
    [string]$Adapter = 'D:\SLM\FYP-model-runs\qwen35-2b-lora-v6-20261003T113807Z\full\best-adapter',
    [string]$RunDir = 'training-runs/policy-v6-bf16-20261007',
    [switch]$PrepareOnly
)
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw 'Pass -Python with the existing CUDA environment.' }
$env:HF_HOME = 'D:\SLM\hf-cache'
Push-Location -LiteralPath $taskRoot
try {
    $taskArgs = @('-B','-u','scripts/evaluate-policy-comparison.py','--arm',$Arm,'--run-dir',$RunDir)
    if ($Arm -ne 'base') { $taskArgs += @('--adapter',$Adapter) }
    if ($PrepareOnly) { $taskArgs += '--prepare-only' }
    & $Python @taskArgs
    if ($LASTEXITCODE -ne 0) { throw 'Evaluation stopped; inspect the safe run logs. Re-run the identical command to resume.' }
} finally {
    Pop-Location
}
