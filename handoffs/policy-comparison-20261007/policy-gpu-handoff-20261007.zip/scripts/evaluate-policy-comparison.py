"""Fresh, resumable inference on the reviewed cohort and frozen parsing policy.

OpenAI and CUDA BF16 use the same prompts, labels, parser and semantic scorer.
No training/final labels are read. Historical cached responses are not imported.
"""
from __future__ import annotations
import argparse
import asyncio
from contextlib import contextmanager
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "runtime/fpy-v6-pinned/src"))
sys.path.append(str(ROOT / ".openai-deps"))
from forecasting_assistant.application.state_reducer import apply_extraction
from forecasting_assistant.domain.models import DialogueTurn
from forecasting_assistant.domain.schema import create_initial_state, load_schema
from local_slm_lab.comparison_policy import ComparisonPolicy, source_sha256
from local_slm_lab.openai_output_methods import APIUnavailable, SpendLedger, SpendLimit, atomic_json, MODEL
from local_slm_lab.peft_provider import PeftInferenceConfig
from local_slm_lab.policy_providers import PolicyOpenAIProvider, PolicyTransformersProvider, evaluate_with_policy
from local_slm_lab.v5_eval import build_call_plan, digest, now, score_records, sha256, state_snapshot

REVISION = "15852e8c16360a2fea060d615a32b45270f8a8fc"
ADAPTER_HASHES = {
    "v5": {"adapter_model.safetensors": "e97f5e9808713a1daaaa105b3251b96f2f273834eca0e4e6da53989c652d7080",
           "adapter_config.json": "fd6f87135e9a032d0bdbeed093a379d5f3871d4796888df27dcacb032be3ac50"},
    "v6": {"adapter_model.safetensors": "e7add7b8b02d24615ed89067c7761c3985a4a6afb7c84ca2a72e3b06fd84e74d",
           "adapter_config.json": "38f60de9678324e91fa882ed86c70d09e4a39b27ae28884374ddc3e6fece15ef"},
}


@contextmanager
def process_lock(path):
    """OS releases this lock on crash; no stale PID lock needs removal."""
    with path.open("a+b") as stream:
        stream.seek(0)
        if not stream.read(1):
            stream.write(b"0"); stream.flush()
        stream.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == "nt":
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)


class Limiter:
    def __init__(self, rpm=30):
        self.delay, self.next = 60 / rpm, 0

    async def wait(self):
        loop = asyncio.get_running_loop()
        await asyncio.sleep(max(0, self.next - loop.time()))
        self.next = loop.time() + self.delay


class SynchronizedPolicyProvider(PolicyTransformersProvider):
    async def extract(self, message, state):
        self._torch.cuda.synchronize()
        try:
            return await super().extract(message, state)
        finally:
            self._torch.cuda.synchronize()


def prepare(args):
    policy = ComparisonPolicy()
    schema = load_schema()
    cases = [json.loads(line) for line in (policy.directory / "primary-natural.jsonl").read_text(encoding="utf-8").splitlines()]
    plans = {case["scenario_id"]: build_call_plan([case], schema) for case in cases}
    freeze = json.loads((policy.directory / "freeze-manifest.json").read_text(encoding="utf-8"))
    all_calls = [call for case in cases for call in plans[case["scenario_id"]]]
    if digest([[c["key"], digest(c["context"]), digest(c["expected"])] for c in all_calls]) != freeze["context_gold_sha256"]:
        raise ValueError("Reviewed call plan changed")
    openai_arm = args.arm in {"A", "B", "J", "F"}
    if openai_arm and args.adapter:
        raise ValueError("An OpenAI arm cannot have a LoRA adapter")
    if args.arm == "base" and args.adapter:
        raise ValueError("Stock arm must have no adapter")
    adapter = None
    if args.arm in ADAPTER_HASHES:
        if not args.adapter:
            raise ValueError("SLM v5/v6 requires --adapter")
        actual = {name: sha256(args.adapter / name) for name in ADAPTER_HASHES[args.arm]}
        if actual != ADAPTER_HASHES[args.arm]:
            raise ValueError("Adapter differs from the attested research adapter")
        adapter = actual
    protocol = {"policy_sha256": policy.fingerprint, "cases_sha256": sha256(policy.directory / "primary-natural.jsonl"),
                "context_gold_sha256": freeze["context_gold_sha256"], "runner_sha256": source_sha256(Path(__file__)),
                "base_model": "Qwen/Qwen3.5-2B", "base_revision": REVISION, "openai_model": MODEL,
                "component": "reviewed gold prior state", "rollout": "own predicted state, fixed reviewed user script",
                "one_pass_primary": True, "B_separate_retry_arm": True}
    identity = {"protocol": protocol, "protocol_fingerprint": digest(protocol), "arm": args.arm,
                "tracks": args.tracks, "adapter": adapter, "representation": "OpenAI hosted" if openai_arm else "CUDA BF16 PEFT",
                "generation": {"max_tokens": 2048 if openai_arm else 1024,
                               "reasoning": "minimal" if openai_arm else "disabled",
                               "sampling": "provider default" if openai_arm else "greedy; repetition_penalty=1; seed=42"},
                "openai_cost_cap_usd": args.max_cost_usd if openai_arm else None,
                "parser_versions": freeze["parser_dependencies"]}
    if openai_arm:
        identity["sdk_version"] = importlib.metadata.version("openai")
    return policy, schema, cases, plans, identity


def advance(state, record, policy, schema):
    """Reparse wire exactly once; never revalidate already-decoded candidates."""
    if record["prediction_valid"]:
        parsed = policy.parse(record["raw_output"], "extract")
        if not parsed.admitted:
            raise ValueError("Previously admitted record does not satisfy frozen policy")
        try:
            state = apply_extraction(state, parsed.to_model("extract"), schema, record["key"][2], record["context"]["message"])
        except Exception:
            pass  # Failed semantic/state transition preserves prior values.
    state.turns.append(DialogueTurn(turn_number=len(state.turns) + 1, user_message=record["context"]["message"]))
    return state


async def run_locked(args):
    policy, schema, cases, plans, identity = prepare(args)
    out = args.run_dir.resolve()
    manifest_path = out / "run-manifest.json"
    fingerprint = digest(identity)
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest["fingerprint"] != fingerprint:
            raise ValueError("Resume rejected: settings/source/inputs changed; use a new run directory")
    else:
        manifest = dict(identity=identity, fingerprint=fingerprint, run_id=str(uuid.uuid4()), created_at_utc=now())
        atomic_json(manifest_path, manifest)
    print(json.dumps({"prepared": True, "arm": args.arm, "scenarios": len(cases),
                      "calls_per_track": sum(map(len, plans.values())), "fingerprint": fingerprint}), flush=True)
    if args.prepare_only:
        return
    if (out / "completion.json").exists():
        print("Already complete; no inference repeated", flush=True)
        return
    paid = args.arm in {"A", "B", "J", "F"}
    client, ledger = None, None
    if paid:
        if not args.cost_approved or os.environ.get("V5_OPENAI_COST_APPROVED") != "yes":
            raise PermissionError("Paid testing requires the explicit cost flag and local approval environment")
        if not os.environ.get("OPENAI_API_KEY") or args.max_cost_usd is None:
            raise PermissionError("Set the key locally and an explicit cost cap")
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"], max_retries=0, timeout=120)
        if str(client.base_url).rstrip("/") != "https://api.openai.com/v1":
            raise ValueError("Unexpected API endpoint")
        ledger = SpendLedger(out, args.max_cost_usd)
        provider = PolicyOpenAIProvider(client, ledger, args.arm, schema, policy.schemas, policy=policy,
                                        model=MODEL, max_output_tokens=2048, limiter=Limiter())
    else:
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("This exact BF16 benchmark requires the remote CUDA GPU; no CPU/quantized substitution")
        torch.set_num_threads(4)
        config = PeftInferenceConfig(base_model="Qwen/Qwen3.5-2B", revision=REVISION,
            variant="base" if args.arm == "base" else "custom", adapter_path=args.adapter,
            device="cuda", dtype="bfloat16", max_new_tokens=1024)
        provider = SynchronizedPolicyProvider(config, schema, policy=policy)
        from huggingface_hub import try_to_load_from_cache
        weight = try_to_load_from_cache("Qwen/Qwen3.5-2B", "model.safetensors-00001-of-00001.safetensors", revision=REVISION)
        if not isinstance(weight, str) or sha256(Path(weight)) != "aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1":
            raise ValueError("Pinned base-weight checksum mismatch or cache path missing")
        # Exclude model-loading/first-generation warmup from scored latency.
        warm = next(iter(plans.values()))[:1]
        await evaluate_with_policy(provider, cases[:1], schema=schema, plan=warm)
        atomic_json(out / "runtime.json", {"torch": torch.__version__, "cuda": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(), "dtype": "bfloat16", "warmup_calls": 1,
            "processor_chat_template_sha256": provider.chat_template_sha256})
    jobs = out / "jobs"; jobs.mkdir(exist_ok=True)
    failure = None
    status = "running"
    try:
        for track in args.tracks:
            for index, case in enumerate(cases):
                path = jobs / f"{track}-{index:03d}.json"
                if path.exists():
                    job = json.loads(path.read_text(encoding="utf-8"))
                    if (job["status"] != "complete" or job["fingerprint"] != fingerprint
                            or job["scenario_id"] != case["scenario_id"] or digest(job["records"]) != job["records_sha256"]):
                        raise ValueError("Completed job is incompatible")
                    continue
                if paid:
                    provider.set_scenario(f"{manifest['run_id']}/{track}/{case['scenario_id']}")
                state = create_initial_state(schema)
                records = []
                for gold in plans[case["scenario_id"]]:
                    call = dict(gold)
                    if track == "rollout":
                        call["state"] = state.model_copy(deep=True)
                        call["context"] = {"message": gold["context"]["message"], "state": state_snapshot(state)}
                    if not paid:
                        torch.cuda.synchronize()
                    report = await evaluate_with_policy(provider, [case], schema=schema, plan=[call])
                    if not paid:
                        torch.cuda.synchronize()
                    record = report["records"][0]
                    if paid and any(entry.get("response_model") != MODEL for entry in ledger.entries.values() if entry["status"] == "complete"):
                        raise ValueError("API returned another model snapshot")
                    record.update(arm=args.arm, track=track, run_id=manifest["run_id"], representation=identity["representation"])
                    records.append(record)
                    atomic_json(path.with_suffix(".partial.json"), dict(fingerprint=fingerprint, status="partial", records=records))
                    error = (record.get("error") or {}).get("type")
                    if error in {"SpendLimit", "APIUnavailable"}:
                        raise SpendLimit("Budget exhausted") if error == "SpendLimit" else APIUnavailable("API access paused; no automatic retry")
                    if track == "rollout":
                        state = advance(state, record, policy, schema)
                atomic_json(path, {"status": "complete", "fingerprint": fingerprint, "scenario_id": case["scenario_id"],
                                   "arm": args.arm, "track": track, "records": records, "records_sha256": digest(records)})
                path.with_suffix(".partial.json").unlink(missing_ok=True)
                atomic_json(out / "status.json", {"status": "running", "completed_jobs": len(list(jobs.glob("[cr]*-[0-9][0-9][0-9].json"))),
                                                  "last_scenario": case["scenario_id"], "track": track,
                                                  "budget": ledger.summary() if ledger else None})
                print(json.dumps({"track": track, "scenario": index + 1, "of": len(cases), "budget": ledger.summary() if ledger else None}), flush=True)
        status = "complete"
    except (SpendLimit, APIUnavailable) as error:
        status, failure = "paused", type(error).__name__
    finally:
        if client:
            await client.close()
    reports = {}
    for track in args.tracks:
        files = sorted(jobs.glob(f"{track}-[0-9][0-9][0-9].json"))
        records = []
        for path in files:
            job = json.loads(path.read_text(encoding="utf-8"))
            if job["fingerprint"] != fingerprint or digest(job["records"]) != job["records_sha256"]:
                raise ValueError("Completed report records changed")
            records.extend(job["records"])
        value = {"status": "complete" if len(files) == len(cases) else "partial", "fingerprint": fingerprint,
                 "protocol_fingerprint": identity["protocol_fingerprint"], "arm": args.arm, "track": track,
                 "records": records, "metrics": score_records(records, [s.slot_id for s in schema.slots]),
                 "api_cost_usd": sum(r["usage_cost_usd"] for r in records), "metadata": manifest}
        atomic_json(out / f"{track}-report.json", value)
        reports[track] = {"calls": len(records), "nonintent": value["metrics"]["nonintent"]}
    summary = {"status": status, "failure": failure, "fingerprint": fingerprint, "finished_utc": now(),
               "reports": reports, "budget": ledger.summary() if ledger else None, "sealed_final_accessed": False}
    atomic_json(out / "status.json", summary)
    if status == "complete":
        atomic_json(out / "completion.json", summary)
    print(json.dumps(summary), flush=True)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--arm", choices=("A", "B", "J", "F", "base", "v5", "v6"), required=True)
    p.add_argument("--adapter", type=Path)
    p.add_argument("--run-dir", type=Path, required=True)
    p.add_argument("--tracks", nargs="+", choices=("component", "rollout"), default=["component", "rollout"])
    p.add_argument("--prepare-only", action="store_true")
    p.add_argument("--max-cost-usd", type=float)
    p.add_argument("--cost-approved", action="store_true")
    return p


if __name__ == "__main__":
    args = parser().parse_args()
    args.tracks = list(dict.fromkeys(args.tracks))
    args.run_dir.mkdir(parents=True, exist_ok=True)
    try:
        with process_lock(args.run_dir / "run.lock"):
            asyncio.run(run_locked(args))
    except Exception as error:
        print(json.dumps({"status": "failed_or_not_started", "error_type": type(error).__name__}), flush=True)
        raise SystemExit(1) from None
