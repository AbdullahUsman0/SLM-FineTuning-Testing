# Annotation rubric — development review 2026-10-06

Reviewer: Codex agent. Review is AFTER model predictions existed. It is not
independent human review. Read only original user turns and pinned slot definitions
when deciding changes. Do not infer gold from model responses or optimize for a model.

## Rules, fixed before a new comparison

- R1: `problem_statement` means “What must be predicted”; `target_description`
  means “Domain meaning of the target”. An explicit prediction request naming a
  meaningful target supports BOTH slots. Use the same exact target noun phrase
  for both; include modifiers that identify the target. Evidence may support
  more than one slot. Do not invent a column identifier from that phrase.
- R2: New explicit facts and replacement corrections have status `provided`.
  `confirmed` requires an explicit affirmation of an existing/proposed value;
  “change to 8 days” is a replacement, not confirmation. Keep value/status F1
  primary; report value-only accuracy separately if later desired.
- R3: A correction replaces only its named requirement, sets correction_detected
  true, and does not repeat unchanged prior state. An unresolved contradiction
  is different from an explicit replacement. None of these 32 correction turns
  leaves the new horizon unresolved.
- R4: “I do not know / not decided / leave unset” supplies no candidate value.
  It is not `dont_care`, null, or a guessed default. Emit no update here. Do not
  infer timezone, seasonality, interval levels or credentials. These unknown
  slots were unset in the prior gold state; this rubric does not define deletion
  of a previously known value, which needs separate future cases.
- R5: `frequency` is native observation cadence; `prediction_frequency` is
  forecast refresh cadence; `output_granularity` is requested output resolution.
  Require wording sufficient to distinguish them. “Forecast peak wind speed,
  every hour” does not establish native observations. Flag, do not guess.
- R6: `source_mode=upload` needs explicit upload/uploaded wording in this cohort.
  Merely naming a file format establishes file_format, not the access mode.
  File format does not reveal a filename, columns or credentials. Column names
  need explicit identifiers. No implicit “single_series” or “point” defaults.
- R7: Free-text target and unit labels use exact stated wording; no paraphrases,
  case folding, synonym/unit conversions, or financial advice is added. Preserve
  CPI index vs inflation, price vs return, spot vs futures, and raw vs adjusted.
  A derived target name does not itself request an aggregation operation.
- R8: Durations use {periods:number,unit:singular}; daily=1 day, monthly=1 month,
  quarterly=1 quarter. Do not equate calendar months/quarters with fixed day counts.
- R9: Evidence is a nonempty exact substring of the CURRENT user turn. Prior
  state and assistant text are context, not new evidence. Whole current-message
  evidence is permitted but span-specific evidence is preferred for new labels.
- R10: A task/target statement does not supply a business goal or decision.
  Those slots require an explicit purpose or action supported by the forecast.

## Scope and decisions

All 96 turns in the natural 32-scenario diagnostic were reviewed. Each initial
turn has a missing problem_statement under R1. Added that label using the existing
explicit target phrase; existing correction statuses and unknown-turn abstentions
are retained. WEATHER/03 remains ambiguous on native frequency vs output cadence:
retain its historical proposal for audit but exclude the WHOLE scenario from the
new primary cohort until separately adjudicated. Thus primary=31 scenarios/93
extraction calls, with all four domains retained. No questions are scored in this
natural cohort. No original files, training labels or final labels were changed.

The original v5 synthetic/coverage cohort is outside this label review. Its old
scores cannot be combined with this revised cohort. Broader schema coverage and
fresh independent annotations are future work, not established by these 31 cases.

## Easy explanation

“Predict daily temperature for 7 days” names the prediction problem and target.
Both problem_statement and target_description get “temperature”; frequency=1 day,
horizon=7 days. It does not establish a CSV column named temperature or a goal.
“Actually use 10 days” changes only horizon, status provided, correction true.
“I do not know the timezone” leaves timezone unset.

Roman Urdu: Dono models ka jawab aik hi rule se check hoga. Agar user temperature
predict karne ko kahe to problem aur target dono maloom hain. “10 din kar dein”
sirf horizon ki correction hai. “Timezone nahi pata” par koi value nahi banani.
Jahan “har ghantay” ka matlab data ki frequency ya output ka time dono ho sakta
hai, us case ko abhi primary score se bahar rakha hai.
