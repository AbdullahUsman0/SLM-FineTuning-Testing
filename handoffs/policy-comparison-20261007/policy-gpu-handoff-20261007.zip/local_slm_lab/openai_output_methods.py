"""OpenAI adaptations of the output-method study, with a durable spend ledger.

C's API counterpart is F. XGrammar is not available on hosted model logits.
J is an additional JSON-mode sensitivity arm, not a relabelled XGrammar arm.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter
from typing import Any

from forecasting_assistant.domain.models import ExtractorResult, QuestionOutput
from forecasting_assistant.prompts.extractor import safe_provider_value
from local_slm_lab.structured_output_providers import (
    ControlProbe, SlotProbe, V5SlotWiseTransformersProvider, _combined_trace,
    _error_code, _wire_result, openai_compatible_schema,
)
from local_slm_lab.slm_prompts import build_slm_question_input, build_slm_question_instructions
from local_slm_lab.v5_prompts import build_v5_extractor_input, build_v5_extractor_instructions
from local_slm_lab.v5_provider import strict_json_object, validate_raw_output

MODEL = "gpt-5-mini-2025-08-07"
PRICES = {"input": 0.25, "cached_input": 0.025, "output": 2.0}
PRICE_SOURCE = "https://developers.openai.com/api/docs/models/gpt-5-mini"


class SpendLimit(RuntimeError):
    pass


class APIUnavailable(RuntimeError):
    pass


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".writing")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def digest(value: Any) -> str:
    blob = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def upper_cost(payload: dict, output_limit: int) -> float:
    # UTF-8 bytes plus a generous allowance exceed ordinary text token counts.
    # This is a conservative reservation, not a tokenizer-based estimate.
    input_bound = len(json.dumps(payload, ensure_ascii=False).encode("utf-8")) + 4096
    return (input_bound * PRICES["input"] + output_limit * PRICES["output"]) / 1_000_000


def usage_record(response: Any) -> dict:
    usage = getattr(response, "usage", None)
    incoming = getattr(usage, "input_tokens", None)
    outgoing = getattr(usage, "output_tokens", None)
    cached = getattr(getattr(usage, "input_tokens_details", None), "cached_tokens", 0) or 0
    reasoning = getattr(getattr(usage, "output_tokens_details", None), "reasoning_tokens", 0) or 0
    if not isinstance(incoming, int) or not isinstance(outgoing, int):
        return {"input_tokens": incoming, "output_tokens": outgoing, "cost_usd": None}
    cached = min(max(cached, 0), incoming)
    cost = ((incoming - cached) * PRICES["input"] + cached * PRICES["cached_input"]
            + outgoing * PRICES["output"]) / 1_000_000
    return {"input_tokens": incoming, "output_tokens": outgoing, "cached_input_tokens": cached,
            "reasoning_tokens": reasoning, "cost_usd": cost}


class SpendLedger:
    """Reserve before sending; uncertain failures remain charged at the bound."""

    def __init__(self, directory: Path, limit_usd: float):
        if limit_usd <= 0:
            raise ValueError("A positive USD cap is required")
        self.directory = directory
        self.limit_usd = limit_usd
        directory.mkdir(parents=True, exist_ok=True)
        self.journal = directory / "rpc-journal.jsonl"
        self.entries: dict[str, dict] = {}
        if self.journal.exists():
            # A truncated journal must be repaired explicitly, not silently ignored.
            for line in self.journal.read_text(encoding="utf-8").splitlines():
                entry = json.loads(line)
                self.entries[entry["id"]] = entry

    @property
    def spent_or_reserved(self) -> float:
        return sum(entry.get("cost_usd") if entry.get("cost_usd") is not None else entry["reserved_usd"]
                   for entry in self.entries.values())

    def _append(self, entry: dict) -> None:
        with self.journal.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(entry, ensure_ascii=False, allow_nan=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        self.entries[entry["id"]] = entry

    def reserve(self, request_id: str, payload: dict, output_limit: int) -> dict | None:
        existing = self.entries.get(request_id)
        if existing is not None:
            if existing["status"] == "complete":
                return existing
            if existing["status"] == "reserved":
                return None  # It was reserved but never dispatched.
            # Never silently retry an uncertain timeout or a known API error.
            raise APIUnavailable("Prior request is incomplete or failed; inspect the safe journal before retrying")
        bound = upper_cost(payload, output_limit)
        if self.spent_or_reserved + bound > self.limit_usd:
            raise SpendLimit("Next request would exceed the configured study spending cap")
        self._append({"id": request_id, "status": "reserved", "reserved_usd": bound,
                      "payload_sha256": digest(payload), "cost_usd": None})
        return None

    def dispatched(self, request_id: str) -> None:
        self._append(dict(self.entries[request_id], status="dispatched"))

    def complete(self, request_id: str, value: dict) -> dict:
        entry = dict(self.entries[request_id], status="complete", **value)
        self._append(entry)
        if self.spent_or_reserved > self.limit_usd:
            raise SpendLimit("Observed usage exceeded a reservation; further requests stopped")
        return entry

    def failed(self, request_id: str, error: BaseException) -> None:
        status = getattr(error, "status_code", None)
        self._append(dict(self.entries[request_id], status="api_error", error=type(error).__name__,
                          http_status=status if isinstance(status, int) else None))

    def summary(self) -> dict:
        values = list(self.entries.values())
        return {"cap_usd": self.limit_usd, "spent_or_reserved_usd": self.spent_or_reserved,
                "observed_cost_usd": sum(e.get("cost_usd") or 0 for e in values),
                "requests_reserved": len(values), "responses_received": sum(e["status"] == "complete" for e in values),
                "uncertain_or_failed": sum(e["status"] != "complete" for e in values),
                "prices_per_million": PRICES, "price_source": PRICE_SOURCE,
                "cost_is_usage_estimate_not_invoice": True}


class OpenAIOutputProvider:
    """A/B prompted text, J JSON mode, F schema, D slot-wise prompt extraction."""
    name = "openai_output_methods_v1"

    def __init__(self, client, ledger, arm, schema, output_schemas, *, model=MODEL,
                 max_output_tokens=2048, probe_output_tokens=512, concurrency=4, limiter=None):
        if arm not in {"A", "B", "J", "D", "F"}:
            raise ValueError("C requires local logits; use F as its OpenAI counterpart")
        self.client, self.ledger, self.arm, self.schema = client, ledger, arm, schema
        self.output_schemas, self.model = output_schemas, model
        self.max_output_tokens, self.probe_output_tokens = max_output_tokens, probe_output_tokens
        self.concurrency = concurrency
        self.limiter = limiter
        self._traces = []
        self.last_drained_traces = []
        self.scenario = "unset"
        self.sequence = 0

    def set_scenario(self, identity):
        self.scenario, self.sequence = identity, 0

    def drain_traces(self):
        values, self._traces = self._traces, []
        # The shared legacy scorer intentionally strips unfamiliar trace fields.
        # Keep our known, safe API metadata for the study runner to restore.
        self.last_drained_traces = values
        return values

    @staticmethod
    def _slot_trace(attempts, result, **extra):
        trace = _combined_trace("extract", attempts, result, strategy="D", **extra)
        # Probes are separate measurements, not validation retries.
        trace.update(retry_count=0, retry_success=False,
                     first_pass_json_valid=all(t.get("raw_json_valid") is True for t in attempts),
                     first_pass_schema_valid=all(t.get("raw_schema_valid") is True for t in attempts))
        return trace

    async def _attempt(self, job, purpose, system, user, output_type, *, mode=None, probe=False):
        mode = mode or {"J": "json_object", "F": "json_schema"}.get(self.arm, "text")
        limit = self.probe_output_tokens if probe else self.max_output_tokens
        fmt = {"type": mode}
        if mode == "json_schema":
            task = "extract" if output_type is ExtractorResult else "ask"
            fmt.update(name=f"forecast_{task}", strict=True,
                       schema=openai_compatible_schema(self.output_schemas[task]))
        payload = {"model": self.model, "input": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                   "text": {"format": fmt, "verbosity": "low"}, "reasoning": {"effort": "minimal"},
                   "max_output_tokens": limit, "store": False}
        request_id = digest({"arm": self.arm, "scenario": self.scenario, "job": job,
                             "purpose": purpose, "payload": payload})
        started = perf_counter()
        prior = self.ledger.reserve(request_id, payload, limit)
        if prior is None:
            if self.limiter is not None:
                await self.limiter.wait()
            self.ledger.dispatched(request_id)
            try:
                response = await self.client.responses.create(**payload)
            except Exception as error:
                self.ledger.failed(request_id, error)
                raise APIUnavailable(f"API request failed ({type(error).__name__}); automatic retries disabled") from None
            usage = usage_record(response)
            blocks = getattr(response, "output", []) or []
            refused = any(getattr(content, "type", None) == "refusal"
                          for block in blocks for content in (getattr(block, "content", []) or []))
            prior = self.ledger.complete(request_id, {
                "raw_output": safe_provider_value(getattr(response, "output_text", "") or ""),
                "response_status": getattr(response, "status", None), "refused": refused,
                "response_model": getattr(response, "model", self.model),
                "latency_ms": (perf_counter() - started) * 1000, **usage,
            })
            replayed = False
        else:
            replayed = True
        trace = {"raw_output": prior["raw_output"], "raw_json_valid": False,
                 "raw_schema_valid": False, "parsed": False, "error": None,
                 "prompt_tokens": prior.get("input_tokens"), "completion_tokens": prior.get("output_tokens"),
                 "cached_input_tokens": prior.get("cached_input_tokens", 0), "reasoning_tokens": prior.get("reasoning_tokens", 0),
                 "cost_usd": prior.get("cost_usd"), "latency_ms": prior["latency_ms"],
                 "response_status": prior["response_status"], "refused": prior["refused"],
                 "hit_generation_limit": prior["response_status"] == "incomplete",
                 "request_id": request_id, "replayed_from_journal": replayed}
        result = None
        try:
            if prior["response_status"] != "completed" or prior["refused"]:
                raise ValueError("Incomplete or refused response")
            parsed = strict_json_object(prior["raw_output"])
            trace["raw_json_valid"] = True
            if output_type in {ExtractorResult, QuestionOutput}:
                result = validate_raw_output(parsed, output_type)
            else:
                if set(parsed) != set(output_type.model_fields):
                    raise ValueError("Output keys do not match probe contract")
                result = output_type.model_validate(parsed)
            trace.update(raw_schema_valid=True, parsed=True)
        except Exception as error:
            trace["error"] = _error_code(error)
        return result, trace

    async def _structured(self, operation, system, user, output_type):
        self.sequence += 1
        first, trace = await self._attempt(self.sequence, "first", system, user, output_type)
        attempts = [trace]
        result = first
        if self.arm == "B" and first is None and not trace["refused"] and trace["response_status"] == "completed":
            repair = (user + "\n\nVALIDATION_RETRY (one attempt only):\n"
                      + f"The previous response failed with code {trace['error']}. "
                      + "Return a corrected JSON object only. Preserve facts from current_message and do not add new facts.\n"
                      + "previous_response=" + json.dumps(trace["raw_output"], ensure_ascii=False))
            result, second = await self._attempt(self.sequence, "repair", system, repair, output_type)
            attempts.append(second)
        self._traces.append(_combined_trace(operation, attempts, result,
            constraint_backend={"J": "openai_json_mode", "F": "openai_json_schema"}.get(self.arm),
            strategy=self.arm, cost_usd=sum(t.get("cost_usd") or 0 for t in attempts)))
        if result is None:
            raise RuntimeError("Output contract failed; retained raw attempts")
        return result

    async def extract(self, message, state):
        shared = build_v5_extractor_input(message, state, self.schema)
        if self.arm != "D":
            return await self._structured("extract", build_v5_extractor_instructions(), shared, ExtractorResult)
        self.sequence += 1
        control, control_trace = await self._attempt(self.sequence, "control", V5SlotWiseTransformersProvider.CONTROL_SYSTEM,
                                                     shared, ControlProbe, mode="text", probe=True)
        attempts = [control_trace]
        if control is None:
            self._traces.append(self._slot_trace(attempts, None))
            raise RuntimeError("Control probe failed")
        semaphore = asyncio.Semaphore(self.concurrency)
        async def probe(definition):
            payload = json.dumps({"slot": {"slot_id": definition.slot_id, "description": definition.description,
                                           "allowed_values": list(definition.allowed_values)},
                                  "v5_context": json.loads(shared)}, ensure_ascii=False, sort_keys=True)
            async with semaphore:
                result, trace = await self._attempt(self.sequence, definition.slot_id,
                    V5SlotWiseTransformersProvider.SLOT_SYSTEM, payload, SlotProbe, mode="text", probe=True)
            trace["slot_id"] = definition.slot_id
            return result, trace
        values = await asyncio.gather(*(probe(d) for d in self.schema.slots if d.slot_id != "intent"),
                                      return_exceptions=True)
        fatal = next((value for value in values if isinstance(value, BaseException)), None)
        attempts.extend(trace for value in values if not isinstance(value, BaseException) for _, trace in [value])
        if fatal:
            self._traces.append(self._slot_trace(attempts, None))
            raise fatal
        if any(value is None for value, _ in values):
            self._traces.append(self._slot_trace(attempts, None))
            raise RuntimeError("At least one slot probe failed; partial extraction is not scored as success")
        updates = [{"slot_id": trace["slot_id"], "candidate_value": value.candidate_value, "status": value.status,
                    "confidence": value.confidence, "evidence_text": value.evidence_text}
                   for value, trace in values if value.mentioned]
        result = ExtractorResult(intent=control.intent, intent_confidence=control.intent_confidence,
                                 correction_detected=control.correction_detected,
                                 unsupported_claims=control.unsupported_claims, updates=updates)
        combined = self._slot_trace(attempts, result, probe_concurrency=self.concurrency)
        combined.update(raw_output=json.dumps(_wire_result(result), ensure_ascii=False),
                        raw_json_valid=True, raw_schema_valid=True)
        self._traces.append(combined)
        return result

    async def ask(self, request):
        return await self._structured("ask", build_slm_question_instructions(), build_slm_question_input(request), QuestionOutput)
