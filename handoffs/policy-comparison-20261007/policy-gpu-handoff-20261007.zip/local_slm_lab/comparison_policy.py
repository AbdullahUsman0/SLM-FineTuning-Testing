"""Provider-independent admission for the versioned development comparison.

This deliberately does not replace the historical v5 wire parser. A policy
directory contains the closed schemas, annotation rubric and integrity lock.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import json
from pathlib import Path

from jsonschema import Draft202012Validator
from forecasting_assistant.domain import models

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_POLICY = ROOT / "evaluation/comparison-policy-20261006"


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_sha256(path):
    """Code lock ignores only checkout newline conversion, not source edits."""
    return hashlib.sha256(Path(path).read_bytes().replace(b"\r\n", b"\n")).hexdigest()


def strict_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate_key")
            result[key] = value
        return result

    def constant(_):
        raise ValueError("nonfinite_number")

    value = json.loads(text, object_pairs_hook=pairs, parse_constant=constant)
    json.dumps(value, allow_nan=False)  # Reject exponent overflow, too.
    return value


@dataclass(frozen=True)
class Admission:
    json_valid: bool
    declared_schema_valid: bool
    admitted: bool
    predicted: dict | None
    error_code: str | None

    def to_dict(self):
        return asdict(self)

    def to_model(self, task):
        """Rehydrate already validated values WITHOUT decoding them again."""
        if not self.admitted:
            raise ValueError("Rejected admission has no model")
        if task == "ask":
            return models.QuestionOutput.model_construct(**self.predicted)
        value = dict(self.predicted)
        value["intent"] = models.Intent(value["intent"])
        value["updates"] = [models.SlotUpdate.model_construct(**dict(u, status=models.SlotStatus(u["status"])))
                            for u in value["updates"]]
        return models.ExtractorResult.model_construct(**value)


class ComparisonPolicy:
    def __init__(self, directory=DEFAULT_POLICY):
        self.directory = Path(directory)
        manifest = self.verify(self.directory)
        self.fingerprint = sha256(self.directory / "freeze-manifest.json")
        self.version = manifest["policy_version"]
        self.schemas = {
            task: json.loads((self.directory / filename).read_text(encoding="utf-8"))
            for task, filename in (("extract", "extractor-result.schema.json"),
                                   ("ask", "question-output.schema.json"))
        }
        self.validators = {task: Draft202012Validator(schema) for task, schema in self.schemas.items()}

    @staticmethod
    def verify(directory):
        directory = Path(directory)
        manifest = json.loads((directory / "freeze-manifest.json").read_text(encoding="utf-8"))
        for name, expected in manifest["files_sha256"].items():
            if sha256(directory / name) != expected:
                raise ValueError("Frozen policy/cohort artifact changed")
        for name, expected in manifest["implementation_sha256"].items():
            if source_sha256(ROOT / name) != expected:
                raise ValueError("Frozen comparison implementation changed; create a new policy version")
        package = Path(models.__file__).resolve().parents[1]
        actual = {"src/forecasting_assistant/" + p.relative_to(package).as_posix(): sha256(p)
                  for p in sorted(package.rglob("*.py"))}
        if actual != manifest["fpy_source_sha256"]:
            raise ValueError("Comparison must use the byte-identical pinned fpy source")
        from importlib.metadata import version
        for dependency, expected in manifest["parser_dependencies"].items():
            if version(dependency) != expected:
                raise ValueError("Frozen parser dependency version changed")
        return manifest

    def parse(self, raw, task, *, response_status="completed", refused=False, hit_generation_limit=False):
        if task not in self.validators:
            raise ValueError("Unsupported comparison task")
        try:
            parsed = strict_json(raw)
        except (ValueError, TypeError):
            return Admission(False, False, False, None, "invalid_json")
        valid = not any(self.validators[task].iter_errors(parsed))
        if not valid:
            return Admission(True, False, False, None, "declared_schema")
        if response_status != "completed" or refused or hit_generation_limit:
            return Admission(True, True, False, None, "incomplete_or_refused")
        if task == "extract":
            updates = parsed["updates"]
            if len({u["slot_id"] for u in updates}) != len(updates):
                return Admission(True, True, False, None, "duplicate_slot")
            for update in updates:
                try:
                    # Exactly one decoding pass. Ordinary text remains text;
                    # valid embedded JSON is decoded by the pinned Pydantic model.
                    strict_json(update["candidate_value"])
                except json.JSONDecodeError:
                    pass
                except ValueError:
                    return Admission(True, True, False, None, "unsafe_embedded_json")
        output_type = models.ExtractorResult if task == "extract" else models.QuestionOutput
        try:
            output = output_type.model_validate_json(json.dumps(parsed, allow_nan=False), strict=True)
            predicted = output.model_dump(mode="json")
            json.dumps(predicted, allow_nan=False)
        except (ValueError, TypeError):
            return Admission(True, True, False, None, "pydantic_validation")
        return Admission(True, True, True, predicted, None)
