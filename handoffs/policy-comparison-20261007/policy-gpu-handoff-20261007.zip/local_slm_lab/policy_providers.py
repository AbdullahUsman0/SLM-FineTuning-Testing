"""Opt-in adapters and scorer for the frozen policy; old experiments stay intact.

New runs MUST call evaluate_with_policy, rather than the legacy evaluate whose
wire-validity check requires a second JSON encoding even for ordinary text.
"""
from __future__ import annotations

from forecasting_assistant.domain.models import ExtractorResult
from forecasting_assistant.application.state_reducer import apply_extraction
from forecasting_assistant.prompts.extractor import safe_provider_value
from forecasting_assistant.prompts.llmrei_long import validate_question
from local_slm_lab.comparison_policy import ComparisonPolicy
from local_slm_lab.openai_output_methods import OpenAIOutputProvider
from local_slm_lab.v5_provider import V5TransformersProvider
from local_slm_lab.v5_eval import build_call_plan, evaluate, state_snapshot
from local_slm_lab.v5_eval import digest
import json


class PolicyOpenAIProvider(OpenAIOutputProvider):
    name = "openai_frozen_comparison_policy"

    def __init__(self, *args, policy=None, **kwargs):
        super().__init__(*args, **kwargs)
        if self.arm == "D":
            raise ValueError("Slot-wise probes need a separately frozen contract")
        self.policy = policy or ComparisonPolicy()
        if self.output_schemas != self.policy.schemas:
            raise ValueError("Provider output schemas differ from frozen policy")

    async def _attempt(self, job, purpose, system, user, output_type, *, mode=None, probe=False):
        if probe:
            raise ValueError("Probe schema is outside this policy")
        # Distinct journal identity prevents reusing an old-policy retry history.
        _, trace = await super()._attempt(
            {"job": job, "policy": self.policy.fingerprint}, purpose, system, user, output_type, mode=mode)
        task = "extract" if output_type is ExtractorResult else "ask"
        admission = self.policy.parse(trace["raw_output"], task, response_status=trace["response_status"],
                                      refused=trace["refused"], hit_generation_limit=trace["hit_generation_limit"])
        trace.update(legacy_wire_valid=trace["raw_schema_valid"], raw_json_valid=admission.json_valid,
                     declared_schema_valid=admission.declared_schema_valid, raw_schema_valid=admission.admitted,
                     parsed=admission.admitted, error=admission.error_code, policy_fingerprint=self.policy.fingerprint)
        return admission.to_model(task) if admission.admitted else None, trace


class PolicyTransformersProvider(V5TransformersProvider):
    name = "slm_frozen_comparison_policy"

    def __init__(self, *args, policy=None, **kwargs):
        self.policy = policy or ComparisonPolicy()
        self.last_drained_traces = []
        super().__init__(*args, **kwargs)

    def drain_traces(self):
        values = super().drain_traces()
        self.last_drained_traces = values
        return values

    def _structured(self, operation, system, user, output_type):
        trace = dict(operation=operation, raw_output=None, raw_json_valid=False, raw_schema_valid=False,
                     parsed=False, error=None, prompt_tokens=None, completion_tokens=None, recovery_applied=False,
                     policy_fingerprint=self.policy.fingerprint)
        try:
            raw, prompt_tokens, completion_tokens, hit_limit = self._generate_raw(system, user)
            trace.update(raw_output=safe_provider_value(raw), prompt_tokens=prompt_tokens,
                         completion_tokens=completion_tokens, hit_generation_limit=hit_limit)
            admission = self.policy.parse(trace["raw_output"], operation, hit_generation_limit=hit_limit)
            trace.update(raw_json_valid=admission.json_valid, declared_schema_valid=admission.declared_schema_valid,
                         raw_schema_valid=admission.admitted, parsed=admission.admitted, error=admission.error_code)
            if not admission.admitted:
                raise RuntimeError("Frozen policy rejected output")
            return admission.to_model(operation)
        except Exception:
            trace["error"] = trace["error"] or "generation_failure"
            raise RuntimeError("SLM generation or policy admission failed") from None
        finally:
            self._traces.append(trace)


async def evaluate_with_policy(provider, scenarios, *, schema, plan=None, metadata=None, on_record=None):
    """Same semantic scorer/reducer, explicitly replaced structural admission.

This performs new inference through the provider. It is not a cached re-scoring
routine. For rollouts use admission.to_model when advancing decoded state.
"""
    if not isinstance(getattr(provider, "policy", None), ComparisonPolicy):
        raise TypeError("Use a policy-bound provider")
    plan = build_call_plan(scenarios, schema) if plan is None else plan
    by_key = {tuple(call["key"]): call for call in plan}
    if len(by_key) != len(plan):
        raise ValueError("Duplicate call keys")

    def finish(record):
        call = by_key[tuple(record["key"])]
        trace = provider.last_drained_traces[-1] if provider.last_drained_traces else {}
        final = (trace.get("attempts") or [trace])[-1]
        admission = provider.policy.parse(record["raw_output"], record["task"],
                                         response_status=final.get("response_status", "completed"),
                                         refused=final.get("refused", False),
                                         hit_generation_limit=final.get("hit_generation_limit", False))
        record.update(legacy_wire_valid=record["raw_schema_valid"], raw_json_valid=admission.json_valid,
                      raw_schema_valid=admission.declared_schema_valid, parser_admitted=admission.admitted,
                      prediction_valid=record["provider_success"] and admission.admitted,
                      predicted=admission.predicted, transition_correct=False,
                      policy_version=provider.policy.version, policy_fingerprint=provider.policy.fingerprint)
        first = (trace.get("attempts") or [trace])[0]
        first_admission = provider.policy.parse(first.get("raw_output"), record["task"],
                                               response_status=first.get("response_status", "completed"),
                                               refused=first.get("refused", False),
                                               hit_generation_limit=first.get("hit_generation_limit", False))
        record.update(first_pass_json_valid=first_admission.json_valid,
                      first_pass_schema_valid=first_admission.declared_schema_valid,
                      first_pass_parser_admitted=first_admission.admitted)
        if admission.admitted:
            record["emitted"] = admission.predicted
        record.pop("predicted_after", None)
        record.pop("transition_error", None)
        if record["prediction_valid"]:
            output = admission.to_model(record["task"])
            if record["task"] == "extract":
                try:
                    after = apply_extraction(call["state"], output, schema, call["key"][2], call["context"]["message"])
                    record["predicted_after"] = state_snapshot(after)
                    record["transition_correct"] = record["predicted_after"] == call["gold_after"]
                except Exception as error:
                    record["transition_error"] = {"type": type(error).__name__}
            else:
                record["question_contract"] = bool(validate_question(output, call["request"]))
                record["question_exact_match"] = record["predicted"]["question"] == call["expected"]["question"]
        # Preserve the policy/transport audit fields stripped by the old scorer.
        record["policy_traces"] = provider.last_drained_traces
        attempts = trace.get("attempts", [])
        record["usage_cost_usd"] = sum(a.get("cost_usd") or 0 for a in attempts)
        record["timing_eligible"] = not any(a.get("replayed_from_journal") for a in attempts)
        record["reasoning_tokens"] = sum(a.get("reasoning_tokens") or 0 for a in attempts)
        record["cached_input_tokens"] = sum(a.get("cached_input_tokens") or 0 for a in attempts)
        if on_record:
            on_record(record)

    return await evaluate(provider, scenarios, schema=schema, plan=plan,
                          metadata=dict(metadata or {}, policy_version=provider.policy.version,
                                        policy_fingerprint=provider.policy.fingerprint), on_record=finish)


def matched_primary_records(left, right, *, policy, schema, track="component"):
    """Reject old policies, edited gold, missing calls and mismatched contexts."""
    if track not in {"component", "rollout"}:
        raise ValueError("Unknown comparison track")
    cases = [json.loads(line) for line in (policy.directory / "primary-natural.jsonl").read_text(encoding="utf-8").splitlines()]
    plan = build_call_plan(cases, schema)
    indexes = []
    required = {tuple(call["key"]) for call in plan}
    for records in (left, right):
        index = {tuple(record["key"]): record for record in records}
        if len(index) != len(records) or set(index) != required:
            raise ValueError("Comparison requires every primary call exactly once")
        for call in plan:
            record = index[tuple(call["key"])]
            if record.get("policy_fingerprint") != policy.fingerprint or record.get("policy_version") != policy.version:
                raise ValueError("Comparison policy differs")
            if record["task"] != call["task"] or record["scenario_id"] != call["scenario_id"]:
                raise ValueError("Record call identity differs")
            if (digest(record["expected"]) != digest(call["expected"])
                    or record["forbidden_slots"] != call["forbidden_slots"]
                    or record["cluster_id"] != call["cluster_id"]):
                raise ValueError("Comparison gold differs from frozen reviewed cohort")
            if digest(record["context"]) != record["context_sha256"]:
                raise ValueError("Record context hash invalid")
            if track == "component" and digest(record["context"]) != digest(call["context"]):
                raise ValueError("Component context differs from frozen reviewed cohort")
            if record["context"]["message"] != call["context"]["message"]:
                raise ValueError("User script changed")
        indexes.append(index)
    return [(indexes[0][tuple(call["key"])], indexes[1][tuple(call["key"])]) for call in plan]
