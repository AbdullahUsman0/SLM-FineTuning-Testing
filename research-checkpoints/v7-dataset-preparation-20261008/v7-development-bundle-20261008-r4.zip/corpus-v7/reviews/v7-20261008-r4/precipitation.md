# V7 review examples for precipitation

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261008-r4/precipitation/0000
Split: train

### t1 initial_multislot

I need forecasts of accumulated rainfall for Merlow precipitation site 1100. Measure the target in millimetres. The observations are recorded every 1 day. The forecast should extend 5 days ahead. Use the data source https://inputs.example/precipitation/1100.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated rainfall for Merlow precipitation site 1100",
    "evidence": "I need forecasts of accumulated rainfall for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated rainfall for Merlow precipitation site 1100",
    "evidence": "I need forecasts of accumulated rainfall for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Measure the target in millimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "The forecast should extend 5 days ahead."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "Use the data source https://inputs.example/precipitation/1100."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called rain_mm. The timestamp column is observed_time. Access the input through an API. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "rain_mm",
    "evidence": "The target column is called rain_mm."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 8 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "The forecast should extend 8 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Merlow precipitation site 1100.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow precipitation site 1100",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow precipitation site 1100."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261008-r4/precipitation/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/precipitation/1100. Access the input through an API. I need the next 6 hours predicted. There is one observed data point every 1 hour. The target values are in millimetres. The quantity to predict is rainfall accumulation for Merlow precipitation site 1100.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "The source is https://inputs.example/precipitation/1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "hour"
    },
    "evidence": "I need the next 6 hours predicted."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "The target values are in millimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "rainfall accumulation for Merlow precipitation site 1100",
    "evidence": "The quantity to predict is rainfall accumulation for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "rainfall accumulation for Merlow precipitation site 1100",
    "evidence": "The quantity to predict is rainfall accumulation for Merlow precipitation site 1100."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column hourly_rain_mm as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "hourly_rain_mm",
    "evidence": "Use column hourly_rain_mm as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per hour. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Return forecasts with resolution one prediction row per hour."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 9 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "I need the next 9 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of precipitation. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261008-r4/precipitation/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict snowfall depth for Merlow precipitation site 1100. Keep the measurement unit as centimetres. The native sampling interval is 1 day. The forecast horizon is 7 days. Access the input through an API. Read the observations from https://inputs.example/precipitation/1100. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "snowfall depth for Merlow precipitation site 1100",
    "evidence": "Please predict snowfall depth for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "snowfall depth for Merlow precipitation site 1100",
    "evidence": "Please predict snowfall depth for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "centimetres",
    "evidence": "Keep the measurement unit as centimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 7 days."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "Read the observations from https://inputs.example/precipitation/1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is snow_cm. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "snow_cm",
    "evidence": "The target field name is snow_cm."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 10 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 10 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 days. Read the observations from https://revised.example/precipitation/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 2 days."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/precipitation/2",
    "evidence": "Read the observations from https://revised.example/precipitation/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261008-r4/precipitation/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. My source reference is https://inputs.example/precipitation/1100. Access the input through an API. Predict a horizon of 8 weeks. Source observations arrive every 1 week. Use millimetres as the target unit. My prediction target is accumulated precipitation for Merlow precipitation site 1100.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "My source reference is https://inputs.example/precipitation/1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "week"
    },
    "evidence": "Predict a horizon of 8 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Source observations arrive every 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Use millimetres as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated precipitation for Merlow precipitation site 1100",
    "evidence": "My prediction target is accumulated precipitation for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated precipitation for Merlow precipitation site 1100",
    "evidence": "My prediction target is accumulated precipitation for Merlow precipitation site 1100."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. I do not expect a repeating seasonal pattern. Use timezone Asia/Karachi.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "Use timezone Asia/Karachi."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is observed_time. Read target values from field weekly_precip_mm.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "weekly_precip_mm",
    "evidence": "Read target values from field weekly_precip_mm."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 11 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "week"
    },
    "evidence": "Predict a horizon of 11 weeks."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261008-r4/precipitation/0004
Split: train

### t1 initial_multislot

I need forecasts of accumulated rainfall for Merlow precipitation site 1100. Measure the target in millimetres. The observations are recorded every 1 day. The forecast should extend 9 days ahead. Access the input through an API. Use the data source https://inputs.example/precipitation/1100. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated rainfall for Merlow precipitation site 1100",
    "evidence": "I need forecasts of accumulated rainfall for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated rainfall for Merlow precipitation site 1100",
    "evidence": "I need forecasts of accumulated rainfall for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Measure the target in millimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "The forecast should extend 9 days ahead."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "Use the data source https://inputs.example/precipitation/1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast should extend 9 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Yes, The forecast should extend 9 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 12 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "The forecast should extend 12 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast should extend 12 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Yes, The forecast should extend 12 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261008-r4/precipitation/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/precipitation/1100. Access the input through an API. I need the next 10 hours predicted. There is one observed data point every 1 hour. The target values are in millimetres. The quantity to predict is rainfall accumulation for Merlow precipitation site 1100.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "The source is https://inputs.example/precipitation/1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "I need the next 10 hours predicted."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "The target values are in millimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "rainfall accumulation for Merlow precipitation site 1100",
    "evidence": "The quantity to predict is rainfall accumulation for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "rainfall accumulation for Merlow precipitation site 1100",
    "evidence": "The quantity to predict is rainfall accumulation for Merlow precipitation site 1100."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column hourly_rain_mm as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "hourly_rain_mm",
    "evidence": "Use column hourly_rain_mm as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in millimetres. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "The target values are in millimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 13 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "I need the next 13 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261008-r4/precipitation/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict snowfall depth for Merlow precipitation site 1100. Keep the measurement unit as centimetres. The native sampling interval is 1 day. The forecast horizon is 11 days. Access the input through an API. Read the observations from https://inputs.example/precipitation/1100. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "snowfall depth for Merlow precipitation site 1100",
    "evidence": "Please predict snowfall depth for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "snowfall depth for Merlow precipitation site 1100",
    "evidence": "Please predict snowfall depth for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "centimetres",
    "evidence": "Keep the measurement unit as centimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 11 days."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "Read the observations from https://inputs.example/precipitation/1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is snow_cm. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "snow_cm",
    "evidence": "The target field name is snow_cm."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Aggregate observations using mean. Use column observed_time for the timestamps. Use the calendar calendar. The first forecast period begins at 2026-10-01T00:00:00+00:00. Do not use observations after 2026-09-30T00:00:00+00:00. The lead time is 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t3/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "mean",
    "evidence": "Aggregate observations using mean."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t3/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Use the calendar calendar."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t3/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "The first forecast period begins at 2026-10-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t3/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "Do not use observations after 2026-09-30T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t3/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The lead time is 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The dataset structure is hierarchical. Each series is identified by the columns site_id. The ordered hierarchy columns are region_id, site_id. Return results at the level scope. Limit the scope using these explicit filters: [{"column": "site_id", "operator": "eq", "value": "Merlow precipitation site 1100"}]. Include only these fictional areas: Fictional Merlow precipitation site 1100 region.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t4/dataset_type",
    "slot_id": "dataset_type",
    "status": "provided",
    "value": "hierarchical",
    "evidence": "The dataset structure is hierarchical."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t4/series_id_columns",
    "slot_id": "series_id_columns",
    "status": "provided",
    "value": [
      "site_id"
    ],
    "evidence": "Each series is identified by the columns site_id."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t4/hierarchy_columns",
    "slot_id": "hierarchy_columns",
    "status": "provided",
    "value": [
      "region_id",
      "site_id"
    ],
    "evidence": "The ordered hierarchy columns are region_id, site_id."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t4/aggregation_level",
    "slot_id": "aggregation_level",
    "status": "provided",
    "value": "scope",
    "evidence": "Return results at the level scope."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t4/scope_filters",
    "slot_id": "scope_filters",
    "status": "provided",
    "value": [
      {
        "column": "site_id",
        "operator": "eq",
        "value": "Merlow precipitation site 1100"
      }
    ],
    "evidence": "Limit the scope using these explicit filters: [{\"column\": \"site_id\", \"operator\": \"eq\", \"value\": \"Merlow precipitation site 1100\"}]."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t4/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Merlow precipitation site 1100 region"
    ],
    "evidence": "Include only these fictional areas: Fictional Merlow precipitation site 1100 region."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 14 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 14 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261008-r4/precipitation/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 12 weeks. Source observations arrive every 1 week. Use millimetres as the target unit. My prediction target is accumulated precipitation for Merlow precipitation site 1100. Do not substitute daily accumulated rainfall as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "week"
    },
    "evidence": "Predict a horizon of 12 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Source observations arrive every 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Use millimetres as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated precipitation for Merlow precipitation site 1100",
    "evidence": "My prediction target is accumulated precipitation for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated precipitation for Merlow precipitation site 1100",
    "evidence": "My prediction target is accumulated precipitation for Merlow precipitation site 1100."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field weekly_precip_mm.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "weekly_precip_mm",
    "evidence": "Read target values from field weekly_precip_mm."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is parquet. My source reference is https://inputs.example/precipitation/1100. Access the input through an API.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "My source reference is https://inputs.example/precipitation/1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 15 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "week"
    },
    "evidence": "Predict a horizon of 15 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261008-r4/precipitation/0008
Split: train

### t1 initial_multislot

Mujhe accumulated rainfall for Merlow precipitation site 1100 ka forecast chahiye. Target ki unit millimetres hai. Observations har 1 din record hoti hain. Forecast aglay 13 din tak chahiye. Input API ke zariye lein. Data source https://inputs.example/precipitation/1100 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated rainfall for Merlow precipitation site 1100",
    "evidence": "Mujhe accumulated rainfall for Merlow precipitation site 1100 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated rainfall for Merlow precipitation site 1100",
    "evidence": "Mujhe accumulated rainfall for Merlow precipitation site 1100 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Target ki unit millimetres hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Forecast aglay 13 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1100",
    "evidence": "Data source https://inputs.example/precipitation/1100 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein confidential synthetic records hain. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 16 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Forecast aglay 16 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261008-r4/precipitation/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 14 hours predicted. Target values millimetres mein hain. The quantity to predict is rainfall accumulation for Merlow precipitation site 1100. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "I need the next 14 hours predicted."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Target values millimetres mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "rainfall accumulation for Merlow precipitation site 1100",
    "evidence": "The quantity to predict is rainfall accumulation for Merlow precipitation site 1100."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "rainfall accumulation for Merlow precipitation site 1100",
    "evidence": "The quantity to predict is rainfall accumulation for Merlow precipitation site 1100."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Refresh the predictions every 1 day. Har 1 ghanta aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field observed_time. Column hourly_rain_mm ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "hourly_rain_mm",
    "evidence": "Column hourly_rain_mm ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "I need the next 17 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261008-r4/precipitation/0010
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. Source https://inputs.example/precipitation/1101 hai. Read the input from a database. Aglay 5 din predict karein. There is one observed data point every 1 day. Target values centimetres mein hain. The quantity to predict is snowfall depth for Norelia precipitation site 1101.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1101",
    "evidence": "Source https://inputs.example/precipitation/1101 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "Aglay 5 din predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "centimetres",
    "evidence": "Target values centimetres mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "snowfall depth for Norelia precipitation site 1101",
    "evidence": "The quantity to predict is snowfall depth for Norelia precipitation site 1101."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "snowfall depth for Norelia precipitation site 1101",
    "evidence": "The quantity to predict is snowfall depth for Norelia precipitation site 1101."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Column snow_cm ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "snow_cm",
    "evidence": "Column snow_cm ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "I need the next 8 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Norelia precipitation site 1101.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia precipitation site 1101",
    "evidence": "Our operational goal is prepare a planning reserve for Norelia precipitation site 1101."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261008-r4/precipitation/0011
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target accumulated precipitation for Norelia precipitation site 1101 hai. Measurement unit millimetres rakhein. Asli data ka sampling interval 1 hafta hai. Forecast horizon 6 hafta hai. Input database se read karein. Observations https://inputs.example/precipitation/1101 se lein. Input ko json ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated precipitation for Norelia precipitation site 1101",
    "evidence": "Prediction ka target accumulated precipitation for Norelia precipitation site 1101 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated precipitation for Norelia precipitation site 1101",
    "evidence": "Prediction ka target accumulated precipitation for Norelia precipitation site 1101 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Measurement unit millimetres rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Asli data ka sampling interval 1 hafta hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "week"
    },
    "evidence": "Forecast horizon 6 hafta hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1101",
    "evidence": "Observations https://inputs.example/precipitation/1101 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input ko json ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field weekly_precip_mm hai. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "weekly_precip_mm",
    "evidence": "Target field weekly_precip_mm hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Forecast generation har 2 din run karein. Training har 2 mahina repeat karein. Input source refresh schedule har 3 ghanta hai. Result granularity one prediction row per week banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Forecast generation har 2 din run karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training har 2 mahina repeat karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "Input source refresh schedule har 3 ghanta hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per week",
    "evidence": "Result granularity one prediction row per week banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 9 hafta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0011/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "week"
    },
    "evidence": "Forecast horizon 9 hafta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261008-r4/precipitation/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. The source is https://inputs.example/precipitation/1101. Read the input from a database. I need the next 13 days predicted. There is one observed data point every 1 day. The target values are in centimetres. The quantity to predict is snowfall depth for Norelia precipitation site 1101.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1101",
    "evidence": "The source is https://inputs.example/precipitation/1101."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "I need the next 13 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "centimetres",
    "evidence": "The target values are in centimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "snowfall depth for Norelia precipitation site 1101",
    "evidence": "The quantity to predict is snowfall depth for Norelia precipitation site 1101."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "snowfall depth for Norelia precipitation site 1101",
    "evidence": "The quantity to predict is snowfall depth for Norelia precipitation site 1101."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field measurement_time. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains no personal, confidential, or regulated data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "I need the next 16 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261008-r4/precipitation/0019
Split: train

### t1 initial_multislot

Here is what I need.  Please predict accumulated precipitation for Norelia precipitation site 1101. Keep the measurement unit as millimetres. The forecast horizon is 14 weeks. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated precipitation for Norelia precipitation site 1101",
    "evidence": "Please predict accumulated precipitation for Norelia precipitation site 1101."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated precipitation for Norelia precipitation site 1101",
    "evidence": "Please predict accumulated precipitation for Norelia precipitation site 1101."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Keep the measurement unit as millimetres."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "week"
    },
    "evidence": "The forecast horizon is 14 weeks."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The native sampling interval is 1 week. Run forecast generation once every 2 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The native sampling interval is 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target field name is weekly_precip_mm. Use column measurement_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "weekly_precip_mm",
    "evidence": "The target field name is weekly_precip_mm."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Use column measurement_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 17 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0019/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "week"
    },
    "evidence": "The forecast horizon is 17 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261008-r4/precipitation/0020
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target accumulated rainfall for Orven precipitation site 1102 hai. Measurement unit millimetres rakhein. Asli data ka sampling interval 1 din hai. Forecast horizon 5 din hai. Observations https://inputs.example/precipitation/1102 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated rainfall for Orven precipitation site 1102",
    "evidence": "Prediction ka target accumulated rainfall for Orven precipitation site 1102 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated rainfall for Orven precipitation site 1102",
    "evidence": "Prediction ka target accumulated rainfall for Orven precipitation site 1102 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Measurement unit millimetres rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "Forecast horizon 5 din hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1102",
    "evidence": "Observations https://inputs.example/precipitation/1102 se lein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field rain_mm hai. Timestamps ke liye column recorded_at use karein. Source data catalog se select karein. Input ko xlsx ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "rain_mm",
    "evidence": "Target field rain_mm hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input ko xlsx ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 8 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Forecast horizon 8 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Orven precipitation site 1102 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0020/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven precipitation site 1102",
    "evidence": "business goal ki requirement prepare a planning reserve for Orven precipitation site 1102 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261008-r4/precipitation/0022
Split: train

### t1 initial_multislot

I need forecasts of snowfall depth for Orven precipitation site 1102. Target ki unit centimetres hai. The observations are recorded every 1 day. Forecast aglay 7 din tak chahiye. Select the source from the data catalog. Data source https://inputs.example/precipitation/1102 use karein. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "snowfall depth for Orven precipitation site 1102",
    "evidence": "I need forecasts of snowfall depth for Orven precipitation site 1102."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "snowfall depth for Orven precipitation site 1102",
    "evidence": "I need forecasts of snowfall depth for Orven precipitation site 1102."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "centimetres",
    "evidence": "Target ki unit centimetres hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Forecast aglay 7 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1102",
    "evidence": "Data source https://inputs.example/precipitation/1102 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called snow_cm. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "snow_cm",
    "evidence": "The target column is called snow_cm."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 10 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "The forecast should extend 10 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The observations are recorded every 2 days. Data source https://revised.example/precipitation/22 use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 2 days."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0022/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/precipitation/22",
    "evidence": "Data source https://revised.example/precipitation/22 use karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261008-r4/precipitation/0037
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target rainfall accumulation for Pelmar precipitation site 1103 hai. Measurement unit millimetres rakhein. Asli data ka sampling interval 1 ghanta hai. Forecast horizon 12 ghanta hai. daily snowfall depth nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "rainfall accumulation for Pelmar precipitation site 1103",
    "evidence": "Prediction ka target rainfall accumulation for Pelmar precipitation site 1103 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "rainfall accumulation for Pelmar precipitation site 1103",
    "evidence": "Prediction ka target rainfall accumulation for Pelmar precipitation site 1103 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Measurement unit millimetres rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 1 ghanta hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 12 ghanta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field hourly_rain_mm hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "hourly_rain_mm",
    "evidence": "Target field hourly_rain_mm hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Main data upload karunga. Observations precipitation_archive_1103.csv se lein. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "precipitation_archive_1103.csv",
    "evidence": "Observations precipitation_archive_1103.csv se lein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 15 ghanta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0037/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 15 ghanta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261008-r4/precipitation/0038
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. Mera source reference precipitation_archive_1103.csv hai. I will upload the data. 13 din ka horizon rakhein. Source observations arrive every 1 day. Target ko centimetres mein measure karein. My prediction target is snowfall depth for Pelmar precipitation site 1103.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "precipitation_archive_1103.csv",
    "evidence": "Mera source reference precipitation_archive_1103.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "13 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "centimetres",
    "evidence": "Target ko centimetres mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "snowfall depth for Pelmar precipitation site 1103",
    "evidence": "My prediction target is snowfall depth for Pelmar precipitation site 1103."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "snowfall depth for Pelmar precipitation site 1103",
    "evidence": "My prediction target is snowfall depth for Pelmar precipitation site 1103."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The time field name is sample_date. Target values field value "net" se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "Target values field value \"net\" se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. Source mein personal ya confidential data nahi hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 16 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0038/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 16 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261008-r4/precipitation/0042
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein snowfall depth for Talven precipitation site 1104 ka outlook chahiye. Target measurements ki unit centimetres hai. Har observed record 1 din cover karta hai. Future coverage 7 din chahiye. Input API ke zariye lein. Diya hua source identifier https://inputs.example/precipitation/1104 hai. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "snowfall depth for Talven precipitation site 1104",
    "evidence": "Hamein snowfall depth for Talven precipitation site 1104 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "snowfall depth for Talven precipitation site 1104",
    "evidence": "Hamein snowfall depth for Talven precipitation site 1104 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "centimetres",
    "evidence": "Target measurements ki unit centimetres hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Future coverage 7 din chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1104",
    "evidence": "Diya hua source identifier https://inputs.example/precipitation/1104 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column snow_cm mein hai. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "snow_cm",
    "evidence": "Response variable column snow_cm mein hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 10 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Future coverage 10 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Har observed record 2 din cover karta hai. Diya hua source identifier https://revised.example/precipitation/42 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Har observed record 2 din cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0042/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/precipitation/42",
    "evidence": "Diya hua source identifier https://revised.example/precipitation/42 hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261008-r4/precipitation/0074
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein snowfall depth for Yarven precipitation site 1107 ka outlook chahiye. Target measurements ki unit centimetres hai. Har observed record 1 din cover karta hai. Future coverage 9 din chahiye. Main data upload karunga. Diya hua source identifier precipitation_archive_1107.csv hai. Input container csv use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "snowfall depth for Yarven precipitation site 1107",
    "evidence": "Hamein snowfall depth for Yarven precipitation site 1107 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "snowfall depth for Yarven precipitation site 1107",
    "evidence": "Hamein snowfall depth for Yarven precipitation site 1107 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "centimetres",
    "evidence": "Target measurements ki unit centimetres hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Future coverage 9 din chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "precipitation_archive_1107.csv",
    "evidence": "Diya hua source identifier precipitation_archive_1107.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input container csv use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Haan, Future coverage 9 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Haan, Future coverage 9 din chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 12 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Future coverage 12 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Haan, Future coverage 12 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0074/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Haan, Future coverage 12 din chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261008-r4/precipitation/0083
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format parquet hai. Mera source reference https://inputs.example/precipitation/1108 hai. Input API ke zariye lein. 8 hafta ka horizon rakhein. Source observations har 1 hafta aati hain. Target ko millimetres mein measure karein. accumulated precipitation for Merlow precipitation site 1108 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Source serialization format parquet hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1108",
    "evidence": "Mera source reference https://inputs.example/precipitation/1108 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "week"
    },
    "evidence": "8 hafta ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Source observations har 1 hafta aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Target ko millimetres mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated precipitation for Merlow precipitation site 1108",
    "evidence": "accumulated precipitation for Merlow precipitation site 1108 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated precipitation for Merlow precipitation site 1108",
    "evidence": "accumulated precipitation for Merlow precipitation site 1108 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

prediction interval levels ki requirement 80, 95 hai. forecast type ki requirement probabilistic hai. Repeating seasonal pattern expect nahi karta. Timezone UTC use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Timezone UTC use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Time field ka naam observed_time hai. Target values field weekly_precip_mm se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Time field ka naam observed_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "weekly_precip_mm",
    "evidence": "Target values field weekly_precip_mm se lein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. 11 hafta ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0083/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "week"
    },
    "evidence": "11 hafta ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261008-r4/precipitation/0104
Split: train

### t1 initial_multislot

Here is what I need.  Please predict accumulated rainfall for Orven precipitation site 1110. Measurement unit millimetres rakhein. The native sampling interval is 1 day. Forecast horizon 9 din hai. Select the source from the data catalog. Observations https://inputs.example/precipitation/1110 se lein. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated rainfall for Orven precipitation site 1110",
    "evidence": "Please predict accumulated rainfall for Orven precipitation site 1110."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated rainfall for Orven precipitation site 1110",
    "evidence": "Please predict accumulated rainfall for Orven precipitation site 1110."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Measurement unit millimetres rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Forecast horizon 9 din hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1110",
    "evidence": "Observations https://inputs.example/precipitation/1110 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast horizon is 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Yes, The forecast horizon is 9 days."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 12 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 12 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast horizon is 12 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0104/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Yes, The forecast horizon is 12 days."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261008-r4/precipitation/0105
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format xlsx hai. Mera source reference https://inputs.example/precipitation/1110 hai. Source data catalog se select karein. 10 ghanta ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko millimetres mein measure karein. rainfall accumulation for Orven precipitation site 1110 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Source serialization format xlsx hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1110",
    "evidence": "Mera source reference https://inputs.example/precipitation/1110 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "10 ghanta ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Target ko millimetres mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "rainfall accumulation for Orven precipitation site 1110",
    "evidence": "rainfall accumulation for Orven precipitation site 1110 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "rainfall accumulation for Orven precipitation site 1110",
    "evidence": "rainfall accumulation for Orven precipitation site 1110 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam recorded_at hai. Target values field hourly_rain_mm se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Time field ka naam recorded_at hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "hourly_rain_mm",
    "evidence": "Target values field hourly_rain_mm se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target ko millimetres mein measure karein. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Target ko millimetres mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. 13 ghanta ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0105/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "13 ghanta ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261008-r4/precipitation/0135
Split: train

### t1 initial_multislot

Here is what I need.  Please predict accumulated precipitation for Virelo precipitation site 1113. Measurement unit millimetres rakhein. The native sampling interval is 1 week. Forecast horizon 10 hafta hai. Read the input from a database. Observations https://inputs.example/precipitation/1113 se lein. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "accumulated precipitation for Virelo precipitation site 1113",
    "evidence": "Please predict accumulated precipitation for Virelo precipitation site 1113."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "accumulated precipitation for Virelo precipitation site 1113",
    "evidence": "Please predict accumulated precipitation for Virelo precipitation site 1113."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Measurement unit millimetres rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The native sampling interval is 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "Forecast horizon 10 hafta hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1113",
    "evidence": "Observations https://inputs.example/precipitation/1113 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is weekly_precip_mm. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "weekly_precip_mm",
    "evidence": "The target field name is weekly_precip_mm."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "week"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The native sampling interval is 1 week. Measurement unit millimetres rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The native sampling interval is 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Measurement unit millimetres rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0135/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "The forecast horizon is 13 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261008-r4/precipitation/0141
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. Mera source reference https://inputs.example/precipitation/1114 hai. Select the source from the data catalog. 6 ghanta ka horizon rakhein. Source observations arrive every 1 hour. Target ko millimetres mein measure karein. My prediction target is rainfall accumulation for Weslin precipitation site 1114.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/precipitation/1114",
    "evidence": "Mera source reference https://inputs.example/precipitation/1114 hai."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "hour"
    },
    "evidence": "6 ghanta ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millimetres",
    "evidence": "Target ko millimetres mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "rainfall accumulation for Weslin precipitation site 1114",
    "evidence": "My prediction target is rainfall accumulation for Weslin precipitation site 1114."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "rainfall accumulation for Weslin precipitation site 1114",
    "evidence": "My prediction target is rainfall accumulation for Weslin precipitation site 1114."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Target values field hourly_rain_mm se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "hourly_rain_mm",
    "evidence": "Target values field hourly_rain_mm se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Use one prediction row per hour as the output granularity. Source records har 4 ghanta update karein. Schedule model retraining every 1 month. Har 3 din naye forecasts banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Use one prediction row per hour as the output granularity."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source records har 4 ghanta update karein."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Schedule model retraining every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 9 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/precipitation/0141/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 9 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
