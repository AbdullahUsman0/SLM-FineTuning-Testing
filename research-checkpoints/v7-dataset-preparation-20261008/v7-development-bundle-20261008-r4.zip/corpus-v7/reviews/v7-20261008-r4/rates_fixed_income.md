# V7 review examples for rates_fixed_income

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## mixed core_recall

Scenario: v7-20261008-r4/rates_fixed_income/0000
Split: train

### t1 initial_multislot

I need forecasts of policy interest rate level for Merlow rates fixed income site 1900. Target ki unit percent per year hai. The observations are recorded every 1 day. Forecast aglay 13 din tak chahiye. Use the data source https://inputs.example/rates_fixed_income/1900.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "policy interest rate level for Merlow rates fixed income site 1900",
    "evidence": "I need forecasts of policy interest rate level for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "policy interest rate level for Merlow rates fixed income site 1900",
    "evidence": "I need forecasts of policy interest rate level for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ki unit percent per year hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Forecast aglay 13 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "Use the data source https://inputs.example/rates_fixed_income/1900."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called policy_rate. Timestamp column observed_time hai. Access the input through an API. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "policy_rate",
    "evidence": "The target column is called policy_rate."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 16 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "The forecast should extend 16 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Merlow rates fixed income site 1900.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow rates fixed income site 1900",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow rates fixed income site 1900."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261008-r4/rates_fixed_income/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/rates_fixed_income/1900. Access the input through an API. I need the next 14 days predicted. There is one observed data point every 1 day. The target values are in basis points. The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1900.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "The source is https://inputs.example/rates_fixed_income/1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "I need the next 14 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "The target values are in basis points."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "investment-grade credit spread for Merlow rates fixed income site 1900",
    "evidence": "The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "investment-grade credit spread for Merlow rates fixed income site 1900",
    "evidence": "The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1900."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column credit_spread_bp as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "credit_spread_bp",
    "evidence": "Use column credit_spread_bp as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per day. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Return forecasts with resolution one prediction row per day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "I need the next 17 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261008-r4/rates_fixed_income/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict bank lending growth for Merlow rates fixed income site 1900. Keep the measurement unit as percent year over year. The native sampling interval is 1 day. The forecast horizon is 15 days. Access the input through an API. Read the observations from https://inputs.example/rates_fixed_income/1900. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "bank lending growth for Merlow rates fixed income site 1900",
    "evidence": "Please predict bank lending growth for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "bank lending growth for Merlow rates fixed income site 1900",
    "evidence": "Please predict bank lending growth for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Keep the measurement unit as percent year over year."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 15 days."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "Read the observations from https://inputs.example/rates_fixed_income/1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is lending_growth. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "lending_growth",
    "evidence": "The target field name is lending_growth."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 18 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 18 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 days. Read the observations from https://revised.example/rates_fixed_income/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 2 days."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/rates_fixed_income/2",
    "evidence": "Read the observations from https://revised.example/rates_fixed_income/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261008-r4/rates_fixed_income/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. My source reference is https://inputs.example/rates_fixed_income/1900. Access the input through an API. Predict a horizon of 16 days. Source observations arrive every 1 day. Use percent per year as the target unit. My prediction target is mortgage interest rate level for Merlow rates fixed income site 1900.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "My source reference is https://inputs.example/rates_fixed_income/1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 16 days."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Use percent per year as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mortgage interest rate level for Merlow rates fixed income site 1900",
    "evidence": "My prediction target is mortgage interest rate level for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mortgage interest rate level for Merlow rates fixed income site 1900",
    "evidence": "My prediction target is mortgage interest rate level for Merlow rates fixed income site 1900."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. I do not expect a repeating seasonal pattern. Use timezone UTC.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Use timezone UTC."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is observed_time. Read target values from field mortgage_rate.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "mortgage_rate",
    "evidence": "Read target values from field mortgage_rate."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 19 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 19 days."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261008-r4/rates_fixed_income/0004
Split: train

### t1 initial_multislot

I need forecasts of 10-year government bond yield level for Merlow rates fixed income site 1900. Measure the target in percent per year. The observations are recorded every 1 day. The forecast should extend 17 days ahead. Access the input through an API. Use the data source https://inputs.example/rates_fixed_income/1900. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "10-year government bond yield level for Merlow rates fixed income site 1900",
    "evidence": "I need forecasts of 10-year government bond yield level for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "10-year government bond yield level for Merlow rates fixed income site 1900",
    "evidence": "I need forecasts of 10-year government bond yield level for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Measure the target in percent per year."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "The forecast should extend 17 days ahead."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "Use the data source https://inputs.example/rates_fixed_income/1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast should extend 17 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Yes, The forecast should extend 17 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 20 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "The forecast should extend 20 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast should extend 20 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Yes, The forecast should extend 20 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261008-r4/rates_fixed_income/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/rates_fixed_income/1900. Access the input through an API. I need the next 18 days predicted. There is one observed data point every 1 day. The target values are in basis points. The quantity to predict is 10-year minus 2-year yield spread for Merlow rates fixed income site 1900.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "The source is https://inputs.example/rates_fixed_income/1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "I need the next 18 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "The target values are in basis points."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "10-year minus 2-year yield spread for Merlow rates fixed income site 1900",
    "evidence": "The quantity to predict is 10-year minus 2-year yield spread for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "10-year minus 2-year yield spread for Merlow rates fixed income site 1900",
    "evidence": "The quantity to predict is 10-year minus 2-year yield spread for Merlow rates fixed income site 1900."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column curve_spread_bp as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "curve_spread_bp",
    "evidence": "Use column curve_spread_bp as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in basis points. There is one observed data point every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "The target values are in basis points."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 21 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "I need the next 21 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261008-r4/rates_fixed_income/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict corporate bond clean price excluding accrued interest for Merlow rates fixed income site 1900. Keep the measurement unit as percent of par. The native sampling interval is 1 day. The forecast horizon is 19 days. Access the input through an API. Read the observations from https://inputs.example/rates_fixed_income/1900. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "corporate bond clean price excluding accrued interest for Merlow rates fixed income site 1900",
    "evidence": "Please predict corporate bond clean price excluding accrued interest for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "corporate bond clean price excluding accrued interest for Merlow rates fixed income site 1900",
    "evidence": "Please predict corporate bond clean price excluding accrued interest for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of par",
    "evidence": "Keep the measurement unit as percent of par."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 19 days."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "Read the observations from https://inputs.example/rates_fixed_income/1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is clean_price. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "clean_price",
    "evidence": "The target field name is clean_price."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Detailed data lineage is not required. The required explanation level is feature_level. Human approval before modeling is not required. Our operational goal is prepare a planning reserve for Merlow rates fixed income site 1900. My role in this project is monetary and fixed-income analyst. This forecast will inform the decision set the contingency allowance for Merlow rates fixed income site 1900.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t3/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": false,
    "evidence": "Detailed data lineage is not required."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t3/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "feature_level",
    "evidence": "The required explanation level is feature_level."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Human approval before modeling is not required."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow rates fixed income site 1900",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "monetary and fixed-income analyst",
    "evidence": "My role in this project is monetary and fixed-income analyst."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Merlow rates fixed income site 1900",
    "evidence": "This forecast will inform the decision set the contingency allowance for Merlow rates fixed income site 1900."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

I will consider the result useful if it meets MAE no more than 2 percent of par for Birch synthetic rates fixed income scope 2. The target field name is clean_price. Valid target bounds are {"max": 1000000, "min": 0}. Negative target values are not valid. Aggregate observations using last. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t4/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 2 percent of par for Birch synthetic rates fixed income scope 2",
    "evidence": "I will consider the result useful if it meets MAE no more than 2 percent of par for Birch synthetic rates fixed income scope 2."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "clean_price",
    "evidence": "The target field name is clean_price."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t4/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "Valid target bounds are {\"max\": 1000000, \"min\": 0}."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "Aggregate observations using last."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 22 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 22 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261008-r4/rates_fixed_income/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 20 days. Source observations arrive every 1 day. Use percent as the target unit. My prediction target is bond total return for Merlow rates fixed income site 1900. Do not substitute policy interest rate level as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 20 days."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Use percent as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "bond total return for Merlow rates fixed income site 1900",
    "evidence": "My prediction target is bond total return for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "bond total return for Merlow rates fixed income site 1900",
    "evidence": "My prediction target is bond total return for Merlow rates fixed income site 1900."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field bond_return_pct.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "bond_return_pct",
    "evidence": "Read target values from field bond_return_pct."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is parquet. My source reference is https://inputs.example/rates_fixed_income/1900. Access the input through an API.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "My source reference is https://inputs.example/rates_fixed_income/1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 23 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 23 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261008-r4/rates_fixed_income/0008
Split: train

### t1 initial_multislot

Mujhe policy interest rate level for Merlow rates fixed income site 1900 ka forecast chahiye. Target ki unit percent per year hai. Observations har 1 din record hoti hain. Forecast aglay 4 din tak chahiye. Input API ke zariye lein. Data source https://inputs.example/rates_fixed_income/1900 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "policy interest rate level for Merlow rates fixed income site 1900",
    "evidence": "Mujhe policy interest rate level for Merlow rates fixed income site 1900 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "policy interest rate level for Merlow rates fixed income site 1900",
    "evidence": "Mujhe policy interest rate level for Merlow rates fixed income site 1900 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ki unit percent per year hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "Forecast aglay 4 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1900",
    "evidence": "Data source https://inputs.example/rates_fixed_income/1900 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein confidential synthetic records hain. Negative target values allowed hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values allowed hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 7 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Forecast aglay 7 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261008-r4/rates_fixed_income/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 5 days predicted. The target values are in basis points. The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1900. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "I need the next 5 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "The target values are in basis points."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "investment-grade credit spread for Merlow rates fixed income site 1900",
    "evidence": "The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1900."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "investment-grade credit spread for Merlow rates fixed income site 1900",
    "evidence": "The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1900."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Refresh the predictions every 1 day. There is one observed data point every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field observed_time. Use column credit_spread_bp as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "credit_spread_bp",
    "evidence": "Use column credit_spread_bp as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "I need the next 8 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of rates fixed income. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en core_recall

Scenario: v7-20261008-r4/rates_fixed_income/0030
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903. Target measurements use percent of par. Each observed record covers 1 day. The requested future coverage is 13 days. I will upload the data. The supplied source identifier is rates_fixed_income_archive_1903.csv. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903",
    "evidence": "We need an outlook for corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903",
    "evidence": "We need an outlook for corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of par",
    "evidence": "Target measurements use percent of par."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 13 days."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "rates_fixed_income_archive_1903.csv",
    "evidence": "The supplied source identifier is rates_fixed_income_archive_1903.csv."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column clean_price. The input timestamp identifier is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "clean_price",
    "evidence": "The response variable is stored in column clean_price."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The input timestamp identifier is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 16 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 16 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Pelmar rates fixed income site 1903.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0030/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Pelmar rates fixed income site 1903",
    "evidence": "Our operational goal is prepare a planning reserve for Pelmar rates fixed income site 1903."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261008-r4/rates_fixed_income/0031
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for bond total return for Pelmar rates fixed income site 1903. Target measurements ki unit percent hai. Each observed record covers 1 day. Future coverage 14 din chahiye. I will upload the data. Diya hua source identifier rates_fixed_income_archive_1903.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "bond total return for Pelmar rates fixed income site 1903",
    "evidence": "We need an outlook for bond total return for Pelmar rates fixed income site 1903."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "bond total return for Pelmar rates fixed income site 1903",
    "evidence": "We need an outlook for bond total return for Pelmar rates fixed income site 1903."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target measurements ki unit percent hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Future coverage 14 din chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "rates_fixed_income_archive_1903.csv",
    "evidence": "Diya hua source identifier rates_fixed_income_archive_1903.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column bond_return_pct. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "bond_return_pct",
    "evidence": "The response variable is stored in column bond_return_pct."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

New forecasts must be issued every 1 day. Model har 2 mahina dobara estimate karein. Source ingestion repeats every 5 hours. Prediction rows ki resolution one prediction row per day hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "New forecasts must be issued every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Model har 2 mahina dobara estimate karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Source ingestion repeats every 5 hours."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Prediction rows ki resolution one prediction row per day hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 17 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0031/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 17 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261008-r4/rates_fixed_income/0033
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein investment-grade credit spread for Pelmar rates fixed income site 1903 ka outlook chahiye. Target measurements ki unit basis points hai. Har observed record 1 din cover karta hai. Future coverage 16 din chahiye. Main data upload karunga. Diya hua source identifier rates_fixed_income_archive_1903.csv hai. Input container csv use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "investment-grade credit spread for Pelmar rates fixed income site 1903",
    "evidence": "Hamein investment-grade credit spread for Pelmar rates fixed income site 1903 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "investment-grade credit spread for Pelmar rates fixed income site 1903",
    "evidence": "Hamein investment-grade credit spread for Pelmar rates fixed income site 1903 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "Target measurements ki unit basis points hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Future coverage 16 din chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "rates_fixed_income_archive_1903.csv",
    "evidence": "Diya hua source identifier rates_fixed_income_archive_1903.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input container csv use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Saare observed times UTC timezone mein hain. Repeating seasonal pattern expect karta hoon. seasonal periods ki requirement 7, 365 hai. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Saare observed times UTC timezone mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      7,
      365
    ],
    "evidence": "seasonal periods ki requirement 7, 365 hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Response variable column credit_spread_bp mein hai. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "credit_spread_bp",
    "evidence": "Response variable column credit_spread_bp mein hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Future coverage 19 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0033/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "Future coverage 19 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261008-r4/rates_fixed_income/0038
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903. Target measurements use percent of par. Each observed record covers 1 day. The requested future coverage is 4 days. I will upload the data. The supplied source identifier is rates_fixed_income_archive_1903.csv. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903",
    "evidence": "We need an outlook for corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903",
    "evidence": "We need an outlook for corporate bond clean price excluding accrued interest for Pelmar rates fixed income site 1903."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of par",
    "evidence": "Target measurements use percent of par."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 4 days."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "rates_fixed_income_archive_1903.csv",
    "evidence": "The supplied source identifier is rates_fixed_income_archive_1903.csv."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The response variable is stored in column value "net". The input timestamp identifier is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "The response variable is stored in column value \"net\"."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The input timestamp identifier is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 7 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0038/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 7 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261008-r4/rates_fixed_income/0047
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein bond total return for Talven rates fixed income site 1904 ka outlook chahiye. Target measurements ki unit percent hai. Har observed record 1 din cover karta hai. Future coverage 20 din chahiye. policy interest rate level nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "bond total return for Talven rates fixed income site 1904",
    "evidence": "Hamein bond total return for Talven rates fixed income site 1904 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "bond total return for Talven rates fixed income site 1904",
    "evidence": "Hamein bond total return for Talven rates fixed income site 1904 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target measurements ki unit percent hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Future coverage 20 din chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column bond_return_pct mein hai. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "bond_return_pct",
    "evidence": "Response variable column bond_return_pct mein hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Input API ke zariye lein. Diya hua source identifier https://inputs.example/rates_fixed_income/1904 hai. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1904",
    "evidence": "Diya hua source identifier https://inputs.example/rates_fixed_income/1904 hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 23 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0047/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "Future coverage 23 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261008-r4/rates_fixed_income/0052
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format json hai. Mera source reference https://inputs.example/rates_fixed_income/1905 hai. Input database se read karein. 15 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko percent per year mein measure karein. 10-year government bond yield level for Virelo rates fixed income site 1905 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Source serialization format json hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1905",
    "evidence": "Mera source reference https://inputs.example/rates_fixed_income/1905 hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "15 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ko percent per year mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "10-year government bond yield level for Virelo rates fixed income site 1905",
    "evidence": "10-year government bond yield level for Virelo rates fixed income site 1905 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "10-year government bond yield level for Virelo rates fixed income site 1905",
    "evidence": "10-year government bond yield level for Virelo rates fixed income site 1905 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam measurement_time hai. Target values field yield_10y se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "yield_10y",
    "evidence": "Target values field yield_10y se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. 18 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "18 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Mera source reference https://revised.example/rates_fixed_income/52 hai. Source observations har 2 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/rates_fixed_income/52",
    "evidence": "Mera source reference https://revised.example/rates_fixed_income/52 hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0052/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Source observations har 2 din aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261008-r4/rates_fixed_income/0072
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. Source rates_fixed_income_archive_1907.csv hai. I will upload the data. Aglay 15 din predict karein. There is one observed data point every 1 day. Target values percent per year mein hain. The quantity to predict is policy interest rate level for Yarven rates fixed income site 1907.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "rates_fixed_income_archive_1907.csv",
    "evidence": "Source rates_fixed_income_archive_1907.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "Aglay 15 din predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target values percent per year mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "policy interest rate level for Yarven rates fixed income site 1907",
    "evidence": "The quantity to predict is policy interest rate level for Yarven rates fixed income site 1907."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "policy interest rate level for Yarven rates fixed income site 1907",
    "evidence": "The quantity to predict is policy interest rate level for Yarven rates fixed income site 1907."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Column policy_rate ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "policy_rate",
    "evidence": "Column policy_rate ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 18 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "I need the next 18 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The source is https://revised.example/rates_fixed_income/72. Har 2 din aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/rates_fixed_income/72",
    "evidence": "The source is https://revised.example/rates_fixed_income/72."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0072/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Har 2 din aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261008-r4/rates_fixed_income/0075
Split: train

### t1 initial_multislot

Mujhe mortgage interest rate level for Yarven rates fixed income site 1907 ka forecast chahiye. Target ki unit percent per year hai. Observations har 1 din record hoti hain. Forecast aglay 18 din tak chahiye. Main data upload karunga. Data source rates_fixed_income_archive_1907.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mortgage interest rate level for Yarven rates fixed income site 1907",
    "evidence": "Mujhe mortgage interest rate level for Yarven rates fixed income site 1907 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mortgage interest rate level for Yarven rates fixed income site 1907",
    "evidence": "Mujhe mortgage interest rate level for Yarven rates fixed income site 1907 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ki unit percent per year hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Forecast aglay 18 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "rates_fixed_income_archive_1907.csv",
    "evidence": "Data source rates_fixed_income_archive_1907.csv use karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam mortgage_rate hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "mortgage_rate",
    "evidence": "Target column ka naam mortgage_rate hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Observations har 1 din record hoti hain. Target ki unit percent per year hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ki unit percent per year hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 21 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0075/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "Forecast aglay 21 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261008-r4/rates_fixed_income/0081
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/rates_fixed_income/1908 hai. Input API ke zariye lein. Aglay 14 din predict karein. Har 1 din aik observed data point milta hai. Target values basis points mein hain. investment-grade credit spread for Merlow rates fixed income site 1908 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1908",
    "evidence": "Source https://inputs.example/rates_fixed_income/1908 hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Aglay 14 din predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "Target values basis points mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "investment-grade credit spread for Merlow rates fixed income site 1908",
    "evidence": "investment-grade credit spread for Merlow rates fixed income site 1908 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "investment-grade credit spread for Merlow rates fixed income site 1908",
    "evidence": "investment-grade credit spread for Merlow rates fixed income site 1908 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field observed_time mein hain. Column credit_spread_bp ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates field observed_time mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "credit_spread_bp",
    "evidence": "Column credit_spread_bp ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Forecast resolution one prediction row per day rakhein. Har 2 ghanta naya source update lein. Forecasting model har 1 mahina refit karein. Predictions har 3 din refresh karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Forecast resolution one prediction row per day rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghanta naya source update lein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Forecasting model har 1 mahina refit karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Predictions har 3 din refresh karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 17 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0081/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Aglay 17 din predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261008-r4/rates_fixed_income/0089
Split: train

### t1 initial_multislot

For my request,  I need the next 5 days predicted. Target values basis points mein hain. The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1908. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "I need the next 5 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "Target values basis points mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "investment-grade credit spread for Merlow rates fixed income site 1908",
    "evidence": "The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1908."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "investment-grade credit spread for Merlow rates fixed income site 1908",
    "evidence": "The quantity to predict is investment-grade credit spread for Merlow rates fixed income site 1908."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Refresh the predictions every 3 days. Har 1 din aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 3 days."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field observed_time. Column credit_spread_bp ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "credit_spread_bp",
    "evidence": "Column credit_spread_bp ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0089/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "I need the next 8 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261008-r4/rates_fixed_income/0095
Split: train

### t1 initial_multislot

Here is what I need.  Please predict bond total return for Norelia rates fixed income site 1909. Measurement unit percent rakhein. The native sampling interval is 1 day. Forecast horizon 18 din hai. Read the input from a database. Observations https://inputs.example/rates_fixed_income/1909 se lein. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "bond total return for Norelia rates fixed income site 1909",
    "evidence": "Please predict bond total return for Norelia rates fixed income site 1909."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "bond total return for Norelia rates fixed income site 1909",
    "evidence": "Please predict bond total return for Norelia rates fixed income site 1909."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Forecast horizon 18 din hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1909",
    "evidence": "Observations https://inputs.example/rates_fixed_income/1909 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is bond_return_pct. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "bond_return_pct",
    "evidence": "The target field name is bond_return_pct."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The native sampling interval is 1 day. Measurement unit percent rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 21 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0095/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 21 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261008-r4/rates_fixed_income/0107
Split: train

### t1 initial_multislot

For my request,  I need the next 20 days predicted. Har 1 din aik observed data point milta hai. The target values are in percent per year. mortgage interest rate level for Orven rates fixed income site 1910 predict karna hai. Do not substitute 10-year government bond yield level as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "I need the next 20 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "The target values are in percent per year."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mortgage interest rate level for Orven rates fixed income site 1910",
    "evidence": "mortgage interest rate level for Orven rates fixed income site 1910 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mortgage interest rate level for Orven rates fixed income site 1910",
    "evidence": "mortgage interest rate level for Orven rates fixed income site 1910 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Column mortgage_rate ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "mortgage_rate",
    "evidence": "Column mortgage_rate ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is xlsx. Source https://inputs.example/rates_fixed_income/1910 hai. Select the source from the data catalog.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1910",
    "evidence": "Source https://inputs.example/rates_fixed_income/1910 hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 23 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0107/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "I need the next 23 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261008-r4/rates_fixed_income/0113
Split: train

### t1 initial_multislot

Here is what I need.  Please predict investment-grade credit spread for Pelmar rates fixed income site 1911. Measurement unit basis points rakhein. The native sampling interval is 1 day. Forecast horizon 16 din hai. I will upload the data. Observations rates_fixed_income_archive_1911.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "investment-grade credit spread for Pelmar rates fixed income site 1911",
    "evidence": "Please predict investment-grade credit spread for Pelmar rates fixed income site 1911."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "investment-grade credit spread for Pelmar rates fixed income site 1911",
    "evidence": "Please predict investment-grade credit spread for Pelmar rates fixed income site 1911."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "Measurement unit basis points rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Forecast horizon 16 din hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "rates_fixed_income_archive_1911.csv",
    "evidence": "Observations rates_fixed_income_archive_1911.csv se lein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Interpret timestamps using Europe/London. Repeating seasonal pattern expect karta hoon. The seasonal cycles in observation periods are 7, 365. forecast type ki requirement probabilistic hai. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Interpret timestamps using Europe/London."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      7,
      365
    ],
    "evidence": "The seasonal cycles in observation periods are 7, 365."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target field name is credit_spread_bp. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "credit_spread_bp",
    "evidence": "The target field name is credit_spread_bp."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 19 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0113/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 19 days."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261008-r4/rates_fixed_income/0164
Split: train

### t1 initial_multislot

Mujhe 10-year government bond yield level for Merlow rates fixed income site 1916 ka forecast chahiye. Target ki unit percent per year hai. Observations har 1 din record hoti hain. Forecast aglay 17 din tak chahiye. Input API ke zariye lein. Data source https://inputs.example/rates_fixed_income/1916 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "10-year government bond yield level for Merlow rates fixed income site 1916",
    "evidence": "Mujhe 10-year government bond yield level for Merlow rates fixed income site 1916 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "10-year government bond yield level for Merlow rates fixed income site 1916",
    "evidence": "Mujhe 10-year government bond yield level for Merlow rates fixed income site 1916 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ki unit percent per year hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Forecast aglay 17 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1916",
    "evidence": "Data source https://inputs.example/rates_fixed_income/1916 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Haan, Forecast aglay 17 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Haan, Forecast aglay 17 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 20 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Forecast aglay 20 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Haan, Forecast aglay 20 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0164/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Haan, Forecast aglay 20 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261008-r4/rates_fixed_income/0186
Split: train

### t1 initial_multislot

Mujhe bank lending growth for Orven rates fixed income site 1918 ka forecast chahiye. Target ki unit percent year over year hai. Observations har 1 din record hoti hain. Forecast aglay 19 din tak chahiye. Source data catalog se select karein. Data source https://inputs.example/rates_fixed_income/1918 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "bank lending growth for Orven rates fixed income site 1918",
    "evidence": "Mujhe bank lending growth for Orven rates fixed income site 1918 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "bank lending growth for Orven rates fixed income site 1918",
    "evidence": "Mujhe bank lending growth for Orven rates fixed income site 1918 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Target ki unit percent year over year hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "Forecast aglay 19 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1918",
    "evidence": "Data source https://inputs.example/rates_fixed_income/1918 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam lending_growth hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "lending_growth",
    "evidence": "Target column ka naam lending_growth hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Repeating seasonal pattern expect karta hoon. Weekends aur non-business days exclude karein. holidays ki requirement synthetic reporting holiday hai. special events ki requirement [{"date": "2026-10-05", "name": "synthetic scheduled data release"}] hai. past covariates ki requirement lagged_target hai. known future covariates ki requirement announced_calendar_event hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t3/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": true,
    "evidence": "Weekends aur non-business days exclude karein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t3/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "holidays ki requirement synthetic reporting holiday hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t3/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "special events ki requirement [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t3/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "past covariates ki requirement lagged_target hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t3/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "known future covariates ki requirement announced_calendar_event hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

static features ki requirement scope_sector hai. covariate availability ki requirement [{"available": "announced before cutoff", "name": "announced_calendar_event"}] hai. external covariate sources ki requirement [{"name": "announced_calendar_event", "source": "synthetic_calendar"}] hai. forecast type ki requirement probabilistic hai. quantiles ki requirement 0.1, 0.5, 0.9 hai. scenario forecasts ki requirement [{"description": "synthetic planning sensitivity", "name": "stress"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t4/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_sector"
    ],
    "evidence": "static features ki requirement scope_sector hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t4/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "covariate availability ki requirement [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t4/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "external covariate sources ki requirement [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t4/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t4/quantiles",
    "slot_id": "quantiles",
    "status": "provided",
    "value": [
      0.1,
      0.5,
      0.9
    ],
    "evidence": "quantiles ki requirement 0.1, 0.5, 0.9 hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t4/scenario_forecasts",
    "slot_id": "scenario_forecasts",
    "status": "provided",
    "value": [
      {
        "description": "synthetic planning sensitivity",
        "name": "stress"
      }
    ],
    "evidence": "scenario forecasts ki requirement [{\"description\": \"synthetic planning sensitivity\", \"name\": \"stress\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 22 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0186/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "day"
    },
    "evidence": "Forecast aglay 22 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261008-r4/rates_fixed_income/0188
Split: train

### t1 initial_multislot

Here is what I need.  Please predict 10-year government bond yield level for Orven rates fixed income site 1918. Measurement unit percent per year rakhein. The native sampling interval is 1 day. Forecast horizon 4 din hai. Select the source from the data catalog. Observations https://inputs.example/rates_fixed_income/1918 se lein. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "10-year government bond yield level for Orven rates fixed income site 1918",
    "evidence": "Please predict 10-year government bond yield level for Orven rates fixed income site 1918."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "10-year government bond yield level for Orven rates fixed income site 1918",
    "evidence": "Please predict 10-year government bond yield level for Orven rates fixed income site 1918."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Measurement unit percent per year rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "Forecast horizon 4 din hai."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/rates_fixed_income/1918",
    "evidence": "Observations https://inputs.example/rates_fixed_income/1918 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target field name is inflation (%). Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "inflation (%)",
    "evidence": "The target field name is inflation (%)."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values allowed hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values allowed hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 7 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/rates_fixed_income/0188/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 7 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
