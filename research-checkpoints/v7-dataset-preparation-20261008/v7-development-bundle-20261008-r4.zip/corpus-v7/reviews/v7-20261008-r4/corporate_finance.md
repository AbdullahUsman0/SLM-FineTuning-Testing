# V7 review examples for corporate_finance

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261008-r4/corporate_finance/0000
Split: train

### t1 initial_multislot

I need forecasts of net operating cash flow, not revenue for Merlow corporate finance site 2700. Measure the target in thousands of USD. The observations are recorded every 1 month. The forecast should extend 4 months ahead. Use the data source https://inputs.example/corporate_finance/2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Merlow corporate finance site 2700",
    "evidence": "I need forecasts of net operating cash flow, not revenue for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Merlow corporate finance site 2700",
    "evidence": "I need forecasts of net operating cash flow, not revenue for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measure the target in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "The forecast should extend 4 months ahead."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Use the data source https://inputs.example/corporate_finance/2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called operating_cash_flow. The timestamp column is observed_time. Access the input through an API. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "The target column is called operating_cash_flow."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 7 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "The forecast should extend 7 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow corporate finance site 2700",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261008-r4/corporate_finance/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/corporate_finance/2700. Access the input through an API. I need the next 5 months predicted. There is one observed data point every 1 month. The target values are in thousands of USD. The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "The source is https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "I need the next 5 months predicted."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column recognized_revenue as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "Use column recognized_revenue as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per month. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Return forecasts with resolution one prediction row per month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "I need the next 8 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261008-r4/corporate_finance/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict operating expenditure for Merlow corporate finance site 2700. Keep the measurement unit as thousands of USD. The native sampling interval is 1 month. The forecast horizon is 6 months. Access the input through an API. Read the observations from https://inputs.example/corporate_finance/2700. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "Please predict operating expenditure for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "Please predict operating expenditure for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Keep the measurement unit as thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 6 months."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Read the observations from https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is operating_expense. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "The target field name is operating_expense."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 9 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 9 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 months. Read the observations from https://revised.example/corporate_finance/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 2 months."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/corporate_finance/2",
    "evidence": "Read the observations from https://revised.example/corporate_finance/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261008-r4/corporate_finance/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. Mera source reference https://inputs.example/corporate_finance/2700 hai. Access the input through an API. 7 mahina ka horizon rakhein. Source observations arrive every 1 month. Target ko thousands of USD mein measure karein. My prediction target is working-capital change for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Mera source reference https://inputs.example/corporate_finance/2700 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "7 mahina ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ko thousands of USD mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2700",
    "evidence": "My prediction target is working-capital change for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2700",
    "evidence": "My prediction target is working-capital change for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. forecast type ki requirement probabilistic hai. I do not expect a repeating seasonal pattern. Timezone Europe/London use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Timezone Europe/London use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is observed_time. Target values field working_capital_change se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "Target values field working_capital_change se lein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 10 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 10 months."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261008-r4/corporate_finance/0004
Split: train

### t1 initial_multislot

I need forecasts of net operating cash flow, not revenue for Merlow corporate finance site 2700. Measure the target in thousands of USD. The observations are recorded every 1 month. The forecast should extend 8 months ahead. Access the input through an API. Use the data source https://inputs.example/corporate_finance/2700. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Merlow corporate finance site 2700",
    "evidence": "I need forecasts of net operating cash flow, not revenue for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Merlow corporate finance site 2700",
    "evidence": "I need forecasts of net operating cash flow, not revenue for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measure the target in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "The forecast should extend 8 months ahead."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Use the data source https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast should extend 8 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Yes, The forecast should extend 8 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 11 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "The forecast should extend 11 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast should extend 11 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Yes, The forecast should extend 11 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261008-r4/corporate_finance/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/corporate_finance/2700. Access the input through an API. I need the next 9 months predicted. There is one observed data point every 1 month. The target values are in thousands of USD. The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "The source is https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "I need the next 9 months predicted."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column recognized_revenue as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "Use column recognized_revenue as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in thousands of USD. There is one observed data point every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 12 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "I need the next 12 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261008-r4/corporate_finance/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict operating expenditure for Merlow corporate finance site 2700. Keep the measurement unit as thousands of USD. The native sampling interval is 1 month. The forecast horizon is 10 months. Access the input through an API. Read the observations from https://inputs.example/corporate_finance/2700. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "Please predict operating expenditure for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "Please predict operating expenditure for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Keep the measurement unit as thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 10 months."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Read the observations from https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is operating_expense. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "The target field name is operating_expense."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The acceptable error threshold is {"maximum": 8, "metric": "mae"}. Generate predictions in batch mode. Run forecast generation once every 1 day. Training should be repeated every 1 month. The maximum response time is 8 seconds. Serialize the results as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t3/acceptable_error",
    "slot_id": "acceptable_error",
    "status": "provided",
    "value": {
      "maximum": 8,
      "metric": "mae"
    },
    "evidence": "The acceptable error threshold is {\"maximum\": 8, \"metric\": \"mae\"}."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t3/inference_mode",
    "slot_id": "inference_mode",
    "status": "provided",
    "value": "batch",
    "evidence": "Generate predictions in batch mode."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Training should be repeated every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t3/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "second"
    },
    "evidence": "The maximum response time is 8 seconds."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t3/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "json",
    "evidence": "Serialize the results as json."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Deliver completed forecasts to https://planning.example/corporate_finance/2. The source contains no personal, confidential, or regulated data. Enforce these privacy restrictions: synthetic data only, no external redistribution. The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed. Detailed data lineage is not required. The required explanation level is feature_level.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t4/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/corporate_finance/2",
    "evidence": "Deliver completed forecasts to https://planning.example/corporate_finance/2."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t4/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t4/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "Enforce these privacy restrictions: synthetic data only, no external redistribution."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t4/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t4/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": false,
    "evidence": "Detailed data lineage is not required."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t4/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "feature_level",
    "evidence": "The required explanation level is feature_level."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 13 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261008-r4/corporate_finance/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 11 months. Source observations arrive every 1 month. Use thousands of USD as the target unit. My prediction target is working-capital change for Merlow corporate finance site 2700. Do not substitute net operating cash flow, not revenue as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 11 months."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Use thousands of USD as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2700",
    "evidence": "My prediction target is working-capital change for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2700",
    "evidence": "My prediction target is working-capital change for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field working_capital_change.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "Read target values from field working_capital_change."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is parquet. My source reference is https://inputs.example/corporate_finance/2700. Access the input through an API.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "My source reference is https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 14 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 14 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of corporate finance. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261008-r4/corporate_finance/0008
Split: train

### t1 initial_multislot

Mujhe net operating cash flow, not revenue for Merlow corporate finance site 2700 ka forecast chahiye. Target ki unit thousands of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 12 mahina tak chahiye. Input API ke zariye lein. Data source https://inputs.example/corporate_finance/2700 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Merlow corporate finance site 2700",
    "evidence": "Mujhe net operating cash flow, not revenue for Merlow corporate finance site 2700 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Merlow corporate finance site 2700",
    "evidence": "Mujhe net operating cash flow, not revenue for Merlow corporate finance site 2700 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast aglay 12 mahina tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Data source https://inputs.example/corporate_finance/2700 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein confidential synthetic records hain. Negative target values allowed hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values allowed hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 15 mahina tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Forecast aglay 15 mahina tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261008-r4/corporate_finance/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 13 months predicted. The target values are in thousands of USD. The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "I need the next 13 months predicted."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Refresh the predictions every 1 day. There is one observed data point every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field observed_time. Use column recognized_revenue as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "Use column recognized_revenue as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "I need the next 16 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261008-r4/corporate_finance/0023
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/corporate_finance/2702. Select the source from the data catalog. I need the next 7 months predicted. There is one observed data point every 1 month. The target values are in thousands of USD. The quantity to predict is working-capital change for Orven corporate finance site 2702.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2702",
    "evidence": "The source is https://inputs.example/corporate_finance/2702."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "I need the next 7 months predicted."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Orven corporate finance site 2702",
    "evidence": "The quantity to predict is working-capital change for Orven corporate finance site 2702."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Orven corporate finance site 2702",
    "evidence": "The quantity to predict is working-capital change for Orven corporate finance site 2702."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. I do not expect a repeating seasonal pattern. Times are in Asia/Karachi.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "Times are in Asia/Karachi."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates are stored in field recorded_at. Use column working_capital_change as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "Use column working_capital_change as the target."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 10 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0023/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "I need the next 10 months predicted."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261008-r4/corporate_finance/0029
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 13 months. Target ko thousands of USD mein measure karein. My prediction target is recognized sales revenue, not cash collections for Orven corporate finance site 2702. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 13 months."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ko thousands of USD mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Orven corporate finance site 2702",
    "evidence": "My prediction target is recognized sales revenue, not cash collections for Orven corporate finance site 2702."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Orven corporate finance site 2702",
    "evidence": "My prediction target is recognized sales revenue, not cash collections for Orven corporate finance site 2702."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Produce new forecasts every 3 days. Source observations har 1 mahina aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 3 days."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The time field name is recorded_at. Target values field recognized_revenue se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "Target values field recognized_revenue se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 16 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0029/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 16 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of corporate finance. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261008-r4/corporate_finance/0040
Split: train

### t1 initial_multislot

Mujhe net operating cash flow, not revenue for Talven corporate finance site 2704 ka forecast chahiye. Target ki unit thousands of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 4 mahina tak chahiye. Data source https://inputs.example/corporate_finance/2704 use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Talven corporate finance site 2704",
    "evidence": "Mujhe net operating cash flow, not revenue for Talven corporate finance site 2704 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Talven corporate finance site 2704",
    "evidence": "Mujhe net operating cash flow, not revenue for Talven corporate finance site 2704 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "Forecast aglay 4 mahina tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2704",
    "evidence": "Data source https://inputs.example/corporate_finance/2704 use karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam operating_cash_flow hai. Timestamp column observed_time hai. Input API ke zariye lein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "Target column ka naam operating_cash_flow hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 7 mahina tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "Forecast aglay 7 mahina tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Talven corporate finance site 2704 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0040/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Talven corporate finance site 2704",
    "evidence": "business goal ki requirement prepare a planning reserve for Talven corporate finance site 2704 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261008-r4/corporate_finance/0048
Split: train

### t1 initial_multislot

I need forecasts of net operating cash flow, not revenue for Talven corporate finance site 2704. Measure the target in thousands of USD. The observations are recorded every 1 month. The forecast should extend 12 months ahead. Access the input through an API. Use the data source https://inputs.example/corporate_finance/2704. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Talven corporate finance site 2704",
    "evidence": "I need forecasts of net operating cash flow, not revenue for Talven corporate finance site 2704."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Talven corporate finance site 2704",
    "evidence": "I need forecasts of net operating cash flow, not revenue for Talven corporate finance site 2704."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measure the target in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "The forecast should extend 12 months ahead."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2704",
    "evidence": "Use the data source https://inputs.example/corporate_finance/2704."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is observed_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values are valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values are valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 15 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0048/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "The forecast should extend 15 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261008-r4/corporate_finance/0055
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target working-capital change for Virelo corporate finance site 2705 hai. Measurement unit thousands of USD rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 9 mahina hai. Input database se read karein. Observations https://inputs.example/corporate_finance/2705 se lein. Input ko json ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Virelo corporate finance site 2705",
    "evidence": "Prediction ka target working-capital change for Virelo corporate finance site 2705 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Virelo corporate finance site 2705",
    "evidence": "Prediction ka target working-capital change for Virelo corporate finance site 2705 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Forecast horizon 9 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2705",
    "evidence": "Observations https://inputs.example/corporate_finance/2705 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input ko json ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field working_capital_change hai. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "Target field working_capital_change hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Asli data ka sampling interval 1 mahina hai. Measurement unit thousands of USD rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 12 mahina hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0055/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast horizon 12 mahina hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261008-r4/corporate_finance/0067
Split: train

### t1 initial_multislot

Meri request yeh hai.  Aglay 11 mahina predict karein. Har 1 mahina aik observed data point milta hai. Target values thousands of USD mein hain. working-capital change for Weslin corporate finance site 2706 predict karna hai. net operating cash flow, not revenue nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Aglay 11 mahina predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target values thousands of USD mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Weslin corporate finance site 2706",
    "evidence": "working-capital change for Weslin corporate finance site 2706 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Weslin corporate finance site 2706",
    "evidence": "working-capital change for Weslin corporate finance site 2706 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field recorded_at mein hain. Column working_capital_change ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates field recorded_at mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "Column working_capital_change ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Diye hue data ka format xlsx hai. Source https://inputs.example/corporate_finance/2706 hai. Source data catalog se select karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Diye hue data ka format xlsx hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2706",
    "evidence": "Source https://inputs.example/corporate_finance/2706 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 14 mahina predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0067/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Aglay 14 mahina predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261008-r4/corporate_finance/0072
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source corporate_finance_archive_2707.csv hai. Main data upload karunga. Aglay 6 mahina predict karein. Har 1 mahina aik observed data point milta hai. Target values thousands of USD mein hain. net operating cash flow, not revenue for Yarven corporate finance site 2707 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "corporate_finance_archive_2707.csv",
    "evidence": "Source corporate_finance_archive_2707.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Aglay 6 mahina predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target values thousands of USD mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Yarven corporate finance site 2707",
    "evidence": "net operating cash flow, not revenue for Yarven corporate finance site 2707 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Yarven corporate finance site 2707",
    "evidence": "net operating cash flow, not revenue for Yarven corporate finance site 2707 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field sample_date mein hain. Column operating_cash_flow ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates field sample_date mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "Column operating_cash_flow ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 9 mahina predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Aglay 9 mahina predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Source https://revised.example/corporate_finance/72 hai. Har 2 mahina aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/corporate_finance/72",
    "evidence": "Source https://revised.example/corporate_finance/72 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0072/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Har 2 mahina aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261008-r4/corporate_finance/0074
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. Mera source reference corporate_finance_archive_2707.csv hai. I will upload the data. 8 mahina ka horizon rakhein. Source observations arrive every 1 month. Target ko thousands of USD mein measure karein. My prediction target is operating expenditure for Yarven corporate finance site 2707.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "corporate_finance_archive_2707.csv",
    "evidence": "Mera source reference corporate_finance_archive_2707.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "8 mahina ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ko thousands of USD mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Yarven corporate finance site 2707",
    "evidence": "My prediction target is operating expenditure for Yarven corporate finance site 2707."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Yarven corporate finance site 2707",
    "evidence": "My prediction target is operating expenditure for Yarven corporate finance site 2707."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, Predict a horizon of 8 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Yes, Predict a horizon of 8 months."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 11 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 11 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, Predict a horizon of 11 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0074/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Yes, Predict a horizon of 11 months."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of corporate finance. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261008-r4/corporate_finance/0084
Split: train

### t1 initial_multislot

Mujhe net operating cash flow, not revenue for Merlow corporate finance site 2708 ka forecast chahiye. Target ki unit thousands of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 8 mahina tak chahiye. Input API ke zariye lein. Data source https://inputs.example/corporate_finance/2708 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Merlow corporate finance site 2708",
    "evidence": "Mujhe net operating cash flow, not revenue for Merlow corporate finance site 2708 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Merlow corporate finance site 2708",
    "evidence": "Mujhe net operating cash flow, not revenue for Merlow corporate finance site 2708 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Forecast aglay 8 mahina tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2708",
    "evidence": "Data source https://inputs.example/corporate_finance/2708 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Haan, Forecast aglay 8 mahina tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Haan, Forecast aglay 8 mahina tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 11 mahina tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Forecast aglay 11 mahina tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Haan, Forecast aglay 11 mahina tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0084/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Haan, Forecast aglay 11 mahina tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261008-r4/corporate_finance/0086
Split: train

### t1 initial_multislot

Here is what I need.  Please predict operating expenditure for Merlow corporate finance site 2708. Measurement unit thousands of USD rakhein. The native sampling interval is 1 month. Forecast horizon 10 mahina hai. Access the input through an API. Observations https://inputs.example/corporate_finance/2708 se lein. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2708",
    "evidence": "Please predict operating expenditure for Merlow corporate finance site 2708."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2708",
    "evidence": "Please predict operating expenditure for Merlow corporate finance site 2708."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Forecast horizon 10 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2708",
    "evidence": "Observations https://inputs.example/corporate_finance/2708 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is operating_expense. Timestamps ke liye column observed_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "The target field name is operating_expense."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamps ke liye column observed_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Require at least 24 training observations. known regime changes ki requirement [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}] hai. For missing periods, use the policy resample. missing target policy ki requirement interpolate hai. For duplicate observations, use the policy latest. outlier policy ki requirement cap hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t3/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 24,
    "evidence": "Require at least 24 training observations."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t3/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "known regime changes ki requirement [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t3/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "resample",
    "evidence": "For missing periods, use the policy resample."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t3/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "interpolate",
    "evidence": "missing target policy ki requirement interpolate hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t3/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "latest",
    "evidence": "For duplicate observations, use the policy latest."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t3/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "outlier policy ki requirement cap hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

For invalid values, use the policy flag. minimum coverage ki requirement 86 hai. I expect a repeating seasonal pattern. Weekends aur non-business days exclude na karein. Use these fictional holiday calendars: synthetic reporting holiday. special events ki requirement [{"date": "2026-10-05", "name": "synthetic scheduled data release"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t4/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "flag",
    "evidence": "For invalid values, use the policy flag."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t4/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "minimum coverage ki requirement 86 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t4/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t4/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Weekends aur non-business days exclude na karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t4/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "Use these fictional holiday calendars: synthetic reporting holiday."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t4/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "special events ki requirement [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0086/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 13 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261008-r4/corporate_finance/0095
Split: train

### t1 initial_multislot

Here is what I need.  Please predict working-capital change for Norelia corporate finance site 2709. Measurement unit thousands of USD rakhein. The native sampling interval is 1 month. Forecast horizon 9 mahina hai. Read the input from a database. Observations https://inputs.example/corporate_finance/2709 se lein. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Norelia corporate finance site 2709",
    "evidence": "Please predict working-capital change for Norelia corporate finance site 2709."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Norelia corporate finance site 2709",
    "evidence": "Please predict working-capital change for Norelia corporate finance site 2709."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Forecast horizon 9 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2709",
    "evidence": "Observations https://inputs.example/corporate_finance/2709 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is working_capital_change. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "The target field name is working_capital_change."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The native sampling interval is 1 month. Measurement unit thousands of USD rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 12 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0095/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 12 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261008-r4/corporate_finance/0146
Split: train

### t1 initial_multislot

Mujhe operating expenditure for Weslin corporate finance site 2714 ka forecast chahiye. Target ki unit thousands of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 10 mahina tak chahiye. Source data catalog se select karein. Data source https://inputs.example/corporate_finance/2714 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Weslin corporate finance site 2714",
    "evidence": "Mujhe operating expenditure for Weslin corporate finance site 2714 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Weslin corporate finance site 2714",
    "evidence": "Mujhe operating expenditure for Weslin corporate finance site 2714 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Forecast aglay 10 mahina tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2714",
    "evidence": "Data source https://inputs.example/corporate_finance/2714 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam operating_expense hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "Target column ka naam operating_expense hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

past covariates ki requirement lagged_target hai. known future covariates ki requirement announced_calendar_event hai. static features ki requirement scope_sector hai. covariate availability ki requirement [{"available": "announced before cutoff", "name": "announced_calendar_event"}] hai. external covariate sources ki requirement [{"name": "announced_calendar_event", "source": "synthetic_calendar"}] hai. forecast type ki requirement probabilistic hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t3/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "past covariates ki requirement lagged_target hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t3/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "known future covariates ki requirement announced_calendar_event hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t3/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_sector"
    ],
    "evidence": "static features ki requirement scope_sector hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t3/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "covariate availability ki requirement [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t3/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "external covariate sources ki requirement [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

quantiles ki requirement 0.1, 0.5, 0.9 hai. scenario forecasts ki requirement [{"description": "synthetic planning sensitivity", "name": "stress"}] hai. rounding rule ki requirement {"decimal_places": 2} hai. Output resolution one prediction row per month chahiye. primary metric ki requirement mase hai. secondary metrics ki requirement rmse, smape hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t4/quantiles",
    "slot_id": "quantiles",
    "status": "provided",
    "value": [
      0.1,
      0.5,
      0.9
    ],
    "evidence": "quantiles ki requirement 0.1, 0.5, 0.9 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t4/scenario_forecasts",
    "slot_id": "scenario_forecasts",
    "status": "provided",
    "value": [
      {
        "description": "synthetic planning sensitivity",
        "name": "stress"
      }
    ],
    "evidence": "scenario forecasts ki requirement [{\"description\": \"synthetic planning sensitivity\", \"name\": \"stress\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t4/rounding_rule",
    "slot_id": "rounding_rule",
    "status": "provided",
    "value": {
      "decimal_places": 2
    },
    "evidence": "rounding rule ki requirement {\"decimal_places\": 2} hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t4/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Output resolution one prediction row per month chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t4/primary_metric",
    "slot_id": "primary_metric",
    "status": "provided",
    "value": "mase",
    "evidence": "primary metric ki requirement mase hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t4/secondary_metrics",
    "slot_id": "secondary_metrics",
    "status": "provided",
    "value": [
      "rmse",
      "smape"
    ],
    "evidence": "secondary metrics ki requirement rmse, smape hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 13 mahina tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0146/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Forecast aglay 13 mahina tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261008-r4/corporate_finance/0147
Split: train

### t1 initial_multislot

For my request,  I need the next 11 months predicted. Har 1 mahina aik observed data point milta hai. The target values are in thousands of USD. working-capital change for Weslin corporate finance site 2714 predict karna hai. Do not substitute net operating cash flow, not revenue as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "I need the next 11 months predicted."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Weslin corporate finance site 2714",
    "evidence": "working-capital change for Weslin corporate finance site 2714 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Weslin corporate finance site 2714",
    "evidence": "working-capital change for Weslin corporate finance site 2714 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Column working_capital_change ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "Column working_capital_change ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is xlsx. Source https://inputs.example/corporate_finance/2714 hai. Select the source from the data catalog.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2714",
    "evidence": "Source https://inputs.example/corporate_finance/2714 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 14 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0147/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "I need the next 14 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261008-r4/corporate_finance/0152
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for net operating cash flow, not revenue for Yarven corporate finance site 2715. Target measurements ki unit thousands of USD hai. Each observed record covers 1 month. Future coverage 6 mahina chahiye. I will upload the data. Diya hua source identifier corporate_finance_archive_2715.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Yarven corporate finance site 2715",
    "evidence": "We need an outlook for net operating cash flow, not revenue for Yarven corporate finance site 2715."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Yarven corporate finance site 2715",
    "evidence": "We need an outlook for net operating cash flow, not revenue for Yarven corporate finance site 2715."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target measurements ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Future coverage 6 mahina chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "corporate_finance_archive_2715.csv",
    "evidence": "Diya hua source identifier corporate_finance_archive_2715.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column operating_cash_flow. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "The response variable is stored in column operating_cash_flow."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 9 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 9 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. Each observed record covers 2 months. Diya hua source identifier https://revised.example/corporate_finance/152 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Each observed record covers 2 months."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0152/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/corporate_finance/152",
    "evidence": "Diya hua source identifier https://revised.example/corporate_finance/152 hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of corporate finance. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261008-r4/corporate_finance/0161
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. Source https://inputs.example/corporate_finance/2716 hai. Access the input through an API. Aglay 5 mahina predict karein. There is one observed data point every 1 month. Target values thousands of USD mein hain. The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2716.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2716",
    "evidence": "Source https://inputs.example/corporate_finance/2716 hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "Aglay 5 mahina predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target values thousands of USD mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Merlow corporate finance site 2716",
    "evidence": "The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2716."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue, not cash collections for Merlow corporate finance site 2716",
    "evidence": "The quantity to predict is recognized sales revenue, not cash collections for Merlow corporate finance site 2716."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Column recognized_revenue ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "Column recognized_revenue ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per month. Har 2 ghanta naya source update lein. Refit the forecasting model every 1 month. Predictions har 2 din refresh karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Return forecasts with resolution one prediction row per month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghanta naya source update lein."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Predictions har 2 din refresh karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0161/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "I need the next 8 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261008-r4/corporate_finance/0180
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for net operating cash flow, not revenue for Orven corporate finance site 2718. Target measurements ki unit thousands of USD hai. Each observed record covers 1 month. Future coverage 4 mahina chahiye. The supplied source identifier is https://inputs.example/corporate_finance/2718.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Orven corporate finance site 2718",
    "evidence": "We need an outlook for net operating cash flow, not revenue for Orven corporate finance site 2718."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow, not revenue for Orven corporate finance site 2718",
    "evidence": "We need an outlook for net operating cash flow, not revenue for Orven corporate finance site 2718."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target measurements ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "Future coverage 4 mahina chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2718",
    "evidence": "The supplied source identifier is https://inputs.example/corporate_finance/2718."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column operating_cash_flow. Input timestamp identifier recorded_at hai. Select the source from the data catalog. Input container xlsx use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "The response variable is stored in column operating_cash_flow."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input container xlsx use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 7 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 7 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Orven corporate finance site 2718.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/corporate_finance/0180/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven corporate finance site 2718",
    "evidence": "Our operational goal is prepare a planning reserve for Orven corporate finance site 2718."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
