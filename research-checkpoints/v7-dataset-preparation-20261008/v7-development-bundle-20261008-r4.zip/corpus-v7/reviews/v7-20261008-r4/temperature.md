# V7 review examples for temperature

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261008-r4/temperature/0000
Split: train

### t1 initial_multislot

I need forecasts of maximum air temperature for Merlow temperature site 1000. Measure the target in degrees Celsius. The observations are recorded every 1 day. The forecast should extend 4 days ahead. I will upload the data. Use the data source temperature_archive_1000.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum air temperature for Merlow temperature site 1000",
    "evidence": "I need forecasts of maximum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum air temperature for Merlow temperature site 1000",
    "evidence": "I need forecasts of maximum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Measure the target in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "The forecast should extend 4 days ahead."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "Use the data source temperature_archive_1000.csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called tmax_c. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmax_c",
    "evidence": "The target column is called tmax_c."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 7 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "The forecast should extend 7 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Merlow temperature site 1000.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow temperature site 1000",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow temperature site 1000."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of temperature. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261008-r4/temperature/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is temperature_archive_1000.csv. I will upload the data. I need the next 5 days predicted. There is one observed data point every 1 day. The target values are in degrees Celsius. The quantity to predict is minimum air temperature for Merlow temperature site 1000.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "The source is temperature_archive_1000.csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "I need the next 5 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "The target values are in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "minimum air temperature for Merlow temperature site 1000",
    "evidence": "The quantity to predict is minimum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "minimum air temperature for Merlow temperature site 1000",
    "evidence": "The quantity to predict is minimum air temperature for Merlow temperature site 1000."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Use column tmin_c as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmin_c",
    "evidence": "Use column tmin_c as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per day. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Return forecasts with resolution one prediction row per day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "I need the next 8 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261008-r4/temperature/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict mean air temperature for Merlow temperature site 1000. Keep the measurement unit as degrees Fahrenheit. The native sampling interval is 1 day. The forecast horizon is 6 days. I will upload the data. Read the observations from temperature_archive_1000.csv. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean air temperature for Merlow temperature site 1000",
    "evidence": "Please predict mean air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean air temperature for Merlow temperature site 1000",
    "evidence": "Please predict mean air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Fahrenheit",
    "evidence": "Keep the measurement unit as degrees Fahrenheit."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 6 days."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "Read the observations from temperature_archive_1000.csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is tmean_f. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmean_f",
    "evidence": "The target field name is tmean_f."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 9 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 days. Read the observations from https://revised.example/temperature/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 2 days."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/temperature/2",
    "evidence": "Read the observations from https://revised.example/temperature/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261008-r4/temperature/0003
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format csv hai. Mera source reference temperature_archive_1000.csv hai. Main data upload karunga. 7 ghanta ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko degrees Celsius mein measure karein. air temperature for Merlow temperature site 1000 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Source serialization format csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "Mera source reference temperature_archive_1000.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "7 ghanta ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ko degrees Celsius mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "air temperature for Merlow temperature site 1000",
    "evidence": "air temperature for Merlow temperature site 1000 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "air temperature for Merlow temperature site 1000",
    "evidence": "air temperature for Merlow temperature site 1000 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

prediction interval levels ki requirement 80, 95 hai. forecast type ki requirement probabilistic hai. seasonal periods ki requirement 24, 168 hai. Repeating seasonal pattern expect karta hoon. Timezone UTC use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "seasonal periods ki requirement 24, 168 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Timezone UTC use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Time field ka naam sample_date hai. Target values field temp_c se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Time field ka naam sample_date hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "temp_c",
    "evidence": "Target values field temp_c se lein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. 10 ghanta ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "10 ghanta ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261008-r4/temperature/0004
Split: train

### t1 initial_multislot

I need forecasts of maximum air temperature for Merlow temperature site 1000. Target ki unit degrees Celsius hai. The observations are recorded every 1 day. Forecast aglay 8 din tak chahiye. I will upload the data. Data source temperature_archive_1000.csv use karein. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum air temperature for Merlow temperature site 1000",
    "evidence": "I need forecasts of maximum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum air temperature for Merlow temperature site 1000",
    "evidence": "I need forecasts of maximum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ki unit degrees Celsius hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Forecast aglay 8 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "Data source temperature_archive_1000.csv use karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast should extend 8 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Yes, The forecast should extend 8 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 11 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "The forecast should extend 11 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast should extend 11 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Yes, The forecast should extend 11 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261008-r4/temperature/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is temperature_archive_1000.csv. I will upload the data. I need the next 9 days predicted. There is one observed data point every 1 day. The target values are in degrees Celsius. The quantity to predict is minimum air temperature for Merlow temperature site 1000.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "The source is temperature_archive_1000.csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "I need the next 9 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "The target values are in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "minimum air temperature for Merlow temperature site 1000",
    "evidence": "The quantity to predict is minimum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "minimum air temperature for Merlow temperature site 1000",
    "evidence": "The quantity to predict is minimum air temperature for Merlow temperature site 1000."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Use column tmin_c as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmin_c",
    "evidence": "Use column tmin_c as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in degrees Celsius. There is one observed data point every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "The target values are in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 12 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "I need the next 12 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261008-r4/temperature/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict mean air temperature for Merlow temperature site 1000. Keep the measurement unit as degrees Fahrenheit. The native sampling interval is 1 day. The forecast horizon is 10 days. I will upload the data. Read the observations from temperature_archive_1000.csv. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean air temperature for Merlow temperature site 1000",
    "evidence": "Please predict mean air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean air temperature for Merlow temperature site 1000",
    "evidence": "Please predict mean air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Fahrenheit",
    "evidence": "Keep the measurement unit as degrees Fahrenheit."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 10 days."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "Read the observations from temperature_archive_1000.csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is tmean_f. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmean_f",
    "evidence": "The target field name is tmean_f."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Our operational goal is prepare a planning reserve for Merlow temperature site 1000. My role in this project is weather analyst. This forecast will inform the decision set the contingency allowance for Merlow temperature site 1000. I will consider the result useful if it meets MAE no more than 2 degrees Fahrenheit for Birch synthetic temperature scope 2. The target field name is tmean_f. Valid target bounds are {"max": 158, "min": -148}.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow temperature site 1000",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "weather analyst",
    "evidence": "My role in this project is weather analyst."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Merlow temperature site 1000",
    "evidence": "This forecast will inform the decision set the contingency allowance for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 2 degrees Fahrenheit for Birch synthetic temperature scope 2",
    "evidence": "I will consider the result useful if it meets MAE no more than 2 degrees Fahrenheit for Birch synthetic temperature scope 2."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmean_f",
    "evidence": "The target field name is tmean_f."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t3/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 158,
      "min": -148
    },
    "evidence": "Valid target bounds are {\"max\": 158, \"min\": -148}."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Negative target values are valid. Aggregate observations using mean. Use column sample_date for the timestamps. Use the calendar calendar. The first forecast period begins at 2026-10-01T00:00:00+00:00. Do not use observations after 2026-09-30T00:00:00+00:00.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values are valid."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "mean",
    "evidence": "Aggregate observations using mean."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Use the calendar calendar."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "The first forecast period begins at 2026-10-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t4/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "Do not use observations after 2026-09-30T00:00:00+00:00."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 13 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261008-r4/temperature/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 11 hours. Source observations arrive every 1 hour. Use degrees Celsius as the target unit. My prediction target is air temperature for Merlow temperature site 1000. Do not substitute daily maximum air temperature as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 11 hours."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Use degrees Celsius as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "air temperature for Merlow temperature site 1000",
    "evidence": "My prediction target is air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "air temperature for Merlow temperature site 1000",
    "evidence": "My prediction target is air temperature for Merlow temperature site 1000."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field temp_c.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "temp_c",
    "evidence": "Read target values from field temp_c."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is csv. My source reference is temperature_archive_1000.csv. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "My source reference is temperature_archive_1000.csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 14 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 14 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261008-r4/temperature/0008
Split: train

### t1 initial_multislot

I need forecasts of maximum air temperature for Merlow temperature site 1000. Measure the target in degrees Celsius. The observations are recorded every 1 day. The forecast should extend 12 days ahead. I will upload the data. Use the data source temperature_archive_1000.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum air temperature for Merlow temperature site 1000",
    "evidence": "I need forecasts of maximum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum air temperature for Merlow temperature site 1000",
    "evidence": "I need forecasts of maximum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Measure the target in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "The forecast should extend 12 days ahead."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1000.csv",
    "evidence": "Use the data source temperature_archive_1000.csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values are valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values are valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 15 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "The forecast should extend 15 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261008-r4/temperature/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 13 days predicted. The target values are in degrees Celsius. The quantity to predict is minimum air temperature for Merlow temperature site 1000. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "I need the next 13 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "The target values are in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "minimum air temperature for Merlow temperature site 1000",
    "evidence": "The quantity to predict is minimum air temperature for Merlow temperature site 1000."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "minimum air temperature for Merlow temperature site 1000",
    "evidence": "The quantity to predict is minimum air temperature for Merlow temperature site 1000."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Refresh the predictions every 1 day. There is one observed data point every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field sample_date. Use column tmin_c as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmin_c",
    "evidence": "Use column tmin_c as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "I need the next 16 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261008-r4/temperature/0013
Split: train

### t1 initial_multislot

I need forecasts of minimum air temperature for Norelia temperature site 1001. Measure the target in degrees Celsius. The observations are recorded every 1 day. The forecast should extend 7 days ahead. Access the input through an API. Use the data source https://inputs.example/temperature/1001. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "minimum air temperature for Norelia temperature site 1001",
    "evidence": "I need forecasts of minimum air temperature for Norelia temperature site 1001."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "minimum air temperature for Norelia temperature site 1001",
    "evidence": "I need forecasts of minimum air temperature for Norelia temperature site 1001."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Measure the target in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "The forecast should extend 7 days ahead."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1001",
    "evidence": "Use the data source https://inputs.example/temperature/1001."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

The timestamp timezone is Asia/Karachi. I do not expect a repeating seasonal pattern. The requested forecast output type is probabilistic. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "The timestamp timezone is Asia/Karachi."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target column is called tmin_c. The timestamp column is observed_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmin_c",
    "evidence": "The target column is called tmin_c."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 10 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "The forecast should extend 10 days ahead."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261008-r4/temperature/0014
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/temperature/1001. Access the input through an API. I need the next 8 days predicted. There is one observed data point every 1 day. The target values are in degrees Fahrenheit. The quantity to predict is mean air temperature for Norelia temperature site 1001.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1001",
    "evidence": "The source is https://inputs.example/temperature/1001."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "I need the next 8 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Fahrenheit",
    "evidence": "The target values are in degrees Fahrenheit."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean air temperature for Norelia temperature site 1001",
    "evidence": "The quantity to predict is mean air temperature for Norelia temperature site 1001."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean air temperature for Norelia temperature site 1001",
    "evidence": "The quantity to predict is mean air temperature for Norelia temperature site 1001."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, I need the next 8 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Yes, I need the next 8 days predicted."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 11 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "I need the next 11 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, I need the next 11 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0014/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Yes, I need the next 11 days predicted."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261008-r4/temperature/0016
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format parquet hai. Mera source reference https://inputs.example/temperature/1001 hai. Input API ke zariye lein. 10 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko degrees Celsius mein measure karein. maximum air temperature for Norelia temperature site 1001 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Source serialization format parquet hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1001",
    "evidence": "Mera source reference https://inputs.example/temperature/1001 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "10 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ko degrees Celsius mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum air temperature for Norelia temperature site 1001",
    "evidence": "maximum air temperature for Norelia temperature site 1001 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum air temperature for Norelia temperature site 1001",
    "evidence": "maximum air temperature for Norelia temperature site 1001 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam observed_time hai. Target values field tmax_c se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Time field ka naam observed_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmax_c",
    "evidence": "Target values field tmax_c se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

geography ki requirement Fictional Norelia temperature site 1001 region hai. scope filters ki requirement [{"column": "site_id", "operator": "eq", "value": "Norelia temperature site 1001"}] hai. aggregation level ki requirement scope hai. hierarchy columns ki requirement region_id, site_id hai. series id columns ki requirement site_id hai. dataset type ki requirement hierarchical hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t3/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Norelia temperature site 1001 region"
    ],
    "evidence": "geography ki requirement Fictional Norelia temperature site 1001 region hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t3/scope_filters",
    "slot_id": "scope_filters",
    "status": "provided",
    "value": [
      {
        "column": "site_id",
        "operator": "eq",
        "value": "Norelia temperature site 1001"
      }
    ],
    "evidence": "scope filters ki requirement [{\"column\": \"site_id\", \"operator\": \"eq\", \"value\": \"Norelia temperature site 1001\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t3/aggregation_level",
    "slot_id": "aggregation_level",
    "status": "provided",
    "value": "scope",
    "evidence": "aggregation level ki requirement scope hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t3/hierarchy_columns",
    "slot_id": "hierarchy_columns",
    "status": "provided",
    "value": [
      "region_id",
      "site_id"
    ],
    "evidence": "hierarchy columns ki requirement region_id, site_id hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t3/series_id_columns",
    "slot_id": "series_id_columns",
    "status": "provided",
    "value": [
      "site_id"
    ],
    "evidence": "series id columns ki requirement site_id hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t3/dataset_type",
    "slot_id": "dataset_type",
    "status": "provided",
    "value": "hierarchical",
    "evidence": "dataset type ki requirement hierarchical hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

available historical coverage 81 mahina hai. history end ki requirement 2026-09-30T00:00:00+00:00 hai. history start ki requirement 2020-01-01T00:00:00+00:00 hai. Source records har 3 ghanta update karein. sheet or table ki requirement temperature_observations hai. source provider ki requirement Synthetic Weather Laboratory hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t4/expected_history_length",
    "slot_id": "expected_history_length",
    "status": "provided",
    "value": {
      "periods": 81,
      "unit": "month"
    },
    "evidence": "available historical coverage 81 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t4/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "history end ki requirement 2026-09-30T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t4/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "history start ki requirement 2020-01-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t4/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "Source records har 3 ghanta update karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t4/sheet_or_table",
    "slot_id": "sheet_or_table",
    "status": "provided",
    "value": "temperature_observations",
    "evidence": "sheet or table ki requirement temperature_observations hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t4/source_provider",
    "slot_id": "source_provider",
    "status": "provided",
    "value": "Synthetic Weather Laboratory",
    "evidence": "source provider ki requirement Synthetic Weather Laboratory hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. 13 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0016/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "13 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261008-r4/temperature/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. Source https://inputs.example/temperature/1001 hai. Access the input through an API. Aglay 12 din predict karein. There is one observed data point every 1 day. Target values degrees Fahrenheit mein hain. The quantity to predict is mean air temperature for Norelia temperature site 1001.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1001",
    "evidence": "Source https://inputs.example/temperature/1001 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Aglay 12 din predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Fahrenheit",
    "evidence": "Target values degrees Fahrenheit mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean air temperature for Norelia temperature site 1001",
    "evidence": "The quantity to predict is mean air temperature for Norelia temperature site 1001."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean air temperature for Norelia temperature site 1001",
    "evidence": "The quantity to predict is mean air temperature for Norelia temperature site 1001."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field observed_time. Column true ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Column true ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are valid. Source mein confidential synthetic records hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values are valid."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 15 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "I need the next 15 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261008-r4/temperature/0023
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. Source https://inputs.example/temperature/1002 hai. Read the input from a database. Aglay 7 ghanta predict karein. There is one observed data point every 1 hour. Target values degrees Celsius mein hain. The quantity to predict is air temperature for Orven temperature site 1002.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1002",
    "evidence": "Source https://inputs.example/temperature/1002 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "Aglay 7 ghanta predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target values degrees Celsius mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "air temperature for Orven temperature site 1002",
    "evidence": "The quantity to predict is air temperature for Orven temperature site 1002."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "air temperature for Orven temperature site 1002",
    "evidence": "The quantity to predict is air temperature for Orven temperature site 1002."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. forecast type ki requirement probabilistic hai. The seasonal cycles in observation periods are 24, 168. Repeating seasonal pattern expect karta hoon. Times are in Europe/London.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "The seasonal cycles in observation periods are 24, 168."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Times are in Europe/London."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates are stored in field measurement_time. Column temp_c ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "temp_c",
    "evidence": "Column temp_c ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 10 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0023/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "I need the next 10 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261008-r4/temperature/0029
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  13 din ka horizon rakhein. Target ko degrees Celsius mein measure karein. minimum air temperature for Orven temperature site 1002 ke liye prediction bana dein. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "13 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ko degrees Celsius mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "minimum air temperature for Orven temperature site 1002",
    "evidence": "minimum air temperature for Orven temperature site 1002 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "minimum air temperature for Orven temperature site 1002",
    "evidence": "minimum air temperature for Orven temperature site 1002 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Har 3 din naye forecasts banayein. Source observations har 1 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Time field ka naam measurement_time hai. Target values field tmin_c se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmin_c",
    "evidence": "Target values field tmin_c se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 16 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0029/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "16 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261008-r4/temperature/0040
Split: train

### t1 initial_multislot

I need forecasts of maximum air temperature for Talven temperature site 1004. Target ki unit degrees Celsius hai. The observations are recorded every 1 day. Forecast aglay 4 din tak chahiye. I will upload the data. Data source temperature_archive_1004.csv use karein. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum air temperature for Talven temperature site 1004",
    "evidence": "I need forecasts of maximum air temperature for Talven temperature site 1004."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum air temperature for Talven temperature site 1004",
    "evidence": "I need forecasts of maximum air temperature for Talven temperature site 1004."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ki unit degrees Celsius hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "Forecast aglay 4 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1004.csv",
    "evidence": "Data source temperature_archive_1004.csv use karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called tmax_c. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmax_c",
    "evidence": "The target column is called tmax_c."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 7 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "The forecast should extend 7 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Talven temperature site 1004.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0040/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Talven temperature site 1004",
    "evidence": "Our operational goal is prepare a planning reserve for Talven temperature site 1004."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261008-r4/temperature/0047
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  11 ghanta ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko degrees Celsius mein measure karein. air temperature for Talven temperature site 1004 ke liye prediction bana dein. daily maximum air temperature nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "11 ghanta ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ko degrees Celsius mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "air temperature for Talven temperature site 1004",
    "evidence": "air temperature for Talven temperature site 1004 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "air temperature for Talven temperature site 1004",
    "evidence": "air temperature for Talven temperature site 1004 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam sample_date hai. Target values field temp_c se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Time field ka naam sample_date hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "temp_c",
    "evidence": "Target values field temp_c se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Source serialization format csv hai. Mera source reference temperature_archive_1004.csv hai. Main data upload karunga.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Source serialization format csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1004.csv",
    "evidence": "Mera source reference temperature_archive_1004.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 14 ghanta ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0047/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "14 ghanta ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261008-r4/temperature/0052
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. Mera source reference https://inputs.example/temperature/1005 hai. Access the input through an API. 6 din ka horizon rakhein. Source observations arrive every 1 day. Target ko degrees Celsius mein measure karein. My prediction target is maximum air temperature for Virelo temperature site 1005.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1005",
    "evidence": "Mera source reference https://inputs.example/temperature/1005 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "6 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ko degrees Celsius mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum air temperature for Virelo temperature site 1005",
    "evidence": "My prediction target is maximum air temperature for Virelo temperature site 1005."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum air temperature for Virelo temperature site 1005",
    "evidence": "My prediction target is maximum air temperature for Virelo temperature site 1005."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Target values field tmax_c se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmax_c",
    "evidence": "Target values field tmax_c se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 9 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/temperature/52. Source observations har 2 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/temperature/52",
    "evidence": "My source reference is https://revised.example/temperature/52."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0052/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Source observations har 2 din aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261008-r4/temperature/0076
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. Source https://inputs.example/temperature/1007 hai. Select the source from the data catalog. Aglay 10 din predict karein. There is one observed data point every 1 day. Target values degrees Celsius mein hain. The quantity to predict is maximum air temperature for Yarven temperature site 1007.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1007",
    "evidence": "Source https://inputs.example/temperature/1007 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Aglay 10 din predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target values degrees Celsius mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum air temperature for Yarven temperature site 1007",
    "evidence": "The quantity to predict is maximum air temperature for Yarven temperature site 1007."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum air temperature for Yarven temperature site 1007",
    "evidence": "The quantity to predict is maximum air temperature for Yarven temperature site 1007."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Column tmax_c ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmax_c",
    "evidence": "Column tmax_c ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

For unusual values, use the policy cap. duplicate policy ki requirement reject hai. For missing target values, use the policy reject. missing timestamp policy ki requirement reject hai. The recorded structural breaks are [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}]. minimum training points ki requirement 365 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t3/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "For unusual values, use the policy cap."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t3/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "duplicate policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t3/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "For missing target values, use the policy reject."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t3/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "missing timestamp policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t3/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "The recorded structural breaks are [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}]."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t3/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 365,
    "evidence": "minimum training points ki requirement 365 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The known special events are [{"date": "2026-10-05", "name": "synthetic weather alert"}]. holidays ki requirement synthetic reporting holiday hai. Do not exclude weekends or non-business days. Repeating seasonal pattern expect karta hoon. Require non-missing coverage of at least 96 percent. invalid value policy ki requirement coerce hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t4/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic weather alert"
      }
    ],
    "evidence": "The known special events are [{\"date\": \"2026-10-05\", \"name\": \"synthetic weather alert\"}]."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t4/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "holidays ki requirement synthetic reporting holiday hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t4/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Do not exclude weekends or non-business days."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t4/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t4/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 96,
    "evidence": "Require non-missing coverage of at least 96 percent."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t4/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "coerce",
    "evidence": "invalid value policy ki requirement coerce hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 13 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0076/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "I need the next 13 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261008-r4/temperature/0094
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/temperature/1009 hai. Input API ke zariye lein. Aglay 8 din predict karein. Har 1 din aik observed data point milta hai. Target values degrees Fahrenheit mein hain. mean air temperature for Norelia temperature site 1009 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1009",
    "evidence": "Source https://inputs.example/temperature/1009 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Aglay 8 din predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Fahrenheit",
    "evidence": "Target values degrees Fahrenheit mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean air temperature for Norelia temperature site 1009",
    "evidence": "mean air temperature for Norelia temperature site 1009 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean air temperature for Norelia temperature site 1009",
    "evidence": "mean air temperature for Norelia temperature site 1009 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Haan, Aglay 8 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Haan, Aglay 8 din predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 11 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Aglay 11 din predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Haan, Aglay 11 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0094/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Haan, Aglay 11 din predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261008-r4/temperature/0109
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 13 days. Target ko degrees Celsius mein measure karein. My prediction target is minimum air temperature for Orven temperature site 1010. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 13 days."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ko degrees Celsius mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "minimum air temperature for Orven temperature site 1010",
    "evidence": "My prediction target is minimum air temperature for Orven temperature site 1010."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "minimum air temperature for Orven temperature site 1010",
    "evidence": "My prediction target is minimum air temperature for Orven temperature site 1010."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Produce new forecasts every 2 days. Source observations har 1 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 2 days."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The time field name is measurement_time. Target values field tmin_c se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmin_c",
    "evidence": "Target values field tmin_c se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 16 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0109/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 16 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261008-r4/temperature/0111
Split: train

### t1 initial_multislot

Mujhe air temperature for Pelmar temperature site 1011 ka forecast chahiye. Target ki unit degrees Celsius hai. Observations har 1 ghanta record hoti hain. Forecast aglay 5 ghanta tak chahiye. Source data catalog se select karein. Data source https://inputs.example/temperature/1011 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "air temperature for Pelmar temperature site 1011",
    "evidence": "Mujhe air temperature for Pelmar temperature site 1011 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "air temperature for Pelmar temperature site 1011",
    "evidence": "Mujhe air temperature for Pelmar temperature site 1011 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ki unit degrees Celsius hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 5 ghanta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1011",
    "evidence": "Data source https://inputs.example/temperature/1011 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam temp_c hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "temp_c",
    "evidence": "Target column ka naam temp_c hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Naya forecast har 3 din banayein. Model har 2 mahina retrain karein. Source data har 5 ghanta refresh karein. Output resolution one prediction row per hour chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Naya forecast har 3 din banayein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Model har 2 mahina retrain karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Source data har 5 ghanta refresh karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Output resolution one prediction row per hour chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 8 ghanta tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0111/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 8 ghanta tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: temperature ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261008-r4/temperature/0115
Split: train

### t1 initial_multislot

I need forecasts of air temperature for Pelmar temperature site 1011. Target ki unit degrees Celsius hai. The observations are recorded every 1 hour. Forecast aglay 9 ghanta tak chahiye. Select the source from the data catalog. Data source https://inputs.example/temperature/1011 use karein. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "air temperature for Pelmar temperature site 1011",
    "evidence": "I need forecasts of air temperature for Pelmar temperature site 1011."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "air temperature for Pelmar temperature site 1011",
    "evidence": "I need forecasts of air temperature for Pelmar temperature site 1011."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ki unit degrees Celsius hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 9 ghanta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1011",
    "evidence": "Data source https://inputs.example/temperature/1011 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called temp_c. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "temp_c",
    "evidence": "The target column is called temp_c."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The observations are recorded every 1 hour. Target ki unit degrees Celsius hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ki unit degrees Celsius hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 12 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0115/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 12 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261008-r4/temperature/0127
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 11 hours. Source observations har 1 ghanta aati hain. Use degrees Celsius as the target unit. air temperature for Talven temperature site 1012 ke liye prediction bana dein. Do not substitute daily maximum air temperature as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 11 hours."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Use degrees Celsius as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "air temperature for Talven temperature site 1012",
    "evidence": "air temperature for Talven temperature site 1012 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "air temperature for Talven temperature site 1012",
    "evidence": "air temperature for Talven temperature site 1012 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Target values field temp_c se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "temp_c",
    "evidence": "Target values field temp_c se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is csv. Mera source reference temperature_archive_1012.csv hai. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "temperature_archive_1012.csv",
    "evidence": "Mera source reference temperature_archive_1012.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 14 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0127/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 14 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261008-r4/temperature/0170
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein mean air temperature for Norelia temperature site 1017 ka outlook chahiye. Target measurements ki unit degrees Fahrenheit hai. Har observed record 1 din cover karta hai. Future coverage 4 din chahiye. Diya hua source identifier https://inputs.example/temperature/1017 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean air temperature for Norelia temperature site 1017",
    "evidence": "Hamein mean air temperature for Norelia temperature site 1017 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean air temperature for Norelia temperature site 1017",
    "evidence": "Hamein mean air temperature for Norelia temperature site 1017 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Fahrenheit",
    "evidence": "Target measurements ki unit degrees Fahrenheit hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "Future coverage 4 din chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1017",
    "evidence": "Diya hua source identifier https://inputs.example/temperature/1017 hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column tmean_f mein hai. Input timestamp identifier observed_time hai. Input API ke zariye lein. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tmean_f",
    "evidence": "Response variable column tmean_f mein hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 7 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Future coverage 7 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Norelia temperature site 1017 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0170/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia temperature site 1017",
    "evidence": "business goal ki requirement prepare a planning reserve for Norelia temperature site 1017 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261008-r4/temperature/0171
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for air temperature for Norelia temperature site 1017. Target measurements ki unit degrees Celsius hai. Each observed record covers 1 hour. Future coverage 5 ghanta chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/temperature/1017 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "air temperature for Norelia temperature site 1017",
    "evidence": "We need an outlook for air temperature for Norelia temperature site 1017."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "air temperature for Norelia temperature site 1017",
    "evidence": "We need an outlook for air temperature for Norelia temperature site 1017."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target measurements ki unit degrees Celsius hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Future coverage 5 ghanta chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/temperature/1017",
    "evidence": "Diya hua source identifier https://inputs.example/temperature/1017 hai."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column temp_c. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "temp_c",
    "evidence": "The response variable is stored in column temp_c."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

New forecasts must be issued every 3 days. Model har 2 mahina dobara estimate karein. Source ingestion repeats every 3 hours. Prediction rows ki resolution one prediction row per hour hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "New forecasts must be issued every 3 days."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Model har 2 mahina dobara estimate karein."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "Source ingestion repeats every 3 hours."
  },
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Prediction rows ki resolution one prediction row per hour hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 8 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/temperature/0171/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 8 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
