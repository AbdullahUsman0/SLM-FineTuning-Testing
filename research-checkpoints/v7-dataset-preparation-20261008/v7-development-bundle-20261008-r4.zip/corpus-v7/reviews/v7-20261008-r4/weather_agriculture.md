# V7 review examples for weather_agriculture

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261008-r4/weather_agriculture/0000
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900. Target measurements use USD per metric tonne. Each observed record covers 1 week. The requested future coverage is 6 weeks. The supplied source identifier is https://inputs.example/weather_agriculture/2900.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target measurements use USD per metric tonne."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 6 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "The supplied source identifier is https://inputs.example/weather_agriculture/2900."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column wheat_weather_price. The input timestamp identifier is recorded_at. Select the source from the data catalog. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_weather_price",
    "evidence": "The response variable is stored in column wheat_weather_price."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 9 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 9 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Merlow weather agriculture site 2900.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow weather agriculture site 2900",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow weather agriculture site 2900."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261008-r4/weather_agriculture/0001
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900. Target measurements use metric tonnes. Each observed record covers 1 week. The requested future coverage is 7 weeks. Select the source from the data catalog. The supplied source identifier is https://inputs.example/weather_agriculture/2900. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metric tonnes",
    "evidence": "Target measurements use metric tonnes."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 7 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "The supplied source identifier is https://inputs.example/weather_agriculture/2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column crop_shipments. The input timestamp identifier is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crop_shipments",
    "evidence": "The response variable is stored in column crop_shipments."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

New forecasts must be issued every 1 day. Re-estimate the model every 1 month. Source ingestion repeats every 2 hours. The requested prediction row resolution is one prediction row per week.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "New forecasts must be issued every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Re-estimate the model every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Source ingestion repeats every 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per week",
    "evidence": "The requested prediction row resolution is one prediction row per week."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 10 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 10 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261008-r4/weather_agriculture/0002
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900 ka outlook chahiye. Target measurements ki unit thousands of USD hai. Har observed record 1 hafta cover karta hai. Future coverage 8 hafta chahiye. Source data catalog se select karein. Diya hua source identifier https://inputs.example/weather_agriculture/2900 hai. Input container xlsx use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900",
    "evidence": "Hamein irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900",
    "evidence": "Hamein irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target measurements ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Har observed record 1 hafta cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "week"
    },
    "evidence": "Future coverage 8 hafta chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "Diya hua source identifier https://inputs.example/weather_agriculture/2900 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input container xlsx use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column irrigation_cost mein hai. Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "irrigation_cost",
    "evidence": "Response variable column irrigation_cost mein hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 11 hafta chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "week"
    },
    "evidence": "Future coverage 11 hafta chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Har observed record 2 hafta cover karta hai. Diya hua source identifier https://revised.example/weather_agriculture/2 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "week"
    },
    "evidence": "Har observed record 2 hafta cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/weather_agriculture/2",
    "evidence": "Diya hua source identifier https://revised.example/weather_agriculture/2 hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261008-r4/weather_agriculture/0003
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900. Target measurements use index points, base 2020=100. Each observed record covers 1 week. The requested future coverage is 9 weeks. Select the source from the data catalog. The supplied source identifier is https://inputs.example/weather_agriculture/2900. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements use index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 9 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "The supplied source identifier is https://inputs.example/weather_agriculture/2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

All observed times use the Asia/Karachi timezone. I do not expect a repeating seasonal pattern. The requested forecast output type is probabilistic. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "All observed times use the Asia/Karachi timezone."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The response variable is stored in column yield_index. The input timestamp identifier is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "yield_index",
    "evidence": "The response variable is stored in column yield_index."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 12 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 12 weeks."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261008-r4/weather_agriculture/0004
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900. Target measurements use USD per metric tonne. Each observed record covers 1 week. The requested future coverage is 10 weeks. Select the source from the data catalog. The supplied source identifier is https://inputs.example/weather_agriculture/2900. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target measurements use USD per metric tonne."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 10 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "The supplied source identifier is https://inputs.example/weather_agriculture/2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The requested future coverage is 10 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "Yes, The requested future coverage is 10 weeks."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 13 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 13 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The requested future coverage is 13 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "Yes, The requested future coverage is 13 weeks."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261008-r4/weather_agriculture/0005
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900. Target measurements use metric tonnes. Each observed record covers 1 week. The requested future coverage is 11 weeks. Select the source from the data catalog. The supplied source identifier is https://inputs.example/weather_agriculture/2900. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metric tonnes",
    "evidence": "Target measurements use metric tonnes."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 11 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "The supplied source identifier is https://inputs.example/weather_agriculture/2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column crop_shipments. The input timestamp identifier is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crop_shipments",
    "evidence": "The response variable is stored in column crop_shipments."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "week"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Each observed record covers 1 week. Target measurements use metric tonnes.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metric tonnes",
    "evidence": "Target measurements use metric tonnes."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 14 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 14 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261008-r4/weather_agriculture/0006
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900. Target measurements use thousands of USD. Each observed record covers 1 week. The requested future coverage is 12 weeks. Select the source from the data catalog. The supplied source identifier is https://inputs.example/weather_agriculture/2900. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for irrigation expenditure with temperature covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target measurements use thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 12 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "The supplied source identifier is https://inputs.example/weather_agriculture/2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column irrigation_cost. The input timestamp identifier is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "irrigation_cost",
    "evidence": "The response variable is stored in column irrigation_cost."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

My role in this project is agricultural market analyst. This forecast will inform the decision set the contingency allowance for Merlow weather agriculture site 2900. I will consider the result useful if it meets MAE no more than 2 thousands of USD for Birch synthetic weather agriculture scope 2. The response variable is stored in column irrigation_cost. Valid target bounds are {"max": 1000000, "min": 0}. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "agricultural market analyst",
    "evidence": "My role in this project is agricultural market analyst."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Merlow weather agriculture site 2900",
    "evidence": "This forecast will inform the decision set the contingency allowance for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 2 thousands of USD for Birch synthetic weather agriculture scope 2",
    "evidence": "I will consider the result useful if it meets MAE no more than 2 thousands of USD for Birch synthetic weather agriculture scope 2."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "irrigation_cost",
    "evidence": "The response variable is stored in column irrigation_cost."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t3/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "Valid target bounds are {\"max\": 1000000, \"min\": 0}."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Aggregate observations using last. The input timestamp identifier is recorded_at. Use the calendar calendar. The first forecast period begins at 2026-10-01T00:00:00+00:00. Do not use observations after 2026-09-30T00:00:00+00:00. The lead time is 1 week.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "Aggregate observations using last."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Use the calendar calendar."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "The first forecast period begins at 2026-10-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t4/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "Do not use observations after 2026-09-30T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t4/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The lead time is 1 week."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 15 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 15 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261008-r4/weather_agriculture/0007
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900. Target measurements use index points, base 2020=100. Each observed record covers 1 week. The requested future coverage is 13 weeks. Do not substitute wheat cash price with precipitation covariates as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop-yield index with soil-moisture covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements use index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 13 weeks."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column yield_index. The input timestamp identifier is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "yield_index",
    "evidence": "The response variable is stored in column yield_index."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Select the source from the data catalog. The supplied source identifier is https://inputs.example/weather_agriculture/2900. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "The supplied source identifier is https://inputs.example/weather_agriculture/2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 16 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 16 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261008-r4/weather_agriculture/0008
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900. Target measurements ki unit USD per metric tonne hai. Each observed record covers 1 week. Future coverage 14 hafta chahiye. Select the source from the data catalog. Diya hua source identifier https://inputs.example/weather_agriculture/2900 hai. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for wheat cash price with precipitation covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target measurements ki unit USD per metric tonne hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "week"
    },
    "evidence": "Future coverage 14 hafta chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2900",
    "evidence": "Diya hua source identifier https://inputs.example/weather_agriculture/2900 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The response variable is stored in column 2026. Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The response variable is stored in column 2026."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 17 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 17 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261008-r4/weather_agriculture/0009
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900. Target measurements use metric tonnes. The requested future coverage is 15 weeks. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900",
    "evidence": "We need an outlook for crop shipment demand with rainfall covariates for Merlow weather agriculture site 2900."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metric tonnes",
    "evidence": "Target measurements use metric tonnes."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 15 weeks."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Each observed record covers 1 week. New forecasts must be issued every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "New forecasts must be issued every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The response variable is stored in column crop_shipments. The input timestamp identifier is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crop_shipments",
    "evidence": "The response variable is stored in column crop_shipments."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 18 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 18 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of weather agriculture. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261008-r4/weather_agriculture/0010
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source weather_agriculture_archive_2901.csv hai. Main data upload karunga. Aglay 6 hafta predict karein. Har 1 hafta aik observed data point milta hai. Target values thousands of USD mein hain. irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_agriculture_archive_2901.csv",
    "evidence": "Source weather_agriculture_archive_2901.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "week"
    },
    "evidence": "Aglay 6 hafta predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Har 1 hafta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target values thousands of USD mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901",
    "evidence": "irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901",
    "evidence": "irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field sample_date mein hain. Column irrigation_cost ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates field sample_date mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "irrigation_cost",
    "evidence": "Column irrigation_cost ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 9 hafta predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "week"
    },
    "evidence": "Aglay 9 hafta predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Norelia weather agriculture site 2901 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia weather agriculture site 2901",
    "evidence": "business goal ki requirement prepare a planning reserve for Norelia weather agriculture site 2901 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: weather agriculture ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261008-r4/weather_agriculture/0011
Split: train

### t1 initial_multislot

Here is what I need.  Please predict crop-yield index with soil-moisture covariates for Norelia weather agriculture site 2901. Measurement unit index points, base 2020=100 rakhein. The native sampling interval is 1 week. Forecast horizon 7 hafta hai. I will upload the data. Observations weather_agriculture_archive_2901.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Norelia weather agriculture site 2901",
    "evidence": "Please predict crop-yield index with soil-moisture covariates for Norelia weather agriculture site 2901."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Norelia weather agriculture site 2901",
    "evidence": "Please predict crop-yield index with soil-moisture covariates for Norelia weather agriculture site 2901."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Measurement unit index points, base 2020=100 rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The native sampling interval is 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "week"
    },
    "evidence": "Forecast horizon 7 hafta hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_agriculture_archive_2901.csv",
    "evidence": "Observations weather_agriculture_archive_2901.csv se lein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is yield_index. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "yield_index",
    "evidence": "The target field name is yield_index."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Run forecast generation once every 2 days. Training har 2 mahina repeat karein. The input source refresh schedule is every 3 hours. Result granularity one prediction row per week banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training har 2 mahina repeat karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 3 hours."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per week",
    "evidence": "Result granularity one prediction row per week banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 10 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0011/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "The forecast horizon is 10 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261008-r4/weather_agriculture/0012
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is weather_agriculture_archive_2901.csv. I will upload the data. Predict a horizon of 8 weeks. Source observations arrive every 1 week. Use USD per metric tonne as the target unit. My prediction target is wheat cash price with precipitation covariates for Norelia weather agriculture site 2901.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_agriculture_archive_2901.csv",
    "evidence": "My source reference is weather_agriculture_archive_2901.csv."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "week"
    },
    "evidence": "Predict a horizon of 8 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Source observations arrive every 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Use USD per metric tonne as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Norelia weather agriculture site 2901",
    "evidence": "My prediction target is wheat cash price with precipitation covariates for Norelia weather agriculture site 2901."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Norelia weather agriculture site 2901",
    "evidence": "My prediction target is wheat cash price with precipitation covariates for Norelia weather agriculture site 2901."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field wheat_weather_price.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_weather_price",
    "evidence": "Read target values from field wheat_weather_price."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 11 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "week"
    },
    "evidence": "Predict a horizon of 11 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/weather_agriculture/12. Source observations arrive every 2 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/weather_agriculture/12",
    "evidence": "My source reference is https://revised.example/weather_agriculture/12."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0012/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "week"
    },
    "evidence": "Source observations arrive every 2 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261008-r4/weather_agriculture/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is weather_agriculture_archive_2901.csv. I will upload the data. I need the next 14 weeks predicted. There is one observed data point every 1 week. The target values are in thousands of USD. The quantity to predict is irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_agriculture_archive_2901.csv",
    "evidence": "The source is weather_agriculture_archive_2901.csv."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "week"
    },
    "evidence": "I need the next 14 weeks predicted."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "There is one observed data point every 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901",
    "evidence": "The quantity to predict is irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901",
    "evidence": "The quantity to predict is irrigation expenditure with temperature covariates for Norelia weather agriculture site 2901."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field sample_date. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains no personal, confidential, or regulated data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 weeks predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "week"
    },
    "evidence": "I need the next 17 weeks predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261008-r4/weather_agriculture/0024
Split: train

### t1 initial_multislot

Here is what I need.  Please predict wheat cash price with precipitation covariates for Orven weather agriculture site 2902. Measurement unit USD per metric tonne rakhein. The native sampling interval is 1 week. Forecast horizon 10 hafta hai. Access the input through an API. Observations https://inputs.example/weather_agriculture/2902 se lein. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Orven weather agriculture site 2902",
    "evidence": "Please predict wheat cash price with precipitation covariates for Orven weather agriculture site 2902."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Orven weather agriculture site 2902",
    "evidence": "Please predict wheat cash price with precipitation covariates for Orven weather agriculture site 2902."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Measurement unit USD per metric tonne rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The native sampling interval is 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "Forecast horizon 10 hafta hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2902",
    "evidence": "Observations https://inputs.example/weather_agriculture/2902 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast horizon is 10 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "Yes, The forecast horizon is 10 weeks."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "The forecast horizon is 13 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast horizon is 13 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0024/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "Yes, The forecast horizon is 13 weeks."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261008-r4/weather_agriculture/0031
Split: train

### t1 initial_multislot

Mujhe crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903 ka forecast chahiye. Target ki unit index points, base 2020=100 hai. Observations har 1 hafta record hoti hain. Forecast aglay 7 hafta tak chahiye. Input database se read karein. Data source https://inputs.example/weather_agriculture/2903 use karein. Input file format json hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903",
    "evidence": "Mujhe crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903",
    "evidence": "Mujhe crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Observations har 1 hafta record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "week"
    },
    "evidence": "Forecast aglay 7 hafta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2903",
    "evidence": "Data source https://inputs.example/weather_agriculture/2903 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input file format json hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam yield_index hai. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "yield_index",
    "evidence": "Target column ka naam yield_index hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Naya forecast har 1 din banayein. Model har 2 mahina retrain karein. Source data har 5 ghanta refresh karein. Output resolution one prediction row per week chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naya forecast har 1 din banayein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Model har 2 mahina retrain karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Source data har 5 ghanta refresh karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per week",
    "evidence": "Output resolution one prediction row per week chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 10 hafta tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0031/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "Forecast aglay 10 hafta tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261008-r4/weather_agriculture/0035
Split: train

### t1 initial_multislot

I need forecasts of crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903. Target ki unit index points, base 2020=100 hai. The observations are recorded every 1 week. Forecast aglay 11 hafta tak chahiye. Read the input from a database. Data source https://inputs.example/weather_agriculture/2903 use karein. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903",
    "evidence": "I need forecasts of crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903",
    "evidence": "I need forecasts of crop-yield index with soil-moisture covariates for Pelmar weather agriculture site 2903."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The observations are recorded every 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "week"
    },
    "evidence": "Forecast aglay 11 hafta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2903",
    "evidence": "Data source https://inputs.example/weather_agriculture/2903 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called yield_index. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "yield_index",
    "evidence": "The target column is called yield_index."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "week"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The observations are recorded every 1 week. Target ki unit index points, base 2020=100 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The observations are recorded every 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ki unit index points, base 2020=100 hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 14 weeks ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0035/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "week"
    },
    "evidence": "The forecast should extend 14 weeks ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261008-r4/weather_agriculture/0047
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 13 weeks. Source observations har 1 hafta aati hain. Use index points, base 2020=100 as the target unit. crop-yield index with soil-moisture covariates for Talven weather agriculture site 2904 ke liye prediction bana dein. Do not substitute wheat cash price with precipitation covariates as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "Predict a horizon of 13 weeks."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Source observations har 1 hafta aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Talven weather agriculture site 2904",
    "evidence": "crop-yield index with soil-moisture covariates for Talven weather agriculture site 2904 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Talven weather agriculture site 2904",
    "evidence": "crop-yield index with soil-moisture covariates for Talven weather agriculture site 2904 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Target values field yield_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "yield_index",
    "evidence": "Target values field yield_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is xlsx. Mera source reference https://inputs.example/weather_agriculture/2904 hai. Select the source from the data catalog.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2904",
    "evidence": "Mera source reference https://inputs.example/weather_agriculture/2904 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 16 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0047/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "week"
    },
    "evidence": "Predict a horizon of 16 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261008-r4/weather_agriculture/0049
Split: train

### t1 initial_multislot

Meri request yeh hai.  Aglay 15 hafta predict karein. Target values metric tonnes mein hain. crop shipment demand with rainfall covariates for Talven weather agriculture site 2904 predict karna hai. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "week"
    },
    "evidence": "Aglay 15 hafta predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metric tonnes",
    "evidence": "Target values metric tonnes mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop shipment demand with rainfall covariates for Talven weather agriculture site 2904",
    "evidence": "crop shipment demand with rainfall covariates for Talven weather agriculture site 2904 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop shipment demand with rainfall covariates for Talven weather agriculture site 2904",
    "evidence": "crop shipment demand with rainfall covariates for Talven weather agriculture site 2904 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Predictions har 2 din refresh karein. Har 1 hafta aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Predictions har 2 din refresh karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Har 1 hafta aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates field recorded_at mein hain. Column crop_shipments ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates field recorded_at mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crop_shipments",
    "evidence": "Column crop_shipments ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 18 hafta predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0049/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "week"
    },
    "evidence": "Aglay 18 hafta predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261008-r4/weather_agriculture/0076
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for wheat cash price with precipitation covariates for Yarven weather agriculture site 2907. Target measurements ki unit USD per metric tonne hai. Each observed record covers 1 week. Future coverage 12 hafta chahiye. Read the input from a database. Diya hua source identifier https://inputs.example/weather_agriculture/2907 hai. The input container uses json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Yarven weather agriculture site 2907",
    "evidence": "We need an outlook for wheat cash price with precipitation covariates for Yarven weather agriculture site 2907."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Yarven weather agriculture site 2907",
    "evidence": "We need an outlook for wheat cash price with precipitation covariates for Yarven weather agriculture site 2907."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target measurements ki unit USD per metric tonne hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Each observed record covers 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "week"
    },
    "evidence": "Future coverage 12 hafta chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2907",
    "evidence": "Diya hua source identifier https://inputs.example/weather_agriculture/2907 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input container uses json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column wheat_weather_price. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_weather_price",
    "evidence": "The response variable is stored in column wheat_weather_price."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The recorded structural breaks are [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}]. missing timestamp policy ki requirement reject hai. For missing target values, use the policy reject. duplicate policy ki requirement reject hai. For unusual values, use the policy cap. invalid value policy ki requirement coerce hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t3/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "The recorded structural breaks are [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}]."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t3/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "missing timestamp policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t3/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "For missing target values, use the policy reject."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t3/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "duplicate policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t3/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "For unusual values, use the policy cap."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t3/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "coerce",
    "evidence": "invalid value policy ki requirement coerce hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Require non-missing coverage of at least 96 percent. Repeating seasonal pattern expect karta hoon. Do not exclude weekends or non-business days. holidays ki requirement synthetic reporting holiday hai. The known special events are [{"date": "2026-10-05", "name": "synthetic scheduled data release"}]. past covariates ki requirement observed_precipitation hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t4/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 96,
    "evidence": "Require non-missing coverage of at least 96 percent."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t4/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t4/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Do not exclude weekends or non-business days."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t4/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "holidays ki requirement synthetic reporting holiday hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t4/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "The known special events are [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}]."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t4/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "observed_precipitation"
    ],
    "evidence": "past covariates ki requirement observed_precipitation hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 15 weeks.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0076/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "week"
    },
    "evidence": "The requested future coverage is 15 weeks."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

For a separate new request, explain the definition of weather agriculture. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261008-r4/weather_agriculture/0078
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein irrigation expenditure with temperature covariates for Yarven weather agriculture site 2907 ka outlook chahiye. Target measurements ki unit thousands of USD hai. Har observed record 1 hafta cover karta hai. Future coverage 14 hafta chahiye. Input database se read karein. Diya hua source identifier https://inputs.example/weather_agriculture/2907 hai. Input container json use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Yarven weather agriculture site 2907",
    "evidence": "Hamein irrigation expenditure with temperature covariates for Yarven weather agriculture site 2907 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "irrigation expenditure with temperature covariates for Yarven weather agriculture site 2907",
    "evidence": "Hamein irrigation expenditure with temperature covariates for Yarven weather agriculture site 2907 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target measurements ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Har observed record 1 hafta cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "week"
    },
    "evidence": "Future coverage 14 hafta chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2907",
    "evidence": "Diya hua source identifier https://inputs.example/weather_agriculture/2907 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input container json use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Response variable column value "net" mein hai. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "Response variable column value \"net\" mein hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein personal ya confidential data nahi hai. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 17 hafta chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0078/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "week"
    },
    "evidence": "Future coverage 17 hafta chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261008-r4/weather_agriculture/0080
Split: train

### t1 initial_multislot

I need forecasts of wheat cash price with precipitation covariates for Merlow weather agriculture site 2908. Target ki unit USD per metric tonne hai. The observations are recorded every 1 week. Forecast aglay 6 hafta tak chahiye. Use the data source https://inputs.example/weather_agriculture/2908.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2908",
    "evidence": "I need forecasts of wheat cash price with precipitation covariates for Merlow weather agriculture site 2908."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2908",
    "evidence": "I need forecasts of wheat cash price with precipitation covariates for Merlow weather agriculture site 2908."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target ki unit USD per metric tonne hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "The observations are recorded every 1 week."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "week"
    },
    "evidence": "Forecast aglay 6 hafta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2908",
    "evidence": "Use the data source https://inputs.example/weather_agriculture/2908."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called wheat_weather_price. Timestamp column recorded_at hai. Select the source from the data catalog. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_weather_price",
    "evidence": "The target column is called wheat_weather_price."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 9 weeks ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "week"
    },
    "evidence": "The forecast should extend 9 weeks ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Merlow weather agriculture site 2908.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0080/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow weather agriculture site 2908",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow weather agriculture site 2908."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261008-r4/weather_agriculture/0103
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/weather_agriculture/2910 hai. Input API ke zariye lein. Aglay 9 hafta predict karein. Har 1 hafta aik observed data point milta hai. Target values index points, base 2020=100 mein hain. crop-yield index with soil-moisture covariates for Orven weather agriculture site 2910 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2910",
    "evidence": "Source https://inputs.example/weather_agriculture/2910 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "week"
    },
    "evidence": "Aglay 9 hafta predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Har 1 hafta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target values index points, base 2020=100 mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Orven weather agriculture site 2910",
    "evidence": "crop-yield index with soil-moisture covariates for Orven weather agriculture site 2910 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "crop-yield index with soil-moisture covariates for Orven weather agriculture site 2910",
    "evidence": "crop-yield index with soil-moisture covariates for Orven weather agriculture site 2910 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

prediction interval levels ki requirement 80, 95 hai. forecast type ki requirement probabilistic hai. Repeating seasonal pattern expect nahi karta. Times Europe/London mein hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Times Europe/London mein hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates field observed_time mein hain. Column yield_index ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates field observed_time mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "yield_index",
    "evidence": "Column yield_index ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Aglay 12 hafta predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0103/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "week"
    },
    "evidence": "Aglay 12 hafta predict karein."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261008-r4/weather_agriculture/0156
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format json hai. Source https://inputs.example/weather_agriculture/2915 hai. Input database se read karein. Aglay 12 hafta predict karein. Har 1 hafta aik observed data point milta hai. Target values USD per metric tonne mein hain. wheat cash price with precipitation covariates for Yarven weather agriculture site 2915 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Diye hue data ka format json hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2915",
    "evidence": "Source https://inputs.example/weather_agriculture/2915 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "week"
    },
    "evidence": "Aglay 12 hafta predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Har 1 hafta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target values USD per metric tonne mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Yarven weather agriculture site 2915",
    "evidence": "wheat cash price with precipitation covariates for Yarven weather agriculture site 2915 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Yarven weather agriculture site 2915",
    "evidence": "wheat cash price with precipitation covariates for Yarven weather agriculture site 2915 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field measurement_time mein hain. Column wheat_weather_price ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_weather_price",
    "evidence": "Column wheat_weather_price ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

success criteria ki requirement MAE no more than 2 USD per metric tonne for Birch synthetic weather agriculture scope 32 hai. decision supported ki requirement set the contingency allowance for Yarven weather agriculture site 2915 hai. stakeholder role ki requirement agricultural market analyst hai. business goal ki requirement prepare a planning reserve for Yarven weather agriculture site 2915 hai. Modeling se pehle human approval required nahi hai. explainability level ki requirement none hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 2 USD per metric tonne for Birch synthetic weather agriculture scope 32",
    "evidence": "success criteria ki requirement MAE no more than 2 USD per metric tonne for Birch synthetic weather agriculture scope 32 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Yarven weather agriculture site 2915",
    "evidence": "decision supported ki requirement set the contingency allowance for Yarven weather agriculture site 2915 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "agricultural market analyst",
    "evidence": "stakeholder role ki requirement agricultural market analyst hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Yarven weather agriculture site 2915",
    "evidence": "business goal ki requirement prepare a planning reserve for Yarven weather agriculture site 2915 hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Modeling se pehle human approval required nahi hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t3/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "none",
    "evidence": "explainability level ki requirement none hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

calendar type ki requirement calendar hai. Dates field measurement_time mein hain. aggregation method ki requirement last hai. Negative target values allowed nahi hain. target bounds ki requirement {"max": 1000000, "min": 0} hai. Column wheat_weather_price ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "calendar type ki requirement calendar hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "aggregation method ki requirement last hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t4/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "target bounds ki requirement {\"max\": 1000000, \"min\": 0} hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_weather_price",
    "evidence": "Column wheat_weather_price ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Aglay 15 hafta predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0156/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "week"
    },
    "evidence": "Aglay 15 hafta predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261008-r4/weather_agriculture/0164
Split: train

### t1 initial_multislot

Mujhe wheat cash price with precipitation covariates for Merlow weather agriculture site 2916 ka forecast chahiye. Target ki unit USD per metric tonne hai. Observations har 1 hafta record hoti hain. Forecast aglay 10 hafta tak chahiye. Source data catalog se select karein. Data source https://inputs.example/weather_agriculture/2916 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2916",
    "evidence": "Mujhe wheat cash price with precipitation covariates for Merlow weather agriculture site 2916 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price with precipitation covariates for Merlow weather agriculture site 2916",
    "evidence": "Mujhe wheat cash price with precipitation covariates for Merlow weather agriculture site 2916 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target ki unit USD per metric tonne hai."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Observations har 1 hafta record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "Forecast aglay 10 hafta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_agriculture/2916",
    "evidence": "Data source https://inputs.example/weather_agriculture/2916 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Haan, Forecast aglay 10 hafta tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "Haan, Forecast aglay 10 hafta tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 13 hafta tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "Forecast aglay 13 hafta tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Haan, Forecast aglay 13 hafta tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/weather_agriculture/0164/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 13,
      "unit": "week"
    },
    "evidence": "Haan, Forecast aglay 13 hafta tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
