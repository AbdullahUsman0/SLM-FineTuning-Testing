# V7 review examples for humidity_pressure

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## mixed core_recall

Scenario: v7-20261008-r4/humidity_pressure/0000
Split: train

### t1 initial_multislot

I need forecasts of relative humidity for Merlow humidity pressure site 1300. Target ki unit percent hai. The observations are recorded every 1 hour. Forecast aglay 7 ghanta tak chahiye. Use the data source https://inputs.example/humidity_pressure/1300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "relative humidity for Merlow humidity pressure site 1300",
    "evidence": "I need forecasts of relative humidity for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "relative humidity for Merlow humidity pressure site 1300",
    "evidence": "I need forecasts of relative humidity for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 7 ghanta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "Use the data source https://inputs.example/humidity_pressure/1300."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called rh_pct. Timestamp column recorded_at hai. Select the source from the data catalog. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "rh_pct",
    "evidence": "The target column is called rh_pct."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 10 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 10 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Merlow humidity pressure site 1300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow humidity pressure site 1300",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow humidity pressure site 1300."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261008-r4/humidity_pressure/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/humidity_pressure/1300. Select the source from the data catalog. I need the next 8 hours predicted. There is one observed data point every 1 hour. The target values are in degrees Celsius. The quantity to predict is dew point temperature for Merlow humidity pressure site 1300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "The source is https://inputs.example/humidity_pressure/1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "I need the next 8 hours predicted."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "The target values are in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "dew point temperature for Merlow humidity pressure site 1300",
    "evidence": "The quantity to predict is dew point temperature for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "dew point temperature for Merlow humidity pressure site 1300",
    "evidence": "The quantity to predict is dew point temperature for Merlow humidity pressure site 1300."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Use column dewpoint_c as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dewpoint_c",
    "evidence": "Use column dewpoint_c as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per hour. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Return forecasts with resolution one prediction row per hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 11 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "I need the next 11 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261008-r4/humidity_pressure/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict sea-level pressure for Merlow humidity pressure site 1300. Keep the measurement unit as hectopascals. The native sampling interval is 1 hour. The forecast horizon is 9 hours. Select the source from the data catalog. Read the observations from https://inputs.example/humidity_pressure/1300. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sea-level pressure for Merlow humidity pressure site 1300",
    "evidence": "Please predict sea-level pressure for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sea-level pressure for Merlow humidity pressure site 1300",
    "evidence": "Please predict sea-level pressure for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hectopascals",
    "evidence": "Keep the measurement unit as hectopascals."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 9 hours."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "Read the observations from https://inputs.example/humidity_pressure/1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is pressure_hpa. Use column recorded_at for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "pressure_hpa",
    "evidence": "The target field name is pressure_hpa."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 12 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 12 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 hours. Read the observations from https://revised.example/humidity_pressure/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/humidity_pressure/2",
    "evidence": "Read the observations from https://revised.example/humidity_pressure/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261008-r4/humidity_pressure/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. My source reference is https://inputs.example/humidity_pressure/1300. Select the source from the data catalog. Predict a horizon of 10 days. Source observations arrive every 1 day. Use percent as the target unit. My prediction target is mean relative humidity for Merlow humidity pressure site 1300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "My source reference is https://inputs.example/humidity_pressure/1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 10 days."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Use percent as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean relative humidity for Merlow humidity pressure site 1300",
    "evidence": "My prediction target is mean relative humidity for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean relative humidity for Merlow humidity pressure site 1300",
    "evidence": "My prediction target is mean relative humidity for Merlow humidity pressure site 1300."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. I do not expect a repeating seasonal pattern. Use timezone UTC.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Use timezone UTC."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is recorded_at. Read target values from field daily_rh_pct.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "daily_rh_pct",
    "evidence": "Read target values from field daily_rh_pct."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 13 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 13 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 explicit_nonforecasting

For a separate new request, explain the definition of humidity pressure. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261008-r4/humidity_pressure/0004
Split: train

### t1 initial_multislot

I need forecasts of relative humidity for Merlow humidity pressure site 1300. Measure the target in percent. The observations are recorded every 1 hour. The forecast should extend 11 hours ahead. Select the source from the data catalog. Use the data source https://inputs.example/humidity_pressure/1300. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "relative humidity for Merlow humidity pressure site 1300",
    "evidence": "I need forecasts of relative humidity for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "relative humidity for Merlow humidity pressure site 1300",
    "evidence": "I need forecasts of relative humidity for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measure the target in percent."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 11 hours ahead."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "Use the data source https://inputs.example/humidity_pressure/1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast should extend 11 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Yes, The forecast should extend 11 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 14 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 14 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast should extend 14 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Yes, The forecast should extend 14 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261008-r4/humidity_pressure/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/humidity_pressure/1300. Select the source from the data catalog. I need the next 12 hours predicted. There is one observed data point every 1 hour. The target values are in degrees Celsius. The quantity to predict is dew point temperature for Merlow humidity pressure site 1300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "The source is https://inputs.example/humidity_pressure/1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "I need the next 12 hours predicted."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "The target values are in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "dew point temperature for Merlow humidity pressure site 1300",
    "evidence": "The quantity to predict is dew point temperature for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "dew point temperature for Merlow humidity pressure site 1300",
    "evidence": "The quantity to predict is dew point temperature for Merlow humidity pressure site 1300."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Use column dewpoint_c as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dewpoint_c",
    "evidence": "Use column dewpoint_c as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in degrees Celsius. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "The target values are in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 15 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "I need the next 15 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261008-r4/humidity_pressure/0006
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target sea-level pressure for Merlow humidity pressure site 1300 hai. Measurement unit hectopascals rakhein. Asli data ka sampling interval 1 ghanta hai. Forecast horizon 13 ghanta hai. Source data catalog se select karein. Observations https://inputs.example/humidity_pressure/1300 se lein. Input ko xlsx ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sea-level pressure for Merlow humidity pressure site 1300",
    "evidence": "Prediction ka target sea-level pressure for Merlow humidity pressure site 1300 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sea-level pressure for Merlow humidity pressure site 1300",
    "evidence": "Prediction ka target sea-level pressure for Merlow humidity pressure site 1300 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hectopascals",
    "evidence": "Measurement unit hectopascals rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 1 ghanta hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 13 ghanta hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "Observations https://inputs.example/humidity_pressure/1300 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input ko xlsx ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field pressure_hpa hai. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "pressure_hpa",
    "evidence": "Target field pressure_hpa hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Input source refresh schedule har 2 ghanta hai. history start ki requirement 2020-01-01T00:00:00+00:00 hai. history end ki requirement 2026-09-30T00:00:00+00:00 hai. available historical coverage 81 mahina hai. minimum training points ki requirement 365 hai. known regime changes ki requirement [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Input source refresh schedule har 2 ghanta hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t3/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "history start ki requirement 2020-01-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t3/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "history end ki requirement 2026-09-30T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t3/expected_history_length",
    "slot_id": "expected_history_length",
    "status": "provided",
    "value": {
      "periods": 81,
      "unit": "month"
    },
    "evidence": "available historical coverage 81 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t3/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 365,
    "evidence": "minimum training points ki requirement 365 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t3/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "known regime changes ki requirement [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

missing timestamp policy ki requirement resample hai. missing target policy ki requirement interpolate hai. duplicate policy ki requirement latest hai. outlier policy ki requirement cap hai. invalid value policy ki requirement reject hai. minimum coverage ki requirement 86 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t4/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "resample",
    "evidence": "missing timestamp policy ki requirement resample hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t4/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "interpolate",
    "evidence": "missing target policy ki requirement interpolate hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t4/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "latest",
    "evidence": "duplicate policy ki requirement latest hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t4/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "outlier policy ki requirement cap hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t4/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "invalid value policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t4/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "minimum coverage ki requirement 86 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 16 ghanta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 16 ghanta hai."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261008-r4/humidity_pressure/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 14 days. Source observations arrive every 1 day. Use percent as the target unit. My prediction target is mean relative humidity for Merlow humidity pressure site 1300. Do not substitute hourly relative humidity as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 14 days."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Use percent as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean relative humidity for Merlow humidity pressure site 1300",
    "evidence": "My prediction target is mean relative humidity for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean relative humidity for Merlow humidity pressure site 1300",
    "evidence": "My prediction target is mean relative humidity for Merlow humidity pressure site 1300."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Read target values from field daily_rh_pct.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "daily_rh_pct",
    "evidence": "Read target values from field daily_rh_pct."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is xlsx. My source reference is https://inputs.example/humidity_pressure/1300. Select the source from the data catalog.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "My source reference is https://inputs.example/humidity_pressure/1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 17 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 17 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261008-r4/humidity_pressure/0008
Split: train

### t1 initial_multislot

I need forecasts of relative humidity for Merlow humidity pressure site 1300. Measure the target in percent. The observations are recorded every 1 hour. The forecast should extend 15 hours ahead. Select the source from the data catalog. Use the data source https://inputs.example/humidity_pressure/1300. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "relative humidity for Merlow humidity pressure site 1300",
    "evidence": "I need forecasts of relative humidity for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "relative humidity for Merlow humidity pressure site 1300",
    "evidence": "I need forecasts of relative humidity for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measure the target in percent."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 15 hours ahead."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1300",
    "evidence": "Use the data source https://inputs.example/humidity_pressure/1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The timestamp column is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 18 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 18 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261008-r4/humidity_pressure/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 16 hours predicted. The target values are in degrees Celsius. The quantity to predict is dew point temperature for Merlow humidity pressure site 1300. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "I need the next 16 hours predicted."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "The target values are in degrees Celsius."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "dew point temperature for Merlow humidity pressure site 1300",
    "evidence": "The quantity to predict is dew point temperature for Merlow humidity pressure site 1300."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "dew point temperature for Merlow humidity pressure site 1300",
    "evidence": "The quantity to predict is dew point temperature for Merlow humidity pressure site 1300."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Refresh the predictions every 1 day. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field recorded_at. Use column dewpoint_c as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dewpoint_c",
    "evidence": "Use column dewpoint_c as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 19 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "I need the next 19 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en core_recall

Scenario: v7-20261008-r4/humidity_pressure/0020
Split: train

### t1 initial_multislot

Here is what I need.  Please predict relative humidity for Orven humidity pressure site 1302. Keep the measurement unit as percent. The native sampling interval is 1 hour. The forecast horizon is 7 hours. Read the observations from https://inputs.example/humidity_pressure/1302.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "relative humidity for Orven humidity pressure site 1302",
    "evidence": "Please predict relative humidity for Orven humidity pressure site 1302."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "relative humidity for Orven humidity pressure site 1302",
    "evidence": "Please predict relative humidity for Orven humidity pressure site 1302."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Keep the measurement unit as percent."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 7 hours."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1302",
    "evidence": "Read the observations from https://inputs.example/humidity_pressure/1302."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is rh_pct. Use column observed_time for the timestamps. Access the input through an API. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "rh_pct",
    "evidence": "The target field name is rh_pct."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 10 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 10 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Orven humidity pressure site 1302.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0020/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven humidity pressure site 1302",
    "evidence": "Our operational goal is prepare a planning reserve for Orven humidity pressure site 1302."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261008-r4/humidity_pressure/0025
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. Mera source reference https://inputs.example/humidity_pressure/1302 hai. Access the input through an API. 12 ghanta ka horizon rakhein. Source observations arrive every 1 hour. Target ko degrees Celsius mein measure karein. My prediction target is dew point temperature for Orven humidity pressure site 1302.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1302",
    "evidence": "Mera source reference https://inputs.example/humidity_pressure/1302 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "12 ghanta ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ko degrees Celsius mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "dew point temperature for Orven humidity pressure site 1302",
    "evidence": "My prediction target is dew point temperature for Orven humidity pressure site 1302."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "dew point temperature for Orven humidity pressure site 1302",
    "evidence": "My prediction target is dew point temperature for Orven humidity pressure site 1302."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Target values field dewpoint_c se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dewpoint_c",
    "evidence": "Target values field dewpoint_c se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Use degrees Celsius as the target unit. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Use degrees Celsius as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 15 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0025/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 15 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of humidity pressure. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261008-r4/humidity_pressure/0035
Split: train

### t1 initial_multislot

Mujhe mean relative humidity for Pelmar humidity pressure site 1303 ka forecast chahiye. Target ki unit percent hai. Observations har 1 din record hoti hain. Forecast aglay 12 din tak chahiye. Input database se read karein. Data source https://inputs.example/humidity_pressure/1303 use karein. Input file format json hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean relative humidity for Pelmar humidity pressure site 1303",
    "evidence": "Mujhe mean relative humidity for Pelmar humidity pressure site 1303 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean relative humidity for Pelmar humidity pressure site 1303",
    "evidence": "Mujhe mean relative humidity for Pelmar humidity pressure site 1303 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Forecast aglay 12 din tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1303",
    "evidence": "Data source https://inputs.example/humidity_pressure/1303 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input file format json hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam daily_rh_pct hai. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "daily_rh_pct",
    "evidence": "Target column ka naam daily_rh_pct hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Observations har 1 din record hoti hain. Target ki unit percent hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 15 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0035/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "Forecast aglay 15 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261008-r4/humidity_pressure/0036
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. The source is https://inputs.example/humidity_pressure/1303. Read the input from a database. I need the next 13 hours predicted. There is one observed data point every 1 hour. The target values are in percent. The quantity to predict is relative humidity for Pelmar humidity pressure site 1303.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1303",
    "evidence": "The source is https://inputs.example/humidity_pressure/1303."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "I need the next 13 hours predicted."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "relative humidity for Pelmar humidity pressure site 1303",
    "evidence": "The quantity to predict is relative humidity for Pelmar humidity pressure site 1303."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "relative humidity for Pelmar humidity pressure site 1303",
    "evidence": "The quantity to predict is relative humidity for Pelmar humidity pressure site 1303."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Use column rh_pct as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "rh_pct",
    "evidence": "Use column rh_pct as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Human approval before modeling is not required. The required explanation level is none. Detailed data lineage is not required. The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed. Enforce these privacy restrictions: synthetic data only, no external redistribution. The source contains no personal, confidential, or regulated data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Human approval before modeling is not required."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t3/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "none",
    "evidence": "The required explanation level is none."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t3/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": false,
    "evidence": "Detailed data lineage is not required."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t3/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t3/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "Enforce these privacy restrictions: synthetic data only, no external redistribution."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Valid target bounds are {"max": 100, "min": 0}. Use column rh_pct as the target. I will consider the result useful if it meets MAE no more than 2 percent for Cedar synthetic humidity pressure scope 8. This forecast will inform the decision set the contingency allowance for Pelmar humidity pressure site 1303. My role in this project is meteorological analyst. Our operational goal is prepare a planning reserve for Pelmar humidity pressure site 1303.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t4/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 100,
      "min": 0
    },
    "evidence": "Valid target bounds are {\"max\": 100, \"min\": 0}."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "rh_pct",
    "evidence": "Use column rh_pct as the target."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t4/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 2 percent for Cedar synthetic humidity pressure scope 8",
    "evidence": "I will consider the result useful if it meets MAE no more than 2 percent for Cedar synthetic humidity pressure scope 8."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t4/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Pelmar humidity pressure site 1303",
    "evidence": "This forecast will inform the decision set the contingency allowance for Pelmar humidity pressure site 1303."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t4/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "meteorological analyst",
    "evidence": "My role in this project is meteorological analyst."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Pelmar humidity pressure site 1303",
    "evidence": "Our operational goal is prepare a planning reserve for Pelmar humidity pressure site 1303."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0036/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "I need the next 16 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

For a separate new request, explain the definition of humidity pressure. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261008-r4/humidity_pressure/0039
Split: train

### t1 initial_multislot

I need forecasts of mean relative humidity for Pelmar humidity pressure site 1303. Target ki unit percent hai. The forecast should extend 16 days ahead. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean relative humidity for Pelmar humidity pressure site 1303",
    "evidence": "I need forecasts of mean relative humidity for Pelmar humidity pressure site 1303."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean relative humidity for Pelmar humidity pressure site 1303",
    "evidence": "I need forecasts of mean relative humidity for Pelmar humidity pressure site 1303."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "The forecast should extend 16 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The observations are recorded every 1 day. Naya forecast har 1 din banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naya forecast har 1 din banayein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target column is called daily_rh_pct. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "daily_rh_pct",
    "evidence": "The target column is called daily_rh_pct."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 19 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0039/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "The forecast should extend 19 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261008-r4/humidity_pressure/0042
Split: train

### t1 initial_multislot

Here is what I need.  Please predict sea-level pressure for Talven humidity pressure site 1304. Measurement unit hectopascals rakhein. The native sampling interval is 1 hour. Forecast horizon 9 ghanta hai. Select the source from the data catalog. Observations https://inputs.example/humidity_pressure/1304 se lein. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sea-level pressure for Talven humidity pressure site 1304",
    "evidence": "Please predict sea-level pressure for Talven humidity pressure site 1304."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sea-level pressure for Talven humidity pressure site 1304",
    "evidence": "Please predict sea-level pressure for Talven humidity pressure site 1304."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hectopascals",
    "evidence": "Measurement unit hectopascals rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 9 ghanta hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1304",
    "evidence": "Observations https://inputs.example/humidity_pressure/1304 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is pressure_hpa. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "pressure_hpa",
    "evidence": "The target field name is pressure_hpa."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 12 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 12 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 hours. Observations https://revised.example/humidity_pressure/42 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0042/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/humidity_pressure/42",
    "evidence": "Observations https://revised.example/humidity_pressure/42 se lein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261008-r4/humidity_pressure/0047
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  14 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko percent mein measure karein. mean relative humidity for Talven humidity pressure site 1304 ke liye prediction bana dein. hourly relative humidity nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "14 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ko percent mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean relative humidity for Talven humidity pressure site 1304",
    "evidence": "mean relative humidity for Talven humidity pressure site 1304 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean relative humidity for Talven humidity pressure site 1304",
    "evidence": "mean relative humidity for Talven humidity pressure site 1304 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam recorded_at hai. Target values field daily_rh_pct se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Time field ka naam recorded_at hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "daily_rh_pct",
    "evidence": "Target values field daily_rh_pct se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Source serialization format xlsx hai. Mera source reference https://inputs.example/humidity_pressure/1304 hai. Source data catalog se select karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Source serialization format xlsx hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1304",
    "evidence": "Mera source reference https://inputs.example/humidity_pressure/1304 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 17 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0047/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "17 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: humidity pressure ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261008-r4/humidity_pressure/0058
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. Source humidity_pressure_archive_1305.csv hai. I will upload the data. Aglay 15 ghanta predict karein. There is one observed data point every 1 hour. Target values hectopascals mein hain. The quantity to predict is sea-level pressure for Virelo humidity pressure site 1305.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "humidity_pressure_archive_1305.csv",
    "evidence": "Source humidity_pressure_archive_1305.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Aglay 15 ghanta predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hectopascals",
    "evidence": "Target values hectopascals mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sea-level pressure for Virelo humidity pressure site 1305",
    "evidence": "The quantity to predict is sea-level pressure for Virelo humidity pressure site 1305."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sea-level pressure for Virelo humidity pressure site 1305",
    "evidence": "The quantity to predict is sea-level pressure for Virelo humidity pressure site 1305."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field sample_date. Column true ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Column true ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. Source mein personal ya confidential data nahi hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 18 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0058/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "I need the next 18 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of humidity pressure. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261008-r4/humidity_pressure/0059
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target mean relative humidity for Virelo humidity pressure site 1305 hai. Measurement unit percent rakhein. Forecast horizon 16 din hai. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean relative humidity for Virelo humidity pressure site 1305",
    "evidence": "Prediction ka target mean relative humidity for Virelo humidity pressure site 1305 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean relative humidity for Virelo humidity pressure site 1305",
    "evidence": "Prediction ka target mean relative humidity for Virelo humidity pressure site 1305 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Forecast horizon 16 din hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Asli data ka sampling interval 1 din hai. Forecast generation har 3 din run karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Forecast generation har 3 din run karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Target field daily_rh_pct hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "daily_rh_pct",
    "evidence": "Target field daily_rh_pct hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 19 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0059/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "Forecast horizon 19 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261008-r4/humidity_pressure/0074
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format json hai. Mera source reference https://inputs.example/humidity_pressure/1307 hai. Input database se read karein. 11 ghanta ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko hectopascals mein measure karein. sea-level pressure for Yarven humidity pressure site 1307 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Source serialization format json hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1307",
    "evidence": "Mera source reference https://inputs.example/humidity_pressure/1307 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "11 ghanta ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hectopascals",
    "evidence": "Target ko hectopascals mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sea-level pressure for Yarven humidity pressure site 1307",
    "evidence": "sea-level pressure for Yarven humidity pressure site 1307 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sea-level pressure for Yarven humidity pressure site 1307",
    "evidence": "sea-level pressure for Yarven humidity pressure site 1307 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Haan, 11 ghanta ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Haan, 11 ghanta ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. 14 ghanta ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "14 ghanta ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Haan, 14 ghanta ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0074/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Haan, 14 ghanta ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261008-r4/humidity_pressure/0103
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for mean relative humidity for Orven humidity pressure site 1310. Target measurements ki unit percent hai. Each observed record covers 1 day. Future coverage 10 din chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/humidity_pressure/1310 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean relative humidity for Orven humidity pressure site 1310",
    "evidence": "We need an outlook for mean relative humidity for Orven humidity pressure site 1310."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean relative humidity for Orven humidity pressure site 1310",
    "evidence": "We need an outlook for mean relative humidity for Orven humidity pressure site 1310."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target measurements ki unit percent hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Future coverage 10 din chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1310",
    "evidence": "Diya hua source identifier https://inputs.example/humidity_pressure/1310 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

All observed times use the Asia/Karachi timezone. Repeating seasonal pattern expect nahi karta. The requested forecast output type is probabilistic. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "All observed times use the Asia/Karachi timezone."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The response variable is stored in column daily_rh_pct. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "daily_rh_pct",
    "evidence": "The response variable is stored in column daily_rh_pct."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 13 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0103/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 13 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 explicit_nonforecasting

For a separate new request, explain the definition of humidity pressure. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261008-r4/humidity_pressure/0124
Split: train

### t1 initial_multislot

I need forecasts of relative humidity for Talven humidity pressure site 1312. Target ki unit percent hai. The observations are recorded every 1 hour. Forecast aglay 11 ghanta tak chahiye. Select the source from the data catalog. Data source https://inputs.example/humidity_pressure/1312 use karein. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "relative humidity for Talven humidity pressure site 1312",
    "evidence": "I need forecasts of relative humidity for Talven humidity pressure site 1312."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "relative humidity for Talven humidity pressure site 1312",
    "evidence": "I need forecasts of relative humidity for Talven humidity pressure site 1312."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 11 ghanta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1312",
    "evidence": "Data source https://inputs.example/humidity_pressure/1312 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast should extend 11 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Yes, The forecast should extend 11 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 14 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 14 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast should extend 14 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0124/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Yes, The forecast should extend 14 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261008-r4/humidity_pressure/0128
Split: train

### t1 initial_multislot

Mujhe relative humidity for Talven humidity pressure site 1312 ka forecast chahiye. Target ki unit percent hai. Observations har 1 ghanta record hoti hain. Forecast aglay 15 ghanta tak chahiye. Source data catalog se select karein. Data source https://inputs.example/humidity_pressure/1312 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "relative humidity for Talven humidity pressure site 1312",
    "evidence": "Mujhe relative humidity for Talven humidity pressure site 1312 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "relative humidity for Talven humidity pressure site 1312",
    "evidence": "Mujhe relative humidity for Talven humidity pressure site 1312 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 15 ghanta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1312",
    "evidence": "Data source https://inputs.example/humidity_pressure/1312 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein confidential synthetic records hain. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 18 ghanta tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0128/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 18 ghanta tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261008-r4/humidity_pressure/0133
Split: train

### t1 initial_multislot

Mujhe dew point temperature for Virelo humidity pressure site 1313 ka forecast chahiye. Target ki unit degrees Celsius hai. Observations har 1 ghanta record hoti hain. Forecast aglay 10 ghanta tak chahiye. Main data upload karunga. Data source humidity_pressure_archive_1313.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "dew point temperature for Virelo humidity pressure site 1313",
    "evidence": "Mujhe dew point temperature for Virelo humidity pressure site 1313 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "dew point temperature for Virelo humidity pressure site 1313",
    "evidence": "Mujhe dew point temperature for Virelo humidity pressure site 1313 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees Celsius",
    "evidence": "Target ki unit degrees Celsius hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 10 ghanta tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "humidity_pressure_archive_1313.csv",
    "evidence": "Data source humidity_pressure_archive_1313.csv use karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Timestamps ki timezone Asia/Karachi hai. Repeating seasonal pattern expect karta hoon. seasonal periods ki requirement 24, 168 hai. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "Timestamps ki timezone Asia/Karachi hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "seasonal periods ki requirement 24, 168 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Target column ka naam dewpoint_c hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dewpoint_c",
    "evidence": "Target column ka naam dewpoint_c hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 13 ghanta tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0133/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 13 ghanta tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261008-r4/humidity_pressure/0147
Split: train

### t1 initial_multislot

For my request,  I need the next 14 days predicted. Har 1 din aik observed data point milta hai. The target values are in percent. mean relative humidity for Weslin humidity pressure site 1314 predict karna hai. Do not substitute hourly relative humidity as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "I need the next 14 days predicted."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean relative humidity for Weslin humidity pressure site 1314",
    "evidence": "mean relative humidity for Weslin humidity pressure site 1314 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean relative humidity for Weslin humidity pressure site 1314",
    "evidence": "mean relative humidity for Weslin humidity pressure site 1314 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Column daily_rh_pct ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "daily_rh_pct",
    "evidence": "Column daily_rh_pct ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is parquet. Source https://inputs.example/humidity_pressure/1314 hai. Access the input through an API.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1314",
    "evidence": "Source https://inputs.example/humidity_pressure/1314 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0147/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "I need the next 17 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of humidity pressure. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261008-r4/humidity_pressure/0152
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format json hai. Source https://inputs.example/humidity_pressure/1315 hai. Input database se read karein. Aglay 9 ghanta predict karein. Har 1 ghanta aik observed data point milta hai. Target values percent mein hain. relative humidity for Yarven humidity pressure site 1315 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Diye hue data ka format json hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1315",
    "evidence": "Source https://inputs.example/humidity_pressure/1315 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Aglay 9 ghanta predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target values percent mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "relative humidity for Yarven humidity pressure site 1315",
    "evidence": "relative humidity for Yarven humidity pressure site 1315 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "relative humidity for Yarven humidity pressure site 1315",
    "evidence": "relative humidity for Yarven humidity pressure site 1315 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field measurement_time mein hain. Column rh_pct ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "rh_pct",
    "evidence": "Column rh_pct ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 12 ghanta predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "Aglay 12 ghanta predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Source https://revised.example/humidity_pressure/152 hai. Har 2 ghanta aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/humidity_pressure/152",
    "evidence": "Source https://revised.example/humidity_pressure/152 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0152/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghanta aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261008-r4/humidity_pressure/0166
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for sea-level pressure for Merlow humidity pressure site 1316. Target measurements ki unit hectopascals hai. Each observed record covers 1 hour. Future coverage 13 ghanta chahiye. Select the source from the data catalog. Diya hua source identifier https://inputs.example/humidity_pressure/1316 hai. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sea-level pressure for Merlow humidity pressure site 1316",
    "evidence": "We need an outlook for sea-level pressure for Merlow humidity pressure site 1316."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sea-level pressure for Merlow humidity pressure site 1316",
    "evidence": "We need an outlook for sea-level pressure for Merlow humidity pressure site 1316."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hectopascals",
    "evidence": "Target measurements ki unit hectopascals hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "Future coverage 13 ghanta chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/humidity_pressure/1316",
    "evidence": "Diya hua source identifier https://inputs.example/humidity_pressure/1316 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column pressure_hpa. Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "pressure_hpa",
    "evidence": "The response variable is stored in column pressure_hpa."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

For invalid values, use the policy coerce. minimum coverage ki requirement 86 hai. I expect a repeating seasonal pattern. Weekends aur non-business days exclude na karein. Use these fictional holiday calendars: synthetic reporting holiday. special events ki requirement [{"date": "2026-10-05", "name": "synthetic weather alert"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t3/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "coerce",
    "evidence": "For invalid values, use the policy coerce."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t3/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "minimum coverage ki requirement 86 hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t3/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Weekends aur non-business days exclude na karein."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t3/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "Use these fictional holiday calendars: synthetic reporting holiday."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t3/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic weather alert"
      }
    ],
    "evidence": "special events ki requirement [{\"date\": \"2026-10-05\", \"name\": \"synthetic weather alert\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

These regressors are observed only through the cutoff: lagged_target. known future covariates ki requirement announced_calendar_event hai. The fixed attributes of each series are scope_elevation. covariate availability ki requirement [{"available": "announced before cutoff", "name": "announced_calendar_event"}] hai. The external regressor source mappings are [{"name": "announced_calendar_event", "source": "synthetic_calendar"}]. forecast type ki requirement probabilistic hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t4/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "These regressors are observed only through the cutoff: lagged_target."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t4/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "known future covariates ki requirement announced_calendar_event hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t4/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_elevation"
    ],
    "evidence": "The fixed attributes of each series are scope_elevation."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t4/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "covariate availability ki requirement [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}] hai."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t4/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "The external regressor source mappings are [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}]."
  },
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t4/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 16 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/humidity_pressure/0166/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 16 hours."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
