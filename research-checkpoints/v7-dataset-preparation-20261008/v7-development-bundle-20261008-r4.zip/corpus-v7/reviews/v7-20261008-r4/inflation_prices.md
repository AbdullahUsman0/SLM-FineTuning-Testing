# V7 review examples for inflation_prices

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## mixed core_recall

Scenario: v7-20261008-r4/inflation_prices/0000
Split: train

### t1 initial_multislot

I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600. Target ki unit index points, base 2020=100 hai. The observations are recorded every 1 month. Forecast aglay 10 mahina tak chahiye. Read the input from a database. Data source https://inputs.example/inflation_prices/1600 use karein. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Merlow inflation prices site 1600",
    "evidence": "I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Merlow inflation prices site 1600",
    "evidence": "I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Forecast aglay 10 mahina tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "Data source https://inputs.example/inflation_prices/1600 use karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called cpi_index. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_index",
    "evidence": "The target column is called cpi_index."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 13 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "The forecast should extend 13 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Merlow inflation prices site 1600.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow inflation prices site 1600",
    "evidence": "Our operational goal is prepare a planning reserve for Merlow inflation prices site 1600."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261008-r4/inflation_prices/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. The source is https://inputs.example/inflation_prices/1600. Read the input from a database. I need the next 11 months predicted. There is one observed data point every 1 month. The target values are in percent year over year. The quantity to predict is headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "The source is https://inputs.example/inflation_prices/1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "I need the next 11 months predicted."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "The target values are in percent year over year."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600",
    "evidence": "The quantity to predict is headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600",
    "evidence": "The quantity to predict is headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Use column cpi_yoy as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_yoy",
    "evidence": "Use column cpi_yoy as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per month. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Return forecasts with resolution one prediction row per month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 14 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "I need the next 14 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261008-r4/inflation_prices/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600. Keep the measurement unit as percent month over month. The native sampling interval is 1 month. The forecast horizon is 12 months. Read the input from a database. Read the observations from https://inputs.example/inflation_prices/1600. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600",
    "evidence": "Please predict seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600",
    "evidence": "Please predict seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent month over month",
    "evidence": "Keep the measurement unit as percent month over month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 12 months."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "Read the observations from https://inputs.example/inflation_prices/1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is core_cpi_mom_sa. Use column measurement_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "core_cpi_mom_sa",
    "evidence": "The target field name is core_cpi_mom_sa."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Use column measurement_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 15 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 15 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 months. Read the observations from https://revised.example/inflation_prices/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 2 months."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/inflation_prices/2",
    "evidence": "Read the observations from https://revised.example/inflation_prices/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261008-r4/inflation_prices/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. My source reference is https://inputs.example/inflation_prices/1600. Read the input from a database. Predict a horizon of 13 months. Source observations arrive every 1 month. Use index points, base 2020=100 as the target unit. My prediction target is producer price index level, not consumer prices for Merlow inflation prices site 1600.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "My source reference is https://inputs.example/inflation_prices/1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 13 months."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Merlow inflation prices site 1600",
    "evidence": "My prediction target is producer price index level, not consumer prices for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Merlow inflation prices site 1600",
    "evidence": "My prediction target is producer price index level, not consumer prices for Merlow inflation prices site 1600."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. The seasonal cycles in observation periods are 12. I expect a repeating seasonal pattern. Use timezone UTC.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      12
    ],
    "evidence": "The seasonal cycles in observation periods are 12."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Use timezone UTC."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is measurement_time. Read target values from field ppi_index.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ppi_index",
    "evidence": "Read target values from field ppi_index."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 16 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 16 months."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261008-r4/inflation_prices/0004
Split: train

### t1 initial_multislot

I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600. Measure the target in index points, base 2020=100. The observations are recorded every 1 month. The forecast should extend 14 months ahead. Read the input from a database. Use the data source https://inputs.example/inflation_prices/1600. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Merlow inflation prices site 1600",
    "evidence": "I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Merlow inflation prices site 1600",
    "evidence": "I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Measure the target in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "The forecast should extend 14 months ahead."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "Use the data source https://inputs.example/inflation_prices/1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast should extend 14 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Yes, The forecast should extend 14 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 17 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "The forecast should extend 17 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast should extend 17 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Yes, The forecast should extend 17 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261008-r4/inflation_prices/0005
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format json hai. Source https://inputs.example/inflation_prices/1600 hai. Input database se read karein. Aglay 15 mahina predict karein. Har 1 mahina aik observed data point milta hai. Target values percent year over year mein hain. headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Diye hue data ka format json hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "Source https://inputs.example/inflation_prices/1600 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Aglay 15 mahina predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Target values percent year over year mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600",
    "evidence": "headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600",
    "evidence": "headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field measurement_time mein hain. Column cpi_yoy ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_yoy",
    "evidence": "Column cpi_yoy ko target rakhein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target values percent year over year mein hain. Har 1 mahina aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Target values percent year over year mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 18 mahina predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Aglay 18 mahina predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261008-r4/inflation_prices/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600. Keep the measurement unit as percent month over month. The native sampling interval is 1 month. The forecast horizon is 16 months. Read the input from a database. Read the observations from https://inputs.example/inflation_prices/1600. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600",
    "evidence": "Please predict seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600",
    "evidence": "Please predict seasonally adjusted monthly core CPI change for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent month over month",
    "evidence": "Keep the measurement unit as percent month over month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 16 months."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "Read the observations from https://inputs.example/inflation_prices/1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is core_cpi_mom_sa. Use column measurement_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "core_cpi_mom_sa",
    "evidence": "The target field name is core_cpi_mom_sa."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Use column measurement_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The requested forecast output type is probabilistic. Return forecast quantiles at probabilities 0.1, 0.5, 0.9. The alternative future scenarios are [{"description": "synthetic planning sensitivity", "name": "stress"}]. Round the output according to {"decimal_places": 2}. Make the result granularity one prediction row per month. Rank forecasts by the primary metric mase.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t3/quantiles",
    "slot_id": "quantiles",
    "status": "provided",
    "value": [
      0.1,
      0.5,
      0.9
    ],
    "evidence": "Return forecast quantiles at probabilities 0.1, 0.5, 0.9."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t3/scenario_forecasts",
    "slot_id": "scenario_forecasts",
    "status": "provided",
    "value": [
      {
        "description": "synthetic planning sensitivity",
        "name": "stress"
      }
    ],
    "evidence": "The alternative future scenarios are [{\"description\": \"synthetic planning sensitivity\", \"name\": \"stress\"}]."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t3/rounding_rule",
    "slot_id": "rounding_rule",
    "status": "provided",
    "value": {
      "decimal_places": 2
    },
    "evidence": "Round the output according to {\"decimal_places\": 2}."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Make the result granularity one prediction row per month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t3/primary_metric",
    "slot_id": "primary_metric",
    "status": "provided",
    "value": "mase",
    "evidence": "Rank forecasts by the primary metric mase."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Also report accuracy using rmse, smape. Use rolling_origin validation. Use 4 historical backtest windows. The holdout window length is 3 months. Include naive as the baseline comparison. The acceptable error threshold is {"maximum": 8, "metric": "mae"}.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t4/secondary_metrics",
    "slot_id": "secondary_metrics",
    "status": "provided",
    "value": [
      "rmse",
      "smape"
    ],
    "evidence": "Also report accuracy using rmse, smape."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t4/validation_strategy",
    "slot_id": "validation_strategy",
    "status": "provided",
    "value": "rolling_origin",
    "evidence": "Use rolling_origin validation."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t4/backtest_folds",
    "slot_id": "backtest_folds",
    "status": "provided",
    "value": 4,
    "evidence": "Use 4 historical backtest windows."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t4/test_window",
    "slot_id": "test_window",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "month"
    },
    "evidence": "The holdout window length is 3 months."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t4/baseline_model",
    "slot_id": "baseline_model",
    "status": "provided",
    "value": "naive",
    "evidence": "Include naive as the baseline comparison."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t4/acceptable_error",
    "slot_id": "acceptable_error",
    "status": "provided",
    "value": {
      "maximum": 8,
      "metric": "mae"
    },
    "evidence": "The acceptable error threshold is {\"maximum\": 8, \"metric\": \"mae\"}."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 19 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 19 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

For a separate new request, explain the definition of inflation prices. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261008-r4/inflation_prices/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 17 months. Source observations arrive every 1 month. Use index points, base 2020=100 as the target unit. My prediction target is producer price index level, not consumer prices for Merlow inflation prices site 1600. Do not substitute headline CPI index level, not its growth rate as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 17 months."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Merlow inflation prices site 1600",
    "evidence": "My prediction target is producer price index level, not consumer prices for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Merlow inflation prices site 1600",
    "evidence": "My prediction target is producer price index level, not consumer prices for Merlow inflation prices site 1600."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Read target values from field ppi_index.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ppi_index",
    "evidence": "Read target values from field ppi_index."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is json. My source reference is https://inputs.example/inflation_prices/1600. Read the input from a database.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "My source reference is https://inputs.example/inflation_prices/1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 20 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 20 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261008-r4/inflation_prices/0008
Split: train

### t1 initial_multislot

I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600. Measure the target in index points, base 2020=100. The observations are recorded every 1 month. The forecast should extend 18 months ahead. Read the input from a database. Use the data source https://inputs.example/inflation_prices/1600. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Merlow inflation prices site 1600",
    "evidence": "I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Merlow inflation prices site 1600",
    "evidence": "I need forecasts of headline CPI index level, not its growth rate for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Measure the target in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "The forecast should extend 18 months ahead."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1600",
    "evidence": "Use the data source https://inputs.example/inflation_prices/1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is measurement_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The timestamp column is measurement_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 21 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "The forecast should extend 21 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261008-r4/inflation_prices/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 19 months predicted. The target values are in percent year over year. The quantity to predict is headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "I need the next 19 months predicted."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "The target values are in percent year over year."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600",
    "evidence": "The quantity to predict is headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600",
    "evidence": "The quantity to predict is headline CPI year-over-year inflation rate, not the index level for Merlow inflation prices site 1600."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Refresh the predictions every 1 day. There is one observed data point every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field measurement_time. Use column cpi_yoy as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_yoy",
    "evidence": "Use column cpi_yoy as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 22 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "I need the next 22 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en core_recall

Scenario: v7-20261008-r4/inflation_prices/0020
Split: train

### t1 initial_multislot

Here is what I need.  Please predict headline CPI index level, not its growth rate for Orven inflation prices site 1602. Keep the measurement unit as index points, base 2020=100. The native sampling interval is 1 month. The forecast horizon is 10 months. I will upload the data. Read the observations from inflation_prices_archive_1602.csv. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Orven inflation prices site 1602",
    "evidence": "Please predict headline CPI index level, not its growth rate for Orven inflation prices site 1602."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Orven inflation prices site 1602",
    "evidence": "Please predict headline CPI index level, not its growth rate for Orven inflation prices site 1602."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Keep the measurement unit as index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 10 months."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "inflation_prices_archive_1602.csv",
    "evidence": "Read the observations from inflation_prices_archive_1602.csv."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is cpi_index. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_index",
    "evidence": "The target field name is cpi_index."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 13 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is prepare a planning reserve for Orven inflation prices site 1602.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0020/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven inflation prices site 1602",
    "evidence": "Our operational goal is prepare a planning reserve for Orven inflation prices site 1602."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261008-r4/inflation_prices/0024
Split: train

### t1 initial_multislot

Here is what I need.  Please predict headline CPI index level, not its growth rate for Orven inflation prices site 1602. Measurement unit index points, base 2020=100 rakhein. The native sampling interval is 1 month. Forecast horizon 14 mahina hai. I will upload the data. Observations inflation_prices_archive_1602.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Orven inflation prices site 1602",
    "evidence": "Please predict headline CPI index level, not its growth rate for Orven inflation prices site 1602."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Orven inflation prices site 1602",
    "evidence": "Please predict headline CPI index level, not its growth rate for Orven inflation prices site 1602."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Measurement unit index points, base 2020=100 rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Forecast horizon 14 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "inflation_prices_archive_1602.csv",
    "evidence": "Observations inflation_prices_archive_1602.csv se lein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Yes, The forecast horizon is 14 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Yes, The forecast horizon is 14 months."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 17 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 17 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Yes, The forecast horizon is 17 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0024/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Yes, The forecast horizon is 17 months."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261008-r4/inflation_prices/0025
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is inflation_prices_archive_1602.csv. I will upload the data. Predict a horizon of 15 months. Source observations arrive every 1 month. Use percent year over year as the target unit. My prediction target is headline CPI year-over-year inflation rate, not the index level for Orven inflation prices site 1602.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "inflation_prices_archive_1602.csv",
    "evidence": "My source reference is inflation_prices_archive_1602.csv."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 15 months."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Use percent year over year as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI year-over-year inflation rate, not the index level for Orven inflation prices site 1602",
    "evidence": "My prediction target is headline CPI year-over-year inflation rate, not the index level for Orven inflation prices site 1602."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI year-over-year inflation rate, not the index level for Orven inflation prices site 1602",
    "evidence": "My prediction target is headline CPI year-over-year inflation rate, not the index level for Orven inflation prices site 1602."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field cpi_yoy.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_yoy",
    "evidence": "Read target values from field cpi_yoy."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Use percent year over year as the target unit. Source observations arrive every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Use percent year over year as the target unit."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 18 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0025/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 18 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261008-r4/inflation_prices/0026
Split: train

### t1 initial_multislot

Mujhe seasonally adjusted monthly core CPI change for Orven inflation prices site 1602 ka forecast chahiye. Target ki unit percent month over month hai. Observations har 1 mahina record hoti hain. Forecast aglay 16 mahina tak chahiye. Main data upload karunga. Data source inflation_prices_archive_1602.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Orven inflation prices site 1602",
    "evidence": "Mujhe seasonally adjusted monthly core CPI change for Orven inflation prices site 1602 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Orven inflation prices site 1602",
    "evidence": "Mujhe seasonally adjusted monthly core CPI change for Orven inflation prices site 1602 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent month over month",
    "evidence": "Target ki unit percent month over month hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Forecast aglay 16 mahina tak chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "inflation_prices_archive_1602.csv",
    "evidence": "Data source inflation_prices_archive_1602.csv use karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam core_cpi_mom_sa hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "core_cpi_mom_sa",
    "evidence": "Target column ka naam core_cpi_mom_sa hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

decision supported ki requirement set the contingency allowance for Orven inflation prices site 1602 hai. success criteria ki requirement MAE no more than 2 percent month over month for Alder synthetic inflation prices scope 6 hai. Target column ka naam core_cpi_mom_sa hai. target bounds ki requirement {"max": 1000000, "min": -100} hai. Negative target values allowed hain. aggregation method ki requirement last hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Orven inflation prices site 1602",
    "evidence": "decision supported ki requirement set the contingency allowance for Orven inflation prices site 1602 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 2 percent month over month for Alder synthetic inflation prices scope 6",
    "evidence": "success criteria ki requirement MAE no more than 2 percent month over month for Alder synthetic inflation prices scope 6 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "core_cpi_mom_sa",
    "evidence": "Target column ka naam core_cpi_mom_sa hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t3/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": -100
    },
    "evidence": "target bounds ki requirement {\"max\": 1000000, \"min\": -100} hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values allowed hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t3/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "aggregation method ki requirement last hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Timestamp column sample_date hai. calendar type ki requirement calendar hai. forecast start ki requirement 2026-10-01T00:00:00+00:00 hai. data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai. lead time 1 mahina hai. dataset type ki requirement hierarchical hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "calendar type ki requirement calendar hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "forecast start ki requirement 2026-10-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t4/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t4/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "lead time 1 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t4/dataset_type",
    "slot_id": "dataset_type",
    "status": "provided",
    "value": "hierarchical",
    "evidence": "dataset type ki requirement hierarchical hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 19 mahina tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0026/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "Forecast aglay 19 mahina tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261008-r4/inflation_prices/0032
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/inflation_prices/1603 hai. Input API ke zariye lein. Aglay 12 mahina predict karein. Har 1 mahina aik observed data point milta hai. Target values index points, base 2020=100 mein hain. headline CPI index level, not its growth rate for Pelmar inflation prices site 1603 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1603",
    "evidence": "Source https://inputs.example/inflation_prices/1603 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Aglay 12 mahina predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target values index points, base 2020=100 mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Pelmar inflation prices site 1603",
    "evidence": "headline CPI index level, not its growth rate for Pelmar inflation prices site 1603 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Pelmar inflation prices site 1603",
    "evidence": "headline CPI index level, not its growth rate for Pelmar inflation prices site 1603 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field observed_time mein hain. Column cpi_index ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates field observed_time mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_index",
    "evidence": "Column cpi_index ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 15 mahina predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Aglay 15 mahina predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Source https://revised.example/inflation_prices/32 hai. Har 2 mahina aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/inflation_prices/32",
    "evidence": "Source https://revised.example/inflation_prices/32 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0032/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Har 2 mahina aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261008-r4/inflation_prices/0038
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. Mera source reference https://inputs.example/inflation_prices/1603 hai. Access the input through an API. 18 mahina ka horizon rakhein. Source observations arrive every 1 month. Target ko percent month over month mein measure karein. My prediction target is seasonally adjusted monthly core CPI change for Pelmar inflation prices site 1603.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1603",
    "evidence": "Mera source reference https://inputs.example/inflation_prices/1603 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "18 mahina ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent month over month",
    "evidence": "Target ko percent month over month mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Pelmar inflation prices site 1603",
    "evidence": "My prediction target is seasonally adjusted monthly core CPI change for Pelmar inflation prices site 1603."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Pelmar inflation prices site 1603",
    "evidence": "My prediction target is seasonally adjusted monthly core CPI change for Pelmar inflation prices site 1603."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The time field name is observed_time. Target values field value "net" se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "Target values field value \"net\" se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are valid. Source mein confidential synthetic records hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values are valid."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 21 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0038/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 21 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261008-r4/inflation_prices/0046
Split: train

### t1 initial_multislot

Here is what I need.  Please predict seasonally adjusted monthly core CPI change for Talven inflation prices site 1604. Measurement unit percent month over month rakhein. The native sampling interval is 1 month. Forecast horizon 16 mahina hai. Read the input from a database. Observations https://inputs.example/inflation_prices/1604 se lein. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Talven inflation prices site 1604",
    "evidence": "Please predict seasonally adjusted monthly core CPI change for Talven inflation prices site 1604."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Talven inflation prices site 1604",
    "evidence": "Please predict seasonally adjusted monthly core CPI change for Talven inflation prices site 1604."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent month over month",
    "evidence": "Measurement unit percent month over month rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Forecast horizon 16 mahina hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1604",
    "evidence": "Observations https://inputs.example/inflation_prices/1604 se lein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is core_cpi_mom_sa. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "core_cpi_mom_sa",
    "evidence": "The target field name is core_cpi_mom_sa."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

For missing target values, use the policy interpolate. duplicate policy ki requirement latest hai. For unusual values, use the policy cap. invalid value policy ki requirement coerce hai. Require non-missing coverage of at least 86 percent. Repeating seasonal pattern expect karta hoon.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t3/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "interpolate",
    "evidence": "For missing target values, use the policy interpolate."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t3/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "latest",
    "evidence": "duplicate policy ki requirement latest hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t3/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "For unusual values, use the policy cap."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t3/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "coerce",
    "evidence": "invalid value policy ki requirement coerce hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t3/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "Require non-missing coverage of at least 86 percent."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Do not exclude weekends or non-business days. holidays ki requirement synthetic reporting holiday hai. The known special events are [{"date": "2026-10-05", "name": "synthetic scheduled data release"}]. past covariates ki requirement lagged_target hai. These regressors are known for future periods: announced_calendar_event. static features ki requirement scope_sector hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t4/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Do not exclude weekends or non-business days."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t4/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "holidays ki requirement synthetic reporting holiday hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t4/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "The known special events are [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}]."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t4/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "past covariates ki requirement lagged_target hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t4/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "These regressors are known for future periods: announced_calendar_event."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t4/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_sector"
    ],
    "evidence": "static features ki requirement scope_sector hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 19 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0046/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 19 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261008-r4/inflation_prices/0047
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  17 mahina ka horizon rakhein. Source observations har 1 mahina aati hain. Target ko index points, base 2020=100 mein measure karein. producer price index level, not consumer prices for Talven inflation prices site 1604 ke liye prediction bana dein. headline CPI index level, not its growth rate nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "17 mahina ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Talven inflation prices site 1604",
    "evidence": "producer price index level, not consumer prices for Talven inflation prices site 1604 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Talven inflation prices site 1604",
    "evidence": "producer price index level, not consumer prices for Talven inflation prices site 1604 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam measurement_time hai. Target values field ppi_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ppi_index",
    "evidence": "Target values field ppi_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Source serialization format json hai. Mera source reference https://inputs.example/inflation_prices/1604 hai. Input database se read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Source serialization format json hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1604",
    "evidence": "Mera source reference https://inputs.example/inflation_prices/1604 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 20 mahina ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0047/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "20 mahina ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261008-r4/inflation_prices/0052
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. Mera source reference https://inputs.example/inflation_prices/1605 hai. Select the source from the data catalog. 12 mahina ka horizon rakhein. Source observations arrive every 1 month. Target ko index points, base 2020=100 mein measure karein. My prediction target is headline CPI index level, not its growth rate for Virelo inflation prices site 1605.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1605",
    "evidence": "Mera source reference https://inputs.example/inflation_prices/1605 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "12 mahina ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Virelo inflation prices site 1605",
    "evidence": "My prediction target is headline CPI index level, not its growth rate for Virelo inflation prices site 1605."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Virelo inflation prices site 1605",
    "evidence": "My prediction target is headline CPI index level, not its growth rate for Virelo inflation prices site 1605."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Target values field cpi_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_index",
    "evidence": "Target values field cpi_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 15 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 15 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/inflation_prices/52. Source observations har 2 mahina aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/inflation_prices/52",
    "evidence": "My source reference is https://revised.example/inflation_prices/52."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0052/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Source observations har 2 mahina aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261008-r4/inflation_prices/0058
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format xlsx hai. Source https://inputs.example/inflation_prices/1605 hai. Source data catalog se select karein. Aglay 18 mahina predict karein. Har 1 mahina aik observed data point milta hai. Target values percent month over month mein hain. seasonally adjusted monthly core CPI change for Virelo inflation prices site 1605 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Diye hue data ka format xlsx hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1605",
    "evidence": "Source https://inputs.example/inflation_prices/1605 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Aglay 18 mahina predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent month over month",
    "evidence": "Target values percent month over month mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Virelo inflation prices site 1605",
    "evidence": "seasonally adjusted monthly core CPI change for Virelo inflation prices site 1605 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Virelo inflation prices site 1605",
    "evidence": "seasonally adjusted monthly core CPI change for Virelo inflation prices site 1605 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates field recorded_at mein hain. Column true ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates field recorded_at mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Column true ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values allowed hain. Source mein confidential synthetic records hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values allowed hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 21 mahina predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0058/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "Aglay 21 mahina predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261008-r4/inflation_prices/0067
Split: train

### t1 initial_multislot

For my request,  I need the next 17 months predicted. Har 1 mahina aik observed data point milta hai. The target values are in index points, base 2020=100. producer price index level, not consumer prices for Weslin inflation prices site 1606 predict karna hai. Do not substitute headline CPI index level, not its growth rate as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "I need the next 17 months predicted."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "The target values are in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Weslin inflation prices site 1606",
    "evidence": "producer price index level, not consumer prices for Weslin inflation prices site 1606 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Weslin inflation prices site 1606",
    "evidence": "producer price index level, not consumer prices for Weslin inflation prices site 1606 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Column ppi_index ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ppi_index",
    "evidence": "Column ppi_index ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is csv. Source inflation_prices_archive_1606.csv hai. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "inflation_prices_archive_1606.csv",
    "evidence": "Source inflation_prices_archive_1606.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 20 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0067/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "I need the next 20 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261008-r4/inflation_prices/0075
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for producer price index level, not consumer prices for Yarven inflation prices site 1607. Target measurements ki unit index points, base 2020=100 hai. Each observed record covers 1 month. Future coverage 15 mahina chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/inflation_prices/1607 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Yarven inflation prices site 1607",
    "evidence": "We need an outlook for producer price index level, not consumer prices for Yarven inflation prices site 1607."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Yarven inflation prices site 1607",
    "evidence": "We need an outlook for producer price index level, not consumer prices for Yarven inflation prices site 1607."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Future coverage 15 mahina chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1607",
    "evidence": "Diya hua source identifier https://inputs.example/inflation_prices/1607 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column ppi_index. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ppi_index",
    "evidence": "The response variable is stored in column ppi_index."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Each observed record covers 1 month. Target measurements ki unit index points, base 2020=100 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements ki unit index points, base 2020=100 hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 18 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0075/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 18 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261008-r4/inflation_prices/0094
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format xlsx hai. Source https://inputs.example/inflation_prices/1609 hai. Source data catalog se select karein. Aglay 14 mahina predict karein. Har 1 mahina aik observed data point milta hai. Target values percent month over month mein hain. seasonally adjusted monthly core CPI change for Norelia inflation prices site 1609 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Diye hue data ka format xlsx hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1609",
    "evidence": "Source https://inputs.example/inflation_prices/1609 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Aglay 14 mahina predict karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent month over month",
    "evidence": "Target values percent month over month mein hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Norelia inflation prices site 1609",
    "evidence": "seasonally adjusted monthly core CPI change for Norelia inflation prices site 1609 predict karna hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "seasonally adjusted monthly core CPI change for Norelia inflation prices site 1609",
    "evidence": "seasonally adjusted monthly core CPI change for Norelia inflation prices site 1609 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Haan, Aglay 14 mahina predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Haan, Aglay 14 mahina predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 17 mahina predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Aglay 17 mahina predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Haan, Aglay 17 mahina predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0094/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Haan, Aglay 17 mahina predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261008-r4/inflation_prices/0123
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format json hai. Mera source reference https://inputs.example/inflation_prices/1612 hai. Input database se read karein. 13 mahina ka horizon rakhein. Source observations har 1 mahina aati hain. Target ko index points, base 2020=100 mein measure karein. producer price index level, not consumer prices for Talven inflation prices site 1612 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Source serialization format json hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/inflation_prices/1612",
    "evidence": "Mera source reference https://inputs.example/inflation_prices/1612 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "13 mahina ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Talven inflation prices site 1612",
    "evidence": "producer price index level, not consumer prices for Talven inflation prices site 1612 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Talven inflation prices site 1612",
    "evidence": "producer price index level, not consumer prices for Talven inflation prices site 1612 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

prediction interval levels ki requirement 80, 95 hai. forecast type ki requirement probabilistic hai. seasonal periods ki requirement 12 hai. Repeating seasonal pattern expect karta hoon. Timezone UTC use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      12
    ],
    "evidence": "seasonal periods ki requirement 12 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Timezone UTC use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Time field ka naam measurement_time hai. Target values field ppi_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ppi_index",
    "evidence": "Target values field ppi_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. 16 mahina ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0123/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "16 mahina ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261008-r4/inflation_prices/0139
Split: train

### t1 initial_multislot

Here is what I need.  Please predict producer price index level, not consumer prices for Virelo inflation prices site 1613. Measurement unit index points, base 2020=100 rakhein. The forecast horizon is 19 months. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Virelo inflation prices site 1613",
    "evidence": "Please predict producer price index level, not consumer prices for Virelo inflation prices site 1613."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Virelo inflation prices site 1613",
    "evidence": "Please predict producer price index level, not consumer prices for Virelo inflation prices site 1613."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Measurement unit index points, base 2020=100 rakhein."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 19 months."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The native sampling interval is 1 month. Forecast generation har 2 din run karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Forecast generation har 2 din run karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target field name is ppi_index. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ppi_index",
    "evidence": "The target field name is ppi_index."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 22 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0139/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 22 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of inflation prices. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261008-r4/inflation_prices/0140
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein headline CPI index level, not its growth rate for Weslin inflation prices site 1614 ka outlook chahiye. Target measurements ki unit index points, base 2020=100 hai. Har observed record 1 mahina cover karta hai. Future coverage 10 mahina chahiye. Main data upload karunga. Diya hua source identifier inflation_prices_archive_1614.csv hai. Input container csv use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Weslin inflation prices site 1614",
    "evidence": "Hamein headline CPI index level, not its growth rate for Weslin inflation prices site 1614 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "headline CPI index level, not its growth rate for Weslin inflation prices site 1614",
    "evidence": "Hamein headline CPI index level, not its growth rate for Weslin inflation prices site 1614 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har observed record 1 mahina cover karta hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Future coverage 10 mahina chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "inflation_prices_archive_1614.csv",
    "evidence": "Diya hua source identifier inflation_prices_archive_1614.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input container csv use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column cpi_index mein hai. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cpi_index",
    "evidence": "Response variable column cpi_index mein hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 13 mahina chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Future coverage 13 mahina chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Weslin inflation prices site 1614 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0140/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Weslin inflation prices site 1614",
    "evidence": "business goal ki requirement prepare a planning reserve for Weslin inflation prices site 1614 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: inflation prices ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261008-r4/inflation_prices/0143
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for producer price index level, not consumer prices for Weslin inflation prices site 1614. Target measurements ki unit index points, base 2020=100 hai. Each observed record covers 1 month. Future coverage 13 mahina chahiye. I will upload the data. Diya hua source identifier inflation_prices_archive_1614.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Weslin inflation prices site 1614",
    "evidence": "We need an outlook for producer price index level, not consumer prices for Weslin inflation prices site 1614."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "producer price index level, not consumer prices for Weslin inflation prices site 1614",
    "evidence": "We need an outlook for producer price index level, not consumer prices for Weslin inflation prices site 1614."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Future coverage 13 mahina chahiye."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "inflation_prices_archive_1614.csv",
    "evidence": "Diya hua source identifier inflation_prices_archive_1614.csv hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

All observed times use the Europe/London timezone. Repeating seasonal pattern expect karta hoon. The seasonal cycles in observation periods are 12. forecast type ki requirement probabilistic hai. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "All observed times use the Europe/London timezone."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      12
    ],
    "evidence": "The seasonal cycles in observation periods are 12."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The response variable is stored in column ppi_index. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ppi_index",
    "evidence": "The response variable is stored in column ppi_index."
  },
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 16 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261008-r4/inflation_prices/0143/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 16 months."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending
