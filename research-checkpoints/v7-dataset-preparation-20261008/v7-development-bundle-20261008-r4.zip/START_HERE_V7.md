# Standalone v7 development bundle

Extract into a NEW directory and work there. It contains a research snapshot,
not changes to your live FYP application. All human decisions are pending.

Read corpus-v7/README.md and V7_DATASET_PLAN_2026-10-08.md first. Install the
small data-check dependencies in your chosen environment:

python -m pip install -r requirements-v7-data.txt
python scripts/verify-corpus-v7.py --output corpus-v7/v7-20261008-r4
python -m unittest discover -s tests -p test_corpus_v7.py

The pinned fpy source is included under runtime/fpy-v6-pinned/src and validated
by 31 source hashes. The live sibling fpy is not required for these checks.
The frozen policy's old 31/32 development cases are included ONLY to protect
against copying and to validate the parser lock, not as v7 training records.

The 524-case review sample and blank decisions are under corpus-v7/reviews/.
The approval template is FALSE, not an approval. Review the 35 flagged nearest
neighbors and actual labels before materialization. The PDF explains v1-v6,
A-F/J, historical parser effects and the fresh four-model comparison.

The cached tokenizer preflight has passed for every development row, with zero
examples above 3584 tokens. On another environment repeat that preflight in a
NEW output file after installing the training requirements; tokenizer files are
downloaded at the pinned revision only with --allow-tokenizer-download.

No final-label files, weights, adapters, API keys or production database are
included. Do not run build-corpus-v7.py on the frozen paths: it refuses overwrite.
Sealed final labels stay on the originating machine. A new v7 extraction-only
evaluation protocol, independent human natural cohort and model training remain
pending. No old scorer/cohort files should be changed to pretend a new result.
