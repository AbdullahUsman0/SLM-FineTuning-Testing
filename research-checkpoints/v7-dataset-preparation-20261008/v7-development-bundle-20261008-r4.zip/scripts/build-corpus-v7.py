"""Build a new immutable v7 candidate with exact domain/language quotas."""
import argparse
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
# Load pinned package before legacy corpus.py considers the live sibling fpy.
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.corpus_v7 import build_artifacts

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--sealed-output',type=Path,required=True)
    p.add_argument('--per-domain',type=int,default=200)
    a=p.parse_args(); m=build_artifacts(a.output,a.sealed_output,a.per_domain)
    print(json.dumps({'status':m['build_status'],'statistics':{k:m['statistics'][k] for k in ('source_scenarios','development_sft_examples','languages_by_split','domain_families_by_split')}},indent=2))
