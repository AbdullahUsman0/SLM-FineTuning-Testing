"""Pending human decisions must not release or start training."""
from pathlib import Path
import importlib.util
import json
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
spec=importlib.util.spec_from_file_location('v7_materializer',ROOT/'scripts/materialize-v7-training.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)


class ReviewGateTests(unittest.TestCase):
    def test_pending_actual_review_cannot_materialize_inputs(self):
        corpus=ROOT/'corpus-v7/v7-20261008-r4'
        review=ROOT/'corpus-v7/reviews/v7-20261008-r4'
        if not corpus.exists() or not review.exists(): self.skipTest('Candidate build required for integration gate test')
        # A temporary unsignable pending record, not a human approval.
        with tempfile.TemporaryDirectory(prefix='v7-review-gate-') as tmp:
            tmp=Path(tmp); approval=tmp/'pending.json'; preflight=tmp/'preflight.json'
            approval.write_text(json.dumps({'corpus_manifest_sha256':module.bytes_record(corpus/'manifest.json')['sha256'],
              'decision_ledger_sha256':module.bytes_record(review/'decisions.csv')['sha256'],
              'rubric_sha256':module.bytes_record(ROOT/'corpus-v7/ANNOTATION_RUBRIC.md')['sha256'],
              'review_complete':False,'overlap_review_complete':False}),encoding='utf-8')
            preflight.write_text('{}',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'reviews are still pending'):
                module.materialize(corpus,review,approval,preflight,tmp/'inputs')
            self.assertFalse((tmp/'inputs').exists())


if __name__=='__main__': unittest.main()
