"""Semantic safeguards for fact-ledger supervision, not generation quality tests."""
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.comparison_policy import ComparisonPolicy
from local_slm_lab import corpus_v7 as corpus


class V7SemanticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema=load_schema(); cls.policy=ComparisonPolicy()
        cls.plan=corpus.freeze_plan()
        cls.cases=[corpus.build_scenario(r,cls.schema,cls.policy) for r in cls.plan['assignments'][:10]]

    def test_split_and_language_quotas_and_group_exclusion(self):
        rows=self.plan['assignments']; groups=defaultdict(set)
        self.assertEqual(Counter(r['split'] for r in rows),{'train':2800,'validation':600,'final':600})
        self.assertEqual(Counter(r['domain_family'] for r in rows),{'weather':1200,'economics':2400,'combined':400})
        for split,total in [('train',2800),('validation',600),('final',600)]:
            self.assertEqual(Counter(r['language'] for r in rows if r['split']==split),{'en':total*.8,'ur':total*.1,'mixed':total*.1})
        for r in rows: groups[r['contrast_group']].add(r['split'])
        self.assertTrue(all(len(s)==1 for s in groups.values()))
        self.assertEqual(self.plan,corpus.freeze_plan())

    def test_all_gold_replays_with_exact_evidence(self):
        for case in self.cases: corpus.validate_scenario(case,self.schema,self.policy)

    def test_unknown_does_not_fill_or_remove_old_values(self):
        for case in self.cases:
            for turn in case['turns']:
                if turn['behavior']=='unknown_omission':
                    self.assertEqual(turn['gold_extraction']['updates'],[])
                    # Top-level intent may update the intent slot's metadata only.
                    self.assertEqual({k:v for k,v in turn['context_state'].items() if k!='intent'},
                                     {k:v for k,v in turn['expected_state_after'].items() if k!='intent'})

    def test_target_phrase_supports_both_slots_not_a_guessed_column(self):
        turn=self.cases[0]['turns'][0]; updates=turn['gold_extraction']['updates']
        mapping={u['slot_id']:u for u in updates}
        self.assertEqual(mapping['target_description']['candidate_value'],mapping['problem_statement']['candidate_value'])
        self.assertNotIn('target_column',mapping)

    def test_confirmation_and_replacement_have_distinct_status(self):
        case=self.cases[4]
        for turn in case['turns']:
            if 'confirmation' in turn['behavior']:
                self.assertTrue(all(u['status']=='confirmed' for u in turn['gold_extraction']['updates']))
                self.assertFalse(turn['gold_extraction']['correction_detected'])
            if turn['behavior']=='targeted_replacement':
                self.assertEqual([u['slot_id'] for u in turn['gold_extraction']['updates']],['forecast_horizon'])
                self.assertTrue(turn['gold_extraction']['correction_detected'])
                self.assertEqual(turn['gold_extraction']['updates'][0]['status'],'provided')

    def test_repair_needs_new_evidence_and_records_corruption(self):
        case=self.cases[5]; repair=case['turns'][2]
        self.assertNotIn('target_unit',repair['context_state'])
        self.assertEqual(case['turns'][1]['state_intervention']['mutations'][0]['kind'],'wrong_prior_value')
        repaired={u['slot_id'] for u in repair['gold_extraction']['updates']}
        self.assertEqual(repaired,{'frequency','target_unit'})
        for span in repair['evidence_spans']: self.assertIn(span['text'],repair['message'])

    def test_ambiguous_cadence_is_not_guessed(self):
        initial=self.cases[9]['turns'][0]
        self.assertNotIn('frequency',[u['slot_id'] for u in initial['gold_extraction']['updates']])
        self.assertNotIn('prediction_frequency',[u['slot_id'] for u in initial['gold_extraction']['updates']])

    def test_mutated_labels_and_context_fail_verification(self):
        case=deepcopy(self.cases[0]); case['turns'][0]['gold_extraction']['updates'][0]['candidate_value']='"invented"'
        with self.assertRaises(ValueError): corpus.validate_scenario(case,self.schema,self.policy)
        case=deepcopy(self.cases[0]); case['turns'][1]['context_state']['forecast_horizon']['value']['periods']=999
        with self.assertRaises(ValueError): corpus.validate_scenario(case,self.schema,self.policy)
        case=deepcopy(self.cases[0]); case['turns'][0]['gold_extraction']['updates'][0]['evidence_text']='Assistant said this'
        with self.assertRaises(ValueError): corpus.validate_scenario(case,self.schema,self.policy)

    def test_extract_only_and_no_credential_targets(self):
        for case in self.cases:
            for example in corpus.sft_examples(case,self.schema):
                self.assertEqual(example['metadata']['task'],'extract')
                self.assertNotIn('authentication_reference',[f['slot_id'] for t in case['turns'] for f in t['facts']])

    def test_literals_decode_exactly_once(self):
        rows=[r for r in self.plan['assignments'] if r['category']=='encoding_literal' and r['domain_index']==0][:4]
        for row in rows:
            case=corpus.build_scenario(row,self.schema,self.policy)
            turn=case['turns'][1]; admitted=self.policy.parse(corpus.dumps(turn['gold_extraction']),'extract')
            value=next(u['candidate_value'] for u in admitted.predicted['updates'] if u['slot_id']=='target_column')
            self.assertIsInstance(value,str)

    def test_filename_does_not_supply_access_mode_or_format(self):
        row=next(r for r in self.plan['assignments'] if r['category']=='core_recall' and (r['index']//10+r['domain_index'])%2)
        case=corpus.build_scenario(row,self.schema,self.policy)
        initial={f['slot_id'] for f in case['turns'][0]['facts']}
        self.assertIn('source_reference',initial)
        self.assertNotIn('source_mode',initial); self.assertNotIn('file_format',initial)
        added={f['slot_id'] for f in case['turns'][1]['facts']}
        self.assertIn('source_mode',added); self.assertIn('file_format',added)

    def test_unknown_controls_do_not_withdraw_known_values(self):
        for case in self.cases:
            for turn in case['turns']:
                if turn['behavior']=='unknown_omission':
                    self.assertTrue(all(s not in turn['context_state'] for s in turn['forbidden_slots']))

    def test_negative_intent_does_not_emit_invented_requirements(self):
        controls=[t for c in self.cases for t in c['turns'] if t['behavior']=='explicit_nonforecasting']
        self.assertTrue(controls)
        for t in controls:
            self.assertEqual(t['gold_extraction']['intent'],'not_forecasting')
            self.assertEqual(t['gold_extraction']['updates'],[])

    def test_index_levels_and_binary_events_are_nonnegative(self):
        for domain in ('inflation_prices','weather_extremes'):
            for row in [r for r in self.plan['assignments'] if r['domain']==domain][:12]:
                values=corpus.source_values(row,self.schema)
                if values['target_column'] in ('cpi_index','ppi_index','heatwave_flag','heavy_rain_flag','frost_days','gust_flag'):
                    self.assertFalse(values['allow_negative_values'])
                    self.assertGreaterEqual(values['target_bounds']['min'],0)
                if values['target_unit']=='0 or 1': self.assertEqual(values['target_bounds'],{'min':0,'max':1})

    def test_explicit_no_seasonality_does_not_invent_cycle_lengths(self):
        row=next(r for r in self.plan['assignments'] if r['category']=='unknown_then_value' and (r['index']//10+r['domain_index'])%2)
        case=corpus.build_scenario(row,self.schema,self.policy)
        resolution=case['turns'][2]; mapping={f['slot_id']:f['value'] for f in resolution['facts']}
        self.assertFalse(mapping['known_seasonality'])
        self.assertNotIn('seasonal_periods',mapping)


if __name__=='__main__': unittest.main()
