"""Pinned generation with the versioned user-approved v7 extraction prompt."""
from local_slm_lab.v5_provider import V5TransformersProvider
from local_slm_lab.v7_prompts import build_v7_extractor_instructions,build_v7_extractor_input
from forecasting_assistant.domain.models import ExtractorResult

class V7TransformersProvider(V5TransformersProvider):
    name='v7_transformers_raw'

    async def extract(self,message,state):
        return self._structured('extract',build_v7_extractor_instructions(),
            build_v7_extractor_input(message,state,self.schema),ExtractorResult)
