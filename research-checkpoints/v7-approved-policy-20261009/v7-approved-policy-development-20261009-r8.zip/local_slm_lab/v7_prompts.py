"""Versioned extractor instructions for the user's approved v7 conventions."""
from local_slm_lab.v5_prompts import build_v5_extractor_instructions,build_v5_extractor_input

PROMPT_VERSION='v7-user-approved-extraction-1'

def build_v7_extractor_instructions():
    return build_v5_extractor_instructions()+(
        '\nApply annotation policy v7-user-approved-annotation-1. '
        'An explicitly described forecasting target supports both problem_statement and '
        'target_description using the same exact meaningful target noun phrase. '
        'A column name alone does not establish its domain meaning. '
        'A clear filename extension .csv, .json, .parquet or .xlsx supports file_format '
        'with status inferred; match extensions case-insensitively and ignore URL queries. '
        'An explicit format declaration uses provided and may upgrade inferred to provided. '
        'Do not guess a format for extensionless or unsupported names. '
        'Do not infer source_mode, columns, contents, privacy or credentials from a filename. '
        'Explicit confirmation of the same recorded value uses confirmed and is an '
        'exception to omission of unchanged prior state. Otherwise omit unchanged value '
        'and status. Replacements use provided and correction_detected true. '
        'An unresolved sampling-versus-generation cadence supplies neither cadence slot '
        'until resolved. Unknown information gives no update. '
        'Apply these same rules to English, Roman Urdu and mixed requests. '
        'Keep rejected alternatives outside positive target values.'
    )

def build_v7_extractor_input(message,state,schema):
    return build_v5_extractor_input(message,state,schema)
