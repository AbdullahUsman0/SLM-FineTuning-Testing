"""Verify the accepted filename/status policy without model weights or APIs."""
import asyncio,importlib.util,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import Mock
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
from forecasting_assistant.domain.schema import load_schema,create_initial_state
from local_slm_lab.comparison_policy import ComparisonPolicy
from local_slm_lab import corpus_v7_reviewed_r8 as corpus
from local_slm_lab.v7_prompts import PROMPT_VERSION,build_v7_extractor_instructions

class ApprovedPolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema=load_schema();cls.policy=ComparisonPolicy()
        cls.rows=[r for r in corpus.freeze_plan()['assignments'] if r['split']!='final']

    def test_filename_formats_and_non_format_queries(self):
        for name,expected in [('weather.csv','csv'),('WEATHER.CSV','csv'),('price.parquet','parquet'),
                              ('history.JSON','json'),('book.xlsx','xlsx'),
                              ('https://data.example/weather.csv?download=1','csv'),
                              ('https://data.example/input?format=csv',None),('weather',None),
                              ('weather.unknown',None),('weather.csv.gz',None)]:
            with self.subTest(name=name):self.assertEqual(corpus.filename_format(name),expected)

    def test_all_supported_formats_have_inferred_development_examples(self):
        seen=set();languages=set();cases=[]
        for row in self.rows:
            if row['category']!='core_recall':continue
            case=corpus.build_scenario(row,self.schema,self.policy)
            corpus.validate_scenario(case,self.schema,self.policy);corpus.reviewed_semantic_checks(case)
            first=case['turns'][0];facts={f['slot_id']:f for f in first['facts']}
            if facts.get('file_format',{}).get('status')=='inferred':
                seen.add(facts['file_format']['value']);languages.add(row['language']);cases.append(case)
                self.assertNotIn('source_mode',facts)
        self.assertEqual(seen,{'csv','json','parquet','xlsx'})
        self.assertEqual(languages,{'en','ur','mixed'})
        for case in cases:
            later=case['turns'][1]
            fmt=next(f for f in later['facts'] if f['slot_id']=='file_format')
            self.assertEqual(later['context_state']['file_format']['status'],'inferred')
            self.assertEqual(fmt['status'],'provided')
            self.assertFalse(later['gold_extraction']['correction_detected'])
            self.assertEqual(later['expected_state_after']['file_format']['status'],'provided')

    def test_extensionless_and_unknown_names_do_not_infer_format(self):
        checked=0
        for r in self.rows:
            if r['category']!='core_recall' or r['index']//10%4!=2:continue
            case=corpus.build_scenario(r,self.schema,self.policy)
            self.assertNotIn('file_format',[f['slot_id'] for f in case['turns'][0]['facts']]);checked+=1
        self.assertGreater(checked,0)

    def test_mislabeled_inference_is_rejected(self):
        row=next(r for r in self.rows if r['category']=='core_recall' and r['index']//10%4==1)
        case=corpus.build_scenario(row,self.schema,self.policy)
        fmt=next(f for f in case['turns'][0]['facts'] if f['slot_id']=='file_format')
        fmt['status']='provided'
        with self.assertRaisesRegex(ValueError,'mislabeled'):corpus.reviewed_semantic_checks(case)

    def test_policy_and_sft_prompt_match(self):
        record=json.loads((ROOT/'corpus-v7/policies/v7-user-approved-annotation-1.json').read_bytes())
        self.assertTrue(all(v['decision']=='approved' for v in record['rules'].values()))
        self.assertFalse(record['human_sample_review_complete']);self.assertFalse(record['training_approved'])
        row=self.rows[0];case=corpus.build_scenario(row,self.schema,self.policy)
        example=next(corpus.sft_examples(case,self.schema))
        self.assertEqual(example['messages'][0]['content'],build_v7_extractor_instructions())
        self.assertEqual(case['prompt_version'],PROMPT_VERSION)

    def test_runtime_provider_uses_the_training_prompt(self):
        from local_slm_lab.v7_provider import V7TransformersProvider
        provider=object.__new__(V7TransformersProvider);provider.schema=self.schema
        provider._structured=Mock(return_value='test-only-result')
        result=asyncio.run(provider.extract('My source is weather.csv.',create_initial_state(self.schema)))
        self.assertEqual(result,'test-only-result')
        self.assertEqual(provider._structured.call_args.args[1],build_v7_extractor_instructions())

    def test_policy_agreement_cannot_release_pending_sample(self):
        corpus_path=ROOT/'corpus-v7/v7-20261009-r8-dev';review=ROOT/'corpus-v7/reviews/v7-20261009-r8-dev'
        if not review.exists():self.skipTest('New review export required')
        spec=importlib.util.spec_from_file_location('approved_v7_gate',ROOT/'scripts/materialize-v7-training.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        manifest=json.loads((corpus_path/'manifest.json').read_bytes())
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp);approval=tmp/'unsignable-fixture.json';preflight=tmp/'length.json'
            approval.write_text(json.dumps({'corpus_manifest_sha256':module.bytes_record(corpus_path/'manifest.json')['sha256'],
                'decision_ledger_sha256':module.bytes_record(review/'decisions.csv')['sha256'],
                'rubric_sha256':module.bytes_record(corpus_path/manifest['annotation_rubric_file'])['sha256'],
                'annotation_policy_sha256':module.bytes_record(corpus_path/manifest['annotation_policy_file'])['sha256'],
                'review_complete':False,'overlap_review_complete':False}),encoding='utf-8')
            preflight.write_text('{}',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'reviews are still pending'):
                module.materialize(corpus_path,review,approval,preflight,tmp/'inputs')
            self.assertFalse((tmp/'inputs').exists())

if __name__=='__main__':unittest.main()
