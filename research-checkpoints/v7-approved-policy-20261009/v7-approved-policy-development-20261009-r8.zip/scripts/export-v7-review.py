"""Produce readable development examples and blank decisions, without final data."""
import argparse
import csv
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.corpus_v7 import read_gzip, bytes_record, verify_artifacts


def export(corpus,output):
    if output.exists(): raise FileExistsError('Review export exists')
    output.mkdir(parents=True)
    manifest=json.loads((corpus/'manifest.json').read_bytes())
    expected=manifest['files']['review-sample.jsonl.gz']
    if bytes_record(corpus/'review-sample.jsonl.gz')!={k:expected[k] for k in ('sha256','bytes')}: raise ValueError('Sample hash mismatch')
    sample=list(read_gzip(corpus/'review-sample.jsonl.gz')); rows=[]; index=[]
    for case in sample:
        if case['split']=='final': raise ValueError('Final label export forbidden')
        group=case['domain']; path=output/(group+'.md')
        if not path.exists(): path.write_text(f'# V7 review examples for {group}\n\nAll decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.\n',encoding='utf-8')
        blocks=[f"\n## {case['language']} {case['category']}\n",f"Scenario: {case['scenario_id']}\nSplit: {case['split']}\n"]
        for t in case['turns']:
            blocks += [f"### {t['turn_id']} {t['behavior']}\n",t['message']+'\n',
                       'Expected decoded updates\n', '```json\n'+json.dumps([dict(f, evidence=sp['text']) for f,sp in zip(t['facts'],t['evidence_spans'])],ensure_ascii=False,indent=2)+'\n```\n']
            if t['state_intervention']: blocks.append('Synthetic prior-state intervention: '+json.dumps(t['state_intervention'])+'\n')
            blocks.append(f"Intent: {t['gold_extraction']['intent']}; correction: {t['gold_extraction']['correction_detected']}\n")
        blocks.append('Human decision and rationale: pending\n')
        with path.open('a',encoding='utf-8',newline='\n') as stream: stream.write('\n'.join(blocks))
        rows.append({'scenario_id':case['scenario_id'],'domain':group,'language':case['language'],'category':case['category'],
                     'split':case['split'],'decision':'pending','reviewer':'','reviewed_utc':'','rationale':''})
        index.append(case['scenario_id'])
    with (output/'decisions.csv').open('x',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    review_manifest={'corpus_manifest_sha256':bytes_record(corpus/'manifest.json')['sha256'],
        'sample_scenarios':len(sample),'scenario_ids':index,'human_review':'pending','final_labels_accessed':False}
    if manifest.get('annotation_policy_file'):
        review_manifest['annotation_policy_sha256']=bytes_record(corpus/manifest['annotation_policy_file'])['sha256']
        review_manifest['rubric_sha256']=bytes_record(corpus/manifest['annotation_rubric_file'])['sha256']
    (output/'review-manifest.json').write_text(json.dumps(review_manifest,indent=2)+'\n',encoding='utf-8')
    return {'review_scenarios':len(sample),'domain_files':len({c['domain'] for c in sample}),'human_review':'pending'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--corpus',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); print(json.dumps(export(a.corpus,a.output),indent=2))
