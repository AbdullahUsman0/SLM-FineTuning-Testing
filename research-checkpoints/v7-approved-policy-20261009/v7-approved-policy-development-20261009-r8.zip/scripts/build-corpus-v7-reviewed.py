"""Build/verify the corrected development revision, never render final labels."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.corpus_v7_reviewed_r8 import build_artifacts,verify_artifacts
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--verify',action='store_true')
    a=p.parse_args()
    if a.verify:
        print(json.dumps(verify_artifacts(a.output),indent=2))
    else:
        m=build_artifacts(a.output)
        print(json.dumps({'status':m['build_status'],'corpus_version':m['corpus_version'],
                         'statistics':m['statistics'],'final_status':m['final_status']},indent=2))
