"""Release verified development inputs after a recorded human review.

This prepares files only. It never starts a trainer or reads final labels.
"""
import argparse
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.corpus_v7 import bytes_record, read_gzip, verify_artifacts


def review_gate(corpus,review,approval,preflight):
    approved=json.loads(approval.read_bytes()); length=json.loads(preflight.read_bytes())
    manifest_hash=bytes_record(corpus/'manifest.json')['sha256']
    ledger=review/'decisions.csv'; review_manifest=json.loads((review/'review-manifest.json').read_bytes())
    manifest=json.loads((corpus/'manifest.json').read_bytes())
    if approved.get('corpus_manifest_sha256')!=manifest_hash or review_manifest['corpus_manifest_sha256']!=manifest_hash:
        raise ValueError('Human review is not bound to this corpus')
    if approved.get('decision_ledger_sha256')!=bytes_record(ledger)['sha256']: raise ValueError('Decision ledger differs from approval')
    rubric=ROOT/'corpus-v7/ANNOTATION_RUBRIC.md'
    if manifest.get('annotation_rubric_file'):
        rubric=(corpus/manifest['annotation_rubric_file']).resolve()
        if not rubric.is_relative_to(corpus.resolve()):raise ValueError('Rubric outside corpus')
    if approved.get('rubric_sha256')!=bytes_record(rubric)['sha256']: raise ValueError('Rubric differs from approval')
    if manifest.get('annotation_policy_file'):
        annotation=(corpus/manifest['annotation_policy_file']).resolve()
        if not annotation.is_relative_to(corpus.resolve()):raise ValueError('Policy outside corpus')
        policy_hash=bytes_record(annotation)['sha256']
        if approved.get('annotation_policy_sha256')!=policy_hash or review_manifest.get('annotation_policy_sha256')!=policy_hash:
            raise ValueError('Review is not bound to the approved annotation policy')
    if approved.get('review_complete') is not True or approved.get('overlap_review_complete') is not True:
        raise ValueError('Human corpus and overlap reviews are still pending')
    holds=ROOT/'corpus-v7/review-holds-20261009.json'
    if holds.is_file():
        held=json.loads(holds.read_bytes())['held_candidates']
        if any(row['corpus_manifest_sha256']==manifest_hash for row in held):
            raise ValueError('Agent review hold: known defective candidate requires a new revision')
    if not approved.get('reviewer') or not approved.get('review_scope'): raise ValueError('Missing reviewer/scope')
    when=datetime.fromisoformat(approved['reviewed_at_utc'].replace('Z','+00:00'))
    if when.tzinfo is None or when.utcoffset().total_seconds()!=0: raise ValueError('Review date must be UTC')
    with ledger.open(encoding='utf-8',newline='') as stream:
        rows=list(csv.DictReader(stream))
    expected=set(review_manifest['scenario_ids'])
    if len(rows)!=len(expected) or {r['scenario_id'] for r in rows}!=expected: raise ValueError('Review sample inventory changed')
    if any(r['decision']!='approved' or not r['reviewer'] or not r['reviewed_utc'] or not r['rationale'] for r in rows):
        raise ValueError('Pending/rejected sample or missing substantive human decisions; revise corpus, do not bypass')
    if length['corpus_manifest_sha256']!=manifest_hash or length['status']!='pass' or length['truncation'] is not False:
        raise ValueError('Missing valid tokenizer preflight for this corpus')
    manifest=json.loads((corpus/'manifest.json').read_bytes())
    if length.get('revision')!='15852e8c16360a2fea060d615a32b45270f8a8fc' or length.get('chat_template_kwargs')!={'enable_thinking':False}:
        raise ValueError('Wrong model/template preflight')
    if length.get('trainer_token_length_helper_sha256')!=bytes_record(ROOT/'training/train_lora.py')['sha256']:
        raise ValueError('Trainer changed after tokenizer preflight')
    if any(length['results'][s]['examples']!=manifest['files'][f'sft/{s}.jsonl.gz']['records']
           or length['results'][s]['over_limit']!=0 or length['results'][s]['max_tokens']>length['max_length'] for s in ('train','validation')):
        raise ValueError('Preflight lacks all examples or contains overlength rows')
    return {'corpus_manifest_sha256':manifest_hash,'review_scenarios':len(rows),
            'review_scope':approved['review_scope'],'approval_sha256':bytes_record(approval)['sha256'],
            'preflight_sha256':bytes_record(preflight)['sha256'],'max_length':length['max_length']}


def materialize(corpus,review,approval,preflight,output):
    if output.exists(): raise FileExistsError('Use a new training inputs directory')
    record=review_gate(corpus,review,approval,preflight)
    manifest=json.loads((corpus/'manifest.json').read_bytes())
    verifier=verify_artifacts
    if manifest.get('annotation_policy_version')=='v7-user-approved-annotation-1':
        from local_slm_lab.corpus_v7_reviewed_r8 import verify_artifacts as verifier
    verification=verifier(corpus) # Never passes a final-label path.
    output.mkdir(parents=True)
    records={}
    for split in ('train','validation'):
        destination=output/(split+'.jsonl')
        with gzip.open(corpus/'sft'/f'{split}.jsonl.gz','rb') as source,destination.open('xb') as target:
            for block in iter(lambda:source.read(1024*1024),b''): target.write(block)
        expected=json.loads((corpus/'manifest.json').read_bytes())['files'][f'sft/{split}.jsonl.gz']['raw_sha256']
        if bytes_record(destination)['sha256']!=expected: raise ValueError('Materialized input hash mismatch')
        records[destination.name]=bytes_record(destination)
    result={**record,'inputs':records,'verification':verification,'prepared_at_utc':datetime.now(timezone.utc).isoformat(),
            'training_started':False,'final_labels_accessed':False,
            'review_note':'Sample review approval is not a claim that every generated label was manually read'}
    (output/'inputs-manifest.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('corpus','review','approval','preflight','output'): p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args(); print(json.dumps(materialize(a.corpus,a.review,a.approval,a.preflight,a.output),indent=2))
