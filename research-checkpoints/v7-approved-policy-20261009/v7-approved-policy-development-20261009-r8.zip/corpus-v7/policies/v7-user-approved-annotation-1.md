# User-approved v7 annotation policy

Version: v7-user-approved-annotation-1. All six policy decisions were agreed by
the user in this chat. This agreement covers annotation conventions only;
individual example and overlap reviews remain pending.

1. An explicitly described forecasting target fills both problem_statement and
   target_description with the same exact meaningful target noun phrase. A
   column name alone does not supply its domain meaning. Why the forecast is
   needed belongs to business_goal; no purpose is invented.
2. A clear filename extension `.csv`, `.json`, `.parquet` or `.xlsx` supplies
   file_format with status inferred, using current-message evidence. Matching
   is case-insensitive and URL query strings are excluded. Extensionless,
   unsupported or unclear names supply no format inference. An explicit format
   declaration is provided and may upgrade an inferred status. Filename hints
   do not establish access mode, columns, contents, privacy or credentials.
3. New explicit values and replacements are provided. Explicit affirmation of
   the same recorded value is confirmed. Explicit replacement sets correction
   true; confirmation alone does not. Omit unchanged value and status unless
   explicitly confirmed. The pinned reducer's saved status may differ from
   the extracted status; this policy does not alter that reducer.
4. An unresolved cadence role is not guessed. A later clarification establishes
   the appropriate observation or forecast-generation schedule.
5. Unknown/undecided/unavailable information gives no slot update. Do not store
   an unknown sentence as a value, guess a default or label indifference.
6. English, Roman Urdu and mixed requests have the same semantic rules. Check
   meaning, target boundaries, duration roles and exact evidence in each language.

Every candidate_value is one JSON-encoded string, including free text and typed
objects. Evidence is a nonempty exact substring of the current message. Include
all stated requirements, use unique slot IDs, preserve chronological context
and make replacements affect only the named facts. Positive target values do
not include rejected alternatives. Seeded repairs require explicit new evidence.

The scope remains controlled synthetic requirement extraction. Conflict,
known-value withdrawal, explicit indifference, STT and adversarial coverage need
separate fixtures. No positive credential references are supplied.

Human reviewers must compare actual sentences against values/status/evidence,
check both missing and unwanted updates, review the actual overlap queue and
record substantive decisions. Policy agreement does not certify the sample,
every conversation, zero semantic leakage or model quality. Keep old revisions
and all historical comparisons intact.
