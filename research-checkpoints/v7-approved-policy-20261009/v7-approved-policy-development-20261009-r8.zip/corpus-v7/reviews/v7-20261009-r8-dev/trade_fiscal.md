# V7 review examples for trade_fiscal

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r8-dev/trade_fiscal/0010
Split: train

### t1 initial_multislot

For my request,  The source is trade_fiscal_archive_2601.parquet. I need the next 12 months predicted. There is one observed data point every 1 month. The target values are in index points, base 2020=100. The quantity to predict is goods export volume index for Norelia trade fiscal site 2601.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "trade_fiscal_archive_2601.parquet",
    "evidence": "The source is trade_fiscal_archive_2601.parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "parquet",
    "evidence": "The source is trade_fiscal_archive_2601.parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "I need the next 12 months predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "The target values are in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods export volume index for Norelia trade fiscal site 2601",
    "evidence": "The quantity to predict is goods export volume index for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods export volume index for Norelia trade fiscal site 2601",
    "evidence": "The quantity to predict is goods export volume index for Norelia trade fiscal site 2601."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The supplied data format is parquet. Access the input through an API. Dates are stored in field observed_time. Use column export_volume as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "export_volume",
    "evidence": "Use column export_volume as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 15 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "I need the next 15 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Norelia trade fiscal site 2601.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia trade fiscal site 2601",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia trade fiscal site 2601."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/trade_fiscal/0011
Split: train

### t1 initial_multislot

Here is what I need.  Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601. Keep the measurement unit as millions of USD. The native sampling interval is 1 month. The forecast horizon is 19 months. Access the input through an API. Read the observations from https://inputs.example/trade_fiscal/2601. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Norelia trade fiscal site 2601",
    "evidence": "Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Norelia trade fiscal site 2601",
    "evidence": "Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 19 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2601",
    "evidence": "Read the observations from https://inputs.example/trade_fiscal/2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is trade_balance. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "trade_balance",
    "evidence": "The target field name is trade_balance."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Run forecast generation once every 2 days. Training should be repeated every 2 months. The input source refresh schedule is every 3 hours. Make the result granularity one prediction row per month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training should be repeated every 2 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Make the result granularity one prediction row per month."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 22 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0011/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 22 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/trade_fiscal/0012
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. Mera source reference https://inputs.example/trade_fiscal/2601 hai. Access the input through an API. 9 mahinay ka horizon rakhein. Source observations arrive every 1 month. Target ko millions of USD mein measure karein. My prediction target is government tax revenue for Norelia trade fiscal site 2601.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2601",
    "evidence": "Mera source reference https://inputs.example/trade_fiscal/2601 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "9 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target ko millions of USD mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government tax revenue for Norelia trade fiscal site 2601",
    "evidence": "My prediction target is government tax revenue for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government tax revenue for Norelia trade fiscal site 2601",
    "evidence": "My prediction target is government tax revenue for Norelia trade fiscal site 2601."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Target values field tax_revenue se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tax_revenue",
    "evidence": "Target values field tax_revenue se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 12 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 12 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/trade_fiscal/12. Source observations har 2 mahinay aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/trade_fiscal/12",
    "evidence": "My source reference is https://revised.example/trade_fiscal/12."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0012/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Source observations har 2 mahinay aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/trade_fiscal/0013
Split: train

### t1 initial_multislot

I need forecasts of government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601. Measure the target in millions of USD. The observations are recorded every 1 month. The forecast should extend 16 months ahead. Access the input through an API. Use the data source https://inputs.example/trade_fiscal/2601. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601",
    "evidence": "I need forecasts of government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601",
    "evidence": "I need forecasts of government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Measure the target in millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "The forecast should extend 16 months ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2601",
    "evidence": "Use the data source https://inputs.example/trade_fiscal/2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

The timestamp timezone is Europe/London. I do not expect a repeating seasonal pattern. The requested forecast output type is probabilistic. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "The timestamp timezone is Europe/London."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target column is called fiscal_balance. The timestamp column is observed_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "fiscal_balance",
    "evidence": "The target column is called fiscal_balance."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 19 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast should extend 19 months ahead."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/trade_fiscal/0014
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/trade_fiscal/2601 hai. Input API ke zariye lein. Aglay 6 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values index points, base 2020=100 mein hain. goods export volume index for Norelia trade fiscal site 2601 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2601",
    "evidence": "Source https://inputs.example/trade_fiscal/2601 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Aglay 6 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target values index points, base 2020=100 mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods export volume index for Norelia trade fiscal site 2601",
    "evidence": "goods export volume index for Norelia trade fiscal site 2601 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods export volume index for Norelia trade fiscal site 2601",
    "evidence": "goods export volume index for Norelia trade fiscal site 2601 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 6 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 6 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 9 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Aglay 9 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 9 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0014/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 9 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/trade_fiscal/0015
Split: train

### t1 initial_multislot

Here is what I need.  Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601. Keep the measurement unit as millions of USD. The native sampling interval is 1 month. The forecast horizon is 13 months. Access the input through an API. Read the observations from https://inputs.example/trade_fiscal/2601. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Norelia trade fiscal site 2601",
    "evidence": "Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Norelia trade fiscal site 2601",
    "evidence": "Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 13 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2601",
    "evidence": "Read the observations from https://inputs.example/trade_fiscal/2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is trade_balance. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "trade_balance",
    "evidence": "The target field name is trade_balance."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The native sampling interval is 1 month. Keep the measurement unit as millions of USD.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 16 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0015/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 16 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/trade_fiscal/0016
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. My source reference is https://inputs.example/trade_fiscal/2601. Access the input through an API. Predict a horizon of 20 months. Source observations arrive every 1 month. Use millions of USD as the target unit. My prediction target is government tax revenue for Norelia trade fiscal site 2601.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2601",
    "evidence": "My source reference is https://inputs.example/trade_fiscal/2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 20 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Use millions of USD as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government tax revenue for Norelia trade fiscal site 2601",
    "evidence": "My prediction target is government tax revenue for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government tax revenue for Norelia trade fiscal site 2601",
    "evidence": "My prediction target is government tax revenue for Norelia trade fiscal site 2601."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field tax_revenue.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tax_revenue",
    "evidence": "Read target values from field tax_revenue."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

This forecast will inform the decision to set the contingency allowance for Norelia trade fiscal site 2601. My role in this project is trade and fiscal analyst. Our operational goal is to prepare a planning reserve for Norelia trade fiscal site 2601. Human approval before modeling is required. The required explanation level is none. Detailed data lineage is required.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Norelia trade fiscal site 2601",
    "evidence": "This forecast will inform the decision to set the contingency allowance for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "trade and fiscal analyst",
    "evidence": "My role in this project is trade and fiscal analyst."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia trade fiscal site 2601",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": true,
    "evidence": "Human approval before modeling is required."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t3/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "none",
    "evidence": "The required explanation level is none."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t3/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": true,
    "evidence": "Detailed data lineage is required."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The first forecast period begins at 2026-10-01T00:00:00+00:00. Use ordinary calendar days. Aggregate observations using last. Negative target values are not valid. Valid target bounds are {"max": 1000000, "min": 0}. I will consider the result useful if it meets MAE no more than 2 millions of USD for Norelia trade fiscal site 2601.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "The first forecast period begins at 2026-10-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Use ordinary calendar days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "Aggregate observations using last."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t4/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "Valid target bounds are {\"max\": 1000000, \"min\": 0}."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t4/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 2 millions of USD for Norelia trade fiscal site 2601",
    "evidence": "I will consider the result useful if it meets MAE no more than 2 millions of USD for Norelia trade fiscal site 2601."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 23 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0016/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 23 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/trade_fiscal/0017
Split: train

### t1 initial_multislot

I need forecasts of government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601. Measure the target in millions of USD. The observations are recorded every 1 month. The forecast should extend 10 months ahead. Do not substitute goods export volume index as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601",
    "evidence": "I need forecasts of government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601",
    "evidence": "I need forecasts of government fiscal balance, revenue minus expenditure for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Measure the target in millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "The forecast should extend 10 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called fiscal_balance. The timestamp column is observed_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "fiscal_balance",
    "evidence": "The target column is called fiscal_balance."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Access the input through an API. Use the data source https://inputs.example/trade_fiscal/2601. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2601",
    "evidence": "Use the data source https://inputs.example/trade_fiscal/2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 13 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0017/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "The forecast should extend 13 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of trade fiscal. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/trade_fiscal/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/trade_fiscal/2601. Access the input through an API. I need the next 17 months predicted. There is one observed data point every 1 month. The target values are in index points, base 2020=100. The quantity to predict is goods export volume index for Norelia trade fiscal site 2601.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2601",
    "evidence": "The source is https://inputs.example/trade_fiscal/2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "I need the next 17 months predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "The target values are in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods export volume index for Norelia trade fiscal site 2601",
    "evidence": "The quantity to predict is goods export volume index for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods export volume index for Norelia trade fiscal site 2601",
    "evidence": "The quantity to predict is goods export volume index for Norelia trade fiscal site 2601."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field observed_time. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains confidential synthetic records.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 20 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "I need the next 20 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/trade_fiscal/0019
Split: train

### t1 initial_multislot

Here is what I need.  Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601. Keep the measurement unit as millions of USD. The forecast horizon is 7 months. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Norelia trade fiscal site 2601",
    "evidence": "Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Norelia trade fiscal site 2601",
    "evidence": "Please predict goods trade balance, exports minus imports for Norelia trade fiscal site 2601."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 7 months."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. The native sampling interval is 1 month. Run forecast generation once every 2 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target field name is trade_balance. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "trade_balance",
    "evidence": "The target field name is trade_balance."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 10 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0019/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 10 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/trade_fiscal/0022
Split: train

### t1 initial_multislot

I need forecasts of goods trade balance, exports minus imports for Orven trade fiscal site 2602. Measure the target in millions of USD. The observations are recorded every 1 month. The forecast should extend 20 months ahead. Read the input from a database. Use the data source https://inputs.example/trade_fiscal/2602. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Orven trade fiscal site 2602",
    "evidence": "I need forecasts of goods trade balance, exports minus imports for Orven trade fiscal site 2602."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Orven trade fiscal site 2602",
    "evidence": "I need forecasts of goods trade balance, exports minus imports for Orven trade fiscal site 2602."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Measure the target in millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "The forecast should extend 20 months ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2602",
    "evidence": "Use the data source https://inputs.example/trade_fiscal/2602."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called trade_balance. The timestamp column is measurement_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "trade_balance",
    "evidence": "The target column is called trade_balance."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The timestamp column is measurement_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 23 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "month"
    },
    "evidence": "The forecast should extend 23 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The observations are recorded every 2 months. Use the data source https://revised.example/trade_fiscal/22.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 2 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0022/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/trade_fiscal/22",
    "evidence": "Use the data source https://revised.example/trade_fiscal/22."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/trade_fiscal/0024
Split: train

### t1 initial_multislot

Here is what I need.  Please predict government fiscal balance, revenue minus expenditure for Orven trade fiscal site 2602. Keep the measurement unit as millions of USD. The native sampling interval is 1 month. The forecast horizon is 17 months. Read the input from a database. Read the observations from https://inputs.example/trade_fiscal/2602. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Orven trade fiscal site 2602",
    "evidence": "Please predict government fiscal balance, revenue minus expenditure for Orven trade fiscal site 2602."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Orven trade fiscal site 2602",
    "evidence": "Please predict government fiscal balance, revenue minus expenditure for Orven trade fiscal site 2602."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 17 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2602",
    "evidence": "Read the observations from https://inputs.example/trade_fiscal/2602."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast horizon is 17 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast horizon is 17 months."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 20 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 20 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast horizon is 20 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0024/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast horizon is 20 months."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/trade_fiscal/0025
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. Mera source reference https://inputs.example/trade_fiscal/2602 hai. Read the input from a database. 7 mahinay ka horizon rakhein. Source observations arrive every 1 month. Target ko index points, base 2020=100 mein measure karein. My prediction target is goods export volume index for Orven trade fiscal site 2602.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2602",
    "evidence": "Mera source reference https://inputs.example/trade_fiscal/2602 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "7 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods export volume index for Orven trade fiscal site 2602",
    "evidence": "My prediction target is goods export volume index for Orven trade fiscal site 2602."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods export volume index for Orven trade fiscal site 2602",
    "evidence": "My prediction target is goods export volume index for Orven trade fiscal site 2602."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Target values field export_volume se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "export_volume",
    "evidence": "Target values field export_volume se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Use index points, base 2020=100 as the target unit. Source observations har 1 mahina aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 10 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0025/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 10 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r8-dev/trade_fiscal/0026
Split: train

### t1 initial_multislot

Mujhe goods trade balance, exports minus imports for Orven trade fiscal site 2602 ka forecast chahiye. Target ki unit millions of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 14 mahinay tak chahiye. Input database se read karein. Data source https://inputs.example/trade_fiscal/2602 use karein. Input file format json hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Orven trade fiscal site 2602",
    "evidence": "Mujhe goods trade balance, exports minus imports for Orven trade fiscal site 2602 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Orven trade fiscal site 2602",
    "evidence": "Mujhe goods trade balance, exports minus imports for Orven trade fiscal site 2602 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Forecast aglay 14 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2602",
    "evidence": "Data source https://inputs.example/trade_fiscal/2602 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input file format json hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam trade_balance hai. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "trade_balance",
    "evidence": "Target column ka naam trade_balance hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

lead time 1 mahina hai. dataset type ki requirement hierarchical hai. series id columns ki requirement site_id hai. hierarchy columns ki requirement region_id, site_id hai. aggregation level ki requirement site hai. scope filters ki requirement [{"column": "site_id", "operator": "eq", "value": "Orven trade fiscal site 2602"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t3/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "lead time 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t3/dataset_type",
    "slot_id": "dataset_type",
    "status": "provided",
    "value": "hierarchical",
    "evidence": "dataset type ki requirement hierarchical hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t3/series_id_columns",
    "slot_id": "series_id_columns",
    "status": "provided",
    "value": [
      "site_id"
    ],
    "evidence": "series id columns ki requirement site_id hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t3/hierarchy_columns",
    "slot_id": "hierarchy_columns",
    "status": "provided",
    "value": [
      "region_id",
      "site_id"
    ],
    "evidence": "hierarchy columns ki requirement region_id, site_id hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t3/aggregation_level",
    "slot_id": "aggregation_level",
    "status": "provided",
    "value": "site",
    "evidence": "aggregation level ki requirement site hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t3/scope_filters",
    "slot_id": "scope_filters",
    "status": "provided",
    "value": [
      {
        "column": "site_id",
        "operator": "eq",
        "value": "Orven trade fiscal site 2602"
      }
    ],
    "evidence": "scope filters ki requirement [{\"column\": \"site_id\", \"operator\": \"eq\", \"value\": \"Orven trade fiscal site 2602\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

geography ki requirement Fictional Orven trade fiscal site 2602 region hai. source provider ki requirement Synthetic Economic Research Laboratory hai. sheet or table ki requirement trade_fiscal_observations hai. Source data har 4 ghantay refresh karein. history start ki requirement 2020-01-01T00:00:00+00:00 hai. history end ki requirement 2026-09-30T00:00:00+00:00 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t4/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Orven trade fiscal site 2602 region"
    ],
    "evidence": "geography ki requirement Fictional Orven trade fiscal site 2602 region hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t4/source_provider",
    "slot_id": "source_provider",
    "status": "provided",
    "value": "Synthetic Economic Research Laboratory",
    "evidence": "source provider ki requirement Synthetic Economic Research Laboratory hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t4/sheet_or_table",
    "slot_id": "sheet_or_table",
    "status": "provided",
    "value": "trade_fiscal_observations",
    "evidence": "sheet or table ki requirement trade_fiscal_observations hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t4/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source data har 4 ghantay refresh karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t4/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "history start ki requirement 2020-01-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t4/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "history end ki requirement 2026-09-30T00:00:00+00:00 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 17 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0026/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Forecast aglay 17 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r8-dev/trade_fiscal/0042
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target government fiscal balance, revenue minus expenditure for Talven trade fiscal site 2604 hai. Measurement unit millions of USD rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 8 mahinay hai. Main data upload karunga. Observations trade_fiscal_archive_2604.csv se lein. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Talven trade fiscal site 2604",
    "evidence": "Prediction ka target government fiscal balance, revenue minus expenditure for Talven trade fiscal site 2604 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Talven trade fiscal site 2604",
    "evidence": "Prediction ka target government fiscal balance, revenue minus expenditure for Talven trade fiscal site 2604 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Measurement unit millions of USD rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Forecast horizon 8 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "trade_fiscal_archive_2604.csv",
    "evidence": "Observations trade_fiscal_archive_2604.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field fiscal_balance hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "fiscal_balance",
    "evidence": "Target field fiscal_balance hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 11 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Forecast horizon 11 mahinay hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Asli data ka sampling interval 2 mahinay hai. Observations https://revised.example/trade_fiscal/42 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 2 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0042/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/trade_fiscal/42",
    "evidence": "Observations https://revised.example/trade_fiscal/42 se lein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/trade_fiscal/0049
Split: train

### t1 initial_multislot

For my request,  I need the next 6 months predicted. Target values millions of USD mein hain. The quantity to predict is government tax revenue for Talven trade fiscal site 2604. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "I need the next 6 months predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target values millions of USD mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government tax revenue for Talven trade fiscal site 2604",
    "evidence": "The quantity to predict is government tax revenue for Talven trade fiscal site 2604."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government tax revenue for Talven trade fiscal site 2604",
    "evidence": "The quantity to predict is government tax revenue for Talven trade fiscal site 2604."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 2 days. Har 1 mahina aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field sample_date. Column tax_revenue ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tax_revenue",
    "evidence": "Column tax_revenue ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 9 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0049/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "I need the next 9 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r8-dev/trade_fiscal/0050
Split: train

### t1 initial_multislot

Meri request yeh hai.  Source trade_fiscal_archive_2605.PARQUET hai. Aglay 5 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values index points, base 2020=100 mein hain. goods export volume index for Virelo trade fiscal site 2605 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "trade_fiscal_archive_2605.PARQUET",
    "evidence": "Source trade_fiscal_archive_2605.PARQUET hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "parquet",
    "evidence": "Source trade_fiscal_archive_2605.PARQUET hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "Aglay 5 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target values index points, base 2020=100 mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods export volume index for Virelo trade fiscal site 2605",
    "evidence": "goods export volume index for Virelo trade fiscal site 2605 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods export volume index for Virelo trade fiscal site 2605",
    "evidence": "goods export volume index for Virelo trade fiscal site 2605 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Diye hue data ka format parquet hai. Input API ke zariye lein. Dates field observed_time mein hain. Column export_volume ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates field observed_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "export_volume",
    "evidence": "Column export_volume ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 8 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Aglay 8 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Virelo trade fiscal site 2605 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0050/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Virelo trade fiscal site 2605",
    "evidence": "business goal ki requirement prepare a planning reserve for Virelo trade fiscal site 2605 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r8-dev/trade_fiscal/0067
Split: train

### t1 initial_multislot

For my request,  I need the next 14 months predicted. Har 1 mahina aik observed data point milta hai. The target values are in millions of USD. government tax revenue for Weslin trade fiscal site 2606 predict karna hai. Do not substitute government fiscal balance, revenue minus expenditure as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "I need the next 14 months predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "The target values are in millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government tax revenue for Weslin trade fiscal site 2606",
    "evidence": "government tax revenue for Weslin trade fiscal site 2606 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government tax revenue for Weslin trade fiscal site 2606",
    "evidence": "government tax revenue for Weslin trade fiscal site 2606 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Column tax_revenue ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tax_revenue",
    "evidence": "Column tax_revenue ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is json. Source https://inputs.example/trade_fiscal/2606 hai. Read the input from a database.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2606",
    "evidence": "Source https://inputs.example/trade_fiscal/2606 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0067/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "I need the next 17 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261009-r8-dev/trade_fiscal/0080
Split: train

### t1 initial_multislot

I need forecasts of goods trade balance, exports minus imports for Merlow trade fiscal site 2608. Target ki unit millions of USD hai. The observations are recorded every 1 month. Forecast aglay 4 mahinay tak chahiye. I will upload the data. Data source trade_fiscal_archive_2608.csv use karein. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Merlow trade fiscal site 2608",
    "evidence": "I need forecasts of goods trade balance, exports minus imports for Merlow trade fiscal site 2608."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods trade balance, exports minus imports for Merlow trade fiscal site 2608",
    "evidence": "I need forecasts of goods trade balance, exports minus imports for Merlow trade fiscal site 2608."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "Forecast aglay 4 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "trade_fiscal_archive_2608.csv",
    "evidence": "Data source trade_fiscal_archive_2608.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called trade_balance. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "trade_balance",
    "evidence": "The target column is called trade_balance."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 7 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "The forecast should extend 7 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow trade fiscal site 2608.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0080/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow trade fiscal site 2608",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow trade fiscal site 2608."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r8-dev/trade_fiscal/0085
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source trade_fiscal_archive_2608.csv hai. Main data upload karunga. Aglay 5 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values millions of USD mein hain. government tax revenue for Merlow trade fiscal site 2608 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "trade_fiscal_archive_2608.csv",
    "evidence": "Source trade_fiscal_archive_2608.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "Aglay 5 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target values millions of USD mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government tax revenue for Merlow trade fiscal site 2608",
    "evidence": "government tax revenue for Merlow trade fiscal site 2608 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government tax revenue for Merlow trade fiscal site 2608",
    "evidence": "government tax revenue for Merlow trade fiscal site 2608 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field sample_date mein hain. Column tax_revenue ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates field sample_date mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tax_revenue",
    "evidence": "Column tax_revenue ko target rakhein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target values millions of USD mein hain. Har 1 mahina aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target values millions of USD mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 8 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0085/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Aglay 8 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/trade_fiscal/0101
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format json hai. Mera source reference https://inputs.example/trade_fiscal/2610 hai. Input database se read karein. 16 mahinay ka horizon rakhein. Source observations har 1 mahina aati hain. Target ko index points, base 2020=100 mein measure karein. goods export volume index for Orven trade fiscal site 2610 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Source serialization format json hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2610",
    "evidence": "Mera source reference https://inputs.example/trade_fiscal/2610 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "16 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods export volume index for Orven trade fiscal site 2610",
    "evidence": "goods export volume index for Orven trade fiscal site 2610 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods export volume index for Orven trade fiscal site 2610",
    "evidence": "goods export volume index for Orven trade fiscal site 2610 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam measurement_time hai. Target values field export_volume se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "export_volume",
    "evidence": "Target values field export_volume se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Output granularity one prediction row per month use karein. Source records har 4 ghantay update karein. Retraining har 1 mahina schedule karein. Har 2 din naye forecasts banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Output granularity one prediction row per month use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source records har 4 ghantay update karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Retraining har 1 mahina schedule karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Har 2 din naye forecasts banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 19 mahinay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0101/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "19 mahinay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r8-dev/trade_fiscal/0133
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613. Target measurements ki unit millions of USD hai. Each observed record covers 1 month. Future coverage 12 mahinay chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/trade_fiscal/2613 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613",
    "evidence": "We need an outlook for government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613",
    "evidence": "We need an outlook for government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target measurements ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Future coverage 12 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2613",
    "evidence": "Diya hua source identifier https://inputs.example/trade_fiscal/2613 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

All observed times use the Europe/London timezone. Repeating seasonal pattern expect nahi karta. The requested forecast output type is probabilistic. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "All observed times use the Europe/London timezone."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The response variable is stored in column fiscal_balance. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "fiscal_balance",
    "evidence": "The response variable is stored in column fiscal_balance."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 15 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0133/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 15 months."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r8-dev/trade_fiscal/0137
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613 ka outlook chahiye. Target measurements ki unit millions of USD hai. Har observed record 1 mahina cover karta hai. Future coverage 6 mahinay chahiye. goods export volume index nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613",
    "evidence": "Hamein government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613",
    "evidence": "Hamein government fiscal balance, revenue minus expenditure for Virelo trade fiscal site 2613 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target measurements ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har observed record 1 mahina cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Future coverage 6 mahinay chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column fiscal_balance mein hai. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "fiscal_balance",
    "evidence": "Response variable column fiscal_balance mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Input API ke zariye lein. Diya hua source identifier https://inputs.example/trade_fiscal/2613 hai. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2613",
    "evidence": "Diya hua source identifier https://inputs.example/trade_fiscal/2613 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 9 mahinay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0137/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Future coverage 9 mahinay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/trade_fiscal/0149
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  14 mahinay ka horizon rakhein. Target ko index points, base 2020=100 mein measure karein. goods export volume index for Weslin trade fiscal site 2614 ke liye prediction bana dein. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "14 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "goods export volume index for Weslin trade fiscal site 2614",
    "evidence": "goods export volume index for Weslin trade fiscal site 2614 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "goods export volume index for Weslin trade fiscal site 2614",
    "evidence": "goods export volume index for Weslin trade fiscal site 2614 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Har 3 din naye forecasts banayein. Source observations har 1 mahina aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Time field ka naam measurement_time hai. Target values field export_volume se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "export_volume",
    "evidence": "Target values field export_volume se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 17 mahinay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0149/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "17 mahinay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r8-dev/trade_fiscal/0176
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for government tax revenue for Norelia trade fiscal site 2617. Target measurements ki unit millions of USD hai. Each observed record covers 1 month. Future coverage 9 mahinay chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/trade_fiscal/2617 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "government tax revenue for Norelia trade fiscal site 2617",
    "evidence": "We need an outlook for government tax revenue for Norelia trade fiscal site 2617."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "government tax revenue for Norelia trade fiscal site 2617",
    "evidence": "We need an outlook for government tax revenue for Norelia trade fiscal site 2617."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target measurements ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Future coverage 9 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/trade_fiscal/2617",
    "evidence": "Diya hua source identifier https://inputs.example/trade_fiscal/2617 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column tax_revenue. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "tax_revenue",
    "evidence": "The response variable is stored in column tax_revenue."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The ordered hierarchy columns are region_id, site_id. aggregation level ki requirement site hai. Limit the scope using these explicit filters: [{"column": "site_id", "operator": "eq", "value": "Norelia trade fiscal site 2617"}]. geography ki requirement Fictional Norelia trade fiscal site 2617 region hai. The fictional data provider is Synthetic Economic Research Laboratory. sheet or table ki requirement trade_fiscal_observations hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t3/hierarchy_columns",
    "slot_id": "hierarchy_columns",
    "status": "provided",
    "value": [
      "region_id",
      "site_id"
    ],
    "evidence": "The ordered hierarchy columns are region_id, site_id."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t3/aggregation_level",
    "slot_id": "aggregation_level",
    "status": "provided",
    "value": "site",
    "evidence": "aggregation level ki requirement site hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t3/scope_filters",
    "slot_id": "scope_filters",
    "status": "provided",
    "value": [
      {
        "column": "site_id",
        "operator": "eq",
        "value": "Norelia trade fiscal site 2617"
      }
    ],
    "evidence": "Limit the scope using these explicit filters: [{\"column\": \"site_id\", \"operator\": \"eq\", \"value\": \"Norelia trade fiscal site 2617\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t3/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Norelia trade fiscal site 2617 region"
    ],
    "evidence": "geography ki requirement Fictional Norelia trade fiscal site 2617 region hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t3/source_provider",
    "slot_id": "source_provider",
    "status": "provided",
    "value": "Synthetic Economic Research Laboratory",
    "evidence": "The fictional data provider is Synthetic Economic Research Laboratory."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t3/sheet_or_table",
    "slot_id": "sheet_or_table",
    "status": "provided",
    "value": "trade_fiscal_observations",
    "evidence": "sheet or table ki requirement trade_fiscal_observations hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Source ingestion repeats every 3 hours. history start ki requirement 2020-01-01T00:00:00+00:00 hai. The historical observations end at 2026-09-30T00:00:00+00:00. available historical coverage 81 mahinay hai. Require at least 24 training observations. known regime changes ki requirement [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t4/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "Source ingestion repeats every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t4/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "history start ki requirement 2020-01-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t4/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "The historical observations end at 2026-09-30T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t4/expected_history_length",
    "slot_id": "expected_history_length",
    "status": "provided",
    "value": {
      "periods": 81,
      "unit": "month"
    },
    "evidence": "available historical coverage 81 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t4/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 24,
    "evidence": "Require at least 24 training observations."
  },
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t4/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "known regime changes ki requirement [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 12 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/trade_fiscal/0176/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 12 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
