# V7 review examples for solar_cloud

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## ur core_recall

Scenario: v7-20261009-r8-dev/solar_cloud/0000
Split: train

### t1 initial_multislot

Mujhe global horizontal irradiance for Merlow solar cloud site 1400 ka forecast chahiye. Target ki unit watts per square metre hai. Observations har 1 ghanta record hoti hain. Forecast aglay 16 ghantay tak chahiye. Main data upload karunga. Data source solar_cloud_archive_1400.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1400",
    "evidence": "Mujhe global horizontal irradiance for Merlow solar cloud site 1400 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1400",
    "evidence": "Mujhe global horizontal irradiance for Merlow solar cloud site 1400 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target ki unit watts per square metre hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 16 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "Data source solar_cloud_archive_1400.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam ghi_wm2 hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ghi_wm2",
    "evidence": "Target column ka naam ghi_wm2 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 19 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 19 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Merlow solar cloud site 1400 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow solar cloud site 1400",
    "evidence": "business goal ki requirement prepare a planning reserve for Merlow solar cloud site 1400 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/solar_cloud/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is solar_cloud_archive_1400.csv. I will upload the data. I need the next 6 hours predicted. There is one observed data point every 1 hour. The target values are in percent. The quantity to predict is cloud cover for Merlow solar cloud site 1400.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "The source is solar_cloud_archive_1400.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "hour"
    },
    "evidence": "I need the next 6 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "cloud cover for Merlow solar cloud site 1400",
    "evidence": "The quantity to predict is cloud cover for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "cloud cover for Merlow solar cloud site 1400",
    "evidence": "The quantity to predict is cloud cover for Merlow solar cloud site 1400."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Use column cloud_pct as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cloud_pct",
    "evidence": "Use column cloud_pct as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per hour. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Return forecasts with resolution one prediction row per hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 9 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "I need the next 9 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/solar_cloud/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict sunshine duration for Merlow solar cloud site 1400. Keep the measurement unit as hours. The native sampling interval is 1 day. The forecast horizon is 13 days. I will upload the data. Read the observations from solar_cloud_archive_1400.csv. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sunshine duration for Merlow solar cloud site 1400",
    "evidence": "Please predict sunshine duration for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sunshine duration for Merlow solar cloud site 1400",
    "evidence": "Please predict sunshine duration for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hours",
    "evidence": "Keep the measurement unit as hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 13 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "Read the observations from solar_cloud_archive_1400.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is sunshine_hours. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "sunshine_hours",
    "evidence": "The target field name is sunshine_hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 16 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 16 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 days. Read the observations from https://revised.example/solar_cloud/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/solar_cloud/2",
    "evidence": "Read the observations from https://revised.example/solar_cloud/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/solar_cloud/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is solar_cloud_archive_1400.csv. I will upload the data. Predict a horizon of 20 hours. Source observations arrive every 1 hour. Use watts per square metre as the target unit. My prediction target is direct normal irradiance for Merlow solar cloud site 1400.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "My source reference is solar_cloud_archive_1400.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 20 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Use watts per square metre as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "direct normal irradiance for Merlow solar cloud site 1400",
    "evidence": "My prediction target is direct normal irradiance for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "direct normal irradiance for Merlow solar cloud site 1400",
    "evidence": "My prediction target is direct normal irradiance for Merlow solar cloud site 1400."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. The seasonal cycles in observation periods are 24, 168. I expect a repeating seasonal pattern. Use timezone Asia/Karachi.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "The seasonal cycles in observation periods are 24, 168."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "Use timezone Asia/Karachi."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is sample_date. Read target values from field dni_wm2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dni_wm2",
    "evidence": "Read target values from field dni_wm2."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 23 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 23 hours."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/solar_cloud/0004
Split: train

### t1 initial_multislot

I need forecasts of global horizontal irradiance for Merlow solar cloud site 1400. Measure the target in watts per square metre. The observations are recorded every 1 hour. The forecast should extend 10 hours ahead. I will upload the data. Use the data source solar_cloud_archive_1400.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1400",
    "evidence": "I need forecasts of global horizontal irradiance for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1400",
    "evidence": "I need forecasts of global horizontal irradiance for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Measure the target in watts per square metre."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 10 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "Use the data source solar_cloud_archive_1400.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 10 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 10 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 13 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 13 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 13 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 13 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of solar cloud. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/solar_cloud/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is solar_cloud_archive_1400.csv. I will upload the data. I need the next 17 hours predicted. There is one observed data point every 1 hour. The target values are in percent. The quantity to predict is cloud cover for Merlow solar cloud site 1400.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "The source is solar_cloud_archive_1400.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "I need the next 17 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "cloud cover for Merlow solar cloud site 1400",
    "evidence": "The quantity to predict is cloud cover for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "cloud cover for Merlow solar cloud site 1400",
    "evidence": "The quantity to predict is cloud cover for Merlow solar cloud site 1400."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Use column cloud_pct as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cloud_pct",
    "evidence": "Use column cloud_pct as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in percent. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 20 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "I need the next 20 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r8-dev/solar_cloud/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict sunshine duration for Merlow solar cloud site 1400. Measurement unit hours rakhein. The native sampling interval is 1 day. Forecast horizon 7 din hai. I will upload the data. Observations solar_cloud_archive_1400.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sunshine duration for Merlow solar cloud site 1400",
    "evidence": "Please predict sunshine duration for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sunshine duration for Merlow solar cloud site 1400",
    "evidence": "Please predict sunshine duration for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hours",
    "evidence": "Measurement unit hours rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Forecast horizon 7 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "Observations solar_cloud_archive_1400.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is sunshine_hours. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "sunshine_hours",
    "evidence": "The target field name is sunshine_hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

For unusual values, use the policy cap. invalid value policy ki requirement reject hai. Require non-missing coverage of at least 86 percent. Repeating seasonal pattern expect karta hoon. Do not exclude weekends or non-business days. holidays ki requirement synthetic reporting holiday hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t3/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "For unusual values, use the policy cap."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t3/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "invalid value policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t3/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "Require non-missing coverage of at least 86 percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t3/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Do not exclude weekends or non-business days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t3/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "holidays ki requirement synthetic reporting holiday hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The known special events are [{"date": "2026-10-05", "name": "synthetic weather alert"}]. past covariates ki requirement lagged_target hai. These regressors are known for future periods: announced_calendar_event. static features ki requirement scope_elevation hai. The future regressor availability records are [{"available": "announced before cutoff", "name": "announced_calendar_event"}]. external covariate sources ki requirement [{"name": "announced_calendar_event", "source": "synthetic_calendar"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t4/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic weather alert"
      }
    ],
    "evidence": "The known special events are [{\"date\": \"2026-10-05\", \"name\": \"synthetic weather alert\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t4/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "past covariates ki requirement lagged_target hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t4/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "These regressors are known for future periods: announced_calendar_event."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t4/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_elevation"
    ],
    "evidence": "static features ki requirement scope_elevation hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t4/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "The future regressor availability records are [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t4/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "external covariate sources ki requirement [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 10 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 10 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/solar_cloud/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 14 hours. Source observations arrive every 1 hour. Use watts per square metre as the target unit. My prediction target is direct normal irradiance for Merlow solar cloud site 1400. Do not substitute hourly global horizontal irradiance as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 14 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Use watts per square metre as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "direct normal irradiance for Merlow solar cloud site 1400",
    "evidence": "My prediction target is direct normal irradiance for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "direct normal irradiance for Merlow solar cloud site 1400",
    "evidence": "My prediction target is direct normal irradiance for Merlow solar cloud site 1400."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field dni_wm2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dni_wm2",
    "evidence": "Read target values from field dni_wm2."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is csv. My source reference is solar_cloud_archive_1400.csv. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "My source reference is solar_cloud_archive_1400.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 17 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 17 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/solar_cloud/0008
Split: train

### t1 initial_multislot

I need forecasts of global horizontal irradiance for Merlow solar cloud site 1400. Measure the target in watts per square metre. The observations are recorded every 1 hour. The forecast should extend 4 hours ahead. I will upload the data. Use the data source solar_cloud_archive_1400.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1400",
    "evidence": "I need forecasts of global horizontal irradiance for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1400",
    "evidence": "I need forecasts of global horizontal irradiance for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Measure the target in watts per square metre."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 4 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1400.csv",
    "evidence": "Use the data source solar_cloud_archive_1400.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 7 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 7 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/solar_cloud/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 11 hours predicted. The target values are in percent. The quantity to predict is cloud cover for Merlow solar cloud site 1400. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "I need the next 11 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "cloud cover for Merlow solar cloud site 1400",
    "evidence": "The quantity to predict is cloud cover for Merlow solar cloud site 1400."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "cloud cover for Merlow solar cloud site 1400",
    "evidence": "The quantity to predict is cloud cover for Merlow solar cloud site 1400."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field sample_date. Use column cloud_pct as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cloud_pct",
    "evidence": "Use column cloud_pct as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 14 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "I need the next 14 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en core_recall

Scenario: v7-20261009-r8-dev/solar_cloud/0010
Split: train

### t1 initial_multislot

For my request,  The source is solar_cloud_archive_1401.parquet. I need the next 10 hours predicted. There is one observed data point every 1 hour. The target values are in watts per square metre. The quantity to predict is direct normal irradiance for Norelia solar cloud site 1401.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1401.parquet",
    "evidence": "The source is solar_cloud_archive_1401.parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "parquet",
    "evidence": "The source is solar_cloud_archive_1401.parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "I need the next 10 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "The target values are in watts per square metre."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "direct normal irradiance for Norelia solar cloud site 1401",
    "evidence": "The quantity to predict is direct normal irradiance for Norelia solar cloud site 1401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "direct normal irradiance for Norelia solar cloud site 1401",
    "evidence": "The quantity to predict is direct normal irradiance for Norelia solar cloud site 1401."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The supplied data format is parquet. Access the input through an API. Dates are stored in field observed_time. Use column dni_wm2 as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dni_wm2",
    "evidence": "Use column dni_wm2 as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 13 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "I need the next 13 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Norelia solar cloud site 1401.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia solar cloud site 1401",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia solar cloud site 1401."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r8-dev/solar_cloud/0013
Split: train

### t1 initial_multislot

Mujhe sunshine duration for Norelia solar cloud site 1401 ka forecast chahiye. Target ki unit hours hai. Observations har 1 din record hoti hain. Forecast aglay 14 din tak chahiye. Input API ke zariye lein. Data source https://inputs.example/solar_cloud/1401 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sunshine duration for Norelia solar cloud site 1401",
    "evidence": "Mujhe sunshine duration for Norelia solar cloud site 1401 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sunshine duration for Norelia solar cloud site 1401",
    "evidence": "Mujhe sunshine duration for Norelia solar cloud site 1401 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hours",
    "evidence": "Target ki unit hours hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Forecast aglay 14 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1401",
    "evidence": "Data source https://inputs.example/solar_cloud/1401 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Timestamps ki timezone Europe/London hai. Repeating seasonal pattern expect nahi karta. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Timestamps ki timezone Europe/London hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Target column ka naam sunshine_hours hai. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "sunshine_hours",
    "evidence": "Target column ka naam sunshine_hours hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 17 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Forecast aglay 17 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r8-dev/solar_cloud/0021
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. Mera source reference https://inputs.example/solar_cloud/1402 hai. Read the input from a database. 11 ghantay ka horizon rakhein. Source observations arrive every 1 hour. Target ko watts per square metre mein measure karein. My prediction target is direct normal irradiance for Orven solar cloud site 1402.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1402",
    "evidence": "Mera source reference https://inputs.example/solar_cloud/1402 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "11 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target ko watts per square metre mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "direct normal irradiance for Orven solar cloud site 1402",
    "evidence": "My prediction target is direct normal irradiance for Orven solar cloud site 1402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "direct normal irradiance for Orven solar cloud site 1402",
    "evidence": "My prediction target is direct normal irradiance for Orven solar cloud site 1402."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Target values field dni_wm2 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dni_wm2",
    "evidence": "Target values field dni_wm2 se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Use one prediction row per hour as the output granularity. Source records har 4 ghantay update karein. Schedule model retraining every 1 month. Har 3 din naye forecasts banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Use one prediction row per hour as the output granularity."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source records har 4 ghantay update karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Schedule model retraining every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 14 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0021/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 14 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/solar_cloud/0026
Split: train

### t1 initial_multislot

I need forecasts of global horizontal irradiance for Orven solar cloud site 1402. Measure the target in watts per square metre. The observations are recorded every 1 hour. The forecast should extend 12 hours ahead. Read the input from a database. Use the data source https://inputs.example/solar_cloud/1402. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "global horizontal irradiance for Orven solar cloud site 1402",
    "evidence": "I need forecasts of global horizontal irradiance for Orven solar cloud site 1402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "global horizontal irradiance for Orven solar cloud site 1402",
    "evidence": "I need forecasts of global horizontal irradiance for Orven solar cloud site 1402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Measure the target in watts per square metre."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 12 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1402",
    "evidence": "Use the data source https://inputs.example/solar_cloud/1402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called ghi_wm2. The timestamp column is measurement_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ghi_wm2",
    "evidence": "The target column is called ghi_wm2."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The timestamp column is measurement_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Retrain the model every 1 month. The maximum response time is 3 seconds. Serialize the results as xlsx. Deliver completed forecasts to https://planning.example/solar_cloud/1402. The source contains no personal, confidential, or regulated data. Enforce these privacy restrictions: synthetic data only, no external redistribution.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Retrain the model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t3/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "second"
    },
    "evidence": "The maximum response time is 3 seconds."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t3/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Serialize the results as xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t3/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/solar_cloud/1402",
    "evidence": "Deliver completed forecasts to https://planning.example/solar_cloud/1402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t3/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "Enforce these privacy restrictions: synthetic data only, no external redistribution."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed. Detailed data lineage is not required. The required explanation level is feature_level. Human approval before modeling is not required. Our operational goal is to prepare a planning reserve for Orven solar cloud site 1402. My role in this project is solar resource analyst.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t4/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t4/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": false,
    "evidence": "Detailed data lineage is not required."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t4/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "feature_level",
    "evidence": "The required explanation level is feature_level."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t4/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Human approval before modeling is not required."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven solar cloud site 1402",
    "evidence": "Our operational goal is to prepare a planning reserve for Orven solar cloud site 1402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t4/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "solar resource analyst",
    "evidence": "My role in this project is solar resource analyst."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 15 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0026/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 15 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

For a separate new request, explain the definition of solar cloud. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/solar_cloud/0029
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  16 ghantay ka horizon rakhein. Target ko watts per square metre mein measure karein. direct normal irradiance for Orven solar cloud site 1402 ke liye prediction bana dein. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "16 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target ko watts per square metre mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "direct normal irradiance for Orven solar cloud site 1402",
    "evidence": "direct normal irradiance for Orven solar cloud site 1402 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "direct normal irradiance for Orven solar cloud site 1402",
    "evidence": "direct normal irradiance for Orven solar cloud site 1402 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Har 3 din naye forecasts banayein. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Time field ka naam measurement_time hai. Target values field dni_wm2 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dni_wm2",
    "evidence": "Target values field dni_wm2 se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 19 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0029/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "19 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r8-dev/solar_cloud/0044
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for global horizontal irradiance for Talven solar cloud site 1404. Target measurements ki unit watts per square metre hai. Each observed record covers 1 hour. Future coverage 20 ghantay chahiye. I will upload the data. Diya hua source identifier solar_cloud_archive_1404.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "global horizontal irradiance for Talven solar cloud site 1404",
    "evidence": "We need an outlook for global horizontal irradiance for Talven solar cloud site 1404."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "global horizontal irradiance for Talven solar cloud site 1404",
    "evidence": "We need an outlook for global horizontal irradiance for Talven solar cloud site 1404."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target measurements ki unit watts per square metre hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "Future coverage 20 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1404.csv",
    "evidence": "Diya hua source identifier solar_cloud_archive_1404.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The requested future coverage is 20 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The requested future coverage is 20 hours."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 23 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 23 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The requested future coverage is 23 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0044/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 23,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The requested future coverage is 23 hours."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/solar_cloud/0052
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. Mera source reference https://inputs.example/solar_cloud/1405 hai. Access the input through an API. 17 ghantay ka horizon rakhein. Source observations arrive every 1 hour. Target ko percent mein measure karein. My prediction target is cloud cover for Virelo solar cloud site 1405.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1405",
    "evidence": "Mera source reference https://inputs.example/solar_cloud/1405 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "17 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ko percent mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "cloud cover for Virelo solar cloud site 1405",
    "evidence": "My prediction target is cloud cover for Virelo solar cloud site 1405."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "cloud cover for Virelo solar cloud site 1405",
    "evidence": "My prediction target is cloud cover for Virelo solar cloud site 1405."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Target values field cloud_pct se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cloud_pct",
    "evidence": "Target values field cloud_pct se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 20 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 20 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/solar_cloud/52. Source observations har 2 ghantay aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/solar_cloud/52",
    "evidence": "My source reference is https://revised.example/solar_cloud/52."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0052/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Source observations har 2 ghantay aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r8-dev/solar_cloud/0058
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/solar_cloud/1405 hai. Input API ke zariye lein. Aglay 8 ghantay predict karein. Har 1 ghanta aik observed data point milta hai. Target values watts per square metre mein hain. direct normal irradiance for Virelo solar cloud site 1405 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1405",
    "evidence": "Source https://inputs.example/solar_cloud/1405 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Aglay 8 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target values watts per square metre mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "direct normal irradiance for Virelo solar cloud site 1405",
    "evidence": "direct normal irradiance for Virelo solar cloud site 1405 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "direct normal irradiance for Virelo solar cloud site 1405",
    "evidence": "direct normal irradiance for Virelo solar cloud site 1405 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates field observed_time mein hain. Column true ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates field observed_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Column true ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values allowed nahi hain. Source mein confidential synthetic records hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 11 ghantay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0058/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Aglay 11 ghantay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r8-dev/solar_cloud/0063
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for cloud cover for Weslin solar cloud site 1406. Target measurements ki unit percent hai. Each observed record covers 1 hour. Future coverage 18 ghantay chahiye. Read the input from a database. Diya hua source identifier https://inputs.example/solar_cloud/1406 hai. The input container uses json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "cloud cover for Weslin solar cloud site 1406",
    "evidence": "We need an outlook for cloud cover for Weslin solar cloud site 1406."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "cloud cover for Weslin solar cloud site 1406",
    "evidence": "We need an outlook for cloud cover for Weslin solar cloud site 1406."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target measurements ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "Future coverage 18 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1406",
    "evidence": "Diya hua source identifier https://inputs.example/solar_cloud/1406 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input container uses json."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

All observed times use the Asia/Karachi timezone. Repeating seasonal pattern expect karta hoon. The seasonal cycles in observation periods are 24, 168. forecast type ki requirement probabilistic hai. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "All observed times use the Asia/Karachi timezone."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "The seasonal cycles in observation periods are 24, 168."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The response variable is stored in column cloud_pct. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cloud_pct",
    "evidence": "The response variable is stored in column cloud_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 21 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0063/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 21 hours."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r8-dev/solar_cloud/0066
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein global horizontal irradiance for Weslin solar cloud site 1406 ka outlook chahiye. Target measurements ki unit watts per square metre hai. Har observed record 1 ghanta cover karta hai. Future coverage 5 ghantay chahiye. Input database se read karein. Diya hua source identifier https://inputs.example/solar_cloud/1406 hai. Input container json use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "global horizontal irradiance for Weslin solar cloud site 1406",
    "evidence": "Hamein global horizontal irradiance for Weslin solar cloud site 1406 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "global horizontal irradiance for Weslin solar cloud site 1406",
    "evidence": "Hamein global horizontal irradiance for Weslin solar cloud site 1406 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target measurements ki unit watts per square metre hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har observed record 1 ghanta cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Future coverage 5 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1406",
    "evidence": "Diya hua source identifier https://inputs.example/solar_cloud/1406 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input container json use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column ghi_wm2 mein hai. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ghi_wm2",
    "evidence": "Response variable column ghi_wm2 mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

scenario forecasts ki requirement [{"description": "synthetic planning sensitivity", "name": "stress"}] hai. rounding rule ki requirement {"decimal_places": 2} hai. Prediction rows ki resolution one prediction row per hour hai. primary metric ki requirement mase hai. secondary metrics ki requirement rmse, smape hai. validation strategy ki requirement rolling_origin hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t3/scenario_forecasts",
    "slot_id": "scenario_forecasts",
    "status": "provided",
    "value": [
      {
        "description": "synthetic planning sensitivity",
        "name": "stress"
      }
    ],
    "evidence": "scenario forecasts ki requirement [{\"description\": \"synthetic planning sensitivity\", \"name\": \"stress\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t3/rounding_rule",
    "slot_id": "rounding_rule",
    "status": "provided",
    "value": {
      "decimal_places": 2
    },
    "evidence": "rounding rule ki requirement {\"decimal_places\": 2} hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Prediction rows ki resolution one prediction row per hour hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t3/primary_metric",
    "slot_id": "primary_metric",
    "status": "provided",
    "value": "mase",
    "evidence": "primary metric ki requirement mase hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t3/secondary_metrics",
    "slot_id": "secondary_metrics",
    "status": "provided",
    "value": [
      "rmse",
      "smape"
    ],
    "evidence": "secondary metrics ki requirement rmse, smape hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t3/validation_strategy",
    "slot_id": "validation_strategy",
    "status": "provided",
    "value": "rolling_origin",
    "evidence": "validation strategy ki requirement rolling_origin hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

backtest folds ki requirement 4 hai. holdout window length 7 ghantay hai. baseline model ki requirement naive hai. acceptable error ki requirement {"maximum": 2, "metric": "mae"} hai. inference mode ki requirement batch hai. Naye forecasts har 1 din issue karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t4/backtest_folds",
    "slot_id": "backtest_folds",
    "status": "provided",
    "value": 4,
    "evidence": "backtest folds ki requirement 4 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t4/test_window",
    "slot_id": "test_window",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "holdout window length 7 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t4/baseline_model",
    "slot_id": "baseline_model",
    "status": "provided",
    "value": "naive",
    "evidence": "baseline model ki requirement naive hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t4/acceptable_error",
    "slot_id": "acceptable_error",
    "status": "provided",
    "value": {
      "maximum": 2,
      "metric": "mae"
    },
    "evidence": "acceptable error ki requirement {\"maximum\": 2, \"metric\": \"mae\"} hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t4/inference_mode",
    "slot_id": "inference_mode",
    "status": "provided",
    "value": "batch",
    "evidence": "inference mode ki requirement batch hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t4/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naye forecasts har 1 din issue karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Future coverage 8 ghantay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0066/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Future coverage 8 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261009-r8-dev/solar_cloud/0080
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for global horizontal irradiance for Merlow solar cloud site 1408. Target measurements ki unit watts per square metre hai. Each observed record covers 1 hour. Future coverage 19 ghantay chahiye. I will upload the data. Diya hua source identifier solar_cloud_archive_1408.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1408",
    "evidence": "We need an outlook for global horizontal irradiance for Merlow solar cloud site 1408."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1408",
    "evidence": "We need an outlook for global horizontal irradiance for Merlow solar cloud site 1408."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target measurements ki unit watts per square metre hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "Future coverage 19 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1408.csv",
    "evidence": "Diya hua source identifier solar_cloud_archive_1408.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column ghi_wm2. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "ghi_wm2",
    "evidence": "The response variable is stored in column ghi_wm2."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 22 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 22 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow solar cloud site 1408.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0080/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow solar cloud site 1408",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow solar cloud site 1408."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/solar_cloud/0084
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein global horizontal irradiance for Merlow solar cloud site 1408 ka outlook chahiye. Target measurements ki unit watts per square metre hai. Har observed record 1 ghanta cover karta hai. Future coverage 13 ghantay chahiye. Main data upload karunga. Diya hua source identifier solar_cloud_archive_1408.csv hai. Input container csv use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1408",
    "evidence": "Hamein global horizontal irradiance for Merlow solar cloud site 1408 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "global horizontal irradiance for Merlow solar cloud site 1408",
    "evidence": "Hamein global horizontal irradiance for Merlow solar cloud site 1408 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target measurements ki unit watts per square metre hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har observed record 1 ghanta cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "Future coverage 13 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1408.csv",
    "evidence": "Diya hua source identifier solar_cloud_archive_1408.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input container csv use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Future coverage 13 ghantay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Future coverage 13 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 16 ghantay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Future coverage 16 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Future coverage 16 ghantay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0084/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Future coverage 16 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r8-dev/solar_cloud/0118
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. Mera source reference https://inputs.example/solar_cloud/1411 hai. Select the source from the data catalog. 6 ghantay ka horizon rakhein. Source observations arrive every 1 hour. Target ko percent mein measure karein. My prediction target is cloud cover for Pelmar solar cloud site 1411.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1411",
    "evidence": "Mera source reference https://inputs.example/solar_cloud/1411 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "hour"
    },
    "evidence": "6 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ko percent mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "cloud cover for Pelmar solar cloud site 1411",
    "evidence": "My prediction target is cloud cover for Pelmar solar cloud site 1411."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "cloud cover for Pelmar solar cloud site 1411",
    "evidence": "My prediction target is cloud cover for Pelmar solar cloud site 1411."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The time field name is recorded_at. Target values field value "net" se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "Target values field value \"net\" se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. Source mein confidential synthetic records hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 9 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0118/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 9 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/solar_cloud/0125
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. Source solar_cloud_archive_1412.csv hai. I will upload the data. Aglay 13 ghantay predict karein. There is one observed data point every 1 hour. Target values percent mein hain. The quantity to predict is cloud cover for Talven solar cloud site 1412.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1412.csv",
    "evidence": "Source solar_cloud_archive_1412.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "Aglay 13 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target values percent mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "cloud cover for Talven solar cloud site 1412",
    "evidence": "The quantity to predict is cloud cover for Talven solar cloud site 1412."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "cloud cover for Talven solar cloud site 1412",
    "evidence": "The quantity to predict is cloud cover for Talven solar cloud site 1412."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Column cloud_pct ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "cloud_pct",
    "evidence": "Column cloud_pct ko target rakhein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in percent. Har 1 ghanta aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0125/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "I need the next 16 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r8-dev/solar_cloud/0145
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format json hai. Mera source reference https://inputs.example/solar_cloud/1414 hai. Input database se read karein. 18 ghantay ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko watts per square metre mein measure karein. direct normal irradiance for Weslin solar cloud site 1414 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Source serialization format json hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/solar_cloud/1414",
    "evidence": "Mera source reference https://inputs.example/solar_cloud/1414 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "18 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target ko watts per square metre mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "direct normal irradiance for Weslin solar cloud site 1414",
    "evidence": "direct normal irradiance for Weslin solar cloud site 1414 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "direct normal irradiance for Weslin solar cloud site 1414",
    "evidence": "direct normal irradiance for Weslin solar cloud site 1414 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam measurement_time hai. Target values field dni_wm2 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dni_wm2",
    "evidence": "Target values field dni_wm2 se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target ko watts per square metre mein measure karein. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target ko watts per square metre mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. 21 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0145/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "21 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r8-dev/solar_cloud/0162
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target sunshine duration for Merlow solar cloud site 1416 hai. Measurement unit hours rakhein. Asli data ka sampling interval 1 din hai. Forecast horizon 19 din hai. Main data upload karunga. Observations solar_cloud_archive_1416.csv se lein. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "sunshine duration for Merlow solar cloud site 1416",
    "evidence": "Prediction ka target sunshine duration for Merlow solar cloud site 1416 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "sunshine duration for Merlow solar cloud site 1416",
    "evidence": "Prediction ka target sunshine duration for Merlow solar cloud site 1416 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "hours",
    "evidence": "Measurement unit hours rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "Forecast horizon 19 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "solar_cloud_archive_1416.csv",
    "evidence": "Observations solar_cloud_archive_1416.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field sunshine_hours hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "sunshine_hours",
    "evidence": "Target field sunshine_hours hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 22 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "day"
    },
    "evidence": "Forecast horizon 22 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Asli data ka sampling interval 2 din hai. Observations https://revised.example/solar_cloud/162 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 2 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0162/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/solar_cloud/162",
    "evidence": "Observations https://revised.example/solar_cloud/162 se lein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/solar_cloud/0189
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 5 hours. Target ko watts per square metre mein measure karein. My prediction target is direct normal irradiance for Orven solar cloud site 1418. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 5 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "watts per square metre",
    "evidence": "Target ko watts per square metre mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "direct normal irradiance for Orven solar cloud site 1418",
    "evidence": "My prediction target is direct normal irradiance for Orven solar cloud site 1418."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "direct normal irradiance for Orven solar cloud site 1418",
    "evidence": "My prediction target is direct normal irradiance for Orven solar cloud site 1418."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Produce new forecasts every 1 day. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The time field name is measurement_time. Target values field dni_wm2 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "dni_wm2",
    "evidence": "Target values field dni_wm2 se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 8 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/solar_cloud/0189/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 8 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
