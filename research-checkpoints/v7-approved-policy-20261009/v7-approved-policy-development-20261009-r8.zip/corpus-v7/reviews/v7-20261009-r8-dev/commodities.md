# V7 review examples for commodities

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r8-dev/commodities/0000
Split: train

### t1 initial_multislot

I need forecasts of spot crude-oil price for Merlow commodities site 2200. Measure the target in USD per barrel. The observations are recorded every 1 day. The forecast should extend 6 days ahead. I will upload the data. Use the data source commodities_archive_2200.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2200",
    "evidence": "I need forecasts of spot crude-oil price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2200",
    "evidence": "I need forecasts of spot crude-oil price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per barrel",
    "evidence": "Measure the target in USD per barrel."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "The forecast should extend 6 days ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "Use the data source commodities_archive_2200.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called oil_spot. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "oil_spot",
    "evidence": "The target column is called oil_spot."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 9 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "The forecast should extend 9 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow commodities site 2200.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow commodities site 2200",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow commodities site 2200."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/commodities/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is commodities_archive_2200.csv. I will upload the data. I need the next 13 days predicted. There is one observed data point every 1 day. The target values are in USD per troy ounce. The quantity to predict is spot gold price for Merlow commodities site 2200.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "The source is commodities_archive_2200.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "I need the next 13 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "The target values are in USD per troy ounce."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot gold price for Merlow commodities site 2200",
    "evidence": "The quantity to predict is spot gold price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot gold price for Merlow commodities site 2200",
    "evidence": "The quantity to predict is spot gold price for Merlow commodities site 2200."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Use column gold_spot as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gold_spot",
    "evidence": "Use column gold_spot as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per day. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Return forecasts with resolution one prediction row per day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "I need the next 16 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/commodities/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict wheat cash price for Merlow commodities site 2200. Measurement unit USD per metric tonne rakhein. The native sampling interval is 1 day. Forecast horizon 20 din hai. I will upload the data. Observations commodities_archive_2200.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price for Merlow commodities site 2200",
    "evidence": "Please predict wheat cash price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price for Merlow commodities site 2200",
    "evidence": "Please predict wheat cash price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Measurement unit USD per metric tonne rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Forecast horizon 20 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "Observations commodities_archive_2200.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is wheat_cash. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_cash",
    "evidence": "The target field name is wheat_cash."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 23 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 23 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 days. Observations https://revised.example/commodities/2 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/commodities/2",
    "evidence": "Observations https://revised.example/commodities/2 se lein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of commodities. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/commodities/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is commodities_archive_2200.csv. I will upload the data. Predict a horizon of 10 days. Source observations arrive every 1 day. Use USD per MMBtu as the target unit. My prediction target is natural-gas front-month settlement price for Merlow commodities site 2200.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "My source reference is commodities_archive_2200.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 10 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MMBtu",
    "evidence": "Use USD per MMBtu as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Merlow commodities site 2200",
    "evidence": "My prediction target is natural-gas front-month settlement price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Merlow commodities site 2200",
    "evidence": "My prediction target is natural-gas front-month settlement price for Merlow commodities site 2200."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. The seasonal cycles in observation periods are 7, 365. I expect a repeating seasonal pattern. Use timezone UTC.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      7,
      365
    ],
    "evidence": "The seasonal cycles in observation periods are 7, 365."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Use timezone UTC."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is sample_date. Read target values from field gas_settlement.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gas_settlement",
    "evidence": "Read target values from field gas_settlement."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 13 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 13 days."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/commodities/0004
Split: train

### t1 initial_multislot

I need forecasts of spot crude-oil price for Merlow commodities site 2200. Measure the target in USD per barrel. The observations are recorded every 1 day. The forecast should extend 17 days ahead. I will upload the data. Use the data source commodities_archive_2200.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2200",
    "evidence": "I need forecasts of spot crude-oil price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2200",
    "evidence": "I need forecasts of spot crude-oil price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per barrel",
    "evidence": "Measure the target in USD per barrel."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "The forecast should extend 17 days ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "Use the data source commodities_archive_2200.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 17 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 17 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 20 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "The forecast should extend 20 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 20 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 20 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/commodities/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is commodities_archive_2200.csv. I will upload the data. I need the next 7 days predicted. There is one observed data point every 1 day. The target values are in USD per troy ounce. The quantity to predict is spot gold price for Merlow commodities site 2200.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "The source is commodities_archive_2200.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "I need the next 7 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "The target values are in USD per troy ounce."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot gold price for Merlow commodities site 2200",
    "evidence": "The quantity to predict is spot gold price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot gold price for Merlow commodities site 2200",
    "evidence": "The quantity to predict is spot gold price for Merlow commodities site 2200."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Use column gold_spot as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gold_spot",
    "evidence": "Use column gold_spot as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in USD per troy ounce. There is one observed data point every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "The target values are in USD per troy ounce."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 10 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "I need the next 10 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/commodities/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict wheat cash price for Merlow commodities site 2200. Keep the measurement unit as USD per metric tonne. The native sampling interval is 1 day. The forecast horizon is 14 days. I will upload the data. Read the observations from commodities_archive_2200.csv. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price for Merlow commodities site 2200",
    "evidence": "Please predict wheat cash price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price for Merlow commodities site 2200",
    "evidence": "Please predict wheat cash price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Keep the measurement unit as USD per metric tonne."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 14 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "Read the observations from commodities_archive_2200.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is wheat_cash. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_cash",
    "evidence": "The target field name is wheat_cash."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The historical observations begin at 2020-01-01T00:00:00+00:00. The historical observations end at 2026-09-30T00:00:00+00:00. The available historical coverage is 81 months. Require at least 365 training observations. The recorded structural breaks are [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}]. For missing periods, use the policy resample.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t3/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "The historical observations begin at 2020-01-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t3/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "The historical observations end at 2026-09-30T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t3/expected_history_length",
    "slot_id": "expected_history_length",
    "status": "provided",
    "value": {
      "periods": 81,
      "unit": "month"
    },
    "evidence": "The available historical coverage is 81 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t3/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 365,
    "evidence": "Require at least 365 training observations."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t3/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "The recorded structural breaks are [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t3/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "resample",
    "evidence": "For missing periods, use the policy resample."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

For missing target values, use the policy interpolate. For duplicate observations, use the policy latest. For unusual values, use the policy cap. For invalid values, use the policy reject. Require non-missing coverage of at least 86 percent. I expect a repeating seasonal pattern.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t4/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "interpolate",
    "evidence": "For missing target values, use the policy interpolate."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t4/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "latest",
    "evidence": "For duplicate observations, use the policy latest."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t4/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "For unusual values, use the policy cap."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t4/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "For invalid values, use the policy reject."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t4/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "Require non-missing coverage of at least 86 percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t4/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 17 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 17 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/commodities/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 4 days. Source observations arrive every 1 day. Use USD per MMBtu as the target unit. My prediction target is natural-gas front-month settlement price for Merlow commodities site 2200. Do not substitute spot crude-oil price as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 4 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MMBtu",
    "evidence": "Use USD per MMBtu as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Merlow commodities site 2200",
    "evidence": "My prediction target is natural-gas front-month settlement price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Merlow commodities site 2200",
    "evidence": "My prediction target is natural-gas front-month settlement price for Merlow commodities site 2200."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field gas_settlement.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gas_settlement",
    "evidence": "Read target values from field gas_settlement."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is csv. My source reference is commodities_archive_2200.csv. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "My source reference is commodities_archive_2200.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 7 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 7 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r8-dev/commodities/0008
Split: train

### t1 initial_multislot

Mujhe spot crude-oil price for Merlow commodities site 2200 ka forecast chahiye. Target ki unit USD per barrel hai. Observations har 1 din record hoti hain. Forecast aglay 11 din tak chahiye. Main data upload karunga. Data source commodities_archive_2200.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2200",
    "evidence": "Mujhe spot crude-oil price for Merlow commodities site 2200 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2200",
    "evidence": "Mujhe spot crude-oil price for Merlow commodities site 2200 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per barrel",
    "evidence": "Target ki unit USD per barrel hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Forecast aglay 11 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2200.csv",
    "evidence": "Data source commodities_archive_2200.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein personal ya confidential data nahi hai. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 14 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Forecast aglay 14 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/commodities/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 18 days predicted. The target values are in USD per troy ounce. The quantity to predict is spot gold price for Merlow commodities site 2200. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "I need the next 18 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "The target values are in USD per troy ounce."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot gold price for Merlow commodities site 2200",
    "evidence": "The quantity to predict is spot gold price for Merlow commodities site 2200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot gold price for Merlow commodities site 2200",
    "evidence": "The quantity to predict is spot gold price for Merlow commodities site 2200."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field sample_date. Use column gold_spot as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gold_spot",
    "evidence": "Use column gold_spot as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 21 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "I need the next 21 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/commodities/0012
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. My source reference is https://inputs.example/commodities/2201. Access the input through an API. Predict a horizon of 14 days. Source observations arrive every 1 day. Use USD per troy ounce as the target unit. My prediction target is spot gold price for Norelia commodities site 2201.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2201",
    "evidence": "My source reference is https://inputs.example/commodities/2201."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 14 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "Use USD per troy ounce as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot gold price for Norelia commodities site 2201",
    "evidence": "My prediction target is spot gold price for Norelia commodities site 2201."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot gold price for Norelia commodities site 2201",
    "evidence": "My prediction target is spot gold price for Norelia commodities site 2201."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field gold_spot.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gold_spot",
    "evidence": "Read target values from field gold_spot."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 17 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 17 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/commodities/12. Source observations arrive every 2 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/commodities/12",
    "evidence": "My source reference is https://revised.example/commodities/12."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0012/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 2 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/commodities/0014
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/commodities/2201 hai. Input API ke zariye lein. Aglay 11 din predict karein. Har 1 din aik observed data point milta hai. Target values USD per MMBtu mein hain. natural-gas front-month settlement price for Norelia commodities site 2201 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2201",
    "evidence": "Source https://inputs.example/commodities/2201 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Aglay 11 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MMBtu",
    "evidence": "Target values USD per MMBtu mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Norelia commodities site 2201",
    "evidence": "natural-gas front-month settlement price for Norelia commodities site 2201 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Norelia commodities site 2201",
    "evidence": "natural-gas front-month settlement price for Norelia commodities site 2201 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 11 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 11 din predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 14 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Aglay 14 din predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 14 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0014/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 14 din predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r8-dev/commodities/0017
Split: train

### t1 initial_multislot

I need forecasts of wheat cash price for Norelia commodities site 2201. Target ki unit USD per metric tonne hai. The observations are recorded every 1 day. Forecast aglay 15 din tak chahiye. Do not substitute natural-gas front-month settlement price as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price for Norelia commodities site 2201",
    "evidence": "I need forecasts of wheat cash price for Norelia commodities site 2201."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price for Norelia commodities site 2201",
    "evidence": "I need forecasts of wheat cash price for Norelia commodities site 2201."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target ki unit USD per metric tonne hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "Forecast aglay 15 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called wheat_cash. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_cash",
    "evidence": "The target column is called wheat_cash."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Access the input through an API. Data source https://inputs.example/commodities/2201 use karein. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2201",
    "evidence": "Data source https://inputs.example/commodities/2201 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 18 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0017/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "The forecast should extend 18 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/commodities/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/commodities/2201. Access the input through an API. I need the next 5 days predicted. There is one observed data point every 1 day. The target values are in USD per MMBtu. The quantity to predict is natural-gas front-month settlement price for Norelia commodities site 2201.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2201",
    "evidence": "The source is https://inputs.example/commodities/2201."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "I need the next 5 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MMBtu",
    "evidence": "The target values are in USD per MMBtu."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Norelia commodities site 2201",
    "evidence": "The quantity to predict is natural-gas front-month settlement price for Norelia commodities site 2201."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Norelia commodities site 2201",
    "evidence": "The quantity to predict is natural-gas front-month settlement price for Norelia commodities site 2201."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field observed_time. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains confidential synthetic records.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "I need the next 8 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r8-dev/commodities/0023
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format json hai. Source https://inputs.example/commodities/2202 hai. Input database se read karein. Aglay 15 din predict karein. Har 1 din aik observed data point milta hai. Target values USD per troy ounce mein hain. spot gold price for Orven commodities site 2202 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Diye hue data ka format json hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2202",
    "evidence": "Source https://inputs.example/commodities/2202 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "Aglay 15 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "Target values USD per troy ounce mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot gold price for Orven commodities site 2202",
    "evidence": "spot gold price for Orven commodities site 2202 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot gold price for Orven commodities site 2202",
    "evidence": "spot gold price for Orven commodities site 2202 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

prediction interval levels ki requirement 80, 95 hai. forecast type ki requirement probabilistic hai. seasonal periods ki requirement 7, 365 hai. Repeating seasonal pattern expect karta hoon. Times Europe/London mein hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      7,
      365
    ],
    "evidence": "seasonal periods ki requirement 7, 365 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Times Europe/London mein hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates field measurement_time mein hain. Column gold_spot ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gold_spot",
    "evidence": "Column gold_spot ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Aglay 18 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0023/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Aglay 18 din predict karein."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/commodities/0025
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. Mera source reference https://inputs.example/commodities/2202 hai. Read the input from a database. 12 din ka horizon rakhein. Source observations arrive every 1 day. Target ko USD per MMBtu mein measure karein. My prediction target is natural-gas front-month settlement price for Orven commodities site 2202.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2202",
    "evidence": "Mera source reference https://inputs.example/commodities/2202 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "12 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MMBtu",
    "evidence": "Target ko USD per MMBtu mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Orven commodities site 2202",
    "evidence": "My prediction target is natural-gas front-month settlement price for Orven commodities site 2202."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Orven commodities site 2202",
    "evidence": "My prediction target is natural-gas front-month settlement price for Orven commodities site 2202."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Target values field gas_settlement se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gas_settlement",
    "evidence": "Target values field gas_settlement se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Use USD per MMBtu as the target unit. Source observations har 1 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MMBtu",
    "evidence": "Use USD per MMBtu as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 15 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0025/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 15 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/commodities/0031
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein wheat cash price for Pelmar commodities site 2203 ka outlook chahiye. Target measurements ki unit USD per metric tonne hai. Har observed record 1 din cover karta hai. Future coverage 12 din chahiye. Source data catalog se select karein. Diya hua source identifier https://inputs.example/commodities/2203 hai. Input container xlsx use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price for Pelmar commodities site 2203",
    "evidence": "Hamein wheat cash price for Pelmar commodities site 2203 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price for Pelmar commodities site 2203",
    "evidence": "Hamein wheat cash price for Pelmar commodities site 2203 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target measurements ki unit USD per metric tonne hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Future coverage 12 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2203",
    "evidence": "Diya hua source identifier https://inputs.example/commodities/2203 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input container xlsx use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column wheat_cash mein hai. Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_cash",
    "evidence": "Response variable column wheat_cash mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Naye forecasts har 1 din issue karein. Model har 2 mahinay dobara estimate karein. Source ingestion har 5 ghantay repeat hoti hai. Prediction rows ki resolution one prediction row per day hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naye forecasts har 1 din issue karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Model har 2 mahinay dobara estimate karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Source ingestion har 5 ghantay repeat hoti hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Prediction rows ki resolution one prediction row per day hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 15 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0031/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "Future coverage 15 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r8-dev/commodities/0038
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for spot gold price for Pelmar commodities site 2203. Target measurements ki unit USD per troy ounce hai. Each observed record covers 1 day. Future coverage 10 din chahiye. Select the source from the data catalog. Diya hua source identifier https://inputs.example/commodities/2203 hai. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot gold price for Pelmar commodities site 2203",
    "evidence": "We need an outlook for spot gold price for Pelmar commodities site 2203."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot gold price for Pelmar commodities site 2203",
    "evidence": "We need an outlook for spot gold price for Pelmar commodities site 2203."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "Target measurements ki unit USD per troy ounce hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Future coverage 10 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2203",
    "evidence": "Diya hua source identifier https://inputs.example/commodities/2203 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The response variable is stored in column value "net". Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "The response variable is stored in column value \"net\"."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 13 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0038/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 13 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r8-dev/commodities/0046
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target wheat cash price for Talven commodities site 2204 hai. Measurement unit USD per metric tonne rakhein. Asli data ka sampling interval 1 din hai. Forecast horizon 7 din hai. Main data upload karunga. Observations commodities_archive_2204.csv se lein. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price for Talven commodities site 2204",
    "evidence": "Prediction ka target wheat cash price for Talven commodities site 2204 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price for Talven commodities site 2204",
    "evidence": "Prediction ka target wheat cash price for Talven commodities site 2204 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Measurement unit USD per metric tonne rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Forecast horizon 7 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2204.csv",
    "evidence": "Observations commodities_archive_2204.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field wheat_cash hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_cash",
    "evidence": "Target field wheat_cash hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

forecast start ki requirement 2026-10-01T00:00:00+00:00 hai. data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai. lead time 1 din hai. dataset type ki requirement hierarchical hai. series id columns ki requirement site_id hai. hierarchy columns ki requirement region_id, site_id hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t3/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "forecast start ki requirement 2026-10-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t3/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t3/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "lead time 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t3/dataset_type",
    "slot_id": "dataset_type",
    "status": "provided",
    "value": "hierarchical",
    "evidence": "dataset type ki requirement hierarchical hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t3/series_id_columns",
    "slot_id": "series_id_columns",
    "status": "provided",
    "value": [
      "site_id"
    ],
    "evidence": "series id columns ki requirement site_id hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t3/hierarchy_columns",
    "slot_id": "hierarchy_columns",
    "status": "provided",
    "value": [
      "region_id",
      "site_id"
    ],
    "evidence": "hierarchy columns ki requirement region_id, site_id hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

aggregation level ki requirement site hai. scope filters ki requirement [{"column": "site_id", "operator": "eq", "value": "Talven commodities site 2204"}] hai. geography ki requirement Fictional Talven commodities site 2204 region hai. source provider ki requirement Synthetic Economic Research Laboratory hai. sheet or table ki requirement commodities_observations hai. Input source refresh schedule har 2 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t4/aggregation_level",
    "slot_id": "aggregation_level",
    "status": "provided",
    "value": "site",
    "evidence": "aggregation level ki requirement site hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t4/scope_filters",
    "slot_id": "scope_filters",
    "status": "provided",
    "value": [
      {
        "column": "site_id",
        "operator": "eq",
        "value": "Talven commodities site 2204"
      }
    ],
    "evidence": "scope filters ki requirement [{\"column\": \"site_id\", \"operator\": \"eq\", \"value\": \"Talven commodities site 2204\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t4/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Talven commodities site 2204 region"
    ],
    "evidence": "geography ki requirement Fictional Talven commodities site 2204 region hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t4/source_provider",
    "slot_id": "source_provider",
    "status": "provided",
    "value": "Synthetic Economic Research Laboratory",
    "evidence": "source provider ki requirement Synthetic Economic Research Laboratory hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t4/sheet_or_table",
    "slot_id": "sheet_or_table",
    "status": "provided",
    "value": "commodities_observations",
    "evidence": "sheet or table ki requirement commodities_observations hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t4/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Input source refresh schedule har 2 ghantay hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 10 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0046/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Forecast horizon 10 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

Nayi request: commodities ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r8-dev/commodities/0080
Split: train

### t1 initial_multislot

Mujhe spot crude-oil price for Merlow commodities site 2208 ka forecast chahiye. Target ki unit USD per barrel hai. Observations har 1 din record hoti hain. Forecast aglay 9 din tak chahiye. Main data upload karunga. Data source commodities_archive_2208.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2208",
    "evidence": "Mujhe spot crude-oil price for Merlow commodities site 2208 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2208",
    "evidence": "Mujhe spot crude-oil price for Merlow commodities site 2208 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per barrel",
    "evidence": "Target ki unit USD per barrel hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Forecast aglay 9 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2208.csv",
    "evidence": "Data source commodities_archive_2208.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam oil_spot hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "oil_spot",
    "evidence": "Target column ka naam oil_spot hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 12 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Forecast aglay 12 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Merlow commodities site 2208 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0080/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow commodities site 2208",
    "evidence": "business goal ki requirement prepare a planning reserve for Merlow commodities site 2208 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: commodities ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r8-dev/commodities/0084
Split: train

### t1 initial_multislot

I need forecasts of spot crude-oil price for Merlow commodities site 2208. Target ki unit USD per barrel hai. The observations are recorded every 1 day. Forecast aglay 20 din tak chahiye. I will upload the data. Data source commodities_archive_2208.csv use karein. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2208",
    "evidence": "I need forecasts of spot crude-oil price for Merlow commodities site 2208."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot crude-oil price for Merlow commodities site 2208",
    "evidence": "I need forecasts of spot crude-oil price for Merlow commodities site 2208."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per barrel",
    "evidence": "Target ki unit USD per barrel hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Forecast aglay 20 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "commodities_archive_2208.csv",
    "evidence": "Data source commodities_archive_2208.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 20 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 20 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 23 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "The forecast should extend 23 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 23 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0084/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 23 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r8-dev/commodities/0097
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein wheat cash price for Norelia commodities site 2209 ka outlook chahiye. Target measurements ki unit USD per metric tonne hai. Har observed record 1 din cover karta hai. Future coverage 18 din chahiye. natural-gas front-month settlement price nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wheat cash price for Norelia commodities site 2209",
    "evidence": "Hamein wheat cash price for Norelia commodities site 2209 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wheat cash price for Norelia commodities site 2209",
    "evidence": "Hamein wheat cash price for Norelia commodities site 2209 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per metric tonne",
    "evidence": "Target measurements ki unit USD per metric tonne hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Future coverage 18 din chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column wheat_cash mein hai. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wheat_cash",
    "evidence": "Response variable column wheat_cash mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Input API ke zariye lein. Diya hua source identifier https://inputs.example/commodities/2209 hai. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2209",
    "evidence": "Diya hua source identifier https://inputs.example/commodities/2209 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 21 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0097/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "Future coverage 21 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r8-dev/commodities/0101
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. Mera source reference https://inputs.example/commodities/2210 hai. Read the input from a database. 4 din ka horizon rakhein. Source observations arrive every 1 day. Target ko USD per MMBtu mein measure karein. My prediction target is natural-gas front-month settlement price for Orven commodities site 2210.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2210",
    "evidence": "Mera source reference https://inputs.example/commodities/2210 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "4 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MMBtu",
    "evidence": "Target ko USD per MMBtu mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Orven commodities site 2210",
    "evidence": "My prediction target is natural-gas front-month settlement price for Orven commodities site 2210."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Orven commodities site 2210",
    "evidence": "My prediction target is natural-gas front-month settlement price for Orven commodities site 2210."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Target values field gas_settlement se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gas_settlement",
    "evidence": "Target values field gas_settlement se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Use one prediction row per day as the output granularity. Source records har 4 ghantay update karein. Schedule model retraining every 1 month. Har 2 din naye forecasts banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Use one prediction row per day as the output granularity."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source records har 4 ghantay update karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Schedule model retraining every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Har 2 din naye forecasts banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 7 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0101/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 7 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/commodities/0109
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  9 din ka horizon rakhein. Target ko USD per MMBtu mein measure karein. natural-gas front-month settlement price for Orven commodities site 2210 ke liye prediction bana dein. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "9 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MMBtu",
    "evidence": "Target ko USD per MMBtu mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Orven commodities site 2210",
    "evidence": "natural-gas front-month settlement price for Orven commodities site 2210 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas front-month settlement price for Orven commodities site 2210",
    "evidence": "natural-gas front-month settlement price for Orven commodities site 2210 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Har 2 din naye forecasts banayein. Source observations har 1 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Har 2 din naye forecasts banayein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Time field ka naam measurement_time hai. Target values field gas_settlement se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gas_settlement",
    "evidence": "Target values field gas_settlement se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 12 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0109/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "12 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r8-dev/commodities/0132
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format parquet hai. Mera source reference https://inputs.example/commodities/2213 hai. Input API ke zariye lein. 10 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko USD per troy ounce mein measure karein. spot gold price for Virelo commodities site 2213 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Source serialization format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2213",
    "evidence": "Mera source reference https://inputs.example/commodities/2213 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "10 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "Target ko USD per troy ounce mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot gold price for Virelo commodities site 2213",
    "evidence": "spot gold price for Virelo commodities site 2213 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot gold price for Virelo commodities site 2213",
    "evidence": "spot gold price for Virelo commodities site 2213 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam observed_time hai. Target values field gold_spot se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Time field ka naam observed_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gold_spot",
    "evidence": "Target values field gold_spot se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. 13 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "13 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Mera source reference https://revised.example/commodities/132 hai. Source observations har 2 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/commodities/132",
    "evidence": "Mera source reference https://revised.example/commodities/132 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0132/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Source observations har 2 din aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r8-dev/commodities/0183
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. Source https://inputs.example/commodities/2218 hai. Read the input from a database. Aglay 4 din predict karein. There is one observed data point every 1 day. Target values USD per troy ounce mein hain. The quantity to predict is spot gold price for Orven commodities site 2218.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/commodities/2218",
    "evidence": "Source https://inputs.example/commodities/2218 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "Aglay 4 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per troy ounce",
    "evidence": "Target values USD per troy ounce mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "spot gold price for Orven commodities site 2218",
    "evidence": "The quantity to predict is spot gold price for Orven commodities site 2218."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "spot gold price for Orven commodities site 2218",
    "evidence": "The quantity to predict is spot gold price for Orven commodities site 2218."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. forecast type ki requirement probabilistic hai. The seasonal cycles in observation periods are 7, 365. Repeating seasonal pattern expect karta hoon. Times are in UTC.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      7,
      365
    ],
    "evidence": "The seasonal cycles in observation periods are 7, 365."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Times are in UTC."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates are stored in field measurement_time. Column gold_spot ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gold_spot",
    "evidence": "Column gold_spot ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 7 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/commodities/0183/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "I need the next 7 days predicted."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending
