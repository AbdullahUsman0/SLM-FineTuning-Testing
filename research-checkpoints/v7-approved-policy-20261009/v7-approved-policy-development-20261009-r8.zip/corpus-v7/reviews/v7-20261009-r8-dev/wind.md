# V7 review examples for wind

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r8-dev/wind/0000
Split: train

### t1 initial_multislot

I need forecasts of mean wind speed for Merlow wind site 1200. Measure the target in kilometres per hour. The observations are recorded every 1 day. The forecast should extend 10 days ahead. Read the input from a database. Use the data source https://inputs.example/wind/1200. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "I need forecasts of mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "I need forecasts of mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "kilometres per hour",
    "evidence": "Measure the target in kilometres per hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "The forecast should extend 10 days ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "Use the data source https://inputs.example/wind/1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called wind_kmh. The timestamp column is measurement_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_kmh",
    "evidence": "The target column is called wind_kmh."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The timestamp column is measurement_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 13 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "The forecast should extend 13 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow wind site 1200.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow wind site 1200",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow wind site 1200."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r8-dev/wind/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. Source https://inputs.example/wind/1200 hai. Read the input from a database. Aglay 17 ghantay predict karein. There is one observed data point every 1 hour. Target values degrees clockwise from north mein hain. The quantity to predict is wind direction for Merlow wind site 1200.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "Source https://inputs.example/wind/1200 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Aglay 17 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees clockwise from north",
    "evidence": "Target values degrees clockwise from north mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wind direction for Merlow wind site 1200",
    "evidence": "The quantity to predict is wind direction for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wind direction for Merlow wind site 1200",
    "evidence": "The quantity to predict is wind direction for Merlow wind site 1200."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Column wind_direction ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_direction",
    "evidence": "Column wind_direction ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per hour. Har 2 ghantay naya source update lein. Refit the forecasting model every 1 month. Predictions har 1 din refresh karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Return forecasts with resolution one prediction row per hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghantay naya source update lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Predictions har 1 din refresh karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 20 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "I need the next 20 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/wind/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict mean wind speed for Merlow wind site 1200. Keep the measurement unit as metres per second. The native sampling interval is 1 hour. The forecast horizon is 7 hours. Read the input from a database. Read the observations from https://inputs.example/wind/1200. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "Please predict mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "Please predict mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Keep the measurement unit as metres per second."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 7 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "Read the observations from https://inputs.example/wind/1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is wind_ms. Use column measurement_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_ms",
    "evidence": "The target field name is wind_ms."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Use column measurement_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 10 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 10 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 hours. Read the observations from https://revised.example/wind/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/wind/2",
    "evidence": "Read the observations from https://revised.example/wind/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of wind. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/wind/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. My source reference is https://inputs.example/wind/1200. Read the input from a database. Predict a horizon of 14 hours. Source observations arrive every 1 hour. Use metres per second as the target unit. My prediction target is maximum gust speed for Merlow wind site 1200.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "My source reference is https://inputs.example/wind/1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 14 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Use metres per second as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum gust speed for Merlow wind site 1200",
    "evidence": "My prediction target is maximum gust speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum gust speed for Merlow wind site 1200",
    "evidence": "My prediction target is maximum gust speed for Merlow wind site 1200."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. The seasonal cycles in observation periods are 24, 168. I expect a repeating seasonal pattern. Use timezone Europe/London.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "The seasonal cycles in observation periods are 24, 168."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Use timezone Europe/London."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is measurement_time. Read target values from field gust_ms.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_ms",
    "evidence": "Read target values from field gust_ms."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 17 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 17 hours."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/wind/0004
Split: train

### t1 initial_multislot

I need forecasts of mean wind speed for Merlow wind site 1200. Measure the target in kilometres per hour. The observations are recorded every 1 day. The forecast should extend 4 days ahead. Read the input from a database. Use the data source https://inputs.example/wind/1200. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "I need forecasts of mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "I need forecasts of mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "kilometres per hour",
    "evidence": "Measure the target in kilometres per hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "The forecast should extend 4 days ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "Use the data source https://inputs.example/wind/1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 4 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 4 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 7 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "The forecast should extend 7 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 7 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 7 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/wind/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. The source is https://inputs.example/wind/1200. Read the input from a database. I need the next 11 hours predicted. There is one observed data point every 1 hour. The target values are in degrees clockwise from north. The quantity to predict is wind direction for Merlow wind site 1200.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "The source is https://inputs.example/wind/1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "I need the next 11 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees clockwise from north",
    "evidence": "The target values are in degrees clockwise from north."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wind direction for Merlow wind site 1200",
    "evidence": "The quantity to predict is wind direction for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wind direction for Merlow wind site 1200",
    "evidence": "The quantity to predict is wind direction for Merlow wind site 1200."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Use column wind_direction as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_direction",
    "evidence": "Use column wind_direction as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in degrees clockwise from north. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees clockwise from north",
    "evidence": "The target values are in degrees clockwise from north."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 14 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "I need the next 14 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/wind/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict mean wind speed for Merlow wind site 1200. Keep the measurement unit as metres per second. The native sampling interval is 1 hour. The forecast horizon is 18 hours. Read the input from a database. Read the observations from https://inputs.example/wind/1200. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "Please predict mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "Please predict mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Keep the measurement unit as metres per second."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 18 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "Read the observations from https://inputs.example/wind/1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is wind_ms. Use column measurement_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_ms",
    "evidence": "The target field name is wind_ms."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Use column measurement_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Return results at the level site. Limit the scope using these explicit filters: [{"column": "site_id", "operator": "eq", "value": "Merlow wind site 1200"}]. Include only these fictional areas: Fictional Merlow wind site 1200 region. The fictional data provider is Synthetic Weather Laboratory. Read the worksheet or resource named wind_observations. The input source refresh schedule is every 2 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t3/aggregation_level",
    "slot_id": "aggregation_level",
    "status": "provided",
    "value": "site",
    "evidence": "Return results at the level site."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t3/scope_filters",
    "slot_id": "scope_filters",
    "status": "provided",
    "value": [
      {
        "column": "site_id",
        "operator": "eq",
        "value": "Merlow wind site 1200"
      }
    ],
    "evidence": "Limit the scope using these explicit filters: [{\"column\": \"site_id\", \"operator\": \"eq\", \"value\": \"Merlow wind site 1200\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t3/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Merlow wind site 1200 region"
    ],
    "evidence": "Include only these fictional areas: Fictional Merlow wind site 1200 region."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t3/source_provider",
    "slot_id": "source_provider",
    "status": "provided",
    "value": "Synthetic Weather Laboratory",
    "evidence": "The fictional data provider is Synthetic Weather Laboratory."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t3/sheet_or_table",
    "slot_id": "sheet_or_table",
    "status": "provided",
    "value": "wind_observations",
    "evidence": "Read the worksheet or resource named wind_observations."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 2 hours."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The historical observations begin at 2020-01-01T00:00:00+00:00. The historical observations end at 2026-09-30T00:00:00+00:00. The available historical coverage is 81 months. Require at least 365 training observations. The recorded structural breaks are [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}]. For missing periods, use the policy resample.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t4/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "The historical observations begin at 2020-01-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t4/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "The historical observations end at 2026-09-30T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t4/expected_history_length",
    "slot_id": "expected_history_length",
    "status": "provided",
    "value": {
      "periods": 81,
      "unit": "month"
    },
    "evidence": "The available historical coverage is 81 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t4/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 365,
    "evidence": "Require at least 365 training observations."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t4/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "The recorded structural breaks are [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t4/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "resample",
    "evidence": "For missing periods, use the policy resample."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 21 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 21 hours."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/wind/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 8 hours. Source observations arrive every 1 hour. Use metres per second as the target unit. My prediction target is maximum gust speed for Merlow wind site 1200. Do not substitute daily mean wind speed as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 8 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Use metres per second as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum gust speed for Merlow wind site 1200",
    "evidence": "My prediction target is maximum gust speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum gust speed for Merlow wind site 1200",
    "evidence": "My prediction target is maximum gust speed for Merlow wind site 1200."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Read target values from field gust_ms.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_ms",
    "evidence": "Read target values from field gust_ms."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is json. My source reference is https://inputs.example/wind/1200. Read the input from a database.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "My source reference is https://inputs.example/wind/1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 11 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 11 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/wind/0008
Split: train

### t1 initial_multislot

I need forecasts of mean wind speed for Merlow wind site 1200. Measure the target in kilometres per hour. The observations are recorded every 1 day. The forecast should extend 15 days ahead. Read the input from a database. Use the data source https://inputs.example/wind/1200. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "I need forecasts of mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1200",
    "evidence": "I need forecasts of mean wind speed for Merlow wind site 1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "kilometres per hour",
    "evidence": "Measure the target in kilometres per hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "The forecast should extend 15 days ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1200",
    "evidence": "Use the data source https://inputs.example/wind/1200."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is measurement_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The timestamp column is measurement_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 18 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "The forecast should extend 18 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/wind/0009
Split: train

### t1 initial_multislot

Meri request yeh hai.  Aglay 5 ghantay predict karein. Target values degrees clockwise from north mein hain. wind direction for Merlow wind site 1200 predict karna hai. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Aglay 5 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees clockwise from north",
    "evidence": "Target values degrees clockwise from north mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wind direction for Merlow wind site 1200",
    "evidence": "wind direction for Merlow wind site 1200 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wind direction for Merlow wind site 1200",
    "evidence": "wind direction for Merlow wind site 1200 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Predictions har 1 din refresh karein. Har 1 ghanta aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Predictions har 1 din refresh karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates field measurement_time mein hain. Column wind_direction ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_direction",
    "evidence": "Column wind_direction ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 8 ghantay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Aglay 8 ghantay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/wind/0021
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format csv hai. Mera source reference wind_archive_1202.csv hai. Main data upload karunga. 5 ghantay ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko metres per second mein measure karein. maximum gust speed for Orven wind site 1202 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Source serialization format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "wind_archive_1202.csv",
    "evidence": "Mera source reference wind_archive_1202.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "5 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Target ko metres per second mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum gust speed for Orven wind site 1202",
    "evidence": "maximum gust speed for Orven wind site 1202 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum gust speed for Orven wind site 1202",
    "evidence": "maximum gust speed for Orven wind site 1202 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam sample_date hai. Target values field gust_ms se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Time field ka naam sample_date hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_ms",
    "evidence": "Target values field gust_ms se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Output granularity one prediction row per hour use karein. Source records har 4 ghantay update karein. Retraining har 1 mahina schedule karein. Har 3 din naye forecasts banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Output granularity one prediction row per hour use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source records har 4 ghantay update karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Retraining har 1 mahina schedule karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 8 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0021/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "8 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r8-dev/wind/0024
Split: train

### t1 initial_multislot

Here is what I need.  Please predict mean wind speed for Orven wind site 1202. Measurement unit metres per second rakhein. The native sampling interval is 1 hour. Forecast horizon 9 ghantay hai. I will upload the data. Observations wind_archive_1202.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Orven wind site 1202",
    "evidence": "Please predict mean wind speed for Orven wind site 1202."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Orven wind site 1202",
    "evidence": "Please predict mean wind speed for Orven wind site 1202."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Measurement unit metres per second rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 9 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "wind_archive_1202.csv",
    "evidence": "Observations wind_archive_1202.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast horizon is 9 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast horizon is 9 hours."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 12 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 12 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast horizon is 12 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0024/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast horizon is 12 hours."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of wind. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/wind/0029
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 10 hours. Use metres per second as the target unit. My prediction target is maximum gust speed for Orven wind site 1202. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 10 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Use metres per second as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum gust speed for Orven wind site 1202",
    "evidence": "My prediction target is maximum gust speed for Orven wind site 1202."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum gust speed for Orven wind site 1202",
    "evidence": "My prediction target is maximum gust speed for Orven wind site 1202."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Produce new forecasts every 3 days. Source observations arrive every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 3 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The time field name is sample_date. Read target values from field gust_ms.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_ms",
    "evidence": "Read target values from field gust_ms."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 13 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0029/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 13 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/wind/0041
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for wind direction for Talven wind site 1204. Target measurements use degrees clockwise from north. Each observed record covers 1 hour. The requested future coverage is 10 hours. Read the input from a database. The supplied source identifier is https://inputs.example/wind/1204. The input container uses json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "wind direction for Talven wind site 1204",
    "evidence": "We need an outlook for wind direction for Talven wind site 1204."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "wind direction for Talven wind site 1204",
    "evidence": "We need an outlook for wind direction for Talven wind site 1204."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "degrees clockwise from north",
    "evidence": "Target measurements use degrees clockwise from north."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 10 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1204",
    "evidence": "The supplied source identifier is https://inputs.example/wind/1204."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input container uses json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column wind_direction. The input timestamp identifier is measurement_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_direction",
    "evidence": "The response variable is stored in column wind_direction."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The input timestamp identifier is measurement_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

New forecasts must be issued every 2 days. Re-estimate the model every 1 month. Source ingestion repeats every 2 hours. The requested prediction row resolution is one prediction row per hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "New forecasts must be issued every 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Re-estimate the model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Source ingestion repeats every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "The requested prediction row resolution is one prediction row per hour."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 13 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0041/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 13 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r8-dev/wind/0046
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for mean wind speed for Talven wind site 1204. Target measurements ki unit metres per second hai. Each observed record covers 1 hour. Future coverage 11 ghantay chahiye. Read the input from a database. Diya hua source identifier https://inputs.example/wind/1204 hai. The input container uses json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Talven wind site 1204",
    "evidence": "We need an outlook for mean wind speed for Talven wind site 1204."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Talven wind site 1204",
    "evidence": "We need an outlook for mean wind speed for Talven wind site 1204."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Target measurements ki unit metres per second hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Future coverage 11 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1204",
    "evidence": "Diya hua source identifier https://inputs.example/wind/1204 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input container uses json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column wind_ms. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_ms",
    "evidence": "The response variable is stored in column wind_ms."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

This forecast will inform the decision to set the contingency allowance for Talven wind site 1204. success criteria ki requirement MAE no more than 5 metres per second for Talven wind site 1204 hai. Valid target bounds are {"max": 100, "min": 0}. Negative target values allowed nahi hain. Aggregate observations using mean. Aam calendar ke din use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Talven wind site 1204",
    "evidence": "This forecast will inform the decision to set the contingency allowance for Talven wind site 1204."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 5 metres per second for Talven wind site 1204",
    "evidence": "success criteria ki requirement MAE no more than 5 metres per second for Talven wind site 1204 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t3/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 100,
      "min": 0
    },
    "evidence": "Valid target bounds are {\"max\": 100, \"min\": 0}."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t3/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "mean",
    "evidence": "Aggregate observations using mean."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t3/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Aam calendar ke din use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The first forecast period begins at 2026-10-01T00:00:00+00:00. data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai. The lead time is 1 hour. dataset type ki requirement hierarchical hai. Each series is identified by the columns site_id. hierarchy columns ki requirement region_id, site_id hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "The first forecast period begins at 2026-10-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t4/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t4/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The lead time is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t4/dataset_type",
    "slot_id": "dataset_type",
    "status": "provided",
    "value": "hierarchical",
    "evidence": "dataset type ki requirement hierarchical hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t4/series_id_columns",
    "slot_id": "series_id_columns",
    "status": "provided",
    "value": [
      "site_id"
    ],
    "evidence": "Each series is identified by the columns site_id."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t4/hierarchy_columns",
    "slot_id": "hierarchy_columns",
    "status": "provided",
    "value": [
      "region_id",
      "site_id"
    ],
    "evidence": "hierarchy columns ki requirement region_id, site_id hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 14 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0046/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 14 hours."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

For a separate new request, explain the definition of wind. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r8-dev/wind/0050
Split: train

### t1 initial_multislot

Meri request yeh hai.  Source wind_archive_1205.XLSX hai. Aglay 14 ghantay predict karein. Har 1 ghanta aik observed data point milta hai. Target values metres per second mein hain. maximum gust speed for Virelo wind site 1205 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "wind_archive_1205.XLSX",
    "evidence": "Source wind_archive_1205.XLSX hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "xlsx",
    "evidence": "Source wind_archive_1205.XLSX hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Aglay 14 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Target values metres per second mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum gust speed for Virelo wind site 1205",
    "evidence": "maximum gust speed for Virelo wind site 1205 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum gust speed for Virelo wind site 1205",
    "evidence": "maximum gust speed for Virelo wind site 1205 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Diye hue data ka format xlsx hai. Source data catalog se select karein. Dates field recorded_at mein hain. Column gust_ms ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Diye hue data ka format xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates field recorded_at mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_ms",
    "evidence": "Column gust_ms ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 17 ghantay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Aglay 17 ghantay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Virelo wind site 1205 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0050/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Virelo wind site 1205",
    "evidence": "business goal ki requirement prepare a planning reserve for Virelo wind site 1205 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/wind/0075
Split: train

### t1 initial_multislot

I need forecasts of mean wind speed for Yarven wind site 1207. Target ki unit metres per second hai. The observations are recorded every 1 hour. Forecast aglay 20 ghantay tak chahiye. Access the input through an API. Data source https://inputs.example/wind/1207 use karein. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Yarven wind site 1207",
    "evidence": "I need forecasts of mean wind speed for Yarven wind site 1207."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Yarven wind site 1207",
    "evidence": "I need forecasts of mean wind speed for Yarven wind site 1207."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Target ki unit metres per second hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 20 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1207",
    "evidence": "Data source https://inputs.example/wind/1207 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called wind_ms. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_ms",
    "evidence": "The target column is called wind_ms."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The observations are recorded every 1 hour. Target ki unit metres per second hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Target ki unit metres per second hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 23 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0075/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 23 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/wind/0082
Split: train

### t1 initial_multislot

Here is what I need.  Please predict mean wind speed for Merlow wind site 1208. Measurement unit metres per second rakhein. The native sampling interval is 1 hour. Forecast horizon 10 ghantay hai. Read the input from a database. Observations https://inputs.example/wind/1208 se lein. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1208",
    "evidence": "Please predict mean wind speed for Merlow wind site 1208."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1208",
    "evidence": "Please predict mean wind speed for Merlow wind site 1208."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Measurement unit metres per second rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 10 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1208",
    "evidence": "Observations https://inputs.example/wind/1208 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is wind_ms. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_ms",
    "evidence": "The target field name is wind_ms."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 13 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 hours. Observations https://revised.example/wind/82 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0082/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/wind/82",
    "evidence": "Observations https://revised.example/wind/82 se lein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r8-dev/wind/0088
Split: train

### t1 initial_multislot

Mujhe mean wind speed for Merlow wind site 1208 ka forecast chahiye. Target ki unit kilometres per hour hai. Observations har 1 din record hoti hain. Forecast aglay 18 din tak chahiye. Input database se read karein. Data source https://inputs.example/wind/1208 use karein. Input file format json hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1208",
    "evidence": "Mujhe mean wind speed for Merlow wind site 1208 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Merlow wind site 1208",
    "evidence": "Mujhe mean wind speed for Merlow wind site 1208 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "kilometres per hour",
    "evidence": "Target ki unit kilometres per hour hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Forecast aglay 18 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1208",
    "evidence": "Data source https://inputs.example/wind/1208 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input file format json hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein personal ya confidential data nahi hai. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 21 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0088/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "Forecast aglay 21 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/wind/0124
Split: train

### t1 initial_multislot

Mujhe mean wind speed for Talven wind site 1212 ka forecast chahiye. Target ki unit kilometres per hour hai. Observations har 1 din record hoti hain. Forecast aglay 17 din tak chahiye. Input database se read karein. Data source https://inputs.example/wind/1212 use karein. Input file format json hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Talven wind site 1212",
    "evidence": "Mujhe mean wind speed for Talven wind site 1212 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Talven wind site 1212",
    "evidence": "Mujhe mean wind speed for Talven wind site 1212 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "kilometres per hour",
    "evidence": "Target ki unit kilometres per hour hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Forecast aglay 17 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1212",
    "evidence": "Data source https://inputs.example/wind/1212 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input file format json hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast aglay 17 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast aglay 17 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 20 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Forecast aglay 20 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast aglay 20 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0124/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast aglay 20 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: wind ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r8-dev/wind/0145
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format csv hai. Mera source reference wind_archive_1214.csv hai. Main data upload karunga. 12 ghantay ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko metres per second mein measure karein. maximum gust speed for Weslin wind site 1214 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Source serialization format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "wind_archive_1214.csv",
    "evidence": "Mera source reference wind_archive_1214.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "12 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Target ko metres per second mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "maximum gust speed for Weslin wind site 1214",
    "evidence": "maximum gust speed for Weslin wind site 1214 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "maximum gust speed for Weslin wind site 1214",
    "evidence": "maximum gust speed for Weslin wind site 1214 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam sample_date hai. Target values field gust_ms se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Time field ka naam sample_date hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_ms",
    "evidence": "Target values field gust_ms se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target ko metres per second mein measure karein. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Target ko metres per second mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. 15 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0145/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "15 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r8-dev/wind/0177
Split: train

### t1 initial_multislot

Mujhe mean wind speed for Norelia wind site 1217 ka forecast chahiye. Target ki unit metres per second hai. Observations har 1 ghanta record hoti hain. Forecast aglay 8 ghantay tak chahiye. hourly maximum gust speed nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "mean wind speed for Norelia wind site 1217",
    "evidence": "Mujhe mean wind speed for Norelia wind site 1217 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "mean wind speed for Norelia wind site 1217",
    "evidence": "Mujhe mean wind speed for Norelia wind site 1217 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "metres per second",
    "evidence": "Target ki unit metres per second hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 8 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam wind_ms hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "wind_ms",
    "evidence": "Target column ka naam wind_ms hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Source data catalog se select karein. Data source https://inputs.example/wind/1217 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/wind/1217",
    "evidence": "Data source https://inputs.example/wind/1217 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 11 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/wind/0177/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 11 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
