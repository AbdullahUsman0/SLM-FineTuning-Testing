# V7 review examples for output_growth

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## mixed core_recall

Scenario: v7-20261009-r8-dev/output_growth/0000
Split: train

### t1 initial_multislot

I need forecasts of real household consumption growth for Merlow output growth site 1700. Target ki unit percent year over year hai. The observations are recorded every 1 quarter. Forecast aglay 8 quarter tak chahiye. Select the source from the data catalog. Data source https://inputs.example/output_growth/1700 use karein. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real household consumption growth for Merlow output growth site 1700",
    "evidence": "I need forecasts of real household consumption growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real household consumption growth for Merlow output growth site 1700",
    "evidence": "I need forecasts of real household consumption growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Target ki unit percent year over year hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The observations are recorded every 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "quarter"
    },
    "evidence": "Forecast aglay 8 quarter tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "Data source https://inputs.example/output_growth/1700 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called consumption_growth. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "consumption_growth",
    "evidence": "The target column is called consumption_growth."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 11 quarters ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "quarter"
    },
    "evidence": "The forecast should extend 11 quarters ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow output growth site 1700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow output growth site 1700",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow output growth site 1700."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/output_growth/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/output_growth/1700. Select the source from the data catalog. I need the next 15 quarters predicted. There is one observed data point every 1 quarter. The target values are in percent quarter over quarter. The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "The source is https://inputs.example/output_growth/1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "quarter"
    },
    "evidence": "I need the next 15 quarters predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "There is one observed data point every 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent quarter over quarter",
    "evidence": "The target values are in percent quarter over quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real GDP quarterly growth for Merlow output growth site 1700",
    "evidence": "The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real GDP quarterly growth for Merlow output growth site 1700",
    "evidence": "The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Use column real_gdp_growth as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "real_gdp_growth",
    "evidence": "Use column real_gdp_growth as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per quarter. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per quarter",
    "evidence": "Return forecasts with resolution one prediction row per quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 18 quarters predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "quarter"
    },
    "evidence": "I need the next 18 quarters predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/output_growth/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict nominal GDP level in current prices for Merlow output growth site 1700. Keep the measurement unit as millions of USD. The native sampling interval is 1 quarter. The forecast horizon is 5 quarters. Select the source from the data catalog. Read the observations from https://inputs.example/output_growth/1700. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "nominal GDP level in current prices for Merlow output growth site 1700",
    "evidence": "Please predict nominal GDP level in current prices for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "nominal GDP level in current prices for Merlow output growth site 1700",
    "evidence": "Please predict nominal GDP level in current prices for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The native sampling interval is 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "quarter"
    },
    "evidence": "The forecast horizon is 5 quarters."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "Read the observations from https://inputs.example/output_growth/1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is nominal_gdp. Use column recorded_at for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "nominal_gdp",
    "evidence": "The target field name is nominal_gdp."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 8 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "quarter"
    },
    "evidence": "The forecast horizon is 8 quarters."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 quarters. Read the observations from https://revised.example/output_growth/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "quarter"
    },
    "evidence": "The native sampling interval is 2 quarters."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/output_growth/2",
    "evidence": "Read the observations from https://revised.example/output_growth/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/output_growth/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. My source reference is https://inputs.example/output_growth/1700. Select the source from the data catalog. Predict a horizon of 12 months. Source observations arrive every 1 month. Use index points, base 2020=100 as the target unit. My prediction target is industrial production index level for Merlow output growth site 1700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "My source reference is https://inputs.example/output_growth/1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 12 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Merlow output growth site 1700",
    "evidence": "My prediction target is industrial production index level for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Merlow output growth site 1700",
    "evidence": "My prediction target is industrial production index level for Merlow output growth site 1700."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. I do not expect a repeating seasonal pattern. Use timezone Asia/Karachi.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "Use timezone Asia/Karachi."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is recorded_at. Read target values from field industrial_index.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "industrial_index",
    "evidence": "Read target values from field industrial_index."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 15 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 15 months."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/output_growth/0004
Split: train

### t1 initial_multislot

I need forecasts of real household consumption growth for Merlow output growth site 1700. Measure the target in percent year over year. The observations are recorded every 1 quarter. The forecast should extend 19 quarters ahead. Select the source from the data catalog. Use the data source https://inputs.example/output_growth/1700. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real household consumption growth for Merlow output growth site 1700",
    "evidence": "I need forecasts of real household consumption growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real household consumption growth for Merlow output growth site 1700",
    "evidence": "I need forecasts of real household consumption growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Measure the target in percent year over year."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The observations are recorded every 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "quarter"
    },
    "evidence": "The forecast should extend 19 quarters ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "Use the data source https://inputs.example/output_growth/1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 19 quarters ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 19,
      "unit": "quarter"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 19 quarters ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 22 quarters ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "quarter"
    },
    "evidence": "The forecast should extend 22 quarters ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 22 quarters ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 22,
      "unit": "quarter"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 22 quarters ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/output_growth/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/output_growth/1700. Select the source from the data catalog. I need the next 9 quarters predicted. There is one observed data point every 1 quarter. The target values are in percent quarter over quarter. The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "The source is https://inputs.example/output_growth/1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "quarter"
    },
    "evidence": "I need the next 9 quarters predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "There is one observed data point every 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent quarter over quarter",
    "evidence": "The target values are in percent quarter over quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real GDP quarterly growth for Merlow output growth site 1700",
    "evidence": "The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real GDP quarterly growth for Merlow output growth site 1700",
    "evidence": "The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Use column real_gdp_growth as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "real_gdp_growth",
    "evidence": "Use column real_gdp_growth as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "quarter"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in percent quarter over quarter. There is one observed data point every 1 quarter.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent quarter over quarter",
    "evidence": "The target values are in percent quarter over quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "There is one observed data point every 1 quarter."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 12 quarters predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "quarter"
    },
    "evidence": "I need the next 12 quarters predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/output_growth/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict nominal GDP level in current prices for Merlow output growth site 1700. Keep the measurement unit as millions of USD. The native sampling interval is 1 quarter. The forecast horizon is 16 quarters. Select the source from the data catalog. Read the observations from https://inputs.example/output_growth/1700. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "nominal GDP level in current prices for Merlow output growth site 1700",
    "evidence": "Please predict nominal GDP level in current prices for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "nominal GDP level in current prices for Merlow output growth site 1700",
    "evidence": "Please predict nominal GDP level in current prices for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The native sampling interval is 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "quarter"
    },
    "evidence": "The forecast horizon is 16 quarters."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "Read the observations from https://inputs.example/output_growth/1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is nominal_gdp. Use column recorded_at for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "nominal_gdp",
    "evidence": "The target field name is nominal_gdp."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The holdout window length is 7 quarters. Include naive as the baseline comparison. The acceptable error threshold is {"maximum": 1, "metric": "mae"}. Generate predictions in batch mode. Run forecast generation once every 1 day. Training should be repeated every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t3/test_window",
    "slot_id": "test_window",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "quarter"
    },
    "evidence": "The holdout window length is 7 quarters."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t3/baseline_model",
    "slot_id": "baseline_model",
    "status": "provided",
    "value": "naive",
    "evidence": "Include naive as the baseline comparison."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t3/acceptable_error",
    "slot_id": "acceptable_error",
    "status": "provided",
    "value": {
      "maximum": 1,
      "metric": "mae"
    },
    "evidence": "The acceptable error threshold is {\"maximum\": 1, \"metric\": \"mae\"}."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t3/inference_mode",
    "slot_id": "inference_mode",
    "status": "provided",
    "value": "batch",
    "evidence": "Generate predictions in batch mode."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Training should be repeated every 1 month."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The maximum response time is 8 seconds. Serialize the results as json. Deliver completed forecasts to https://planning.example/output_growth/1700. The source contains confidential synthetic records. Enforce these privacy restrictions: synthetic data only, no external redistribution. The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t4/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "second"
    },
    "evidence": "The maximum response time is 8 seconds."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t4/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "json",
    "evidence": "Serialize the results as json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t4/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/output_growth/1700",
    "evidence": "Deliver completed forecasts to https://planning.example/output_growth/1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t4/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t4/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "Enforce these privacy restrictions: synthetic data only, no external redistribution."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t4/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 19 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "quarter"
    },
    "evidence": "The forecast horizon is 19 quarters."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r8-dev/output_growth/0007
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  6 mahinay ka horizon rakhein. Source observations har 1 mahina aati hain. Target ko index points, base 2020=100 mein measure karein. industrial production index level for Merlow output growth site 1700 ke liye prediction bana dein. real household consumption growth nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "6 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Merlow output growth site 1700",
    "evidence": "industrial production index level for Merlow output growth site 1700 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Merlow output growth site 1700",
    "evidence": "industrial production index level for Merlow output growth site 1700 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam recorded_at hai. Target values field industrial_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Time field ka naam recorded_at hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "industrial_index",
    "evidence": "Target values field industrial_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Source serialization format xlsx hai. Mera source reference https://inputs.example/output_growth/1700 hai. Source data catalog se select karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Source serialization format xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "Mera source reference https://inputs.example/output_growth/1700 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 9 mahinay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "9 mahinay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: output growth ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/output_growth/0008
Split: train

### t1 initial_multislot

I need forecasts of real household consumption growth for Merlow output growth site 1700. Measure the target in percent year over year. The observations are recorded every 1 quarter. The forecast should extend 13 quarters ahead. Select the source from the data catalog. Use the data source https://inputs.example/output_growth/1700. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real household consumption growth for Merlow output growth site 1700",
    "evidence": "I need forecasts of real household consumption growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real household consumption growth for Merlow output growth site 1700",
    "evidence": "I need forecasts of real household consumption growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Measure the target in percent year over year."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The observations are recorded every 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "quarter"
    },
    "evidence": "The forecast should extend 13 quarters ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1700",
    "evidence": "Use the data source https://inputs.example/output_growth/1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The timestamp column is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values are valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values are valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 16 quarters ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "quarter"
    },
    "evidence": "The forecast should extend 16 quarters ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/output_growth/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 20 quarters predicted. The target values are in percent quarter over quarter. The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "quarter"
    },
    "evidence": "I need the next 20 quarters predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent quarter over quarter",
    "evidence": "The target values are in percent quarter over quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real GDP quarterly growth for Merlow output growth site 1700",
    "evidence": "The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real GDP quarterly growth for Merlow output growth site 1700",
    "evidence": "The quantity to predict is real GDP quarterly growth for Merlow output growth site 1700."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 quarter.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "There is one observed data point every 1 quarter."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field recorded_at. Use column real_gdp_growth as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "real_gdp_growth",
    "evidence": "Use column real_gdp_growth as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 23 quarters predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "quarter"
    },
    "evidence": "I need the next 23 quarters predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en core_recall

Scenario: v7-20261009-r8-dev/output_growth/0010
Split: train

### t1 initial_multislot

For my request,  The source is output_growth_archive_1701.csv. I need the next 19 months predicted. There is one observed data point every 1 month. The target values are in index points, base 2020=100. The quantity to predict is industrial production index level for Norelia output growth site 1701.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "output_growth_archive_1701.csv",
    "evidence": "The source is output_growth_archive_1701.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "csv",
    "evidence": "The source is output_growth_archive_1701.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "I need the next 19 months predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "The target values are in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Norelia output growth site 1701",
    "evidence": "The quantity to predict is industrial production index level for Norelia output growth site 1701."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Norelia output growth site 1701",
    "evidence": "The quantity to predict is industrial production index level for Norelia output growth site 1701."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The supplied data format is csv. I will upload the data. Dates are stored in field sample_date. Use column industrial_index as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "industrial_index",
    "evidence": "Use column industrial_index as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 22 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "I need the next 22 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Norelia output growth site 1701.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia output growth site 1701",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia output growth site 1701."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/output_growth/0015
Split: train

### t1 initial_multislot

Here is what I need.  Please predict real household consumption growth for Norelia output growth site 1701. Measurement unit percent year over year rakhein. The native sampling interval is 1 quarter. Forecast horizon 20 quarter hai. I will upload the data. Observations output_growth_archive_1701.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real household consumption growth for Norelia output growth site 1701",
    "evidence": "Please predict real household consumption growth for Norelia output growth site 1701."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real household consumption growth for Norelia output growth site 1701",
    "evidence": "Please predict real household consumption growth for Norelia output growth site 1701."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Measurement unit percent year over year rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The native sampling interval is 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "quarter"
    },
    "evidence": "Forecast horizon 20 quarter hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "output_growth_archive_1701.csv",
    "evidence": "Observations output_growth_archive_1701.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is consumption_growth. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "consumption_growth",
    "evidence": "The target field name is consumption_growth."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "quarter"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The native sampling interval is 1 quarter. Measurement unit percent year over year rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The native sampling interval is 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Measurement unit percent year over year rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 23 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0015/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "quarter"
    },
    "evidence": "The forecast horizon is 23 quarters."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/output_growth/0017
Split: train

### t1 initial_multislot

I need forecasts of nominal GDP level in current prices for Norelia output growth site 1701. Measure the target in millions of USD. The observations are recorded every 1 quarter. The forecast should extend 17 quarters ahead. Do not substitute industrial production index level as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "nominal GDP level in current prices for Norelia output growth site 1701",
    "evidence": "I need forecasts of nominal GDP level in current prices for Norelia output growth site 1701."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "nominal GDP level in current prices for Norelia output growth site 1701",
    "evidence": "I need forecasts of nominal GDP level in current prices for Norelia output growth site 1701."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Measure the target in millions of USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The observations are recorded every 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "quarter"
    },
    "evidence": "The forecast should extend 17 quarters ahead."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called nominal_gdp. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "nominal_gdp",
    "evidence": "The target column is called nominal_gdp."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

I will upload the data. Use the data source output_growth_archive_1701.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "output_growth_archive_1701.csv",
    "evidence": "Use the data source output_growth_archive_1701.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 20 quarters ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0017/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "quarter"
    },
    "evidence": "The forecast should extend 20 quarters ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/output_growth/0019
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target real household consumption growth for Norelia output growth site 1701 hai. Measurement unit percent year over year rakhein. Forecast horizon 14 quarter hai. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real household consumption growth for Norelia output growth site 1701",
    "evidence": "Prediction ka target real household consumption growth for Norelia output growth site 1701 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real household consumption growth for Norelia output growth site 1701",
    "evidence": "Prediction ka target real household consumption growth for Norelia output growth site 1701 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Measurement unit percent year over year rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "quarter"
    },
    "evidence": "Forecast horizon 14 quarter hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Asli data ka sampling interval 1 quarter hai. Forecast generation har 2 din run karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "Asli data ka sampling interval 1 quarter hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Forecast generation har 2 din run karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Target field consumption_growth hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "consumption_growth",
    "evidence": "Target field consumption_growth hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 17 quarter hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0019/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "quarter"
    },
    "evidence": "Forecast horizon 17 quarter hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/output_growth/0032
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. Source https://inputs.example/output_growth/1703 hai. Read the input from a database. Aglay 4 mahinay predict karein. There is one observed data point every 1 month. Target values index points, base 2020=100 mein hain. The quantity to predict is industrial production index level for Pelmar output growth site 1703.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1703",
    "evidence": "Source https://inputs.example/output_growth/1703 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "Aglay 4 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target values index points, base 2020=100 mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Pelmar output growth site 1703",
    "evidence": "The quantity to predict is industrial production index level for Pelmar output growth site 1703."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Pelmar output growth site 1703",
    "evidence": "The quantity to predict is industrial production index level for Pelmar output growth site 1703."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Column industrial_index ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "industrial_index",
    "evidence": "Column industrial_index ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 7 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "I need the next 7 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The source is https://revised.example/output_growth/32. Har 2 mahinay aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/output_growth/32",
    "evidence": "The source is https://revised.example/output_growth/32."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0032/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Har 2 mahinay aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r8-dev/output_growth/0043
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format xlsx hai. Mera source reference https://inputs.example/output_growth/1704 hai. Source data catalog se select karein. 5 mahinay ka horizon rakhein. Source observations har 1 mahina aati hain. Target ko index points, base 2020=100 mein measure karein. industrial production index level for Talven output growth site 1704 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Source serialization format xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1704",
    "evidence": "Mera source reference https://inputs.example/output_growth/1704 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "5 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Talven output growth site 1704",
    "evidence": "industrial production index level for Talven output growth site 1704 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Talven output growth site 1704",
    "evidence": "industrial production index level for Talven output growth site 1704 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

prediction interval levels ki requirement 80, 95 hai. forecast type ki requirement probabilistic hai. Repeating seasonal pattern expect nahi karta. Timezone Europe/London use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Timezone Europe/London use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Time field ka naam recorded_at hai. Target values field industrial_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Time field ka naam recorded_at hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "industrial_index",
    "evidence": "Target values field industrial_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. 8 mahinay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0043/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "8 mahinay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/output_growth/0049
Split: train

### t1 initial_multislot

For my request,  I need the next 13 quarters predicted. Target values percent quarter over quarter mein hain. The quantity to predict is real GDP quarterly growth for Talven output growth site 1704. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "quarter"
    },
    "evidence": "I need the next 13 quarters predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent quarter over quarter",
    "evidence": "Target values percent quarter over quarter mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real GDP quarterly growth for Talven output growth site 1704",
    "evidence": "The quantity to predict is real GDP quarterly growth for Talven output growth site 1704."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real GDP quarterly growth for Talven output growth site 1704",
    "evidence": "The quantity to predict is real GDP quarterly growth for Talven output growth site 1704."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 2 days. Har 1 quarter aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "Har 1 quarter aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field recorded_at. Column real_gdp_growth ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "real_gdp_growth",
    "evidence": "Column real_gdp_growth ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 quarters predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0049/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "quarter"
    },
    "evidence": "I need the next 16 quarters predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r8-dev/output_growth/0051
Split: train

### t1 initial_multislot

Here is what I need.  Please predict real household consumption growth for Virelo output growth site 1705. Measurement unit percent year over year rakhein. The native sampling interval is 1 quarter. Forecast horizon 19 quarter hai. I will upload the data. Observations output_growth_archive_1705.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real household consumption growth for Virelo output growth site 1705",
    "evidence": "Please predict real household consumption growth for Virelo output growth site 1705."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real household consumption growth for Virelo output growth site 1705",
    "evidence": "Please predict real household consumption growth for Virelo output growth site 1705."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Measurement unit percent year over year rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The native sampling interval is 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "quarter"
    },
    "evidence": "Forecast horizon 19 quarter hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "output_growth_archive_1705.csv",
    "evidence": "Observations output_growth_archive_1705.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is consumption_growth. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "consumption_growth",
    "evidence": "The target field name is consumption_growth."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Run forecast generation once every 3 days. Training har 2 mahinay repeat karein. The input source refresh schedule is every 3 hours. Result granularity one prediction row per quarter banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 3 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training har 2 mahinay repeat karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per quarter",
    "evidence": "Result granularity one prediction row per quarter banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 22 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0051/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "quarter"
    },
    "evidence": "The forecast horizon is 22 quarters."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/output_growth/0054
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source output_growth_archive_1705.csv hai. Main data upload karunga. Aglay 6 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values index points, base 2020=100 mein hain. industrial production index level for Virelo output growth site 1705 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "output_growth_archive_1705.csv",
    "evidence": "Source output_growth_archive_1705.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Aglay 6 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target values index points, base 2020=100 mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Virelo output growth site 1705",
    "evidence": "industrial production index level for Virelo output growth site 1705 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Virelo output growth site 1705",
    "evidence": "industrial production index level for Virelo output growth site 1705 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 6 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 6 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 9 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Aglay 9 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 9 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0054/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 9 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r8-dev/output_growth/0086
Split: train

### t1 initial_multislot

Here is what I need.  Please predict nominal GDP level in current prices for Merlow output growth site 1708. Measurement unit millions of USD rakhein. The native sampling interval is 1 quarter. Forecast horizon 19 quarter hai. Select the source from the data catalog. Observations https://inputs.example/output_growth/1708 se lein. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "nominal GDP level in current prices for Merlow output growth site 1708",
    "evidence": "Please predict nominal GDP level in current prices for Merlow output growth site 1708."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "nominal GDP level in current prices for Merlow output growth site 1708",
    "evidence": "Please predict nominal GDP level in current prices for Merlow output growth site 1708."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Measurement unit millions of USD rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "The native sampling interval is 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "quarter"
    },
    "evidence": "Forecast horizon 19 quarter hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1708",
    "evidence": "Observations https://inputs.example/output_growth/1708 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is nominal_gdp. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "nominal_gdp",
    "evidence": "The target field name is nominal_gdp."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

For missing periods, use the policy resample. missing target policy ki requirement interpolate hai. For duplicate observations, use the policy latest. outlier policy ki requirement cap hai. For invalid values, use the policy flag. minimum coverage ki requirement 86 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t3/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "resample",
    "evidence": "For missing periods, use the policy resample."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t3/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "interpolate",
    "evidence": "missing target policy ki requirement interpolate hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t3/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "latest",
    "evidence": "For duplicate observations, use the policy latest."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t3/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "outlier policy ki requirement cap hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t3/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "flag",
    "evidence": "For invalid values, use the policy flag."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t3/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "minimum coverage ki requirement 86 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

I expect a repeating seasonal pattern. Weekends aur non-business days exclude na karein. Use these fictional holiday calendars: synthetic reporting holiday. special events ki requirement [{"date": "2026-10-05", "name": "synthetic scheduled data release"}] hai. These regressors are observed only through the cutoff: lagged_target. known future covariates ki requirement announced_calendar_event hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t4/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t4/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Weekends aur non-business days exclude na karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t4/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "Use these fictional holiday calendars: synthetic reporting holiday."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t4/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "special events ki requirement [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t4/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "These regressors are observed only through the cutoff: lagged_target."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t4/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "known future covariates ki requirement announced_calendar_event hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 22 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0086/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "quarter"
    },
    "evidence": "The forecast horizon is 22 quarters."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/output_growth/0101
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein industrial production index level for Orven output growth site 1710 ka outlook chahiye. Target measurements ki unit index points, base 2020=100 hai. Har observed record 1 mahina cover karta hai. Future coverage 6 mahinay chahiye. Input API ke zariye lein. Diya hua source identifier https://inputs.example/output_growth/1710 hai. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Orven output growth site 1710",
    "evidence": "Hamein industrial production index level for Orven output growth site 1710 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Orven output growth site 1710",
    "evidence": "Hamein industrial production index level for Orven output growth site 1710 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har observed record 1 mahina cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Future coverage 6 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1710",
    "evidence": "Diya hua source identifier https://inputs.example/output_growth/1710 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column industrial_index mein hai. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "industrial_index",
    "evidence": "Response variable column industrial_index mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Naye forecasts har 2 din issue karein. Model har 1 mahina dobara estimate karein. Source ingestion har 4 ghantay repeat hoti hai. Prediction rows ki resolution one prediction row per month hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Naye forecasts har 2 din issue karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Model har 1 mahina dobara estimate karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source ingestion har 4 ghantay repeat hoti hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Prediction rows ki resolution one prediction row per month hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 9 mahinay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0101/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Future coverage 9 mahinay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r8-dev/output_growth/0104
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for nominal GDP level in current prices for Orven output growth site 1710. Target measurements ki unit millions of USD hai. Each observed record covers 1 quarter. Future coverage 10 quarter chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/output_growth/1710 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "nominal GDP level in current prices for Orven output growth site 1710",
    "evidence": "We need an outlook for nominal GDP level in current prices for Orven output growth site 1710."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "nominal GDP level in current prices for Orven output growth site 1710",
    "evidence": "We need an outlook for nominal GDP level in current prices for Orven output growth site 1710."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target measurements ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "Each observed record covers 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "quarter"
    },
    "evidence": "Future coverage 10 quarter chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1710",
    "evidence": "Diya hua source identifier https://inputs.example/output_growth/1710 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The requested future coverage is 10 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 10,
      "unit": "quarter"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The requested future coverage is 10 quarters."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 13 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "quarter"
    },
    "evidence": "The requested future coverage is 13 quarters."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The requested future coverage is 13 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0104/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 13,
      "unit": "quarter"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The requested future coverage is 13 quarters."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r8-dev/output_growth/0116
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein industrial production index level for Pelmar output growth site 1711 ka outlook chahiye. Target measurements ki unit index points, base 2020=100 hai. Har observed record 1 mahina cover karta hai. Future coverage 18 mahinay chahiye. Input database se read karein. Diya hua source identifier https://inputs.example/output_growth/1711 hai. Input container json use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Pelmar output growth site 1711",
    "evidence": "Hamein industrial production index level for Pelmar output growth site 1711 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Pelmar output growth site 1711",
    "evidence": "Hamein industrial production index level for Pelmar output growth site 1711 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har observed record 1 mahina cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Future coverage 18 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1711",
    "evidence": "Diya hua source identifier https://inputs.example/output_growth/1711 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input container json use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column industrial_index mein hai. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "industrial_index",
    "evidence": "Response variable column industrial_index mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

business goal ki requirement prepare a planning reserve for Pelmar output growth site 1711 hai. stakeholder role ki requirement macroeconomic research analyst hai. decision supported ki requirement set the contingency allowance for Pelmar output growth site 1711 hai. success criteria ki requirement MAE no more than 2 index points, base 2020=100 for Pelmar output growth site 1711 hai. target bounds ki requirement {"max": 1000000, "min": 0} hai. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Pelmar output growth site 1711",
    "evidence": "business goal ki requirement prepare a planning reserve for Pelmar output growth site 1711 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "macroeconomic research analyst",
    "evidence": "stakeholder role ki requirement macroeconomic research analyst hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Pelmar output growth site 1711",
    "evidence": "decision supported ki requirement set the contingency allowance for Pelmar output growth site 1711 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 2 index points, base 2020=100 for Pelmar output growth site 1711",
    "evidence": "success criteria ki requirement MAE no more than 2 index points, base 2020=100 for Pelmar output growth site 1711 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t3/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "target bounds ki requirement {\"max\": 1000000, \"min\": 0} hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

aggregation method ki requirement last hai. Aam calendar ke din use karein. forecast start ki requirement 2026-10-01T00:00:00+00:00 hai. data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai. lead time 1 mahina hai. dataset type ki requirement hierarchical hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "aggregation method ki requirement last hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Aam calendar ke din use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "forecast start ki requirement 2026-10-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t4/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t4/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "lead time 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t4/dataset_type",
    "slot_id": "dataset_type",
    "status": "provided",
    "value": "hierarchical",
    "evidence": "dataset type ki requirement hierarchical hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Future coverage 21 mahinay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0116/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "Future coverage 21 mahinay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r8-dev/output_growth/0117
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for real household consumption growth for Pelmar output growth site 1711. Target measurements ki unit percent year over year hai. Each observed record covers 1 quarter. Future coverage 8 quarter chahiye. Do not substitute real GDP quarterly growth as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real household consumption growth for Pelmar output growth site 1711",
    "evidence": "We need an outlook for real household consumption growth for Pelmar output growth site 1711."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real household consumption growth for Pelmar output growth site 1711",
    "evidence": "We need an outlook for real household consumption growth for Pelmar output growth site 1711."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Target measurements ki unit percent year over year hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "Each observed record covers 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "quarter"
    },
    "evidence": "Future coverage 8 quarter chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column consumption_growth. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "consumption_growth",
    "evidence": "The response variable is stored in column consumption_growth."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Read the input from a database. Diya hua source identifier https://inputs.example/output_growth/1711 hai. The input container uses json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1711",
    "evidence": "Diya hua source identifier https://inputs.example/output_growth/1711 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input container uses json."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 11 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0117/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "quarter"
    },
    "evidence": "The requested future coverage is 11 quarters."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r8-dev/output_growth/0138
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein industrial production index level for Virelo output growth site 1713 ka outlook chahiye. Target measurements ki unit index points, base 2020=100 hai. Har observed record 1 mahina cover karta hai. Future coverage 20 mahinay chahiye. Main data upload karunga. Diya hua source identifier output_growth_archive_1713.csv hai. Input container csv use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "industrial production index level for Virelo output growth site 1713",
    "evidence": "Hamein industrial production index level for Virelo output growth site 1713 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "industrial production index level for Virelo output growth site 1713",
    "evidence": "Hamein industrial production index level for Virelo output growth site 1713 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har observed record 1 mahina cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "Future coverage 20 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "output_growth_archive_1713.csv",
    "evidence": "Diya hua source identifier output_growth_archive_1713.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input container csv use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Response variable column true mein hai. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Response variable column true mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein personal ya confidential data nahi hai. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 23 mahinay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0138/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "month"
    },
    "evidence": "Future coverage 23 mahinay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r8-dev/output_growth/0158
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. Mera source reference https://inputs.example/output_growth/1715 hai. Read the input from a database. 8 quarter ka horizon rakhein. Source observations arrive every 1 quarter. Target ko percent quarter over quarter mein measure karein. My prediction target is real GDP quarterly growth for Yarven output growth site 1715.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1715",
    "evidence": "Mera source reference https://inputs.example/output_growth/1715 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "quarter"
    },
    "evidence": "8 quarter ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "Source observations arrive every 1 quarter."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent quarter over quarter",
    "evidence": "Target ko percent quarter over quarter mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real GDP quarterly growth for Yarven output growth site 1715",
    "evidence": "My prediction target is real GDP quarterly growth for Yarven output growth site 1715."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real GDP quarterly growth for Yarven output growth site 1715",
    "evidence": "My prediction target is real GDP quarterly growth for Yarven output growth site 1715."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The time field name is measurement_time. Target values field value "net" se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "Target values field value \"net\" se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are valid. Source mein personal ya confidential data nahi hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values are valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 11 quarters.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0158/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "quarter"
    },
    "evidence": "Predict a horizon of 11 quarters."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r8-dev/output_growth/0190
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format json hai. Mera source reference https://inputs.example/output_growth/1719 hai. Input database se read karein. 13 quarter ka horizon rakhein. Source observations har 1 quarter aati hain. Target ko percent quarter over quarter mein measure karein. real GDP quarterly growth for Pelmar output growth site 1719 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Source serialization format json hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/output_growth/1719",
    "evidence": "Mera source reference https://inputs.example/output_growth/1719 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "quarter"
    },
    "evidence": "13 quarter ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "quarter"
    },
    "evidence": "Source observations har 1 quarter aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent quarter over quarter",
    "evidence": "Target ko percent quarter over quarter mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "real GDP quarterly growth for Pelmar output growth site 1719",
    "evidence": "real GDP quarterly growth for Pelmar output growth site 1719 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "real GDP quarterly growth for Pelmar output growth site 1719",
    "evidence": "real GDP quarterly growth for Pelmar output growth site 1719 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam measurement_time hai. Target values field real_gdp_growth se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "real_gdp_growth",
    "evidence": "Target values field real_gdp_growth se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. 16 quarter ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "quarter"
    },
    "evidence": "16 quarter ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Pelmar output growth site 1719 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/output_growth/0190/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Pelmar output growth site 1719",
    "evidence": "business goal ki requirement prepare a planning reserve for Pelmar output growth site 1719 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
