# V7 review examples for equities_funds

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r8-dev/equities_funds/0010
Split: train

### t1 initial_multislot

For my request,  The source is equities_funds_archive_2001.xlsx. I need the next 11 days predicted. There is one observed data point every 1 day. The target values are in USD per share. The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "equities_funds_archive_2001.xlsx",
    "evidence": "The source is equities_funds_archive_2001.xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "xlsx",
    "evidence": "The source is equities_funds_archive_2001.xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "I need the next 11 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "The target values are in USD per share."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Norelia equities funds site 2001",
    "evidence": "The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Norelia equities funds site 2001",
    "evidence": "The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The supplied data format is xlsx. Select the source from the data catalog. Dates are stored in field recorded_at. Use column raw_close as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "raw_close",
    "evidence": "Use column raw_close as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 14 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "I need the next 14 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Norelia equities funds site 2001.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia equities funds site 2001",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia equities funds site 2001."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/equities_funds/0011
Split: train

### t1 initial_multislot

Here is what I need.  Please predict total return including dividends for Norelia equities funds site 2001. Keep the measurement unit as percent. The native sampling interval is 1 day. The forecast horizon is 18 days. Select the source from the data catalog. Read the observations from https://inputs.example/equities_funds/2001. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "total return including dividends for Norelia equities funds site 2001",
    "evidence": "Please predict total return including dividends for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "total return including dividends for Norelia equities funds site 2001",
    "evidence": "Please predict total return including dividends for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Keep the measurement unit as percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 18 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2001",
    "evidence": "Read the observations from https://inputs.example/equities_funds/2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is total_return_pct. Use column recorded_at for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "total_return_pct",
    "evidence": "The target field name is total_return_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Run forecast generation once every 2 days. Training should be repeated every 2 months. The input source refresh schedule is every 3 hours. Make the result granularity one prediction row per day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training should be repeated every 2 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Make the result granularity one prediction row per day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 21 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0011/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 21 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of equities funds. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/equities_funds/0012
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. My source reference is https://inputs.example/equities_funds/2001. Select the source from the data catalog. Predict a horizon of 8 days. Source observations arrive every 1 day. Use shares as the target unit. My prediction target is ETF trading volume for Norelia equities funds site 2001.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2001",
    "evidence": "My source reference is https://inputs.example/equities_funds/2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 8 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "shares",
    "evidence": "Use shares as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETF trading volume for Norelia equities funds site 2001",
    "evidence": "My prediction target is ETF trading volume for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETF trading volume for Norelia equities funds site 2001",
    "evidence": "My prediction target is ETF trading volume for Norelia equities funds site 2001."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Read target values from field etf_volume.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "etf_volume",
    "evidence": "Read target values from field etf_volume."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 11 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 11 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/equities_funds/12. Source observations arrive every 2 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/equities_funds/12",
    "evidence": "My source reference is https://revised.example/equities_funds/12."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0012/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 2 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/equities_funds/0013
Split: train

### t1 initial_multislot

I need forecasts of split-and-dividend-adjusted closing share price for Norelia equities funds site 2001. Measure the target in USD per share. The observations are recorded every 1 day. The forecast should extend 15 days ahead. Select the source from the data catalog. Use the data source https://inputs.example/equities_funds/2001. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Norelia equities funds site 2001",
    "evidence": "I need forecasts of split-and-dividend-adjusted closing share price for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Norelia equities funds site 2001",
    "evidence": "I need forecasts of split-and-dividend-adjusted closing share price for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Measure the target in USD per share."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "The forecast should extend 15 days ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2001",
    "evidence": "Use the data source https://inputs.example/equities_funds/2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

The timestamp timezone is Europe/London. I do not expect a repeating seasonal pattern. The requested forecast output type is probabilistic. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "The timestamp timezone is Europe/London."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target column is called adjusted_close. The timestamp column is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "adjusted_close",
    "evidence": "The target column is called adjusted_close."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The timestamp column is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 18 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "The forecast should extend 18 days ahead."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/equities_funds/0014
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/equities_funds/2001. Select the source from the data catalog. I need the next 5 days predicted. There is one observed data point every 1 day. The target values are in USD per share. The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2001",
    "evidence": "The source is https://inputs.example/equities_funds/2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "I need the next 5 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "The target values are in USD per share."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Norelia equities funds site 2001",
    "evidence": "The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Norelia equities funds site 2001",
    "evidence": "The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. I need the next 5 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. I need the next 5 days predicted."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "I need the next 8 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. I need the next 8 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0014/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. I need the next 8 days predicted."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r8-dev/equities_funds/0015
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target total return including dividends for Norelia equities funds site 2001 hai. Measurement unit percent rakhein. Asli data ka sampling interval 1 din hai. Forecast horizon 12 din hai. Source data catalog se select karein. Observations https://inputs.example/equities_funds/2001 se lein. Input ko xlsx ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "total return including dividends for Norelia equities funds site 2001",
    "evidence": "Prediction ka target total return including dividends for Norelia equities funds site 2001 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "total return including dividends for Norelia equities funds site 2001",
    "evidence": "Prediction ka target total return including dividends for Norelia equities funds site 2001 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Forecast horizon 12 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2001",
    "evidence": "Observations https://inputs.example/equities_funds/2001 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input ko xlsx ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field total_return_pct hai. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "total_return_pct",
    "evidence": "Target field total_return_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Asli data ka sampling interval 1 din hai. Measurement unit percent rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 15 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0015/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "Forecast horizon 15 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/equities_funds/0016
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. My source reference is https://inputs.example/equities_funds/2001. Select the source from the data catalog. Predict a horizon of 19 days. Source observations arrive every 1 day. Use shares as the target unit. My prediction target is ETF trading volume for Norelia equities funds site 2001.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2001",
    "evidence": "My source reference is https://inputs.example/equities_funds/2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 19 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "shares",
    "evidence": "Use shares as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETF trading volume for Norelia equities funds site 2001",
    "evidence": "My prediction target is ETF trading volume for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETF trading volume for Norelia equities funds site 2001",
    "evidence": "My prediction target is ETF trading volume for Norelia equities funds site 2001."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Read target values from field etf_volume.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "etf_volume",
    "evidence": "Read target values from field etf_volume."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The recorded structural breaks are [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}]. Require at least 365 training observations. The available historical coverage is 81 months. The historical observations end at 2026-09-30T00:00:00+00:00. The historical observations begin at 2020-01-01T00:00:00+00:00. Update the source records every 3 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t3/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "The recorded structural breaks are [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t3/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 365,
    "evidence": "Require at least 365 training observations."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t3/expected_history_length",
    "slot_id": "expected_history_length",
    "status": "provided",
    "value": {
      "periods": 81,
      "unit": "month"
    },
    "evidence": "The available historical coverage is 81 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t3/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "The historical observations end at 2026-09-30T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t3/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "The historical observations begin at 2020-01-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "Update the source records every 3 hours."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Require non-missing coverage of at least 96 percent. For invalid values, use the policy coerce. For unusual values, use the policy cap. For duplicate observations, use the policy reject. For missing target values, use the policy reject. For missing periods, use the policy reject.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t4/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 96,
    "evidence": "Require non-missing coverage of at least 96 percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t4/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "coerce",
    "evidence": "For invalid values, use the policy coerce."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t4/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "For unusual values, use the policy cap."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t4/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "For duplicate observations, use the policy reject."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t4/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "For missing target values, use the policy reject."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t4/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "For missing periods, use the policy reject."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 22 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0016/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 22 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/equities_funds/0017
Split: train

### t1 initial_multislot

I need forecasts of split-and-dividend-adjusted closing share price for Norelia equities funds site 2001. Measure the target in USD per share. The observations are recorded every 1 day. The forecast should extend 9 days ahead. Do not substitute raw closing share price without corporate-action adjustment as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Norelia equities funds site 2001",
    "evidence": "I need forecasts of split-and-dividend-adjusted closing share price for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Norelia equities funds site 2001",
    "evidence": "I need forecasts of split-and-dividend-adjusted closing share price for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Measure the target in USD per share."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "The forecast should extend 9 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called adjusted_close. The timestamp column is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "adjusted_close",
    "evidence": "The target column is called adjusted_close."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The timestamp column is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Select the source from the data catalog. Use the data source https://inputs.example/equities_funds/2001. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2001",
    "evidence": "Use the data source https://inputs.example/equities_funds/2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 12 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0017/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "The forecast should extend 12 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/equities_funds/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/equities_funds/2001. Select the source from the data catalog. I need the next 16 days predicted. There is one observed data point every 1 day. The target values are in USD per share. The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2001",
    "evidence": "The source is https://inputs.example/equities_funds/2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "I need the next 16 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "The target values are in USD per share."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Norelia equities funds site 2001",
    "evidence": "The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Norelia equities funds site 2001",
    "evidence": "The quantity to predict is raw closing share price without corporate-action adjustment for Norelia equities funds site 2001."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field recorded_at. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains confidential synthetic records.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 19 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "I need the next 19 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/equities_funds/0019
Split: train

### t1 initial_multislot

Here is what I need.  Please predict total return including dividends for Norelia equities funds site 2001. Measurement unit percent rakhein. The forecast horizon is 6 days. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "total return including dividends for Norelia equities funds site 2001",
    "evidence": "Please predict total return including dividends for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "total return including dividends for Norelia equities funds site 2001",
    "evidence": "Please predict total return including dividends for Norelia equities funds site 2001."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 6 days."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. The native sampling interval is 1 day. Forecast generation har 2 din run karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Forecast generation har 2 din run karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target field name is total_return_pct. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "total_return_pct",
    "evidence": "The target field name is total_return_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0019/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 9 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r8-dev/equities_funds/0020
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target split-and-dividend-adjusted closing share price for Orven equities funds site 2002 hai. Measurement unit USD per share rakhein. Asli data ka sampling interval 1 din hai. Forecast horizon 5 din hai. Observations equities_funds_archive_2002 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Orven equities funds site 2002",
    "evidence": "Prediction ka target split-and-dividend-adjusted closing share price for Orven equities funds site 2002 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Orven equities funds site 2002",
    "evidence": "Prediction ka target split-and-dividend-adjusted closing share price for Orven equities funds site 2002 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Measurement unit USD per share rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "Forecast horizon 5 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "equities_funds_archive_2002",
    "evidence": "Observations equities_funds_archive_2002 se lein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field adjusted_close hai. Timestamps ke liye column sample_date use karein. Main data upload karunga. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "adjusted_close",
    "evidence": "Target field adjusted_close hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 8 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Forecast horizon 8 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Orven equities funds site 2002 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0020/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven equities funds site 2002",
    "evidence": "business goal ki requirement prepare a planning reserve for Orven equities funds site 2002 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/equities_funds/0025
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is equities_funds_archive_2002.csv. I will upload the data. Predict a horizon of 6 days. Source observations arrive every 1 day. Use USD per share as the target unit. My prediction target is raw closing share price without corporate-action adjustment for Orven equities funds site 2002.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "equities_funds_archive_2002.csv",
    "evidence": "My source reference is equities_funds_archive_2002.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 6 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Use USD per share as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Orven equities funds site 2002",
    "evidence": "My prediction target is raw closing share price without corporate-action adjustment for Orven equities funds site 2002."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Orven equities funds site 2002",
    "evidence": "My prediction target is raw closing share price without corporate-action adjustment for Orven equities funds site 2002."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field raw_close.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "raw_close",
    "evidence": "Read target values from field raw_close."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Use USD per share as the target unit. Source observations arrive every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Use USD per share as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0025/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 9 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r8-dev/equities_funds/0026
Split: train

### t1 initial_multislot

I need forecasts of total return including dividends for Orven equities funds site 2002. Target ki unit percent hai. The observations are recorded every 1 day. Forecast aglay 13 din tak chahiye. I will upload the data. Data source equities_funds_archive_2002.csv use karein. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "total return including dividends for Orven equities funds site 2002",
    "evidence": "I need forecasts of total return including dividends for Orven equities funds site 2002."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "total return including dividends for Orven equities funds site 2002",
    "evidence": "I need forecasts of total return including dividends for Orven equities funds site 2002."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Forecast aglay 13 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "equities_funds_archive_2002.csv",
    "evidence": "Data source equities_funds_archive_2002.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called total_return_pct. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "total_return_pct",
    "evidence": "The target column is called total_return_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Exclude weekends and non-business days. holidays ki requirement synthetic market closure hai. The known special events are [{"date": "2026-10-05", "name": "synthetic scheduled data release"}]. past covariates ki requirement lagged_target hai. These regressors are known for future periods: announced_calendar_event. static features ki requirement scope_sector hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t3/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": true,
    "evidence": "Exclude weekends and non-business days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t3/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic market closure"
    ],
    "evidence": "holidays ki requirement synthetic market closure hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t3/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "The known special events are [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t3/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "past covariates ki requirement lagged_target hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t3/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "These regressors are known for future periods: announced_calendar_event."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t3/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_sector"
    ],
    "evidence": "static features ki requirement scope_sector hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The future regressor availability records are [{"available": "announced before cutoff", "name": "announced_calendar_event"}]. external covariate sources ki requirement [{"name": "announced_calendar_event", "source": "synthetic_calendar"}] hai. The requested forecast output type is probabilistic. quantiles ki requirement 0.1, 0.5, 0.9 hai. The alternative future scenarios are [{"description": "synthetic planning sensitivity", "name": "stress"}]. rounding rule ki requirement {"decimal_places": 2} hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t4/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "The future regressor availability records are [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t4/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "external covariate sources ki requirement [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t4/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t4/quantiles",
    "slot_id": "quantiles",
    "status": "provided",
    "value": [
      0.1,
      0.5,
      0.9
    ],
    "evidence": "quantiles ki requirement 0.1, 0.5, 0.9 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t4/scenario_forecasts",
    "slot_id": "scenario_forecasts",
    "status": "provided",
    "value": [
      {
        "description": "synthetic planning sensitivity",
        "name": "stress"
      }
    ],
    "evidence": "The alternative future scenarios are [{\"description\": \"synthetic planning sensitivity\", \"name\": \"stress\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t4/rounding_rule",
    "slot_id": "rounding_rule",
    "status": "provided",
    "value": {
      "decimal_places": 2
    },
    "evidence": "rounding rule ki requirement {\"decimal_places\": 2} hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 16 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0026/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "The forecast should extend 16 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/equities_funds/0029
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 17 days. Use USD per share as the target unit. My prediction target is raw closing share price without corporate-action adjustment for Orven equities funds site 2002. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 17 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Use USD per share as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Orven equities funds site 2002",
    "evidence": "My prediction target is raw closing share price without corporate-action adjustment for Orven equities funds site 2002."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Orven equities funds site 2002",
    "evidence": "My prediction target is raw closing share price without corporate-action adjustment for Orven equities funds site 2002."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Produce new forecasts every 3 days. Source observations arrive every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 3 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The time field name is sample_date. Read target values from field raw_close.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "raw_close",
    "evidence": "Read target values from field raw_close."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 20 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0029/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 20 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r8-dev/equities_funds/0032
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/equities_funds/2003 hai. Input API ke zariye lein. Aglay 13 din predict karein. Har 1 din aik observed data point milta hai. Target values USD per share mein hain. raw closing share price without corporate-action adjustment for Pelmar equities funds site 2003 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2003",
    "evidence": "Source https://inputs.example/equities_funds/2003 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Aglay 13 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Target values USD per share mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Pelmar equities funds site 2003",
    "evidence": "raw closing share price without corporate-action adjustment for Pelmar equities funds site 2003 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Pelmar equities funds site 2003",
    "evidence": "raw closing share price without corporate-action adjustment for Pelmar equities funds site 2003 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field observed_time mein hain. Column raw_close ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates field observed_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "raw_close",
    "evidence": "Column raw_close ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 16 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Aglay 16 din predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Source https://revised.example/equities_funds/32 hai. Har 2 din aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/equities_funds/32",
    "evidence": "Source https://revised.example/equities_funds/32 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0032/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Har 2 din aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/equities_funds/0035
Split: train

### t1 initial_multislot

I need forecasts of split-and-dividend-adjusted closing share price for Pelmar equities funds site 2003. Target ki unit USD per share hai. The observations are recorded every 1 day. Forecast aglay 17 din tak chahiye. Access the input through an API. Data source https://inputs.example/equities_funds/2003 use karein. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Pelmar equities funds site 2003",
    "evidence": "I need forecasts of split-and-dividend-adjusted closing share price for Pelmar equities funds site 2003."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Pelmar equities funds site 2003",
    "evidence": "I need forecasts of split-and-dividend-adjusted closing share price for Pelmar equities funds site 2003."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Target ki unit USD per share hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Forecast aglay 17 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2003",
    "evidence": "Data source https://inputs.example/equities_funds/2003 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called adjusted_close. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "adjusted_close",
    "evidence": "The target column is called adjusted_close."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The observations are recorded every 1 day. Target ki unit USD per share hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Target ki unit USD per share hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 20 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0035/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "The forecast should extend 20 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/equities_funds/0041
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format json hai. Source https://inputs.example/equities_funds/2004 hai. Input database se read karein. Aglay 17 din predict karein. Har 1 din aik observed data point milta hai. Target values shares mein hain. ETF trading volume for Talven equities funds site 2004 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Diye hue data ka format json hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2004",
    "evidence": "Source https://inputs.example/equities_funds/2004 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Aglay 17 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "shares",
    "evidence": "Target values shares mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETF trading volume for Talven equities funds site 2004",
    "evidence": "ETF trading volume for Talven equities funds site 2004 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETF trading volume for Talven equities funds site 2004",
    "evidence": "ETF trading volume for Talven equities funds site 2004 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field measurement_time mein hain. Column etf_volume ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "etf_volume",
    "evidence": "Column etf_volume ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Forecast resolution one prediction row per day rakhein. Har 2 ghantay naya source update lein. Forecasting model har 1 mahina refit karein. Predictions har 2 din refresh karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Forecast resolution one prediction row per day rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghantay naya source update lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Forecasting model har 1 mahina refit karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Predictions har 2 din refresh karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 20 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0041/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Aglay 20 din predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r8-dev/equities_funds/0047
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 8 days. Source observations har 1 din aati hain. Use USD per share as the target unit. raw closing share price without corporate-action adjustment for Talven equities funds site 2004 ke liye prediction bana dein. Do not substitute daily total return including dividends as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 8 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Use USD per share as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Talven equities funds site 2004",
    "evidence": "raw closing share price without corporate-action adjustment for Talven equities funds site 2004 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Talven equities funds site 2004",
    "evidence": "raw closing share price without corporate-action adjustment for Talven equities funds site 2004 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Target values field raw_close se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "raw_close",
    "evidence": "Target values field raw_close se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is json. Mera source reference https://inputs.example/equities_funds/2004 hai. Read the input from a database.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2004",
    "evidence": "Mera source reference https://inputs.example/equities_funds/2004 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 11 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0047/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 11 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r8-dev/equities_funds/0073
Split: train

### t1 initial_multislot

Here is what I need.  Please predict total return including dividends for Yarven equities funds site 2007. Measurement unit percent rakhein. The native sampling interval is 1 day. Forecast horizon 13 din hai. Access the input through an API. Observations https://inputs.example/equities_funds/2007 se lein. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "total return including dividends for Yarven equities funds site 2007",
    "evidence": "Please predict total return including dividends for Yarven equities funds site 2007."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "total return including dividends for Yarven equities funds site 2007",
    "evidence": "Please predict total return including dividends for Yarven equities funds site 2007."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Forecast horizon 13 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2007",
    "evidence": "Observations https://inputs.example/equities_funds/2007 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Interpret timestamps using Europe/London. Repeating seasonal pattern expect nahi karta. The requested forecast output type is probabilistic. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Interpret timestamps using Europe/London."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target field name is total_return_pct. Timestamps ke liye column observed_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "total_return_pct",
    "evidence": "The target field name is total_return_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamps ke liye column observed_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 16 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0073/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 16 days."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/equities_funds/0074
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format parquet hai. Mera source reference https://inputs.example/equities_funds/2007 hai. Input API ke zariye lein. 20 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko shares mein measure karein. ETF trading volume for Yarven equities funds site 2007 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Source serialization format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2007",
    "evidence": "Mera source reference https://inputs.example/equities_funds/2007 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "20 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "shares",
    "evidence": "Target ko shares mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETF trading volume for Yarven equities funds site 2007",
    "evidence": "ETF trading volume for Yarven equities funds site 2007 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETF trading volume for Yarven equities funds site 2007",
    "evidence": "ETF trading volume for Yarven equities funds site 2007 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. 20 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. 20 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. 23 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "23 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. 23 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0074/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. 23 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/equities_funds/0092
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for ETF trading volume for Norelia equities funds site 2009. Target measurements ki unit shares hai. Each observed record covers 1 day. Future coverage 11 din chahiye. Select the source from the data catalog. Diya hua source identifier https://inputs.example/equities_funds/2009 hai. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETF trading volume for Norelia equities funds site 2009",
    "evidence": "We need an outlook for ETF trading volume for Norelia equities funds site 2009."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETF trading volume for Norelia equities funds site 2009",
    "evidence": "We need an outlook for ETF trading volume for Norelia equities funds site 2009."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "shares",
    "evidence": "Target measurements ki unit shares hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Future coverage 11 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2009",
    "evidence": "Diya hua source identifier https://inputs.example/equities_funds/2009 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column etf_volume. Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "etf_volume",
    "evidence": "The response variable is stored in column etf_volume."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 14 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 14 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. Each observed record covers 2 days. Diya hua source identifier https://revised.example/equities_funds/92 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Each observed record covers 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0092/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/equities_funds/92",
    "evidence": "Diya hua source identifier https://revised.example/equities_funds/92 hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r8-dev/equities_funds/0118
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format parquet hai. Mera source reference https://inputs.example/equities_funds/2011 hai. Input API ke zariye lein. 7 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko shares mein measure karein. ETF trading volume for Pelmar equities funds site 2011 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Source serialization format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2011",
    "evidence": "Mera source reference https://inputs.example/equities_funds/2011 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "7 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "shares",
    "evidence": "Target ko shares mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETF trading volume for Pelmar equities funds site 2011",
    "evidence": "ETF trading volume for Pelmar equities funds site 2011 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETF trading volume for Pelmar equities funds site 2011",
    "evidence": "ETF trading volume for Pelmar equities funds site 2011 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Time field ka naam observed_time hai. Target values field value "net" se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Time field ka naam observed_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "Target values field value \"net\" se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values allowed nahi hain. Source mein confidential synthetic records hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 10 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0118/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "10 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r8-dev/equities_funds/0148
Split: train

### t1 initial_multislot

Here is what I need.  Please predict split-and-dividend-adjusted closing share price for Weslin equities funds site 2014. Measurement unit USD per share rakhein. The native sampling interval is 1 day. Forecast horizon 6 din hai. I will upload the data. Observations equities_funds_archive_2014.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Weslin equities funds site 2014",
    "evidence": "Please predict split-and-dividend-adjusted closing share price for Weslin equities funds site 2014."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Weslin equities funds site 2014",
    "evidence": "Please predict split-and-dividend-adjusted closing share price for Weslin equities funds site 2014."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Measurement unit USD per share rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "Forecast horizon 6 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "equities_funds_archive_2014.csv",
    "evidence": "Observations equities_funds_archive_2014.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target field name is inflation (%). Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "inflation (%)",
    "evidence": "The target field name is inflation (%)."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0148/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 9 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r8-dev/equities_funds/0154
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for ETF trading volume for Yarven equities funds site 2015. Target measurements ki unit shares hai. Each observed record covers 1 day. Future coverage 6 din chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/equities_funds/2015 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETF trading volume for Yarven equities funds site 2015",
    "evidence": "We need an outlook for ETF trading volume for Yarven equities funds site 2015."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETF trading volume for Yarven equities funds site 2015",
    "evidence": "We need an outlook for ETF trading volume for Yarven equities funds site 2015."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "shares",
    "evidence": "Target measurements ki unit shares hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "Future coverage 6 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2015",
    "evidence": "Diya hua source identifier https://inputs.example/equities_funds/2015 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The requested future coverage is 6 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The requested future coverage is 6 days."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 9 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The requested future coverage is 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0154/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The requested future coverage is 9 days."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r8-dev/equities_funds/0173
Split: train

### t1 initial_multislot

Mujhe split-and-dividend-adjusted closing share price for Norelia equities funds site 2017 ka forecast chahiye. Target ki unit USD per share hai. Observations har 1 din record hoti hain. Forecast aglay 4 din tak chahiye. Source data catalog se select karein. Data source https://inputs.example/equities_funds/2017 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Norelia equities funds site 2017",
    "evidence": "Mujhe split-and-dividend-adjusted closing share price for Norelia equities funds site 2017 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "split-and-dividend-adjusted closing share price for Norelia equities funds site 2017",
    "evidence": "Mujhe split-and-dividend-adjusted closing share price for Norelia equities funds site 2017 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Target ki unit USD per share hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "Forecast aglay 4 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2017",
    "evidence": "Data source https://inputs.example/equities_funds/2017 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Timestamps ki timezone UTC hai. Repeating seasonal pattern expect nahi karta. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Timestamps ki timezone UTC hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Target column ka naam adjusted_close hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "adjusted_close",
    "evidence": "Target column ka naam adjusted_close hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 7 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0173/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Forecast aglay 7 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r8-dev/equities_funds/0196
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format parquet hai. Source https://inputs.example/equities_funds/2019 hai. Input API ke zariye lein. Aglay 13 din predict karein. Har 1 din aik observed data point milta hai. Target values USD per share mein hain. raw closing share price without corporate-action adjustment for Pelmar equities funds site 2019 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Diye hue data ka format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/equities_funds/2019",
    "evidence": "Source https://inputs.example/equities_funds/2019 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Aglay 13 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per share",
    "evidence": "Target values USD per share mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Pelmar equities funds site 2019",
    "evidence": "raw closing share price without corporate-action adjustment for Pelmar equities funds site 2019 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "raw closing share price without corporate-action adjustment for Pelmar equities funds site 2019",
    "evidence": "raw closing share price without corporate-action adjustment for Pelmar equities funds site 2019 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field observed_time mein hain. Column raw_close ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates field observed_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "raw_close",
    "evidence": "Column raw_close ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

decision supported ki requirement set the contingency allowance for Pelmar equities funds site 2019 hai. stakeholder role ki requirement equity research analyst hai. business goal ki requirement prepare a planning reserve for Pelmar equities funds site 2019 hai. Modeling se pehle human approval required hai. explainability level ki requirement none hai. Detailed data lineage required hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Pelmar equities funds site 2019",
    "evidence": "decision supported ki requirement set the contingency allowance for Pelmar equities funds site 2019 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "equity research analyst",
    "evidence": "stakeholder role ki requirement equity research analyst hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Pelmar equities funds site 2019",
    "evidence": "business goal ki requirement prepare a planning reserve for Pelmar equities funds site 2019 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": true,
    "evidence": "Modeling se pehle human approval required hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t3/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "none",
    "evidence": "explainability level ki requirement none hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t3/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": true,
    "evidence": "Detailed data lineage required hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

forecast start ki requirement 2026-10-01T00:00:00+00:00 hai. Trading sessions wala calendar use karein. aggregation method ki requirement last hai. Negative target values allowed nahi hain. target bounds ki requirement {"max": 1000000, "min": 0} hai. success criteria ki requirement MAE no more than 5 USD per share for Pelmar equities funds site 2019 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "forecast start ki requirement 2026-10-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "trading",
    "evidence": "Trading sessions wala calendar use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "aggregation method ki requirement last hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t4/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "target bounds ki requirement {\"max\": 1000000, \"min\": 0} hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t4/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 5 USD per share for Pelmar equities funds site 2019",
    "evidence": "success criteria ki requirement MAE no more than 5 USD per share for Pelmar equities funds site 2019 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Aglay 16 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/equities_funds/0196/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Aglay 16 din predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
