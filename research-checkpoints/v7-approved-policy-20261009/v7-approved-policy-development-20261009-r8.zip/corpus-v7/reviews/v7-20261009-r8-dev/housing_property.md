# V7 review examples for housing_property

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r8-dev/housing_property/0010
Split: train

### t1 initial_multislot

For my request,  The source is housing_property_archive_2501.csv. I need the next 9 months predicted. There is one observed data point every 1 month. The target values are in dwellings. The quantity to predict is housing starts count for Norelia housing property site 2501.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "The source is housing_property_archive_2501.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "csv",
    "evidence": "The source is housing_property_archive_2501.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "I need the next 9 months predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "dwellings",
    "evidence": "The target values are in dwellings."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing starts count for Norelia housing property site 2501",
    "evidence": "The quantity to predict is housing starts count for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing starts count for Norelia housing property site 2501",
    "evidence": "The quantity to predict is housing starts count for Norelia housing property site 2501."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The supplied data format is csv. I will upload the data. Dates are stored in field sample_date. Use column housing_starts as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "housing_starts",
    "evidence": "Use column housing_starts as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 12 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "I need the next 12 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Norelia housing property site 2501.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia housing property site 2501",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia housing property site 2501."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r8-dev/housing_property/0011
Split: train

### t1 initial_multislot

Here is what I need.  Please predict housing vacancy rate for Norelia housing property site 2501. Measurement unit percent rakhein. The native sampling interval is 1 month. Forecast horizon 16 mahinay hai. I will upload the data. Observations housing_property_archive_2501.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing vacancy rate for Norelia housing property site 2501",
    "evidence": "Please predict housing vacancy rate for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing vacancy rate for Norelia housing property site 2501",
    "evidence": "Please predict housing vacancy rate for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Forecast horizon 16 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "Observations housing_property_archive_2501.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is vacancy_pct. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "vacancy_pct",
    "evidence": "The target field name is vacancy_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Run forecast generation once every 2 days. Training har 2 mahinay repeat karein. The input source refresh schedule is every 3 hours. Result granularity one prediction row per month banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training har 2 mahinay repeat karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Result granularity one prediction row per month banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 19 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0011/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 19 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/housing_property/0012
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is housing_property_archive_2501.csv. I will upload the data. Predict a horizon of 6 months. Source observations arrive every 1 month. Use index points, base 2020=100 as the target unit. My prediction target is residential house-price index level for Norelia housing property site 2501.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "My source reference is housing_property_archive_2501.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 6 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential house-price index level for Norelia housing property site 2501",
    "evidence": "My prediction target is residential house-price index level for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential house-price index level for Norelia housing property site 2501",
    "evidence": "My prediction target is residential house-price index level for Norelia housing property site 2501."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field house_price_index.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "house_price_index",
    "evidence": "Read target values from field house_price_index."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 9 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 9 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/housing_property/12. Source observations arrive every 2 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/housing_property/12",
    "evidence": "My source reference is https://revised.example/housing_property/12."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0012/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 2 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/housing_property/0013
Split: train

### t1 initial_multislot

I need forecasts of residential rent for Norelia housing property site 2501. Measure the target in USD per dwelling. The observations are recorded every 1 month. The forecast should extend 13 months ahead. I will upload the data. Use the data source housing_property_archive_2501.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential rent for Norelia housing property site 2501",
    "evidence": "I need forecasts of residential rent for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential rent for Norelia housing property site 2501",
    "evidence": "I need forecasts of residential rent for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per dwelling",
    "evidence": "Measure the target in USD per dwelling."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "The forecast should extend 13 months ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "Use the data source housing_property_archive_2501.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

The timestamp timezone is Asia/Karachi. I expect a repeating seasonal pattern. The seasonal cycles in observation periods are 12. The requested forecast output type is probabilistic. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "The timestamp timezone is Asia/Karachi."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      12
    ],
    "evidence": "The seasonal cycles in observation periods are 12."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target column is called monthly_rent. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "monthly_rent",
    "evidence": "The target column is called monthly_rent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 16 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "The forecast should extend 16 months ahead."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/housing_property/0014
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source housing_property_archive_2501.csv hai. Main data upload karunga. Aglay 20 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values dwellings mein hain. housing starts count for Norelia housing property site 2501 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "Source housing_property_archive_2501.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "Aglay 20 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "dwellings",
    "evidence": "Target values dwellings mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing starts count for Norelia housing property site 2501",
    "evidence": "housing starts count for Norelia housing property site 2501 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing starts count for Norelia housing property site 2501",
    "evidence": "housing starts count for Norelia housing property site 2501 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 20 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 20 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 23 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "month"
    },
    "evidence": "Aglay 23 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 23 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0014/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 23,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Aglay 23 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/housing_property/0015
Split: train

### t1 initial_multislot

Here is what I need.  Please predict housing vacancy rate for Norelia housing property site 2501. Keep the measurement unit as percent. The native sampling interval is 1 month. The forecast horizon is 10 months. I will upload the data. Read the observations from housing_property_archive_2501.csv. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing vacancy rate for Norelia housing property site 2501",
    "evidence": "Please predict housing vacancy rate for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing vacancy rate for Norelia housing property site 2501",
    "evidence": "Please predict housing vacancy rate for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Keep the measurement unit as percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 10 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "Read the observations from housing_property_archive_2501.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is vacancy_pct. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "vacancy_pct",
    "evidence": "The target field name is vacancy_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The native sampling interval is 1 month. Keep the measurement unit as percent.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Keep the measurement unit as percent."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0015/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 13 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/housing_property/0016
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is housing_property_archive_2501.csv. I will upload the data. Predict a horizon of 17 months. Source observations arrive every 1 month. Use index points, base 2020=100 as the target unit. My prediction target is residential house-price index level for Norelia housing property site 2501.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "My source reference is housing_property_archive_2501.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 17 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential house-price index level for Norelia housing property site 2501",
    "evidence": "My prediction target is residential house-price index level for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential house-price index level for Norelia housing property site 2501",
    "evidence": "My prediction target is residential house-price index level for Norelia housing property site 2501."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field house_price_index.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "house_price_index",
    "evidence": "Read target values from field house_price_index."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Enforce these privacy restrictions: synthetic data only, no external redistribution. The source contains no personal, confidential, or regulated data. Deliver completed forecasts to https://planning.example/housing_property/2501. Serialize the results as csv. The maximum response time is 18 seconds. Schedule model retraining every 2 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t3/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "Enforce these privacy restrictions: synthetic data only, no external redistribution."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t3/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/housing_property/2501",
    "evidence": "Deliver completed forecasts to https://planning.example/housing_property/2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t3/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Serialize the results as csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t3/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "second"
    },
    "evidence": "The maximum response time is 18 seconds."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Schedule model retraining every 2 months."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

My role in this project is housing research analyst. Our operational goal is to prepare a planning reserve for Norelia housing property site 2501. Human approval before modeling is not required. The required explanation level is none. Detailed data lineage is not required. The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t4/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "housing research analyst",
    "evidence": "My role in this project is housing research analyst."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia housing property site 2501",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t4/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Human approval before modeling is not required."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t4/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "none",
    "evidence": "The required explanation level is none."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t4/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": false,
    "evidence": "Detailed data lineage is not required."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t4/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 20 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0016/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 20 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

For a separate new request, explain the definition of housing property. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/housing_property/0017
Split: train

### t1 initial_multislot

I need forecasts of residential rent for Norelia housing property site 2501. Measure the target in USD per dwelling. The observations are recorded every 1 month. The forecast should extend 7 months ahead. Do not substitute housing starts count as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential rent for Norelia housing property site 2501",
    "evidence": "I need forecasts of residential rent for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential rent for Norelia housing property site 2501",
    "evidence": "I need forecasts of residential rent for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per dwelling",
    "evidence": "Measure the target in USD per dwelling."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "The forecast should extend 7 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called monthly_rent. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "monthly_rent",
    "evidence": "The target column is called monthly_rent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

I will upload the data. Use the data source housing_property_archive_2501.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "Use the data source housing_property_archive_2501.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 10 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0017/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "The forecast should extend 10 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/housing_property/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is housing_property_archive_2501.csv. I will upload the data. I need the next 14 months predicted. There is one observed data point every 1 month. The target values are in dwellings. The quantity to predict is housing starts count for Norelia housing property site 2501.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2501.csv",
    "evidence": "The source is housing_property_archive_2501.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "I need the next 14 months predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "dwellings",
    "evidence": "The target values are in dwellings."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing starts count for Norelia housing property site 2501",
    "evidence": "The quantity to predict is housing starts count for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing starts count for Norelia housing property site 2501",
    "evidence": "The quantity to predict is housing starts count for Norelia housing property site 2501."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field sample_date. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains no personal, confidential, or regulated data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "I need the next 17 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/housing_property/0019
Split: train

### t1 initial_multislot

Here is what I need.  Please predict housing vacancy rate for Norelia housing property site 2501. Keep the measurement unit as percent. The forecast horizon is 4 months. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing vacancy rate for Norelia housing property site 2501",
    "evidence": "Please predict housing vacancy rate for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing vacancy rate for Norelia housing property site 2501",
    "evidence": "Please predict housing vacancy rate for Norelia housing property site 2501."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Keep the measurement unit as percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 4 months."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. The native sampling interval is 1 month. Run forecast generation once every 2 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target field name is vacancy_pct. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "vacancy_pct",
    "evidence": "The target field name is vacancy_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 7 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0019/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 7 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/housing_property/0021
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. My source reference is https://inputs.example/housing_property/2502. Access the input through an API. Predict a horizon of 10 months. Source observations arrive every 1 month. Use dwellings as the target unit. My prediction target is housing starts count for Orven housing property site 2502.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2502",
    "evidence": "My source reference is https://inputs.example/housing_property/2502."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 10 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "dwellings",
    "evidence": "Use dwellings as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing starts count for Orven housing property site 2502",
    "evidence": "My prediction target is housing starts count for Orven housing property site 2502."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing starts count for Orven housing property site 2502",
    "evidence": "My prediction target is housing starts count for Orven housing property site 2502."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field housing_starts.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "housing_starts",
    "evidence": "Read target values from field housing_starts."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Use one prediction row per month as the output granularity. Update the source records every 4 hours. Schedule model retraining every 1 month. Produce new forecasts every 3 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Use one prediction row per month as the output granularity."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Update the source records every 4 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Schedule model retraining every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 3 days."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 13 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0021/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 13 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r8-dev/housing_property/0023
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. Source https://inputs.example/housing_property/2502 hai. Access the input through an API. Aglay 7 mahinay predict karein. There is one observed data point every 1 month. Target values index points, base 2020=100 mein hain. The quantity to predict is residential house-price index level for Orven housing property site 2502.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2502",
    "evidence": "Source https://inputs.example/housing_property/2502 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "Aglay 7 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target values index points, base 2020=100 mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential house-price index level for Orven housing property site 2502",
    "evidence": "The quantity to predict is residential house-price index level for Orven housing property site 2502."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential house-price index level for Orven housing property site 2502",
    "evidence": "The quantity to predict is residential house-price index level for Orven housing property site 2502."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. forecast type ki requirement probabilistic hai. I do not expect a repeating seasonal pattern. Times Europe/London mein hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Times Europe/London mein hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates are stored in field observed_time. Column house_price_index ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "house_price_index",
    "evidence": "Column house_price_index ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 10 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0023/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "I need the next 10 months predicted."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/housing_property/0024
Split: train

### t1 initial_multislot

Here is what I need.  Please predict residential rent for Orven housing property site 2502. Keep the measurement unit as USD per dwelling. The native sampling interval is 1 month. The forecast horizon is 14 months. Access the input through an API. Read the observations from https://inputs.example/housing_property/2502. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential rent for Orven housing property site 2502",
    "evidence": "Please predict residential rent for Orven housing property site 2502."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential rent for Orven housing property site 2502",
    "evidence": "Please predict residential rent for Orven housing property site 2502."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per dwelling",
    "evidence": "Keep the measurement unit as USD per dwelling."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 14 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2502",
    "evidence": "Read the observations from https://inputs.example/housing_property/2502."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast horizon is 14 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast horizon is 14 months."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 17 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 17 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast horizon is 17 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0024/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast horizon is 17 months."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r8-dev/housing_property/0028
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target residential rent for Orven housing property site 2502 hai. Measurement unit USD per dwelling rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 8 mahinay hai. Input API ke zariye lein. Observations https://inputs.example/housing_property/2502 se lein. Input ko parquet ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential rent for Orven housing property site 2502",
    "evidence": "Prediction ka target residential rent for Orven housing property site 2502 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential rent for Orven housing property site 2502",
    "evidence": "Prediction ka target residential rent for Orven housing property site 2502 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per dwelling",
    "evidence": "Measurement unit USD per dwelling rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Forecast horizon 8 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2502",
    "evidence": "Observations https://inputs.example/housing_property/2502 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input ko parquet ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target field inflation (%) hai. Timestamps ke liye column observed_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "inflation (%)",
    "evidence": "Target field inflation (%) hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamps ke liye column observed_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein confidential synthetic records hain. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 11 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0028/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Forecast horizon 11 mahinay hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r8-dev/housing_property/0037
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target housing vacancy rate for Pelmar housing property site 2503 hai. Measurement unit percent rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 12 mahinay hai. residential house-price index level nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing vacancy rate for Pelmar housing property site 2503",
    "evidence": "Prediction ka target housing vacancy rate for Pelmar housing property site 2503 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing vacancy rate for Pelmar housing property site 2503",
    "evidence": "Prediction ka target housing vacancy rate for Pelmar housing property site 2503 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast horizon 12 mahinay hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field vacancy_pct hai. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "vacancy_pct",
    "evidence": "Target field vacancy_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Input database se read karein. Observations https://inputs.example/housing_property/2503 se lein. Input ko json ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2503",
    "evidence": "Observations https://inputs.example/housing_property/2503 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input ko json ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 15 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0037/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Forecast horizon 15 mahinay hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r8-dev/housing_property/0038
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. Mera source reference https://inputs.example/housing_property/2503 hai. Read the input from a database. 19 mahinay ka horizon rakhein. Source observations arrive every 1 month. Target ko index points, base 2020=100 mein measure karein. My prediction target is residential house-price index level for Pelmar housing property site 2503.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2503",
    "evidence": "Mera source reference https://inputs.example/housing_property/2503 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "19 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential house-price index level for Pelmar housing property site 2503",
    "evidence": "My prediction target is residential house-price index level for Pelmar housing property site 2503."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential house-price index level for Pelmar housing property site 2503",
    "evidence": "My prediction target is residential house-price index level for Pelmar housing property site 2503."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The time field name is measurement_time. Target values field value "net" se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "Target values field value \"net\" se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. Source mein personal ya confidential data nahi hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 22 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0038/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 22 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of housing property. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r8-dev/housing_property/0040
Split: train

### t1 initial_multislot

Mujhe housing vacancy rate for Talven housing property site 2504 ka forecast chahiye. Target ki unit percent hai. Observations har 1 mahina record hoti hain. Forecast aglay 8 mahinay tak chahiye. Source data catalog se select karein. Data source https://inputs.example/housing_property/2504 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing vacancy rate for Talven housing property site 2504",
    "evidence": "Mujhe housing vacancy rate for Talven housing property site 2504 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing vacancy rate for Talven housing property site 2504",
    "evidence": "Mujhe housing vacancy rate for Talven housing property site 2504 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Forecast aglay 8 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2504",
    "evidence": "Data source https://inputs.example/housing_property/2504 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam vacancy_pct hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "vacancy_pct",
    "evidence": "Target column ka naam vacancy_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 11 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Forecast aglay 11 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Talven housing property site 2504 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0040/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Talven housing property site 2504",
    "evidence": "business goal ki requirement prepare a planning reserve for Talven housing property site 2504 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/housing_property/0045
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. Source https://inputs.example/housing_property/2504 hai. Select the source from the data catalog. Aglay 9 mahinay predict karein. There is one observed data point every 1 month. Target values index points, base 2020=100 mein hain. The quantity to predict is residential house-price index level for Talven housing property site 2504.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2504",
    "evidence": "Source https://inputs.example/housing_property/2504 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Aglay 9 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target values index points, base 2020=100 mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential house-price index level for Talven housing property site 2504",
    "evidence": "The quantity to predict is residential house-price index level for Talven housing property site 2504."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential house-price index level for Talven housing property site 2504",
    "evidence": "The quantity to predict is residential house-price index level for Talven housing property site 2504."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Column house_price_index ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "house_price_index",
    "evidence": "Column house_price_index ko target rakhein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in index points, base 2020=100. Har 1 mahina aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "The target values are in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 12 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0045/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "I need the next 12 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/housing_property/0059
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein housing vacancy rate for Virelo housing property site 2505 ka outlook chahiye. Target measurements ki unit percent hai. Future coverage 14 mahinay chahiye. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing vacancy rate for Virelo housing property site 2505",
    "evidence": "Hamein housing vacancy rate for Virelo housing property site 2505 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing vacancy rate for Virelo housing property site 2505",
    "evidence": "Hamein housing vacancy rate for Virelo housing property site 2505 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target measurements ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Future coverage 14 mahinay chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Har observed record 1 mahina cover karta hai. Naye forecasts har 3 din issue karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har observed record 1 mahina cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Naye forecasts har 3 din issue karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Response variable column vacancy_pct mein hai. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "vacancy_pct",
    "evidence": "Response variable column vacancy_pct mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 17 mahinay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0059/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Future coverage 17 mahinay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r8-dev/housing_property/0065
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format parquet hai. Mera source reference https://inputs.example/housing_property/2506 hai. Input API ke zariye lein. 14 mahinay ka horizon rakhein. Source observations har 1 mahina aati hain. Target ko dwellings mein measure karein. housing starts count for Weslin housing property site 2506 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Source serialization format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2506",
    "evidence": "Mera source reference https://inputs.example/housing_property/2506 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "14 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "dwellings",
    "evidence": "Target ko dwellings mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing starts count for Weslin housing property site 2506",
    "evidence": "housing starts count for Weslin housing property site 2506 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing starts count for Weslin housing property site 2506",
    "evidence": "housing starts count for Weslin housing property site 2506 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam observed_time hai. Target values field housing_starts se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Time field ka naam observed_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "housing_starts",
    "evidence": "Target values field housing_starts se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target ko dwellings mein measure karein. Source observations har 1 mahina aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "dwellings",
    "evidence": "Target ko dwellings mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. 17 mahinay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0065/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "17 mahinay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/housing_property/0082
Split: train

### t1 initial_multislot

Here is what I need.  Please predict residential rent for Merlow housing property site 2508. Measurement unit USD per dwelling rakhein. The native sampling interval is 1 month. Forecast horizon 15 mahinay hai. Select the source from the data catalog. Observations https://inputs.example/housing_property/2508 se lein. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential rent for Merlow housing property site 2508",
    "evidence": "Please predict residential rent for Merlow housing property site 2508."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential rent for Merlow housing property site 2508",
    "evidence": "Please predict residential rent for Merlow housing property site 2508."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per dwelling",
    "evidence": "Measurement unit USD per dwelling rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Forecast horizon 15 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2508",
    "evidence": "Observations https://inputs.example/housing_property/2508 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is monthly_rent. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "monthly_rent",
    "evidence": "The target field name is monthly_rent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 18 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 18 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 months. Observations https://revised.example/housing_property/82 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 2 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0082/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/housing_property/82",
    "evidence": "Observations https://revised.example/housing_property/82 se lein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/housing_property/0101
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein housing starts count for Orven housing property site 2510 ka outlook chahiye. Target measurements ki unit dwellings hai. Har observed record 1 mahina cover karta hai. Future coverage 13 mahinay chahiye. Input API ke zariye lein. Diya hua source identifier https://inputs.example/housing_property/2510 hai. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing starts count for Orven housing property site 2510",
    "evidence": "Hamein housing starts count for Orven housing property site 2510 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing starts count for Orven housing property site 2510",
    "evidence": "Hamein housing starts count for Orven housing property site 2510 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "dwellings",
    "evidence": "Target measurements ki unit dwellings hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har observed record 1 mahina cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Future coverage 13 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2510",
    "evidence": "Diya hua source identifier https://inputs.example/housing_property/2510 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column housing_starts mein hai. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "housing_starts",
    "evidence": "Response variable column housing_starts mein hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Naye forecasts har 2 din issue karein. Model har 1 mahina dobara estimate karein. Source ingestion har 4 ghantay repeat hoti hai. Prediction rows ki resolution one prediction row per month hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Naye forecasts har 2 din issue karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Model har 1 mahina dobara estimate karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source ingestion har 4 ghantay repeat hoti hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Prediction rows ki resolution one prediction row per month hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 16 mahinay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0101/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Future coverage 16 mahinay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r8-dev/housing_property/0133
Split: train

### t1 initial_multislot

Mujhe residential rent for Virelo housing property site 2513 ka forecast chahiye. Target ki unit USD per dwelling hai. Observations har 1 mahina record hoti hain. Forecast aglay 9 mahinay tak chahiye. Main data upload karunga. Data source housing_property_archive_2513.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential rent for Virelo housing property site 2513",
    "evidence": "Mujhe residential rent for Virelo housing property site 2513 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential rent for Virelo housing property site 2513",
    "evidence": "Mujhe residential rent for Virelo housing property site 2513 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per dwelling",
    "evidence": "Target ki unit USD per dwelling hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Forecast aglay 9 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2513.csv",
    "evidence": "Data source housing_property_archive_2513.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Timestamps ki timezone Asia/Karachi hai. Repeating seasonal pattern expect karta hoon. seasonal periods ki requirement 12 hai. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "Timestamps ki timezone Asia/Karachi hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      12
    ],
    "evidence": "seasonal periods ki requirement 12 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Target column ka naam monthly_rent hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "monthly_rent",
    "evidence": "Target column ka naam monthly_rent hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 12 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0133/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast aglay 12 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/housing_property/0159
Split: train

### t1 initial_multislot

I need forecasts of residential rent for Yarven housing property site 2515. Target ki unit USD per dwelling hai. The forecast should extend 5 months ahead. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential rent for Yarven housing property site 2515",
    "evidence": "I need forecasts of residential rent for Yarven housing property site 2515."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential rent for Yarven housing property site 2515",
    "evidence": "I need forecasts of residential rent for Yarven housing property site 2515."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per dwelling",
    "evidence": "Target ki unit USD per dwelling hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "The forecast should extend 5 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. The observations are recorded every 1 month. Naya forecast har 1 din banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naya forecast har 1 din banayein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target column is called monthly_rent. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "monthly_rent",
    "evidence": "The target column is called monthly_rent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 8 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0159/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "The forecast should extend 8 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r8-dev/housing_property/0167
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 19 months. Source observations har 1 mahina aati hain. Use dwellings as the target unit. housing starts count for Merlow housing property site 2516 ke liye prediction bana dein. Do not substitute housing vacancy rate as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 19 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "dwellings",
    "evidence": "Use dwellings as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "housing starts count for Merlow housing property site 2516",
    "evidence": "housing starts count for Merlow housing property site 2516 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "housing starts count for Merlow housing property site 2516",
    "evidence": "housing starts count for Merlow housing property site 2516 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Target values field housing_starts se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "housing_starts",
    "evidence": "Target values field housing_starts se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is xlsx. Mera source reference https://inputs.example/housing_property/2516 hai. Select the source from the data catalog.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/housing_property/2516",
    "evidence": "Mera source reference https://inputs.example/housing_property/2516 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 22 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0167/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 22 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r8-dev/housing_property/0172
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format csv hai. Mera source reference housing_property_archive_2517.csv hai. Main data upload karunga. 12 mahinay ka horizon rakhein. Source observations har 1 mahina aati hain. Target ko index points, base 2020=100 mein measure karein. residential house-price index level for Norelia housing property site 2517 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Source serialization format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "housing_property_archive_2517.csv",
    "evidence": "Mera source reference housing_property_archive_2517.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "12 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "residential house-price index level for Norelia housing property site 2517",
    "evidence": "residential house-price index level for Norelia housing property site 2517 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "residential house-price index level for Norelia housing property site 2517",
    "evidence": "residential house-price index level for Norelia housing property site 2517 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam sample_date hai. Target values field house_price_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Time field ka naam sample_date hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "house_price_index",
    "evidence": "Target values field house_price_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. 15 mahinay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "15 mahinay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Mera source reference https://revised.example/housing_property/172 hai. Source observations har 2 mahinay aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/housing_property/172",
    "evidence": "Mera source reference https://revised.example/housing_property/172 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/housing_property/0172/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Source observations har 2 mahinay aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: housing property ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending
