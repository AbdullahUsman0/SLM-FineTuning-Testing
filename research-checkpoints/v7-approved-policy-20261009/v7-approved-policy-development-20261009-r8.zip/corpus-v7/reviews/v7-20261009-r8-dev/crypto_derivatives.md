# V7 review examples for crypto_derivatives

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r8-dev/crypto_derivatives/0010
Split: train

### t1 initial_multislot

For my request,  The source is crypto_derivatives_archive_2401.xlsx. I need the next 6 hours predicted. There is one observed data point every 1 hour. The target values are in contracts. The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_derivatives_archive_2401.xlsx",
    "evidence": "The source is crypto_derivatives_archive_2401.xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "xlsx",
    "evidence": "The source is crypto_derivatives_archive_2401.xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "hour"
    },
    "evidence": "I need the next 6 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "The target values are in contracts."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Norelia crypto derivatives site 2401",
    "evidence": "The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Norelia crypto derivatives site 2401",
    "evidence": "The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The supplied data format is xlsx. Select the source from the data catalog. Dates are stored in field recorded_at. Use column eth_open_interest as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eth_open_interest",
    "evidence": "Use column eth_open_interest as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 9 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "I need the next 9 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Norelia crypto derivatives site 2401.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia crypto derivatives site 2401",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia crypto derivatives site 2401."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/crypto_derivatives/0011
Split: train

### t1 initial_multislot

Here is what I need.  Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401. Keep the measurement unit as percent per year. The native sampling interval is 1 hour. The forecast horizon is 13 hours. Select the source from the data catalog. Read the observations from https://inputs.example/crypto_derivatives/2401. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401",
    "evidence": "Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401",
    "evidence": "Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Keep the measurement unit as percent per year."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 13 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2401",
    "evidence": "Read the observations from https://inputs.example/crypto_derivatives/2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is btc_realized_vol. Use column recorded_at for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "The target field name is btc_realized_vol."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Run forecast generation once every 2 days. Training should be repeated every 2 months. The input source refresh schedule is every 3 hours. Make the result granularity one prediction row per hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training should be repeated every 2 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Make the result granularity one prediction row per hour."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 16 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0011/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 16 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/crypto_derivatives/0012
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. My source reference is https://inputs.example/crypto_derivatives/2401. Select the source from the data catalog. Predict a horizon of 20 hours. Source observations arrive every 1 hour. Use basis points as the target unit. My prediction target is BTC futures-minus-spot basis for Norelia crypto derivatives site 2401.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2401",
    "evidence": "My source reference is https://inputs.example/crypto_derivatives/2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 20 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "Use basis points as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC futures-minus-spot basis for Norelia crypto derivatives site 2401",
    "evidence": "My prediction target is BTC futures-minus-spot basis for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC futures-minus-spot basis for Norelia crypto derivatives site 2401",
    "evidence": "My prediction target is BTC futures-minus-spot basis for Norelia crypto derivatives site 2401."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Read target values from field btc_basis_bp.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_basis_bp",
    "evidence": "Read target values from field btc_basis_bp."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 23 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 23 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/crypto_derivatives/12. Source observations arrive every 2 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/crypto_derivatives/12",
    "evidence": "My source reference is https://revised.example/crypto_derivatives/12."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0012/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 2 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/crypto_derivatives/0013
Split: train

### t1 initial_multislot

I need forecasts of BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401. Measure the target in percent per 8 hours. The observations are recorded every 1 hour. The forecast should extend 10 hours ahead. Select the source from the data catalog. Use the data source https://inputs.example/crypto_derivatives/2401. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401",
    "evidence": "I need forecasts of BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401",
    "evidence": "I need forecasts of BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per 8 hours",
    "evidence": "Measure the target in percent per 8 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 10 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2401",
    "evidence": "Use the data source https://inputs.example/crypto_derivatives/2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

The timestamp timezone is UTC. I do not expect a repeating seasonal pattern. The requested forecast output type is probabilistic. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "The timestamp timezone is UTC."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target column is called btc_funding_pct. The timestamp column is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_funding_pct",
    "evidence": "The target column is called btc_funding_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The timestamp column is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 13 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 13 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/crypto_derivatives/0014
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/crypto_derivatives/2401. Select the source from the data catalog. I need the next 17 hours predicted. There is one observed data point every 1 hour. The target values are in contracts. The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2401",
    "evidence": "The source is https://inputs.example/crypto_derivatives/2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "I need the next 17 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "The target values are in contracts."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Norelia crypto derivatives site 2401",
    "evidence": "The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Norelia crypto derivatives site 2401",
    "evidence": "The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. I need the next 17 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. I need the next 17 hours predicted."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 20 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "I need the next 20 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. I need the next 20 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0014/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. I need the next 20 hours predicted."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/crypto_derivatives/0015
Split: train

### t1 initial_multislot

Here is what I need.  Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401. Measurement unit percent per year rakhein. The native sampling interval is 1 hour. Forecast horizon 7 ghantay hai. Select the source from the data catalog. Observations https://inputs.example/crypto_derivatives/2401 se lein. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401",
    "evidence": "Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401",
    "evidence": "Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Measurement unit percent per year rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 7 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2401",
    "evidence": "Observations https://inputs.example/crypto_derivatives/2401 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is btc_realized_vol. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "The target field name is btc_realized_vol."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The native sampling interval is 1 hour. Measurement unit percent per year rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Measurement unit percent per year rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 10 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0015/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 10 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of crypto derivatives. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/crypto_derivatives/0016
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. My source reference is https://inputs.example/crypto_derivatives/2401. Select the source from the data catalog. Predict a horizon of 14 hours. Source observations arrive every 1 hour. Use basis points as the target unit. My prediction target is BTC futures-minus-spot basis for Norelia crypto derivatives site 2401.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2401",
    "evidence": "My source reference is https://inputs.example/crypto_derivatives/2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 14 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "Use basis points as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC futures-minus-spot basis for Norelia crypto derivatives site 2401",
    "evidence": "My prediction target is BTC futures-minus-spot basis for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC futures-minus-spot basis for Norelia crypto derivatives site 2401",
    "evidence": "My prediction target is BTC futures-minus-spot basis for Norelia crypto derivatives site 2401."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Read target values from field btc_basis_bp.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_basis_bp",
    "evidence": "Read target values from field btc_basis_bp."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Generate predictions in scheduled mode. The acceptable error threshold is {"maximum": 2, "metric": "mae"}. Include naive as the baseline comparison. The holdout window length is 7 hours. Use 4 historical backtest windows. Use rolling_origin validation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t3/inference_mode",
    "slot_id": "inference_mode",
    "status": "provided",
    "value": "scheduled",
    "evidence": "Generate predictions in scheduled mode."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t3/acceptable_error",
    "slot_id": "acceptable_error",
    "status": "provided",
    "value": {
      "maximum": 2,
      "metric": "mae"
    },
    "evidence": "The acceptable error threshold is {\"maximum\": 2, \"metric\": \"mae\"}."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t3/baseline_model",
    "slot_id": "baseline_model",
    "status": "provided",
    "value": "naive",
    "evidence": "Include naive as the baseline comparison."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t3/test_window",
    "slot_id": "test_window",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "The holdout window length is 7 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t3/backtest_folds",
    "slot_id": "backtest_folds",
    "status": "provided",
    "value": 4,
    "evidence": "Use 4 historical backtest windows."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t3/validation_strategy",
    "slot_id": "validation_strategy",
    "status": "provided",
    "value": "rolling_origin",
    "evidence": "Use rolling_origin validation."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The source contains confidential synthetic records. Deliver completed forecasts to https://planning.example/crypto_derivatives/2401. Serialize the results as csv. The maximum response time is 18 seconds. Schedule model retraining every 2 months. Produce new forecasts every 2 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t4/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t4/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/crypto_derivatives/2401",
    "evidence": "Deliver completed forecasts to https://planning.example/crypto_derivatives/2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t4/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Serialize the results as csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t4/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "second"
    },
    "evidence": "The maximum response time is 18 seconds."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t4/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Schedule model retraining every 2 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t4/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 2 days."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 17 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0016/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 17 hours."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r8-dev/crypto_derivatives/0017
Split: train

### t1 initial_multislot

Mujhe BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401 ka forecast chahiye. Target ki unit percent per 8 hours hai. Observations har 1 ghanta record hoti hain. Forecast aglay 4 ghantay tak chahiye. ETH perpetual-futures open interest nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401",
    "evidence": "Mujhe BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401",
    "evidence": "Mujhe BTC perpetual-swap funding rate per eight-hour funding interval for Norelia crypto derivatives site 2401 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per 8 hours",
    "evidence": "Target ki unit percent per 8 hours hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 4 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam btc_funding_pct hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_funding_pct",
    "evidence": "Target column ka naam btc_funding_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Source data catalog se select karein. Data source https://inputs.example/crypto_derivatives/2401 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2401",
    "evidence": "Data source https://inputs.example/crypto_derivatives/2401 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 7 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0017/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 7 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/crypto_derivatives/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/crypto_derivatives/2401. Select the source from the data catalog. I need the next 11 hours predicted. There is one observed data point every 1 hour. The target values are in contracts. The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2401",
    "evidence": "The source is https://inputs.example/crypto_derivatives/2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "I need the next 11 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "The target values are in contracts."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Norelia crypto derivatives site 2401",
    "evidence": "The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Norelia crypto derivatives site 2401",
    "evidence": "The quantity to predict is ETH perpetual-futures open interest for Norelia crypto derivatives site 2401."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field recorded_at. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains confidential synthetic records.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 14 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "I need the next 14 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/crypto_derivatives/0019
Split: train

### t1 initial_multislot

Here is what I need.  Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401. Keep the measurement unit as percent per year. The forecast horizon is 18 hours. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401",
    "evidence": "Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401",
    "evidence": "Please predict BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2401."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Keep the measurement unit as percent per year."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 18 hours."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. The native sampling interval is 1 hour. Run forecast generation once every 2 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target field name is btc_realized_vol. Use column recorded_at for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "The target field name is btc_realized_vol."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 21 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0019/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 21 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r8-dev/crypto_derivatives/0021
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. Mera source reference crypto_derivatives_archive_2402.csv hai. I will upload the data. 7 ghantay ka horizon rakhein. Source observations arrive every 1 hour. Target ko contracts mein measure karein. My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2402.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_derivatives_archive_2402.csv",
    "evidence": "Mera source reference crypto_derivatives_archive_2402.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "7 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "Target ko contracts mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Orven crypto derivatives site 2402",
    "evidence": "My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Orven crypto derivatives site 2402",
    "evidence": "My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2402."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Target values field eth_open_interest se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eth_open_interest",
    "evidence": "Target values field eth_open_interest se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Use one prediction row per hour as the output granularity. Source records har 4 ghantay update karein. Schedule model retraining every 1 month. Har 3 din naye forecasts banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Use one prediction row per hour as the output granularity."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source records har 4 ghantay update karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Schedule model retraining every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 10 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0021/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 10 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/crypto_derivatives/0025
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is crypto_derivatives_archive_2402.csv. I will upload the data. Predict a horizon of 18 hours. Source observations arrive every 1 hour. Use contracts as the target unit. My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2402.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_derivatives_archive_2402.csv",
    "evidence": "My source reference is crypto_derivatives_archive_2402.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 18 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "Use contracts as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Orven crypto derivatives site 2402",
    "evidence": "My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Orven crypto derivatives site 2402",
    "evidence": "My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2402."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field eth_open_interest.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eth_open_interest",
    "evidence": "Read target values from field eth_open_interest."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Use contracts as the target unit. Source observations arrive every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "Use contracts as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 21 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0025/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 21 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r8-dev/crypto_derivatives/0026
Split: train

### t1 initial_multislot

Mujhe BTC annualized realized volatility from past returns for Orven crypto derivatives site 2402 ka forecast chahiye. Target ki unit percent per year hai. Observations har 1 ghanta record hoti hain. Forecast aglay 8 ghantay tak chahiye. Main data upload karunga. Data source crypto_derivatives_archive_2402.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Orven crypto derivatives site 2402",
    "evidence": "Mujhe BTC annualized realized volatility from past returns for Orven crypto derivatives site 2402 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Orven crypto derivatives site 2402",
    "evidence": "Mujhe BTC annualized realized volatility from past returns for Orven crypto derivatives site 2402 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ki unit percent per year hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 8 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_derivatives_archive_2402.csv",
    "evidence": "Data source crypto_derivatives_archive_2402.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam btc_realized_vol hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "Target column ka naam btc_realized_vol hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

license ki requirement synthetic examples released under CC0-1.0; no provider data redistributed hai. Detailed data lineage required nahi hai. explainability level ki requirement feature_level hai. Modeling se pehle human approval required nahi hai. business goal ki requirement prepare a planning reserve for Orven crypto derivatives site 2402 hai. stakeholder role ki requirement derivatives research analyst hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t3/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "license ki requirement synthetic examples released under CC0-1.0; no provider data redistributed hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t3/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": false,
    "evidence": "Detailed data lineage required nahi hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t3/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "feature_level",
    "evidence": "explainability level ki requirement feature_level hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Modeling se pehle human approval required nahi hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven crypto derivatives site 2402",
    "evidence": "business goal ki requirement prepare a planning reserve for Orven crypto derivatives site 2402 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "derivatives research analyst",
    "evidence": "stakeholder role ki requirement derivatives research analyst hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

decision supported ki requirement set the contingency allowance for Orven crypto derivatives site 2402 hai. success criteria ki requirement MAE no more than 3 percent per year for Orven crypto derivatives site 2402 hai. target bounds ki requirement {"max": 1000000, "min": 0} hai. Negative target values allowed nahi hain. aggregation method ki requirement last hai. Aam calendar ke din use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t4/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Orven crypto derivatives site 2402",
    "evidence": "decision supported ki requirement set the contingency allowance for Orven crypto derivatives site 2402 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t4/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 3 percent per year for Orven crypto derivatives site 2402",
    "evidence": "success criteria ki requirement MAE no more than 3 percent per year for Orven crypto derivatives site 2402 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t4/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "target bounds ki requirement {\"max\": 1000000, \"min\": 0} hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "aggregation method ki requirement last hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Aam calendar ke din use karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 11 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0026/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 11 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

Nayi request: crypto derivatives ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/crypto_derivatives/0027
Split: train

### t1 initial_multislot

For my request,  I need the next 15 hours predicted. There is one observed data point every 1 hour. The target values are in basis points. The quantity to predict is BTC futures-minus-spot basis for Orven crypto derivatives site 2402. Do not substitute BTC perpetual-swap funding rate per eight-hour funding interval as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "I need the next 15 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "The target values are in basis points."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC futures-minus-spot basis for Orven crypto derivatives site 2402",
    "evidence": "The quantity to predict is BTC futures-minus-spot basis for Orven crypto derivatives site 2402."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC futures-minus-spot basis for Orven crypto derivatives site 2402",
    "evidence": "The quantity to predict is BTC futures-minus-spot basis for Orven crypto derivatives site 2402."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Use column btc_basis_bp as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_basis_bp",
    "evidence": "Use column btc_basis_bp as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is csv. The source is crypto_derivatives_archive_2402.csv. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_derivatives_archive_2402.csv",
    "evidence": "The source is crypto_derivatives_archive_2402.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 18 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0027/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "I need the next 18 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r8-dev/crypto_derivatives/0033
Split: train

### t1 initial_multislot

Here is what I need.  Please predict BTC annualized realized volatility from past returns for Pelmar crypto derivatives site 2403. Measurement unit percent per year rakhein. The native sampling interval is 1 hour. Forecast horizon 15 ghantay hai. Access the input through an API. Observations https://inputs.example/crypto_derivatives/2403 se lein. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Pelmar crypto derivatives site 2403",
    "evidence": "Please predict BTC annualized realized volatility from past returns for Pelmar crypto derivatives site 2403."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Pelmar crypto derivatives site 2403",
    "evidence": "Please predict BTC annualized realized volatility from past returns for Pelmar crypto derivatives site 2403."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Measurement unit percent per year rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 15 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2403",
    "evidence": "Observations https://inputs.example/crypto_derivatives/2403 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Interpret timestamps using Europe/London. Repeating seasonal pattern expect nahi karta. The requested forecast output type is probabilistic. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Interpret timestamps using Europe/London."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target field name is btc_realized_vol. Timestamps ke liye column observed_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "The target field name is btc_realized_vol."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamps ke liye column observed_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 18 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0033/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 18 hours."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r8-dev/crypto_derivatives/0035
Split: train

### t1 initial_multislot

Mujhe BTC perpetual-swap funding rate per eight-hour funding interval for Pelmar crypto derivatives site 2403 ka forecast chahiye. Target ki unit percent per 8 hours hai. Observations har 1 ghanta record hoti hain. Forecast aglay 12 ghantay tak chahiye. Input API ke zariye lein. Data source https://inputs.example/crypto_derivatives/2403 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC perpetual-swap funding rate per eight-hour funding interval for Pelmar crypto derivatives site 2403",
    "evidence": "Mujhe BTC perpetual-swap funding rate per eight-hour funding interval for Pelmar crypto derivatives site 2403 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC perpetual-swap funding rate per eight-hour funding interval for Pelmar crypto derivatives site 2403",
    "evidence": "Mujhe BTC perpetual-swap funding rate per eight-hour funding interval for Pelmar crypto derivatives site 2403 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per 8 hours",
    "evidence": "Target ki unit percent per 8 hours hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 12 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2403",
    "evidence": "Data source https://inputs.example/crypto_derivatives/2403 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam btc_funding_pct hai. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_funding_pct",
    "evidence": "Target column ka naam btc_funding_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Observations har 1 ghanta record hoti hain. Target ki unit percent per 8 hours hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per 8 hours",
    "evidence": "Target ki unit percent per 8 hours hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 15 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0035/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 15 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r8-dev/crypto_derivatives/0048
Split: train

### t1 initial_multislot

Mujhe BTC annualized realized volatility from past returns for Talven crypto derivatives site 2404 ka forecast chahiye. Target ki unit percent per year hai. Observations har 1 ghanta record hoti hain. Forecast aglay 10 ghantay tak chahiye. Input database se read karein. Data source https://inputs.example/crypto_derivatives/2404 use karein. Input file format json hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Talven crypto derivatives site 2404",
    "evidence": "Mujhe BTC annualized realized volatility from past returns for Talven crypto derivatives site 2404 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Talven crypto derivatives site 2404",
    "evidence": "Mujhe BTC annualized realized volatility from past returns for Talven crypto derivatives site 2404 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ki unit percent per year hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 10 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2404",
    "evidence": "Data source https://inputs.example/crypto_derivatives/2404 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input file format json hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein personal ya confidential data nahi hai. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 13 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0048/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 13 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: crypto derivatives ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/crypto_derivatives/0051
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target BTC annualized realized volatility from past returns for Virelo crypto derivatives site 2405 hai. Measurement unit percent per year rakhein. Asli data ka sampling interval 1 ghanta hai. Forecast horizon 6 ghantay hai. Source data catalog se select karein. Observations https://inputs.example/crypto_derivatives/2405 se lein. Input ko xlsx ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Virelo crypto derivatives site 2405",
    "evidence": "Prediction ka target BTC annualized realized volatility from past returns for Virelo crypto derivatives site 2405 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Virelo crypto derivatives site 2405",
    "evidence": "Prediction ka target BTC annualized realized volatility from past returns for Virelo crypto derivatives site 2405 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Measurement unit percent per year rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 1 ghanta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 6 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2405",
    "evidence": "Observations https://inputs.example/crypto_derivatives/2405 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input ko xlsx ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field btc_realized_vol hai. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "Target field btc_realized_vol hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Forecast generation har 3 din run karein. Training har 2 mahinay repeat karein. Input source refresh schedule har 3 ghantay hai. Result granularity one prediction row per hour banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Forecast generation har 3 din run karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training har 2 mahinay repeat karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "Input source refresh schedule har 3 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Result granularity one prediction row per hour banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 9 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0051/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 9 ghantay hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r8-dev/crypto_derivatives/0054
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. Source https://inputs.example/crypto_derivatives/2405 hai. Select the source from the data catalog. Aglay 10 ghantay predict karein. There is one observed data point every 1 hour. Target values contracts mein hain. The quantity to predict is ETH perpetual-futures open interest for Virelo crypto derivatives site 2405.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2405",
    "evidence": "Source https://inputs.example/crypto_derivatives/2405 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Aglay 10 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "Target values contracts mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Virelo crypto derivatives site 2405",
    "evidence": "The quantity to predict is ETH perpetual-futures open interest for Virelo crypto derivatives site 2405."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Virelo crypto derivatives site 2405",
    "evidence": "The quantity to predict is ETH perpetual-futures open interest for Virelo crypto derivatives site 2405."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. I need the next 10 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. I need the next 10 hours predicted."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 13 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "I need the next 13 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. I need the next 13 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0054/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. I need the next 13 hours predicted."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r8-dev/crypto_derivatives/0067
Split: train

### t1 initial_multislot

For my request,  I need the next 8 hours predicted. Har 1 ghanta aik observed data point milta hai. The target values are in basis points. BTC futures-minus-spot basis for Weslin crypto derivatives site 2406 predict karna hai. Do not substitute BTC perpetual-swap funding rate per eight-hour funding interval as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "I need the next 8 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "basis points",
    "evidence": "The target values are in basis points."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC futures-minus-spot basis for Weslin crypto derivatives site 2406",
    "evidence": "BTC futures-minus-spot basis for Weslin crypto derivatives site 2406 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC futures-minus-spot basis for Weslin crypto derivatives site 2406",
    "evidence": "BTC futures-minus-spot basis for Weslin crypto derivatives site 2406 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Column btc_basis_bp ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_basis_bp",
    "evidence": "Column btc_basis_bp ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is csv. Source crypto_derivatives_archive_2406.csv hai. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_derivatives_archive_2406.csv",
    "evidence": "Source crypto_derivatives_archive_2406.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 11 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0067/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "I need the next 11 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/crypto_derivatives/0072
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for ETH perpetual-futures open interest for Yarven crypto derivatives site 2407. Target measurements ki unit contracts hai. Each observed record covers 1 hour. Future coverage 18 ghantay chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/crypto_derivatives/2407 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Yarven crypto derivatives site 2407",
    "evidence": "We need an outlook for ETH perpetual-futures open interest for Yarven crypto derivatives site 2407."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Yarven crypto derivatives site 2407",
    "evidence": "We need an outlook for ETH perpetual-futures open interest for Yarven crypto derivatives site 2407."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "Target measurements ki unit contracts hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "Future coverage 18 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2407",
    "evidence": "Diya hua source identifier https://inputs.example/crypto_derivatives/2407 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column eth_open_interest. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eth_open_interest",
    "evidence": "The response variable is stored in column eth_open_interest."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 21 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 21 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. Each observed record covers 2 hours. Diya hua source identifier https://revised.example/crypto_derivatives/72 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0072/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/crypto_derivatives/72",
    "evidence": "Diya hua source identifier https://revised.example/crypto_derivatives/72 hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r8-dev/crypto_derivatives/0086
Split: train

### t1 initial_multislot

Here is what I need.  Please predict BTC perpetual-swap funding rate per eight-hour funding interval for Merlow crypto derivatives site 2408. Measurement unit percent per 8 hours rakhein. The native sampling interval is 1 hour. Forecast horizon 6 ghantay hai. Read the input from a database. Observations https://inputs.example/crypto_derivatives/2408 se lein. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC perpetual-swap funding rate per eight-hour funding interval for Merlow crypto derivatives site 2408",
    "evidence": "Please predict BTC perpetual-swap funding rate per eight-hour funding interval for Merlow crypto derivatives site 2408."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC perpetual-swap funding rate per eight-hour funding interval for Merlow crypto derivatives site 2408",
    "evidence": "Please predict BTC perpetual-swap funding rate per eight-hour funding interval for Merlow crypto derivatives site 2408."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per 8 hours",
    "evidence": "Measurement unit percent per 8 hours rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 6 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2408",
    "evidence": "Observations https://inputs.example/crypto_derivatives/2408 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is btc_funding_pct. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_funding_pct",
    "evidence": "The target field name is btc_funding_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The lead time is 1 hour. dataset type ki requirement hierarchical hai. Each series is identified by the columns site_id. hierarchy columns ki requirement region_id, site_id hai. Return results at the level site. scope filters ki requirement [{"column": "site_id", "operator": "eq", "value": "Merlow crypto derivatives site 2408"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t3/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The lead time is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t3/dataset_type",
    "slot_id": "dataset_type",
    "status": "provided",
    "value": "hierarchical",
    "evidence": "dataset type ki requirement hierarchical hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t3/series_id_columns",
    "slot_id": "series_id_columns",
    "status": "provided",
    "value": [
      "site_id"
    ],
    "evidence": "Each series is identified by the columns site_id."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t3/hierarchy_columns",
    "slot_id": "hierarchy_columns",
    "status": "provided",
    "value": [
      "region_id",
      "site_id"
    ],
    "evidence": "hierarchy columns ki requirement region_id, site_id hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t3/aggregation_level",
    "slot_id": "aggregation_level",
    "status": "provided",
    "value": "site",
    "evidence": "Return results at the level site."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t3/scope_filters",
    "slot_id": "scope_filters",
    "status": "provided",
    "value": [
      {
        "column": "site_id",
        "operator": "eq",
        "value": "Merlow crypto derivatives site 2408"
      }
    ],
    "evidence": "scope filters ki requirement [{\"column\": \"site_id\", \"operator\": \"eq\", \"value\": \"Merlow crypto derivatives site 2408\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Include only these fictional areas: Fictional Merlow crypto derivatives site 2408 region. source provider ki requirement Synthetic Economic Research Laboratory hai. Read the worksheet or resource named crypto_derivatives_observations. Input source refresh schedule har 2 ghantay hai. The historical observations begin at 2020-01-01T00:00:00+00:00. history end ki requirement 2026-09-30T00:00:00+00:00 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t4/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Merlow crypto derivatives site 2408 region"
    ],
    "evidence": "Include only these fictional areas: Fictional Merlow crypto derivatives site 2408 region."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t4/source_provider",
    "slot_id": "source_provider",
    "status": "provided",
    "value": "Synthetic Economic Research Laboratory",
    "evidence": "source provider ki requirement Synthetic Economic Research Laboratory hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t4/sheet_or_table",
    "slot_id": "sheet_or_table",
    "status": "provided",
    "value": "crypto_derivatives_observations",
    "evidence": "Read the worksheet or resource named crypto_derivatives_observations."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t4/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Input source refresh schedule har 2 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t4/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "The historical observations begin at 2020-01-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t4/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "history end ki requirement 2026-09-30T00:00:00+00:00 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 9 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0086/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 9 hours."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/crypto_derivatives/0099
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2409 hai. Measurement unit percent per year rakhein. Forecast horizon 4 ghantay hai. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2409",
    "evidence": "Prediction ka target BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2409 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2409",
    "evidence": "Prediction ka target BTC annualized realized volatility from past returns for Norelia crypto derivatives site 2409 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Measurement unit percent per year rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 4 ghantay hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Asli data ka sampling interval 1 ghanta hai. Forecast generation har 1 din run karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 1 ghanta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Forecast generation har 1 din run karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Target field btc_realized_vol hai. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "Target field btc_realized_vol hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 7 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0099/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 7 ghantay hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r8-dev/crypto_derivatives/0102
Split: train

### t1 initial_multislot

Mujhe BTC annualized realized volatility from past returns for Orven crypto derivatives site 2410 ka forecast chahiye. Target ki unit percent per year hai. Observations har 1 ghanta record hoti hain. Forecast aglay 17 ghantay tak chahiye. Main data upload karunga. Data source crypto_derivatives_archive_2410.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Orven crypto derivatives site 2410",
    "evidence": "Mujhe BTC annualized realized volatility from past returns for Orven crypto derivatives site 2410 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Orven crypto derivatives site 2410",
    "evidence": "Mujhe BTC annualized realized volatility from past returns for Orven crypto derivatives site 2410 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Target ki unit percent per year hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 17 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_derivatives_archive_2410.csv",
    "evidence": "Data source crypto_derivatives_archive_2410.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam btc_realized_vol hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "Target column ka naam btc_realized_vol hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 20 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 20 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Observations har 2 ghantay record hoti hain. Data source https://revised.example/crypto_derivatives/102 use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Observations har 2 ghantay record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0102/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/crypto_derivatives/102",
    "evidence": "Data source https://revised.example/crypto_derivatives/102 use karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/crypto_derivatives/0109
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 15 hours. Target ko contracts mein measure karein. My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2410. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 15 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "contracts",
    "evidence": "Target ko contracts mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Orven crypto derivatives site 2410",
    "evidence": "My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2410."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH perpetual-futures open interest for Orven crypto derivatives site 2410",
    "evidence": "My prediction target is ETH perpetual-futures open interest for Orven crypto derivatives site 2410."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Produce new forecasts every 2 days. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The time field name is sample_date. Target values field eth_open_interest se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eth_open_interest",
    "evidence": "Target values field eth_open_interest se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 18 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0109/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 18 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r8-dev/crypto_derivatives/0153
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target BTC annualized realized volatility from past returns for Yarven crypto derivatives site 2415 hai. Measurement unit percent per year rakhein. Asli data ka sampling interval 1 ghanta hai. Forecast horizon 11 ghantay hai. Input API ke zariye lein. Observations https://inputs.example/crypto_derivatives/2415 se lein. Input ko parquet ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Yarven crypto derivatives site 2415",
    "evidence": "Prediction ka target BTC annualized realized volatility from past returns for Yarven crypto derivatives site 2415 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC annualized realized volatility from past returns for Yarven crypto derivatives site 2415",
    "evidence": "Prediction ka target BTC annualized realized volatility from past returns for Yarven crypto derivatives site 2415 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent per year",
    "evidence": "Measurement unit percent per year rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 1 ghanta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 11 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_derivatives/2415",
    "evidence": "Observations https://inputs.example/crypto_derivatives/2415 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input ko parquet ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Timestamps ko Europe/London ke mutabiq samjhein. Repeating seasonal pattern expect nahi karta. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Timestamps ko Europe/London ke mutabiq samjhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Target field btc_realized_vol hai. Timestamps ke liye column observed_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_realized_vol",
    "evidence": "Target field btc_realized_vol hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamps ke liye column observed_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 14 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/crypto_derivatives/0153/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 14 ghantay hai."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending
