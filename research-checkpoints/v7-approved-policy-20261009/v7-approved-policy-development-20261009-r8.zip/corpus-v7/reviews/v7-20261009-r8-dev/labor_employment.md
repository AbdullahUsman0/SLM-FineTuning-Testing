# V7 review examples for labor_employment

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r8-dev/labor_employment/0000
Split: train

### t1 initial_multislot

I need forecasts of unemployment rate for Merlow labor employment site 1800. Measure the target in percent of labor force. The observations are recorded every 1 month. The forecast should extend 11 months ahead. I will upload the data. Use the data source labor_employment_archive_1800.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "unemployment rate for Merlow labor employment site 1800",
    "evidence": "I need forecasts of unemployment rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "unemployment rate for Merlow labor employment site 1800",
    "evidence": "I need forecasts of unemployment rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of labor force",
    "evidence": "Measure the target in percent of labor force."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "The forecast should extend 11 months ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "Use the data source labor_employment_archive_1800.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called unemployment_pct. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "unemployment_pct",
    "evidence": "The target column is called unemployment_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 14 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "The forecast should extend 14 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow labor employment site 1800.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow labor employment site 1800",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow labor employment site 1800."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/labor_employment/0001
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source labor_employment_archive_1800.csv hai. Main data upload karunga. Aglay 18 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values thousands of jobs mein hain. payroll employment change for Merlow labor employment site 1800 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "Source labor_employment_archive_1800.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Aglay 18 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of jobs",
    "evidence": "Target values thousands of jobs mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "payroll employment change for Merlow labor employment site 1800",
    "evidence": "payroll employment change for Merlow labor employment site 1800 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "payroll employment change for Merlow labor employment site 1800",
    "evidence": "payroll employment change for Merlow labor employment site 1800 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field sample_date mein hain. Column payroll_change ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates field sample_date mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "payroll_change",
    "evidence": "Column payroll_change ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Forecast resolution one prediction row per month rakhein. Har 2 ghantay naya source update lein. Forecasting model har 1 mahina refit karein. Predictions har 1 din refresh karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Forecast resolution one prediction row per month rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghantay naya source update lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Forecasting model har 1 mahina refit karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Predictions har 1 din refresh karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 21 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "Aglay 21 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/labor_employment/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict labor force participation rate for Merlow labor employment site 1800. Keep the measurement unit as percent of working-age population. The native sampling interval is 1 month. The forecast horizon is 8 months. I will upload the data. Read the observations from labor_employment_archive_1800.csv. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Merlow labor employment site 1800",
    "evidence": "Please predict labor force participation rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Merlow labor employment site 1800",
    "evidence": "Please predict labor force participation rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Keep the measurement unit as percent of working-age population."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 8 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "Read the observations from labor_employment_archive_1800.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is participation_pct. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "participation_pct",
    "evidence": "The target field name is participation_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 11 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 11 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 months. Read the observations from https://revised.example/labor_employment/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 2 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/labor_employment/2",
    "evidence": "Read the observations from https://revised.example/labor_employment/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/labor_employment/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. My source reference is labor_employment_archive_1800.csv. I will upload the data. Predict a horizon of 15 months. Source observations arrive every 1 month. Use percent year over year as the target unit. My prediction target is average hourly earnings growth for Merlow labor employment site 1800.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "My source reference is labor_employment_archive_1800.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 15 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Use percent year over year as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "average hourly earnings growth for Merlow labor employment site 1800",
    "evidence": "My prediction target is average hourly earnings growth for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "average hourly earnings growth for Merlow labor employment site 1800",
    "evidence": "My prediction target is average hourly earnings growth for Merlow labor employment site 1800."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. The seasonal cycles in observation periods are 12. I expect a repeating seasonal pattern. Use timezone Europe/London.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      12
    ],
    "evidence": "The seasonal cycles in observation periods are 12."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Use timezone Europe/London."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is sample_date. Read target values from field earnings_growth.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "earnings_growth",
    "evidence": "Read target values from field earnings_growth."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 18 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 18 months."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/labor_employment/0004
Split: train

### t1 initial_multislot

I need forecasts of unemployment rate for Merlow labor employment site 1800. Measure the target in percent of labor force. The observations are recorded every 1 month. The forecast should extend 5 months ahead. I will upload the data. Use the data source labor_employment_archive_1800.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "unemployment rate for Merlow labor employment site 1800",
    "evidence": "I need forecasts of unemployment rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "unemployment rate for Merlow labor employment site 1800",
    "evidence": "I need forecasts of unemployment rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of labor force",
    "evidence": "Measure the target in percent of labor force."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "The forecast should extend 5 months ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "Use the data source labor_employment_archive_1800.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 5 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 5 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 8 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "The forecast should extend 8 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 8 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 8 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/labor_employment/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. Source labor_employment_archive_1800.csv hai. I will upload the data. Aglay 12 mahinay predict karein. There is one observed data point every 1 month. Target values thousands of jobs mein hain. The quantity to predict is payroll employment change for Merlow labor employment site 1800.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "Source labor_employment_archive_1800.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Aglay 12 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of jobs",
    "evidence": "Target values thousands of jobs mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "payroll employment change for Merlow labor employment site 1800",
    "evidence": "The quantity to predict is payroll employment change for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "payroll employment change for Merlow labor employment site 1800",
    "evidence": "The quantity to predict is payroll employment change for Merlow labor employment site 1800."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Column payroll_change ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "payroll_change",
    "evidence": "Column payroll_change ko target rakhein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in thousands of jobs. Har 1 mahina aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of jobs",
    "evidence": "The target values are in thousands of jobs."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 15 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "I need the next 15 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/labor_employment/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict labor force participation rate for Merlow labor employment site 1800. Keep the measurement unit as percent of working-age population. The native sampling interval is 1 month. The forecast horizon is 19 months. I will upload the data. Read the observations from labor_employment_archive_1800.csv. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Merlow labor employment site 1800",
    "evidence": "Please predict labor force participation rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Merlow labor employment site 1800",
    "evidence": "Please predict labor force participation rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Keep the measurement unit as percent of working-age population."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 19 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "Read the observations from labor_employment_archive_1800.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is participation_pct. Use column sample_date for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "participation_pct",
    "evidence": "The target field name is participation_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Use column sample_date for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Serialize the results as json. Deliver completed forecasts to https://planning.example/labor_employment/1800. The source contains no personal, confidential, or regulated data. Enforce these privacy restrictions: synthetic data only, no external redistribution. The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed. Detailed data lineage is not required.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t3/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "json",
    "evidence": "Serialize the results as json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t3/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/labor_employment/1800",
    "evidence": "Deliver completed forecasts to https://planning.example/labor_employment/1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t3/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "Enforce these privacy restrictions: synthetic data only, no external redistribution."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t3/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t3/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": false,
    "evidence": "Detailed data lineage is not required."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The required explanation level is feature_level. Human approval before modeling is not required. Our operational goal is to prepare a planning reserve for Merlow labor employment site 1800. My role in this project is labor market analyst. This forecast will inform the decision to set the contingency allowance for Merlow labor employment site 1800. I will consider the result useful if it meets MAE no more than 1 percent of working-age population for Merlow labor employment site 1800.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t4/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "feature_level",
    "evidence": "The required explanation level is feature_level."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t4/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Human approval before modeling is not required."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow labor employment site 1800",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t4/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "labor market analyst",
    "evidence": "My role in this project is labor market analyst."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t4/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Merlow labor employment site 1800",
    "evidence": "This forecast will inform the decision to set the contingency allowance for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t4/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 1 percent of working-age population for Merlow labor employment site 1800",
    "evidence": "I will consider the result useful if it meets MAE no more than 1 percent of working-age population for Merlow labor employment site 1800."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 22 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 22 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/labor_employment/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 9 months. Source observations arrive every 1 month. Use percent year over year as the target unit. My prediction target is average hourly earnings growth for Merlow labor employment site 1800. Do not substitute unemployment rate as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 9 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Use percent year over year as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "average hourly earnings growth for Merlow labor employment site 1800",
    "evidence": "My prediction target is average hourly earnings growth for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "average hourly earnings growth for Merlow labor employment site 1800",
    "evidence": "My prediction target is average hourly earnings growth for Merlow labor employment site 1800."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Read target values from field earnings_growth.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "earnings_growth",
    "evidence": "Read target values from field earnings_growth."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is csv. My source reference is labor_employment_archive_1800.csv. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "My source reference is labor_employment_archive_1800.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 12 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 12 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/labor_employment/0008
Split: train

### t1 initial_multislot

I need forecasts of unemployment rate for Merlow labor employment site 1800. Measure the target in percent of labor force. The observations are recorded every 1 month. The forecast should extend 16 months ahead. I will upload the data. Use the data source labor_employment_archive_1800.csv. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "unemployment rate for Merlow labor employment site 1800",
    "evidence": "I need forecasts of unemployment rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "unemployment rate for Merlow labor employment site 1800",
    "evidence": "I need forecasts of unemployment rate for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of labor force",
    "evidence": "Measure the target in percent of labor force."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "The forecast should extend 16 months ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1800.csv",
    "evidence": "Use the data source labor_employment_archive_1800.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is sample_date.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The timestamp column is sample_date."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 19 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast should extend 19 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of labor employment. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/labor_employment/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 6 months predicted. The target values are in thousands of jobs. The quantity to predict is payroll employment change for Merlow labor employment site 1800. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "I need the next 6 months predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of jobs",
    "evidence": "The target values are in thousands of jobs."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "payroll employment change for Merlow labor employment site 1800",
    "evidence": "The quantity to predict is payroll employment change for Merlow labor employment site 1800."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "payroll employment change for Merlow labor employment site 1800",
    "evidence": "The quantity to predict is payroll employment change for Merlow labor employment site 1800."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field sample_date. Use column payroll_change as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "payroll_change",
    "evidence": "Use column payroll_change as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 9 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "I need the next 9 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r8-dev/labor_employment/0021
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. Mera source reference https://inputs.example/labor_employment/1802 hai. Read the input from a database. 6 mahinay ka horizon rakhein. Source observations arrive every 1 month. Target ko percent year over year mein measure karein. My prediction target is average hourly earnings growth for Orven labor employment site 1802.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1802",
    "evidence": "Mera source reference https://inputs.example/labor_employment/1802 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "month"
    },
    "evidence": "6 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Target ko percent year over year mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "average hourly earnings growth for Orven labor employment site 1802",
    "evidence": "My prediction target is average hourly earnings growth for Orven labor employment site 1802."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "average hourly earnings growth for Orven labor employment site 1802",
    "evidence": "My prediction target is average hourly earnings growth for Orven labor employment site 1802."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Target values field earnings_growth se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "earnings_growth",
    "evidence": "Target values field earnings_growth se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Use one prediction row per month as the output granularity. Source records har 4 ghantay update karein. Schedule model retraining every 1 month. Har 3 din naye forecasts banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Use one prediction row per month as the output granularity."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source records har 4 ghantay update karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Schedule model retraining every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 9 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0021/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 9 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/labor_employment/0025
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. My source reference is https://inputs.example/labor_employment/1802. Read the input from a database. Predict a horizon of 17 months. Source observations arrive every 1 month. Use percent year over year as the target unit. My prediction target is average hourly earnings growth for Orven labor employment site 1802.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1802",
    "evidence": "My source reference is https://inputs.example/labor_employment/1802."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 17 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Use percent year over year as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "average hourly earnings growth for Orven labor employment site 1802",
    "evidence": "My prediction target is average hourly earnings growth for Orven labor employment site 1802."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "average hourly earnings growth for Orven labor employment site 1802",
    "evidence": "My prediction target is average hourly earnings growth for Orven labor employment site 1802."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Read target values from field earnings_growth.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "earnings_growth",
    "evidence": "Read target values from field earnings_growth."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Use percent year over year as the target unit. Source observations arrive every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Use percent year over year as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 20 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0025/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 20 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r8-dev/labor_employment/0028
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target labor force participation rate for Orven labor employment site 1802 hai. Measurement unit percent of working-age population rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 4 mahinay hai. Input database se read karein. Observations https://inputs.example/labor_employment/1802 se lein. Input ko json ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Orven labor employment site 1802",
    "evidence": "Prediction ka target labor force participation rate for Orven labor employment site 1802 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Orven labor employment site 1802",
    "evidence": "Prediction ka target labor force participation rate for Orven labor employment site 1802 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Measurement unit percent of working-age population rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "Forecast horizon 4 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1802",
    "evidence": "Observations https://inputs.example/labor_employment/1802 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input ko json ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target field inflation (%) hai. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "inflation (%)",
    "evidence": "Target field inflation (%) hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein personal ya confidential data nahi hai. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 7 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0028/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "Forecast horizon 7 mahinay hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/labor_employment/0031
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for labor force participation rate for Pelmar labor employment site 1803. Target measurements use percent of working-age population. Each observed record covers 1 month. The requested future coverage is 17 months. Select the source from the data catalog. The supplied source identifier is https://inputs.example/labor_employment/1803. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Pelmar labor employment site 1803",
    "evidence": "We need an outlook for labor force participation rate for Pelmar labor employment site 1803."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Pelmar labor employment site 1803",
    "evidence": "We need an outlook for labor force participation rate for Pelmar labor employment site 1803."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Target measurements use percent of working-age population."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 17 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1803",
    "evidence": "The supplied source identifier is https://inputs.example/labor_employment/1803."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column participation_pct. The input timestamp identifier is recorded_at.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "participation_pct",
    "evidence": "The response variable is stored in column participation_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The input timestamp identifier is recorded_at."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

New forecasts must be issued every 1 day. Re-estimate the model every 2 months. Source ingestion repeats every 5 hours. The requested prediction row resolution is one prediction row per month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "New forecasts must be issued every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Re-estimate the model every 2 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Source ingestion repeats every 5 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "The requested prediction row resolution is one prediction row per month."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 20 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0031/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 20 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of labor employment. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r8-dev/labor_employment/0036
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for average hourly earnings growth for Pelmar labor employment site 1803. Target measurements ki unit percent year over year hai. Each observed record covers 1 month. Future coverage 18 mahinay chahiye. Select the source from the data catalog. Diya hua source identifier https://inputs.example/labor_employment/1803 hai. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "average hourly earnings growth for Pelmar labor employment site 1803",
    "evidence": "We need an outlook for average hourly earnings growth for Pelmar labor employment site 1803."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "average hourly earnings growth for Pelmar labor employment site 1803",
    "evidence": "We need an outlook for average hourly earnings growth for Pelmar labor employment site 1803."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Target measurements ki unit percent year over year hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Future coverage 18 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1803",
    "evidence": "Diya hua source identifier https://inputs.example/labor_employment/1803 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column earnings_growth. Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "earnings_growth",
    "evidence": "The response variable is stored in column earnings_growth."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

I expect a repeating seasonal pattern. Weekends aur non-business days exclude na karein. Use these fictional holiday calendars: synthetic reporting holiday. special events ki requirement [{"date": "2026-10-05", "name": "synthetic scheduled data release"}] hai. These regressors are observed only through the cutoff: lagged_target. known future covariates ki requirement announced_calendar_event hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t3/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Weekends aur non-business days exclude na karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t3/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "Use these fictional holiday calendars: synthetic reporting holiday."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t3/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "special events ki requirement [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t3/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "These regressors are observed only through the cutoff: lagged_target."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t3/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "known future covariates ki requirement announced_calendar_event hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The fixed attributes of each series are scope_sector. covariate availability ki requirement [{"available": "announced before cutoff", "name": "announced_calendar_event"}] hai. The external regressor source mappings are [{"name": "announced_calendar_event", "source": "synthetic_calendar"}]. forecast type ki requirement probabilistic hai. Return forecast quantiles at probabilities 0.1, 0.5, 0.9. scenario forecasts ki requirement [{"description": "synthetic planning sensitivity", "name": "stress"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t4/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_sector"
    ],
    "evidence": "The fixed attributes of each series are scope_sector."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t4/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "covariate availability ki requirement [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t4/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "The external regressor source mappings are [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t4/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t4/quantiles",
    "slot_id": "quantiles",
    "status": "provided",
    "value": [
      0.1,
      0.5,
      0.9
    ],
    "evidence": "Return forecast quantiles at probabilities 0.1, 0.5, 0.9."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t4/scenario_forecasts",
    "slot_id": "scenario_forecasts",
    "status": "provided",
    "value": [
      {
        "description": "synthetic planning sensitivity",
        "name": "stress"
      }
    ],
    "evidence": "scenario forecasts ki requirement [{\"description\": \"synthetic planning sensitivity\", \"name\": \"stress\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 21 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0036/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 21 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r8-dev/labor_employment/0046
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target labor force participation rate for Talven labor employment site 1804 hai. Measurement unit percent of working-age population rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 12 mahinay hai. Main data upload karunga. Observations labor_employment_archive_1804.csv se lein. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Talven labor employment site 1804",
    "evidence": "Prediction ka target labor force participation rate for Talven labor employment site 1804 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Talven labor employment site 1804",
    "evidence": "Prediction ka target labor force participation rate for Talven labor employment site 1804 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Measurement unit percent of working-age population rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast horizon 12 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1804.csv",
    "evidence": "Observations labor_employment_archive_1804.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field participation_pct hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "participation_pct",
    "evidence": "Target field participation_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Result granularity one prediction row per month banayein. primary metric ki requirement mase hai. secondary metrics ki requirement rmse, smape hai. validation strategy ki requirement rolling_origin hai. backtest folds ki requirement 4 hai. holdout window length 3 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Result granularity one prediction row per month banayein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t3/primary_metric",
    "slot_id": "primary_metric",
    "status": "provided",
    "value": "mase",
    "evidence": "primary metric ki requirement mase hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t3/secondary_metrics",
    "slot_id": "secondary_metrics",
    "status": "provided",
    "value": [
      "rmse",
      "smape"
    ],
    "evidence": "secondary metrics ki requirement rmse, smape hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t3/validation_strategy",
    "slot_id": "validation_strategy",
    "status": "provided",
    "value": "rolling_origin",
    "evidence": "validation strategy ki requirement rolling_origin hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t3/backtest_folds",
    "slot_id": "backtest_folds",
    "status": "provided",
    "value": 4,
    "evidence": "backtest folds ki requirement 4 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t3/test_window",
    "slot_id": "test_window",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "month"
    },
    "evidence": "holdout window length 3 mahinay hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

baseline model ki requirement naive hai. acceptable error ki requirement {"maximum": 5, "metric": "mae"} hai. inference mode ki requirement scheduled hai. Forecast generation har 2 din run karein. Training har 1 mahina repeat karein. maximum response time 23 second hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t4/baseline_model",
    "slot_id": "baseline_model",
    "status": "provided",
    "value": "naive",
    "evidence": "baseline model ki requirement naive hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t4/acceptable_error",
    "slot_id": "acceptable_error",
    "status": "provided",
    "value": {
      "maximum": 5,
      "metric": "mae"
    },
    "evidence": "acceptable error ki requirement {\"maximum\": 5, \"metric\": \"mae\"} hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t4/inference_mode",
    "slot_id": "inference_mode",
    "status": "provided",
    "value": "scheduled",
    "evidence": "inference mode ki requirement scheduled hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t4/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Forecast generation har 2 din run karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t4/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Training har 1 mahina repeat karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t4/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "second"
    },
    "evidence": "maximum response time 23 second hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 15 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0046/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Forecast horizon 15 mahinay hai."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r8-dev/labor_employment/0054
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for average hourly earnings growth for Virelo labor employment site 1805. Target measurements ki unit percent year over year hai. Each observed record covers 1 month. Future coverage 9 mahinay chahiye. Access the input through an API. Diya hua source identifier https://inputs.example/labor_employment/1805 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "average hourly earnings growth for Virelo labor employment site 1805",
    "evidence": "We need an outlook for average hourly earnings growth for Virelo labor employment site 1805."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "average hourly earnings growth for Virelo labor employment site 1805",
    "evidence": "We need an outlook for average hourly earnings growth for Virelo labor employment site 1805."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent year over year",
    "evidence": "Target measurements ki unit percent year over year hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Future coverage 9 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1805",
    "evidence": "Diya hua source identifier https://inputs.example/labor_employment/1805 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The requested future coverage is 9 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The requested future coverage is 9 months."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 12 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 12 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The requested future coverage is 12 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0054/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The requested future coverage is 12 months."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r8-dev/labor_employment/0060
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target labor force participation rate for Weslin labor employment site 1806 hai. Measurement unit percent of working-age population rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 9 mahinay hai. Observations labor_employment_archive_1806.unknown se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Weslin labor employment site 1806",
    "evidence": "Prediction ka target labor force participation rate for Weslin labor employment site 1806 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Weslin labor employment site 1806",
    "evidence": "Prediction ka target labor force participation rate for Weslin labor employment site 1806 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Measurement unit percent of working-age population rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Forecast horizon 9 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1806.unknown",
    "evidence": "Observations labor_employment_archive_1806.unknown se lein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field participation_pct hai. Timestamps ke liye column measurement_time use karein. Input database se read karein. Input ko json ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "participation_pct",
    "evidence": "Target field participation_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input ko json ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 12 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast horizon 12 mahinay hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Weslin labor employment site 1806 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0060/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Weslin labor employment site 1806",
    "evidence": "business goal ki requirement prepare a planning reserve for Weslin labor employment site 1806 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r8-dev/labor_employment/0063
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. Source https://inputs.example/labor_employment/1806 hai. Read the input from a database. Aglay 13 mahinay predict karein. There is one observed data point every 1 month. Target values thousands of jobs mein hain. The quantity to predict is payroll employment change for Weslin labor employment site 1806.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1806",
    "evidence": "Source https://inputs.example/labor_employment/1806 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Aglay 13 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of jobs",
    "evidence": "Target values thousands of jobs mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "payroll employment change for Weslin labor employment site 1806",
    "evidence": "The quantity to predict is payroll employment change for Weslin labor employment site 1806."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "payroll employment change for Weslin labor employment site 1806",
    "evidence": "The quantity to predict is payroll employment change for Weslin labor employment site 1806."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. forecast type ki requirement probabilistic hai. The seasonal cycles in observation periods are 12. Repeating seasonal pattern expect karta hoon. Times are in Europe/London.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      12
    ],
    "evidence": "The seasonal cycles in observation periods are 12."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Times are in Europe/London."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates are stored in field measurement_time. Column payroll_change ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "payroll_change",
    "evidence": "Column payroll_change ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0063/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "I need the next 16 months predicted."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/labor_employment/0079
Split: train

### t1 initial_multislot

I need forecasts of labor force participation rate for Yarven labor employment site 1807. Target ki unit percent of working-age population hai. The forecast should extend 15 months ahead. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Yarven labor employment site 1807",
    "evidence": "I need forecasts of labor force participation rate for Yarven labor employment site 1807."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Yarven labor employment site 1807",
    "evidence": "I need forecasts of labor force participation rate for Yarven labor employment site 1807."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Target ki unit percent of working-age population hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "The forecast should extend 15 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. The observations are recorded every 1 month. Naya forecast har 2 din banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Naya forecast har 2 din banayein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target column is called participation_pct. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "participation_pct",
    "evidence": "The target column is called participation_pct."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 18 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0079/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "The forecast should extend 18 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r8-dev/labor_employment/0085
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source labor_employment_archive_1808.csv hai. Main data upload karunga. Aglay 15 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values thousands of jobs mein hain. payroll employment change for Merlow labor employment site 1808 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "labor_employment_archive_1808.csv",
    "evidence": "Source labor_employment_archive_1808.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Aglay 15 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of jobs",
    "evidence": "Target values thousands of jobs mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "payroll employment change for Merlow labor employment site 1808",
    "evidence": "payroll employment change for Merlow labor employment site 1808 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "payroll employment change for Merlow labor employment site 1808",
    "evidence": "payroll employment change for Merlow labor employment site 1808 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field sample_date mein hain. Column payroll_change ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates field sample_date mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "payroll_change",
    "evidence": "Column payroll_change ko target rakhein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target values thousands of jobs mein hain. Har 1 mahina aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of jobs",
    "evidence": "Target values thousands of jobs mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 18 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0085/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Aglay 18 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r8-dev/labor_employment/0092
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. Mera source reference https://inputs.example/labor_employment/1809 hai. Access the input through an API. 5 mahinay ka horizon rakhein. Source observations arrive every 1 month. Target ko thousands of jobs mein measure karein. My prediction target is payroll employment change for Norelia labor employment site 1809.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1809",
    "evidence": "Mera source reference https://inputs.example/labor_employment/1809 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "5 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of jobs",
    "evidence": "Target ko thousands of jobs mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "payroll employment change for Norelia labor employment site 1809",
    "evidence": "My prediction target is payroll employment change for Norelia labor employment site 1809."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "payroll employment change for Norelia labor employment site 1809",
    "evidence": "My prediction target is payroll employment change for Norelia labor employment site 1809."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Target values field payroll_change se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "payroll_change",
    "evidence": "Target values field payroll_change se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 8 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 8 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. My source reference is https://revised.example/labor_employment/92. Source observations har 2 mahinay aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/labor_employment/92",
    "evidence": "My source reference is https://revised.example/labor_employment/92."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0092/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Source observations har 2 mahinay aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r8-dev/labor_employment/0093
Split: train

### t1 initial_multislot

Mujhe labor force participation rate for Norelia labor employment site 1809 ka forecast chahiye. Target ki unit percent of working-age population hai. Observations har 1 mahina record hoti hain. Forecast aglay 12 mahinay tak chahiye. Input API ke zariye lein. Data source https://inputs.example/labor_employment/1809 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Norelia labor employment site 1809",
    "evidence": "Mujhe labor force participation rate for Norelia labor employment site 1809 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Norelia labor employment site 1809",
    "evidence": "Mujhe labor force participation rate for Norelia labor employment site 1809 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Target ki unit percent of working-age population hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast aglay 12 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1809",
    "evidence": "Data source https://inputs.example/labor_employment/1809 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Timestamps ki timezone Europe/London hai. Repeating seasonal pattern expect nahi karta. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Timestamps ki timezone Europe/London hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Target column ka naam participation_pct hai. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "participation_pct",
    "evidence": "Target column ka naam participation_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 15 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0093/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Forecast aglay 15 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/labor_employment/0159
Split: train

### t1 initial_multislot

Mujhe labor force participation rate for Yarven labor employment site 1815 ka forecast chahiye. Target ki unit percent of working-age population hai. Forecast aglay 18 mahinay tak chahiye. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Yarven labor employment site 1815",
    "evidence": "Mujhe labor force participation rate for Yarven labor employment site 1815 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Yarven labor employment site 1815",
    "evidence": "Mujhe labor force participation rate for Yarven labor employment site 1815 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Target ki unit percent of working-age population hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Forecast aglay 18 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Observations har 1 mahina record hoti hain. Naya forecast har 1 din banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naya forecast har 1 din banayein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Target column ka naam participation_pct hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "participation_pct",
    "evidence": "Target column ka naam participation_pct hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 21 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0159/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "Forecast aglay 21 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/labor_employment/0184
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target labor force participation rate for Orven labor employment site 1818 hai. Measurement unit percent of working-age population rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 16 mahinay hai. Input database se read karein. Observations https://inputs.example/labor_employment/1818 se lein. Input ko json ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "labor force participation rate for Orven labor employment site 1818",
    "evidence": "Prediction ka target labor force participation rate for Orven labor employment site 1818 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "labor force participation rate for Orven labor employment site 1818",
    "evidence": "Prediction ka target labor force participation rate for Orven labor employment site 1818 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent of working-age population",
    "evidence": "Measurement unit percent of working-age population rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Forecast horizon 16 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/labor_employment/1818",
    "evidence": "Observations https://inputs.example/labor_employment/1818 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input ko json ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 16 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 16 mahinay hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 19 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "Forecast horizon 19 mahinay hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 19 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/labor_employment/0184/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 19 mahinay hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
