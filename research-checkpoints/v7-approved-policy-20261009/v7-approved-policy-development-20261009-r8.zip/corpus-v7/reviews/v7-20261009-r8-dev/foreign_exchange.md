# V7 review examples for foreign_exchange

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## ur core_recall

Scenario: v7-20261009-r8-dev/foreign_exchange/0000
Split: train

### t1 initial_multislot

Mujhe EUR/USD log return for Merlow foreign exchange site 2100 ka forecast chahiye. Target ki unit percent hai. Observations har 1 din record hoti hain. Forecast aglay 20 din tak chahiye. Source data catalog se select karein. Data source https://inputs.example/foreign_exchange/2100 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD log return for Merlow foreign exchange site 2100",
    "evidence": "Mujhe EUR/USD log return for Merlow foreign exchange site 2100 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD log return for Merlow foreign exchange site 2100",
    "evidence": "Mujhe EUR/USD log return for Merlow foreign exchange site 2100 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Forecast aglay 20 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "Data source https://inputs.example/foreign_exchange/2100 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam eurusd_log_return hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_log_return",
    "evidence": "Target column ka naam eurusd_log_return hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 23 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "Forecast aglay 23 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Merlow foreign exchange site 2100 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow foreign exchange site 2100",
    "evidence": "business goal ki requirement prepare a planning reserve for Merlow foreign exchange site 2100 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r8-dev/foreign_exchange/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/foreign_exchange/2100. Select the source from the data catalog. I need the next 10 days predicted. There is one observed data point every 1 day. The target values are in USD per EUR. The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "The source is https://inputs.example/foreign_exchange/2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "I need the next 10 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "The target values are in USD per EUR."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100",
    "evidence": "The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100",
    "evidence": "The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Use column eurusd_spot as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_spot",
    "evidence": "Use column eurusd_spot as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per day. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Return forecasts with resolution one prediction row per day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 13 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "I need the next 13 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of foreign exchange. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r8-dev/foreign_exchange/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100. Keep the measurement unit as JPY per USD. The native sampling interval is 1 day. The forecast horizon is 17 days. Select the source from the data catalog. Read the observations from https://inputs.example/foreign_exchange/2100. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100",
    "evidence": "Please predict USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100",
    "evidence": "Please predict USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "JPY per USD",
    "evidence": "Keep the measurement unit as JPY per USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 17 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "Read the observations from https://inputs.example/foreign_exchange/2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is usdjpy_spot. Use column recorded_at for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "usdjpy_spot",
    "evidence": "The target field name is usdjpy_spot."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 20 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 20 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 days. Read the observations from https://revised.example/foreign_exchange/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 2 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/foreign_exchange/2",
    "evidence": "Read the observations from https://revised.example/foreign_exchange/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r8-dev/foreign_exchange/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. My source reference is https://inputs.example/foreign_exchange/2100. Select the source from the data catalog. Predict a horizon of 7 days. Source observations arrive every 1 day. Use index points, base 2020=100 as the target unit. My prediction target is trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "My source reference is https://inputs.example/foreign_exchange/2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 7 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100",
    "evidence": "My prediction target is trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100",
    "evidence": "My prediction target is trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. I do not expect a repeating seasonal pattern. Use timezone Europe/London.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Use timezone Europe/London."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is recorded_at. Read target values from field reer_index.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "reer_index",
    "evidence": "Read target values from field reer_index."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 10 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 10 days."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r8-dev/foreign_exchange/0004
Split: train

### t1 initial_multislot

I need forecasts of EUR/USD log return for Merlow foreign exchange site 2100. Measure the target in percent. The observations are recorded every 1 day. The forecast should extend 14 days ahead. Select the source from the data catalog. Use the data source https://inputs.example/foreign_exchange/2100. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD log return for Merlow foreign exchange site 2100",
    "evidence": "I need forecasts of EUR/USD log return for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD log return for Merlow foreign exchange site 2100",
    "evidence": "I need forecasts of EUR/USD log return for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measure the target in percent."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "The forecast should extend 14 days ahead."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "Use the data source https://inputs.example/foreign_exchange/2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 14 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 14 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 17 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "The forecast should extend 17 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 17 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 17 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r8-dev/foreign_exchange/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/foreign_exchange/2100. Select the source from the data catalog. I need the next 4 days predicted. There is one observed data point every 1 day. The target values are in USD per EUR. The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "The source is https://inputs.example/foreign_exchange/2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "I need the next 4 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "The target values are in USD per EUR."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100",
    "evidence": "The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100",
    "evidence": "The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Use column eurusd_spot as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_spot",
    "evidence": "Use column eurusd_spot as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in USD per EUR. There is one observed data point every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "The target values are in USD per EUR."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 7 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "I need the next 7 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r8-dev/foreign_exchange/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100. Keep the measurement unit as JPY per USD. The native sampling interval is 1 day. The forecast horizon is 11 days. Select the source from the data catalog. Read the observations from https://inputs.example/foreign_exchange/2100. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100",
    "evidence": "Please predict USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100",
    "evidence": "Please predict USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "JPY per USD",
    "evidence": "Keep the measurement unit as JPY per USD."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 11 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "Read the observations from https://inputs.example/foreign_exchange/2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is usdjpy_spot. Use column recorded_at for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "usdjpy_spot",
    "evidence": "The target field name is usdjpy_spot."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The ordered hierarchy columns are region_id, site_id. Return results at the level site. Limit the scope using these explicit filters: [{"column": "site_id", "operator": "eq", "value": "Merlow foreign exchange site 2100"}]. Include only these fictional areas: Fictional Merlow foreign exchange site 2100 region. The fictional data provider is Synthetic Economic Research Laboratory. Read the worksheet or resource named foreign_exchange_observations.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t3/hierarchy_columns",
    "slot_id": "hierarchy_columns",
    "status": "provided",
    "value": [
      "region_id",
      "site_id"
    ],
    "evidence": "The ordered hierarchy columns are region_id, site_id."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t3/aggregation_level",
    "slot_id": "aggregation_level",
    "status": "provided",
    "value": "site",
    "evidence": "Return results at the level site."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t3/scope_filters",
    "slot_id": "scope_filters",
    "status": "provided",
    "value": [
      {
        "column": "site_id",
        "operator": "eq",
        "value": "Merlow foreign exchange site 2100"
      }
    ],
    "evidence": "Limit the scope using these explicit filters: [{\"column\": \"site_id\", \"operator\": \"eq\", \"value\": \"Merlow foreign exchange site 2100\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t3/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Merlow foreign exchange site 2100 region"
    ],
    "evidence": "Include only these fictional areas: Fictional Merlow foreign exchange site 2100 region."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t3/source_provider",
    "slot_id": "source_provider",
    "status": "provided",
    "value": "Synthetic Economic Research Laboratory",
    "evidence": "The fictional data provider is Synthetic Economic Research Laboratory."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t3/sheet_or_table",
    "slot_id": "sheet_or_table",
    "status": "provided",
    "value": "foreign_exchange_observations",
    "evidence": "Read the worksheet or resource named foreign_exchange_observations."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The input source refresh schedule is every 2 hours. The historical observations begin at 2020-01-01T00:00:00+00:00. The historical observations end at 2026-09-30T00:00:00+00:00. The available historical coverage is 81 months. Require at least 365 training observations. The recorded structural breaks are [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}].

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t4/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t4/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "The historical observations begin at 2020-01-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t4/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "The historical observations end at 2026-09-30T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t4/expected_history_length",
    "slot_id": "expected_history_length",
    "status": "provided",
    "value": {
      "periods": 81,
      "unit": "month"
    },
    "evidence": "The available historical coverage is 81 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t4/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 365,
    "evidence": "Require at least 365 training observations."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t4/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "The recorded structural breaks are [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}]."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 14 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 14 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r8-dev/foreign_exchange/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 18 days. Source observations arrive every 1 day. Use index points, base 2020=100 as the target unit. My prediction target is trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100. Do not substitute daily EUR/USD log return as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 18 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Use index points, base 2020=100 as the target unit."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100",
    "evidence": "My prediction target is trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100",
    "evidence": "My prediction target is trade-weighted real effective exchange-rate index for Merlow foreign exchange site 2100."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Read target values from field reer_index.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "reer_index",
    "evidence": "Read target values from field reer_index."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is xlsx. My source reference is https://inputs.example/foreign_exchange/2100. Select the source from the data catalog.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "My source reference is https://inputs.example/foreign_exchange/2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 21 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 21 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r8-dev/foreign_exchange/0008
Split: train

### t1 initial_multislot

I need forecasts of EUR/USD log return for Merlow foreign exchange site 2100. Target ki unit percent hai. The observations are recorded every 1 day. Forecast aglay 8 din tak chahiye. Select the source from the data catalog. Data source https://inputs.example/foreign_exchange/2100 use karein. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD log return for Merlow foreign exchange site 2100",
    "evidence": "I need forecasts of EUR/USD log return for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD log return for Merlow foreign exchange site 2100",
    "evidence": "I need forecasts of EUR/USD log return for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Forecast aglay 8 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2100",
    "evidence": "Data source https://inputs.example/foreign_exchange/2100 use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values allowed hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values allowed hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 11 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "The forecast should extend 11 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/foreign_exchange/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 15 days predicted. The target values are in USD per EUR. The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "I need the next 15 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "The target values are in USD per EUR."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100",
    "evidence": "The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100",
    "evidence": "The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2100."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field recorded_at. Use column eurusd_spot as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_spot",
    "evidence": "Use column eurusd_spot as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 18 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "I need the next 18 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en core_recall

Scenario: v7-20261009-r8-dev/foreign_exchange/0010
Split: train

### t1 initial_multislot

For my request,  The source is foreign_exchange_archive_2101.csv. I need the next 14 days predicted. There is one observed data point every 1 day. The target values are in index points, base 2020=100. The quantity to predict is trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "foreign_exchange_archive_2101.csv",
    "evidence": "The source is foreign_exchange_archive_2101.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t1/file_format",
    "origin": "filename_extension_inference",
    "slot_id": "file_format",
    "status": "inferred",
    "value": "csv",
    "evidence": "The source is foreign_exchange_archive_2101.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "I need the next 14 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "The target values are in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101",
    "evidence": "The quantity to predict is trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101",
    "evidence": "The quantity to predict is trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The supplied data format is csv. I will upload the data. Dates are stored in field sample_date. Use column reer_index as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "reer_index",
    "evidence": "Use column reer_index as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "I need the next 17 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Norelia foreign exchange site 2101.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia foreign exchange site 2101",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia foreign exchange site 2101."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r8-dev/foreign_exchange/0013
Split: train

### t1 initial_multislot

I need forecasts of USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2101. Target ki unit JPY per USD hai. The observations are recorded every 1 day. Forecast aglay 18 din tak chahiye. I will upload the data. Data source foreign_exchange_archive_2101.csv use karein. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2101",
    "evidence": "I need forecasts of USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2101."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2101",
    "evidence": "I need forecasts of USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2101."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "JPY per USD",
    "evidence": "Target ki unit JPY per USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Forecast aglay 18 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "foreign_exchange_archive_2101.csv",
    "evidence": "Data source foreign_exchange_archive_2101.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

The timestamp timezone is UTC. Repeating seasonal pattern expect karta hoon. The seasonal cycles in observation periods are 7, 365. forecast type ki requirement probabilistic hai. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "The timestamp timezone is UTC."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      7,
      365
    ],
    "evidence": "The seasonal cycles in observation periods are 7, 365."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target column is called usdjpy_spot. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "usdjpy_spot",
    "evidence": "The target column is called usdjpy_spot."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 21 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "The forecast should extend 21 days ahead."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r8-dev/foreign_exchange/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. The source is foreign_exchange_archive_2101.csv. I will upload the data. I need the next 19 days predicted. There is one observed data point every 1 day. The target values are in index points, base 2020=100. The quantity to predict is trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "foreign_exchange_archive_2101.csv",
    "evidence": "The source is foreign_exchange_archive_2101.csv."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "I need the next 19 days predicted."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "The target values are in index points, base 2020=100."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101",
    "evidence": "The quantity to predict is trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101",
    "evidence": "The quantity to predict is trade-weighted real effective exchange-rate index for Norelia foreign exchange site 2101."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field sample_date. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains no personal, confidential, or regulated data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 22 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "day"
    },
    "evidence": "I need the next 22 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/foreign_exchange/0019
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target EUR/USD log return for Norelia foreign exchange site 2101 hai. Measurement unit percent rakhein. Forecast horizon 9 din hai. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD log return for Norelia foreign exchange site 2101",
    "evidence": "Prediction ka target EUR/USD log return for Norelia foreign exchange site 2101 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD log return for Norelia foreign exchange site 2101",
    "evidence": "Prediction ka target EUR/USD log return for Norelia foreign exchange site 2101 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Measurement unit percent rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Forecast horizon 9 din hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Asli data ka sampling interval 1 din hai. Forecast generation har 2 din run karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Forecast generation har 2 din run karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Target field eurusd_log_return hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_log_return",
    "evidence": "Target field eurusd_log_return hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 12 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0019/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Forecast horizon 12 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r8-dev/foreign_exchange/0021
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format parquet hai. Mera source reference https://inputs.example/foreign_exchange/2102 hai. Input API ke zariye lein. 15 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko index points, base 2020=100 mein measure karein. trade-weighted real effective exchange-rate index for Orven foreign exchange site 2102 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Source serialization format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2102",
    "evidence": "Mera source reference https://inputs.example/foreign_exchange/2102 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "15 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Orven foreign exchange site 2102",
    "evidence": "trade-weighted real effective exchange-rate index for Orven foreign exchange site 2102 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Orven foreign exchange site 2102",
    "evidence": "trade-weighted real effective exchange-rate index for Orven foreign exchange site 2102 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam observed_time hai. Target values field reer_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Time field ka naam observed_time hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "reer_index",
    "evidence": "Target values field reer_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Output granularity one prediction row per day use karein. Source records har 4 ghantay update karein. Retraining har 1 mahina schedule karein. Har 3 din naye forecasts banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Output granularity one prediction row per day use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source records har 4 ghantay update karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Retraining har 1 mahina schedule karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 18 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0021/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "18 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r8-dev/foreign_exchange/0043
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format xlsx hai. Mera source reference https://inputs.example/foreign_exchange/2104 hai. Source data catalog se select karein. 17 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko index points, base 2020=100 mein measure karein. trade-weighted real effective exchange-rate index for Talven foreign exchange site 2104 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Source serialization format xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2104",
    "evidence": "Mera source reference https://inputs.example/foreign_exchange/2104 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "17 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Talven foreign exchange site 2104",
    "evidence": "trade-weighted real effective exchange-rate index for Talven foreign exchange site 2104 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Talven foreign exchange site 2104",
    "evidence": "trade-weighted real effective exchange-rate index for Talven foreign exchange site 2104 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

prediction interval levels ki requirement 80, 95 hai. forecast type ki requirement probabilistic hai. Repeating seasonal pattern expect nahi karta. Timezone UTC use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Timezone UTC use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Time field ka naam recorded_at hai. Target values field reer_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Time field ka naam recorded_at hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "reer_index",
    "evidence": "Target values field reer_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. 20 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0043/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "20 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r8-dev/foreign_exchange/0051
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for EUR/USD log return for Virelo foreign exchange site 2105. Target measurements ki unit percent hai. Each observed record covers 1 day. Future coverage 14 din chahiye. I will upload the data. Diya hua source identifier foreign_exchange_archive_2105.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD log return for Virelo foreign exchange site 2105",
    "evidence": "We need an outlook for EUR/USD log return for Virelo foreign exchange site 2105."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD log return for Virelo foreign exchange site 2105",
    "evidence": "We need an outlook for EUR/USD log return for Virelo foreign exchange site 2105."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target measurements ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Future coverage 14 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "foreign_exchange_archive_2105.csv",
    "evidence": "Diya hua source identifier foreign_exchange_archive_2105.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column eurusd_log_return. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_log_return",
    "evidence": "The response variable is stored in column eurusd_log_return."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

New forecasts must be issued every 3 days. Model har 2 mahinay dobara estimate karein. Source ingestion repeats every 3 hours. Prediction rows ki resolution one prediction row per day hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "New forecasts must be issued every 3 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Model har 2 mahinay dobara estimate karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "Source ingestion repeats every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Prediction rows ki resolution one prediction row per day hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 17 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0051/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 17 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r8-dev/foreign_exchange/0069
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 13 days. Target ko index points, base 2020=100 mein measure karein. My prediction target is trade-weighted real effective exchange-rate index for Weslin foreign exchange site 2106. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 13 days."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target ko index points, base 2020=100 mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Weslin foreign exchange site 2106",
    "evidence": "My prediction target is trade-weighted real effective exchange-rate index for Weslin foreign exchange site 2106."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Weslin foreign exchange site 2106",
    "evidence": "My prediction target is trade-weighted real effective exchange-rate index for Weslin foreign exchange site 2106."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Produce new forecasts every 1 day. Source observations har 1 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The time field name is observed_time. Target values field reer_index se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "reer_index",
    "evidence": "Target values field reer_index se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 16 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0069/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 16 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r8-dev/foreign_exchange/0085
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. Source https://inputs.example/foreign_exchange/2108 hai. Select the source from the data catalog. Aglay 7 din predict karein. There is one observed data point every 1 day. Target values USD per EUR mein hain. The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2108.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2108",
    "evidence": "Source https://inputs.example/foreign_exchange/2108 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Aglay 7 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "Target values USD per EUR mein hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2108",
    "evidence": "The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2108."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2108",
    "evidence": "The quantity to predict is EUR/USD spot rate quoted as USD per EUR for Merlow foreign exchange site 2108."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Column eurusd_spot ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_spot",
    "evidence": "Column eurusd_spot ko target rakhein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in USD per EUR. Har 1 din aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "The target values are in USD per EUR."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 10 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0085/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "I need the next 10 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r8-dev/foreign_exchange/0097
Split: train

### t1 initial_multislot

Mujhe USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2109 ka forecast chahiye. Target ki unit JPY per USD hai. Observations har 1 din record hoti hain. Forecast aglay 15 din tak chahiye. trade-weighted real effective exchange-rate index nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2109",
    "evidence": "Mujhe USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2109 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2109",
    "evidence": "Mujhe USD/JPY spot rate quoted as JPY per USD for Norelia foreign exchange site 2109 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "JPY per USD",
    "evidence": "Target ki unit JPY per USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "day"
    },
    "evidence": "Forecast aglay 15 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam usdjpy_spot hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "usdjpy_spot",
    "evidence": "Target column ka naam usdjpy_spot hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Main data upload karunga. Data source foreign_exchange_archive_2109.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "foreign_exchange_archive_2109.csv",
    "evidence": "Data source foreign_exchange_archive_2109.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 18 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0097/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Forecast aglay 18 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r8-dev/foreign_exchange/0104
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2110 ka outlook chahiye. Target measurements ki unit JPY per USD hai. Har observed record 1 din cover karta hai. Future coverage 5 din chahiye. Input API ke zariye lein. Diya hua source identifier https://inputs.example/foreign_exchange/2110 hai. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2110",
    "evidence": "Hamein USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2110 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2110",
    "evidence": "Hamein USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2110 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "JPY per USD",
    "evidence": "Target measurements ki unit JPY per USD hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "Future coverage 5 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2110",
    "evidence": "Diya hua source identifier https://inputs.example/foreign_exchange/2110 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Future coverage 5 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Future coverage 5 din chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 8 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Future coverage 8 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Future coverage 8 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0104/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Future coverage 8 din chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r8-dev/foreign_exchange/0107
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for EUR/USD spot rate quoted as USD per EUR for Orven foreign exchange site 2110. Target measurements ki unit USD per EUR hai. Each observed record covers 1 day. Future coverage 9 din chahiye. Do not substitute USD/JPY spot rate quoted as JPY per USD as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Orven foreign exchange site 2110",
    "evidence": "We need an outlook for EUR/USD spot rate quoted as USD per EUR for Orven foreign exchange site 2110."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Orven foreign exchange site 2110",
    "evidence": "We need an outlook for EUR/USD spot rate quoted as USD per EUR for Orven foreign exchange site 2110."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "Target measurements ki unit USD per EUR hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Future coverage 9 din chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column eurusd_spot. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_spot",
    "evidence": "The response variable is stored in column eurusd_spot."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Access the input through an API. Diya hua source identifier https://inputs.example/foreign_exchange/2110 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2110",
    "evidence": "Diya hua source identifier https://inputs.example/foreign_exchange/2110 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 12 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0107/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 12 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r8-dev/foreign_exchange/0114
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. Mera source reference https://inputs.example/foreign_exchange/2111 hai. Read the input from a database. 16 din ka horizon rakhein. Source observations arrive every 1 day. Target ko USD per EUR mein measure karein. My prediction target is EUR/USD spot rate quoted as USD per EUR for Pelmar foreign exchange site 2111.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2111",
    "evidence": "Mera source reference https://inputs.example/foreign_exchange/2111 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "16 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "Target ko USD per EUR mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Pelmar foreign exchange site 2111",
    "evidence": "My prediction target is EUR/USD spot rate quoted as USD per EUR for Pelmar foreign exchange site 2111."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Pelmar foreign exchange site 2111",
    "evidence": "My prediction target is EUR/USD spot rate quoted as USD per EUR for Pelmar foreign exchange site 2111."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. Predict a horizon of 16 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. Predict a horizon of 16 days."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 19 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 19 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. Predict a horizon of 19 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0114/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. Predict a horizon of 19 days."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r8-dev/foreign_exchange/0132
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format csv hai. Mera source reference foreign_exchange_archive_2113.csv hai. Main data upload karunga. 7 din ka horizon rakhein. Source observations har 1 din aati hain. Target ko USD per EUR mein measure karein. EUR/USD spot rate quoted as USD per EUR for Virelo foreign exchange site 2113 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Source serialization format csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "foreign_exchange_archive_2113.csv",
    "evidence": "Mera source reference foreign_exchange_archive_2113.csv hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "7 din ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations har 1 din aati hain."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per EUR",
    "evidence": "Target ko USD per EUR mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Virelo foreign exchange site 2113",
    "evidence": "EUR/USD spot rate quoted as USD per EUR for Virelo foreign exchange site 2113 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "EUR/USD spot rate quoted as USD per EUR for Virelo foreign exchange site 2113",
    "evidence": "EUR/USD spot rate quoted as USD per EUR for Virelo foreign exchange site 2113 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam sample_date hai. Target values field eurusd_spot se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Time field ka naam sample_date hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eurusd_spot",
    "evidence": "Target values field eurusd_spot se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. 10 din ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "10 din ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Mera source reference https://revised.example/foreign_exchange/132 hai. Source observations har 2 din aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/foreign_exchange/132",
    "evidence": "Mera source reference https://revised.example/foreign_exchange/132 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0132/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Source observations har 2 din aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r8-dev/foreign_exchange/0156
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for trade-weighted real effective exchange-rate index for Yarven foreign exchange site 2115. Target measurements ki unit index points, base 2020=100 hai. Each observed record covers 1 day. Future coverage 6 din chahiye. Read the input from a database. Diya hua source identifier https://inputs.example/foreign_exchange/2115 hai. The input container uses json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Yarven foreign exchange site 2115",
    "evidence": "We need an outlook for trade-weighted real effective exchange-rate index for Yarven foreign exchange site 2115."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "trade-weighted real effective exchange-rate index for Yarven foreign exchange site 2115",
    "evidence": "We need an outlook for trade-weighted real effective exchange-rate index for Yarven foreign exchange site 2115."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "index points, base 2020=100",
    "evidence": "Target measurements ki unit index points, base 2020=100 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "Future coverage 6 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2115",
    "evidence": "Diya hua source identifier https://inputs.example/foreign_exchange/2115 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input container uses json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column reer_index. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "reer_index",
    "evidence": "The response variable is stored in column reer_index."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Include only these fictional areas: Fictional Yarven foreign exchange site 2115 region. source provider ki requirement Synthetic Economic Research Laboratory hai. Read the worksheet or resource named foreign_exchange_observations. Source ingestion har 5 ghantay repeat hoti hai. The historical observations begin at 2020-01-01T00:00:00+00:00. history end ki requirement 2026-09-30T00:00:00+00:00 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t3/geography",
    "slot_id": "geography",
    "status": "provided",
    "value": [
      "Fictional Yarven foreign exchange site 2115 region"
    ],
    "evidence": "Include only these fictional areas: Fictional Yarven foreign exchange site 2115 region."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t3/source_provider",
    "slot_id": "source_provider",
    "status": "provided",
    "value": "Synthetic Economic Research Laboratory",
    "evidence": "source provider ki requirement Synthetic Economic Research Laboratory hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t3/sheet_or_table",
    "slot_id": "sheet_or_table",
    "status": "provided",
    "value": "foreign_exchange_observations",
    "evidence": "Read the worksheet or resource named foreign_exchange_observations."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Source ingestion har 5 ghantay repeat hoti hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t3/history_start",
    "slot_id": "history_start",
    "status": "provided",
    "value": "2020-01-01T00:00:00+00:00",
    "evidence": "The historical observations begin at 2020-01-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t3/history_end",
    "slot_id": "history_end",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "history end ki requirement 2026-09-30T00:00:00+00:00 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The available historical coverage is 81 months. minimum training points ki requirement 365 hai. The recorded structural breaks are [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}]. missing timestamp policy ki requirement reject hai. For missing target values, use the policy reject. duplicate policy ki requirement reject hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t4/expected_history_length",
    "slot_id": "expected_history_length",
    "status": "provided",
    "value": {
      "periods": 81,
      "unit": "month"
    },
    "evidence": "The available historical coverage is 81 months."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t4/minimum_training_points",
    "slot_id": "minimum_training_points",
    "status": "provided",
    "value": 365,
    "evidence": "minimum training points ki requirement 365 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t4/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "The recorded structural breaks are [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}]."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t4/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "missing timestamp policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t4/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "For missing target values, use the policy reject."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t4/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "duplicate policy ki requirement reject hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0156/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 9 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t7 explicit_nonforecasting

For a separate new request, explain the definition of foreign exchange. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r8-dev/foreign_exchange/0166
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2116 hai. Measurement unit JPY per USD rakhein. Asli data ka sampling interval 1 din hai. Forecast horizon 17 din hai. Source data catalog se select karein. Observations https://inputs.example/foreign_exchange/2116 se lein. Input ko xlsx ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2116",
    "evidence": "Prediction ka target USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2116 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2116",
    "evidence": "Prediction ka target USD/JPY spot rate quoted as JPY per USD for Merlow foreign exchange site 2116 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "JPY per USD",
    "evidence": "Measurement unit JPY per USD rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Forecast horizon 17 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/foreign_exchange/2116",
    "evidence": "Observations https://inputs.example/foreign_exchange/2116 se lein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input ko xlsx ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field usdjpy_spot hai. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "usdjpy_spot",
    "evidence": "Target field usdjpy_spot hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

invalid value policy ki requirement coerce hai. minimum coverage ki requirement 86 hai. Repeating seasonal pattern expect karta hoon. Weekends aur non-business days exclude karein. holidays ki requirement synthetic reporting holiday hai. special events ki requirement [{"date": "2026-10-05", "name": "synthetic scheduled data release"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t3/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "coerce",
    "evidence": "invalid value policy ki requirement coerce hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t3/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "minimum coverage ki requirement 86 hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t3/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": true,
    "evidence": "Weekends aur non-business days exclude karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t3/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "holidays ki requirement synthetic reporting holiday hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t3/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "special events ki requirement [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

past covariates ki requirement lagged_target hai. known future covariates ki requirement announced_calendar_event hai. static features ki requirement scope_sector hai. covariate availability ki requirement [{"available": "announced before cutoff", "name": "announced_calendar_event"}] hai. external covariate sources ki requirement [{"name": "announced_calendar_event", "source": "synthetic_calendar"}] hai. forecast type ki requirement probabilistic hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t4/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "past covariates ki requirement lagged_target hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t4/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "known future covariates ki requirement announced_calendar_event hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t4/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_sector"
    ],
    "evidence": "static features ki requirement scope_sector hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t4/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "covariate availability ki requirement [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t4/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "external covariate sources ki requirement [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t4/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 20 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0166/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Forecast horizon 20 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261009-r8-dev/foreign_exchange/0180
Split: train

### t1 initial_multislot

Here is what I need.  Please predict USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2118. Measurement unit JPY per USD rakhein. The native sampling interval is 1 day. Forecast horizon 14 din hai. Read the observations from foreign_exchange_archive_2118.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2118",
    "evidence": "Please predict USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2118."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2118",
    "evidence": "Please predict USD/JPY spot rate quoted as JPY per USD for Orven foreign exchange site 2118."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "JPY per USD",
    "evidence": "Measurement unit JPY per USD rakhein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "Forecast horizon 14 din hai."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "foreign_exchange_archive_2118",
    "evidence": "Read the observations from foreign_exchange_archive_2118."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is usdjpy_spot. Timestamps ke liye column observed_time use karein. Access the input through an API. Input ko parquet ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "usdjpy_spot",
    "evidence": "The target field name is usdjpy_spot."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamps ke liye column observed_time use karein."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input ko parquet ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 17 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 17 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Orven foreign exchange site 2118.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r8-dev/foreign_exchange/0180/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven foreign exchange site 2118",
    "evidence": "Our operational goal is to prepare a planning reserve for Orven foreign exchange site 2118."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
