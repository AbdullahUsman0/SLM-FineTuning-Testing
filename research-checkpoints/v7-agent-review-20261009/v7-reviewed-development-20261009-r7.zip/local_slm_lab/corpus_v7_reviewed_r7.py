"""Development-only v7 revision following the r4 agent semantic review.

The public development package never contains final labels. Rendering is
controlled synthetic language, not independently authored human conversation.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import re

from forecasting_assistant.domain.models import DialogueTurn, SlotState
from forecasting_assistant.domain.schema import create_initial_state, load_schema
from forecasting_assistant.application.state_reducer import apply_extraction
from forecasting_assistant.application.normalization import normalize_value
from local_slm_lab.comparison_policy import ComparisonPolicy, source_sha256
from local_slm_lab import corpus_v6 as previous
from local_slm_lab.corpus_v5 import canonical_check, normalized_input
from local_slm_lab.v5_prompts import build_v5_extractor_instructions, build_v5_extractor_input

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'v7-20261009-r7-dev'
FPY_COMMIT = '04d52c015d1e3ecdefe92b87116f209361509b4b'
REVISION = '15852e8c16360a2fea060d615a32b45270f8a8fc'
SEED = 'v7-fact-ledger-1'
STATUS = 'machine_validated_pending_human'
CATEGORIES = ('core_recall', 'cadence_contrast', 'correction_chain', 'unknown_then_value',
              'confirmation_status', 'explicit_state_repair', 'lifecycle_dense',
              'target_contrast', 'encoding_literal', 'ambiguous_then_clarified')
CORE = ('problem_statement', 'target_description', 'target_unit', 'frequency',
        'forecast_horizon', 'source_mode', 'source_reference', 'file_format')
TEMPORAL = ('frequency', 'prediction_frequency', 'retraining_frequency', 'refresh_frequency',
            'forecast_horizon', 'lead_time', 'test_window', 'latency_requirement', 'expected_history_length')
WORDS = {'en': {'day':'day','hour':'hour','month':'month','week':'week','quarter':'quarter','second':'second','year':'year'},
         'ur': {'day':'din','hour':'ghanta','month':'mahina','week':'hafta','quarter':'quarter','second':'second','year':'saal'}}
PREFIX = {'en': ('', 'For my request, ', 'Here is what I need. ', 'Please record this. ',
                 'The analyst request is as follows. ', 'For the new forecasting brief, '),
          'ur': ('', 'Meri request yeh hai. ', 'Yeh details note kar lein. ', 'Mujhe yeh chahiye. ',
                 'Analyst ki request yeh hai. ', 'Naye forecasting brief ke liye, ')}

# Each phrase makes the role explicit; bare cadence is handled separately.
EN = {
 'target_description': ('I need forecasts of {v}', 'The quantity to predict is {v}', 'Please predict {v}', 'My prediction target is {v}', 'We need an outlook for {v}', 'The requested prediction concerns {v}'),
 'target_unit': ('Measure the target in {v}', 'The target values are in {v}', 'Keep the measurement unit as {v}', 'Use {v} as the target unit', 'Target measurements use {v}', 'The unit of the quantity being predicted is {v}'),
 'frequency': ('The observations are recorded every {v}', 'There is one observed data point every {v}', 'The native sampling interval is {v}', 'Source observations arrive every {v}', 'Each observed record covers {v}', 'Native observations have a cadence of {v}'),
 'forecast_horizon': ('The forecast should extend {v} ahead', 'I need the next {v} predicted', 'The forecast horizon is {v}', 'Predict a horizon of {v}', 'The requested future coverage is {v}', 'Extend predictions into the future by {v}'),
 'source_reference': ('Use the data source {v}', 'The source is {v}', 'Read the observations from {v}', 'My source reference is {v}', 'The supplied source identifier is {v}', 'Retrieve the input from {v}'),
 'target_column': ('The target column is called {v}', 'Use column {v} as the target', 'The target field name is {v}', 'Read target values from field {v}', 'The response variable is stored in column {v}', 'The input column for the prediction target is {v}'),
 'time_column': ('The timestamp column is {v}', 'Dates are stored in field {v}', 'Use column {v} for the timestamps', 'The time field name is {v}', 'The input timestamp identifier is {v}', 'Observation timestamps come from column {v}'),
 'timezone': ('The timestamp timezone is {v}', 'Times are in {v}', 'Interpret timestamps using {v}', 'Use timezone {v}', 'All observed times use the {v} timezone', 'The source clock follows timezone {v}'),
 'file_format': ('The input file format is {v}', 'The supplied data format is {v}', 'Read the input as {v}', 'The source serialization format is {v}', 'The input container uses {v}', 'Parse the supplied source in {v} format'),
 'prediction_frequency': ('Generate a new forecast every {v}', 'Refresh the predictions every {v}', 'Run forecast generation once every {v}', 'Produce new forecasts every {v}', 'New forecasts must be issued every {v}', 'The prediction generation schedule is every {v}'),
 'retraining_frequency': ('Retrain the model every {v}', 'Refit the forecasting model every {v}', 'Training should be repeated every {v}', 'Schedule model retraining every {v}', 'Re-estimate the model every {v}', 'The model refitting schedule is every {v}'),
 'refresh_frequency': ('Refresh the source data every {v}', 'Fetch a new source update every {v}', 'The input source refresh schedule is every {v}', 'Update the source records every {v}', 'Source ingestion repeats every {v}', 'Reload the source data every {v}'),
 'output_granularity': ('The output resolution must be {v}', 'Return forecasts with resolution {v}', 'Make the result granularity {v}', 'Use {v} as the output granularity', 'The requested prediction row resolution is {v}', 'Present the predictions at resolution {v}'),
}
UR = {
 'target_description': ('Mujhe {v} ka forecast chahiye', '{v} predict karna hai', 'Prediction ka target {v} hai', '{v} ke liye prediction bana dein', 'Hamein {v} ka outlook chahiye', 'Naye brief mein {v} predict karna hai'),
 'target_unit': ('Target ki unit {v} hai', 'Target values {v} mein hain', 'Measurement unit {v} rakhein', 'Target ko {v} mein measure karein', 'Target measurements ki unit {v} hai', 'Predict hone wali quantity ki unit {v} hai'),
 'frequency': ('Observations har {v} record hoti hain', 'Har {v} aik observed data point milta hai', 'Asli data ka sampling interval {v} hai', 'Source observations har {v} aati hain', 'Har observed record {v} cover karta hai', 'Native observations ki cadence {v} hai'),
 'forecast_horizon': ('Forecast aglay {v} tak chahiye', 'Aglay {v} predict karein', 'Forecast horizon {v} hai', '{v} ka horizon rakhein', 'Future coverage {v} chahiye', 'Predictions ko {v} aagay tak barhayein'),
 'source_reference': ('Data source {v} use karein', 'Source {v} hai', 'Observations {v} se lein', 'Mera source reference {v} hai', 'Diya hua source identifier {v} hai', 'Input {v} se hasil karein'),
 'target_column': ('Target column ka naam {v} hai', 'Column {v} ko target rakhein', 'Target field {v} hai', 'Target values field {v} se lein', 'Response variable column {v} mein hai', 'Prediction target ka input column {v} hai'),
 'time_column': ('Timestamp column {v} hai', 'Dates field {v} mein hain', 'Timestamps ke liye column {v} use karein', 'Time field ka naam {v} hai', 'Input timestamp identifier {v} hai', 'Observation timestamps column {v} se lein'),
 'timezone': ('Timestamps ki timezone {v} hai', 'Times {v} mein hain', 'Timestamps ko {v} ke mutabiq samjhein', 'Timezone {v} use karein', 'Saare observed times {v} timezone mein hain', 'Source clock ki timezone {v} hai'),
 'file_format': ('Input file format {v} hai', 'Diye hue data ka format {v} hai', 'Input ko {v} ke taur par read karein', 'Source serialization format {v} hai', 'Input container {v} use karta hai', 'Diya hua source {v} format mein parse karein'),
 'prediction_frequency': ('Naya forecast har {v} banayein', 'Predictions har {v} refresh karein', 'Forecast generation har {v} run karein', 'Har {v} naye forecasts banayein', 'Naye forecasts har {v} issue karein', 'Prediction banane ka schedule har {v} hai'),
 'retraining_frequency': ('Model har {v} retrain karein', 'Forecasting model har {v} refit karein', 'Training har {v} repeat karein', 'Retraining har {v} schedule karein', 'Model har {v} dobara estimate karein', 'Model refitting ka schedule har {v} hai'),
 'refresh_frequency': ('Source data har {v} refresh karein', 'Har {v} naya source update lein', 'Input source refresh schedule har {v} hai', 'Source records har {v} update karein', 'Source ingestion har {v} repeat hoti hai', 'Source data har {v} reload karein'),
 'output_granularity': ('Output resolution {v} chahiye', 'Forecast resolution {v} rakhein', 'Result granularity {v} banayein', 'Output granularity {v} use karein', 'Prediction rows ki resolution {v} hai', 'Predictions resolution {v} par dikhayein'),
}
SOURCE_MODE = {
 'upload': ('I will upload the data', 'Main data upload karunga'),
 'api': ('Access the input through an API', 'Input API ke zariye lein'),
 'database': ('Read the input from a database', 'Input database se read karein'),
 'catalog': ('Select the source from the data catalog', 'Source data catalog se select karein'),
}
TEMPLATE_POOLS = {'train': (0,1,2,3), 'validation': (4,), 'final': (5,)}


def dumps(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, default=lambda v:v.isoformat())


def digest(value):
    return hashlib.sha256(dumps(value).encode()).hexdigest()


def bytes_record(path):
    return {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}


def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes((dumps(value)+'\n').encode('utf-8'))


def write_gzip(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    raw_hash=hashlib.sha256(); count=0
    with path.open('wb') as stream, gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped:
        for row in rows:
            content=(dumps(row)+'\n').encode('utf-8'); raw_hash.update(content); zipped.write(content); count+=1
    return {**bytes_record(path),'raw_sha256':raw_hash.hexdigest(),'records':count}


def read_gzip(path):
    with gzip.open(path,'rt',encoding='utf-8') as stream:
        for line in stream:
            if line.strip(): yield json.loads(line)


def freeze_plan(per_domain=200,version=VERSION):
    if per_domain<200 or per_domain%200: raise ValueError('Use multiples of 200 for exact split and language quotas')
    rows=[]
    for di,profile in enumerate(previous.PROFILES):
        domain,family=profile[:2]; groups=per_domain//10
        ordered=sorted(range(groups),key=lambda g:digest([SEED,domain,g]))
        split_by_group={g:'train' if j<groups*7//10 else 'validation' if j<groups*85//100 else 'final' for j,g in enumerate(ordered)}
        for group in range(groups):
            split=split_by_group[group]
            # Language position rotates independently of behavior to avoid
            # making all unknown or ambiguous cases the multilingual subset.
            language_order=sorted(range(10),key=lambda k:digest([SEED,'language',domain,group,k]))
            language={k:'en' if j<8 else 'ur' if j==8 else 'mixed' for j,k in enumerate(language_order)}
            for k in range(10):
                i=group*10+k
                rows.append({'scenario_id':f'{version}/{domain}/{i:04d}', 'domain':domain,'domain_family':family,
                  'index':i,'domain_index':di,'entity_group':f'{version}/{domain}/entity-{group:03d}',
                  'contrast_group':f'{version}/{domain}/entity-{group:03d}', 'split':split,
                  'category':CATEGORIES[k], 'language':language[k],
                  'template_variant':TEMPLATE_POOLS[split][(group+k)%len(TEMPLATE_POOLS[split])]})
    return {'version':version,'seed':SEED,'fpy_commit':FPY_COMMIT,'model_revision':REVISION,
            'schema_version':'1.0.0','prompt_version':'v5-all-schema-1','per_domain':per_domain,
            'domain_mixture':{'weather':.3,'economics':.6,'combined':.1},
            'language_mixture':{'en':.8,'ur':.1,'mixed':.1},'template_pools':TEMPLATE_POOLS,
            'status':'groups_languages_and_splits_frozen_before_rendering','assignments':rows}


def source_values(row,schema):
    group=row['index']//10; domain=row['domain']; di=row['domain_index']
    targets=previous.PROFILE[domain][-1]
    target_variant=(group*3+di+row['index']%10)%len(targets)
    values=previous.source_values({**row,'target_variant':target_variant},schema)
    scope=f"{('Merlow','Norelia','Orven','Pelmar','Talven','Virelo','Weslin','Yarven')[group%8]} {domain.replace('_',' ')} site {1000+di*100+group}"
    description=targets[target_variant][0]
    description=re.sub(r'^(daily|hourly|weekly|monthly|quarterly)\s+','',description)
    # Rejected alternatives belong in contrast text, never in a positive value.
    description=description.split(', not ',1)[0]
    values['target_description']=f'{description} for {scope}'
    values['problem_statement']=values['target_description']
    threshold=round(.05*(1+group%5),2) if values['target_unit']=='0 or 1' else 1+group%5
    values['success_criteria']=f"MAE no more than {threshold} {values['target_unit']} for {scope}"
    values['acceptable_error']={'metric':'mae','maximum':threshold}
    # Legacy v6 chooses weather drivers using the old index, not target_variant.
    # Keep the explicitly listed historical feature aligned with the rotated
    # target; this does not claim that its future measurements are available.
    if row['domain_family']=='combined':
        driver={'load_mw':'observed_temperature','power_price':'observed_temperature',
                'gas_demand':'observed_heating_degree_days','solar_mw':'observed_irradiance',
                'wheat_weather_price':'observed_precipitation','crop_shipments':'observed_rainfall',
                'irrigation_cost':'observed_temperature','yield_index':'observed_soil_moisture'}[values['target_column']]
        values['past_covariates']=[driver]
        values['external_covariate_sources']=[{'name':driver,'source':'synthetic_station_archive'}]
    values['business_goal']=f'prepare a planning reserve for {scope}'
    values['decision_supported']=f'set the contingency allowance for {scope}'
    values['scope_filters']=[{'column':'site_id','operator':'eq','value':scope}]
    values['geography']=[f'Fictional {scope} region']
    values['source_mode']=('upload','api','database','catalog')[(group+di)%4]
    values['file_format']=('csv','parquet','json','xlsx')[(group+di)%4]
    values['source_reference']=(f"{domain}_archive_{1000+di*100+group}.{values['file_format']}" if values['source_mode']=='upload' else f"https://inputs.example/{domain}/{1000+di*100+group}")
    values['time_column']=('sample_date','observed_time','measurement_time','recorded_at')[(group+di)%4]
    # The old expression was (7*g + (10*g + category)) % 17: g
    # cancelled exactly, making horizon a fixed answer per domain/category.
    values['forecast_horizon']={**values['forecast_horizon'],'periods':4+((group*11+di*3+(row['index']%10)*7)%17)}
    values['prediction_frequency']={'periods':1+(group%3),'unit':'day'}
    values['refresh_frequency']={'periods':2+(group%4),'unit':'hour'}
    values['retraining_frequency']={'periods':1+(group%2),'unit':'month'}
    values['output_granularity']='one prediction row per '+values['frequency']['unit']
    values['history_start']='2020-01-01T00:00:00+00:00'
    values['history_end']='2026-09-30T00:00:00+00:00'
    # Adjacent structured requirements must agree if they co-occur.
    values['dataset_type']='hierarchical'
    values['hierarchy_columns']=['region_id','site_id']; values['series_id_columns']=['site_id']
    values['aggregation_level']='site'
    values['destination']=f'https://planning.example/{domain}/{1000+di*100+group}'
    # Lifecycle source index always ends in 6. Index parity otherwise forces
    # every approval/provenance example to false, despite positive slot coverage.
    for boolean in ('human_approval_required','provenance_required','contains_sensitive_data'):
        values[boolean]=bool((group+di)%2)
    values['forecast_type']='probabilistic'; values['known_seasonality']=True
    values['timezone']=('UTC','Asia/Karachi','Europe/London')[(group+di)%3]
    # Domain consistency is explicit, not substring inference. In the previous
    # value helper, “CPI index level, not its growth rate” matched “growth” and
    # binary heatwave indicators matched “temperature”. Neither permits a
    # negative target merely because those words occur in its definition.
    column=values['target_column']
    may_be_negative={'tmax_c','tmin_c','tmean_f','temp_c','dewpoint_c','cpi_yoy','core_cpi_mom_sa',
      'real_gdp_growth','consumption_growth','payroll_change','earnings_growth','policy_rate',
      'credit_spread_bp','lending_growth','mortgage_rate','yield_10y','curve_spread_bp','bond_return_pct',
      'total_return_pct','eurusd_log_return','btc_log_return','btc_funding_pct','btc_basis_bp',
      'trade_balance','fiscal_balance','operating_cash_flow','working_capital_change','power_price'}
    values['allow_negative_values']=column in may_be_negative
    values['target_bounds']={**values['target_bounds'],
      'min':min(values['target_bounds']['min'],-100) if values['allow_negative_values'] else max(0,values['target_bounds']['min'])}
    if values['target_unit']=='0 or 1': values['target_bounds']={'min':0,'max':1}
    for slot,value in values.items():
        if slot!='authentication_reference': canonical_check(slot,value,schema)
    return values


def duration(value,language):
    unit=WORDS['ur' if language=='ur' else 'en'][value['unit']]
    if language=='ur' and value['periods']!=1:
        unit={'ghanta':'ghantay','mahina':'mahinay','hafta':'haftay'}.get(unit,unit)
    return f"{value['periods']} {unit}{'s' if language=='en' and value['periods']!=1 else ''}"


def surface(value,language):
    if isinstance(value,dict) and set(value)=={'periods','unit'}: return duration(value,language)
    if isinstance(value,str): return value
    if isinstance(value,list) and all(isinstance(v,(str,int,float)) for v in value):
        return ', '.join(str(v) for v in value)
    return dumps(value)


def phrase(slot,value,row,ordinal):
    language='ur' if row['language']=='ur' or row['language']=='mixed' and ordinal%2 else 'en'
    variant=row['template_variant']
    if slot=='source_mode': return SOURCE_MODE[value][int(language=='ur')]
    if slot=='calendar_type':
        wording={'calendar':('Use ordinary calendar days','Aam calendar ke din use karein'),
                 'business_day':('Use a business-day calendar','Business days wala calendar use karein'),
                 'trading':('Use the trading-session calendar','Trading sessions wala calendar use karein')}
        return wording[value][int(language=='ur')]
    bank=UR if language=='ur' else EN
    if slot in bank: return bank[slot][variant].format(v=surface(value,language))
    if slot in previous.base.BOOL_CLAUSES:
        en=previous.base.BOOL_CLAUSES[slot][int(value)]
        ur={
          'allow_negative_values':('Negative target values allowed nahi hain','Negative target values allowed hain'),
          'known_seasonality':('Repeating seasonal pattern expect nahi karta','Repeating seasonal pattern expect karta hoon'),
          'business_days_only':('Weekends aur non-business days exclude na karein','Weekends aur non-business days exclude karein'),
          'contains_sensitive_data':('Source mein personal ya confidential data nahi hai','Source mein confidential synthetic records hain'),
          'provenance_required':('Detailed data lineage required nahi hai','Detailed data lineage required hai'),
          'human_approval_required':('Modeling se pehle human approval required nahi hai','Modeling se pehle human approval required hai'),
        }
        return ur[slot][int(value)] if language=='ur' else en
    # Controlled technical clauses cover the remaining lifecycle schema. Complex
    # object values are stated explicitly, rather than silently inferred.
    if slot in TEMPORAL:
        label={'expected_history_length':'available historical coverage','lead_time':'lead time',
               'test_window':'holdout window length','latency_requirement':'maximum response time'}[slot]
        return (f'{label} {surface(value,language)} hai' if language=='ur' else f'The {label} is {surface(value,language)}')
    text=previous.base.CLAUSES[slot].format(v=surface(value,language))
    if language=='en' and slot=='business_goal':
        text=f'Our operational goal is to {surface(value,language)}'
    if language=='en' and slot=='decision_supported':
        text=f'This forecast will inform the decision to {surface(value,language)}'
    if language=='ur':
        # Technical field names and literal values are deliberately retained.
        return f"{schema_label(slot)} ki requirement {surface(value,language)} hai"
    return text


def schema_label(slot):
    return slot.replace('_',' ')


def new_fact(sid,turn,slot,value,status='provided'):
    return {'fact_id':f'{sid}/{turn}/{slot}','slot_id':slot,'value':deepcopy(value),'status':status}


def state_snapshot(state):
    return {slot:{'value':json.loads(dumps(s.value)),'status':s.status.value,
                  'confirmed_by_user':s.confirmed_by_user} for slot,s in state.slots.items() if s.value is not None}


def restore_state(snapshot,schema,intent='create_forecast'):
    from forecasting_assistant.domain.models import Intent
    state=create_initial_state(schema); state.intent=Intent(intent)
    for slot,item in snapshot.items():
        state.slots[slot]=SlotState(slot_id=slot,**item,confidence=1.0,evidence_text='Explicit prior synthetic fact')
    return state


def make_turn(row,number,spec,state,schema):
    tid=f't{number}'; sid=row['scenario_id']; pieces=[]; spans=[]; facts=[]
    if spec.get('prefix'): pieces.append(spec['prefix'])
    content=list(spec['facts'].items())
    if row['template_variant']%2: content.reverse()
    # task noun phrase supplies two slots under the reviewed R1 policy.
    for ordinal,(slot,value) in enumerate(content):
        if slot=='problem_statement': continue
        text=phrase(slot,value,row,ordinal)+'.'
        if spec.get('confirmation'):
            text=('Main pehle se recorded horizon ki tasdeeq karta hoon. ' if row['language']=='ur'
                  else 'I explicitly confirm the previously recorded horizon. ')+text
        start=sum(len(x)+1 for x in pieces); pieces.append(text)
        slots=[slot,'problem_statement'] if slot=='target_description' and spec.get('target_is_task',False) else [slot]
        for s in slots:
            fact=new_fact(sid,tid,s,value,'confirmed' if spec.get('confirmation') else 'provided')
            facts.append(fact); spans.append({'fact_id':fact['fact_id'],'slot_id':s,'start':start,'end':start+len(text),'text':text})
    if spec.get('suffix'): pieces.append(spec['suffix'])
    message=' '.join(pieces)
    if not message: raise ValueError('empty message')
    updates=[{'slot_id':f['slot_id'],'candidate_value':dumps(f['value']),'status':f['status'],
              'confidence':1.0,'evidence_text':span['text']} for f,span in zip(facts,spans)]
    gold={'intent':spec.get('intent','create_forecast'),'intent_confidence':1.0,'updates':updates,
          'correction_detected':spec.get('correction',False),'unsupported_claims':[]}
    snapshot=state_snapshot(state)
    return {'turn_id':tid,'parent_id':sid if number==1 else f'{sid}/t{number-1}',
            'message':message,'gold_extraction':gold,'context_slots':{s:v['value'] for s,v in snapshot.items()},
            'context_state':snapshot,'established_intent':state.intent.value,
            'prior_user_messages':[t.user_message for t in state.turns],
            'facts':facts,'evidence_spans':spans,'behavior':spec['behavior'],
            'forbidden_slots':spec.get('forbidden_slots',[]),
            'state_intervention':spec.get('state_intervention'),
            'language':row['language'],'reviewer_status':STATUS}


def build_scenario(row,schema=None,policy=None):
    schema=schema or load_schema(); policy=policy or ComparisonPolicy(); values=source_values(row,schema)
    language=row['language']; ur=language=='ur'; category=row['category']; i=row['index']; di=row['domain_index']
    # Common source/access facts and target are explicit, not inferred from files.
    initial={s:values[s] for s in ('target_description','target_unit','frequency','forecast_horizon')}
    if category not in {'ambiguous_then_clarified','target_contrast'}:
        initial.update({s:values[s] for s in ('source_mode','source_reference','file_format')})
    if category=='ambiguous_then_clarified': initial.pop('frequency')
    if category=='core_recall' and (i//10+di)%2:
        # A filename identifies a source, not its access method or columns.
        initial.pop('source_mode'); initial.pop('file_format')
    specs=[{'facts':initial,'target_is_task':True,'behavior':'initial_multislot',
            'prefix':PREFIX['ur' if ur else 'en'][row['template_variant']]}]
    extra={'facts':{s:values[s] for s in ('target_column','time_column')},'behavior':'incremental_identifiers'}
    if category=='core_recall' and 'source_mode' not in initial:
        extra['facts'].update({s:values[s] for s in ('source_mode','file_format')})
    horizon={**values['forecast_horizon'],'periods':values['forecast_horizon']['periods']+3}
    correction={'facts':{'forecast_horizon':horizon},'behavior':'targeted_replacement','correction':True,
                'prefix':'Pehla horizon replace kar dein.' if ur else 'Replace the earlier horizon; leave every other requirement unchanged.'}
    unknown_wording={
        'en': ("I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.",
               "Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.",
               "Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.",
               "I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.",
               "Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.",
               "No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later."),
        'ur': ("Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.",
               "Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.",
               "Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.",
               "Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.",
               "Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.",
               "Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.")}
    unknown={'facts':{},'behavior':'unknown_omission','forbidden_slots':['timezone','authentication_reference','seasonal_periods','prediction_interval_levels'],
             'prefix':unknown_wording['ur' if ur else 'en'][(i//10+di)%6]}
    if category=='core_recall':
        specs += [extra,correction,{'facts':{'business_goal':values['business_goal']},'behavior':'purpose_addition'},unknown]
    elif category=='cadence_contrast':
        specs += [extra,{'facts':{s:values[s] for s in ('prediction_frequency','retraining_frequency','refresh_frequency','output_granularity')},'behavior':'cadence_roles'},correction,unknown]
    elif category=='correction_chain':
        freq={**values['frequency'],'periods':values['frequency']['periods']+1}
        specs += [extra,correction,{'facts':{'frequency':freq,'source_reference':f"https://revised.example/{row['domain']}/{i}"},
                  'correction':True,'behavior':'two_slot_replacement','prefix':'Pehli settings badal dein.' if ur else 'Change only these two earlier settings.'},unknown]
    elif category=='unknown_then_value':
        resolution={s:values[s] for s in ('timezone','known_seasonality','seasonal_periods','forecast_type','prediction_interval_levels')}
        if (i//10+di)%2:
            resolution['known_seasonality']=False; resolution.pop('seasonal_periods')
        specs += [unknown,{'facts':resolution,'behavior':'explicit_unknown_resolution'},extra,correction]
    elif category=='confirmation_status':
        specs += [{'facts':{'forecast_horizon':values['forecast_horizon']},'confirmation':True,'behavior':'explicit_confirmation'},
                  correction,{'facts':{'forecast_horizon':horizon},'confirmation':True,'behavior':'confirmation_after_replacement'},unknown]
    elif category=='explicit_state_repair':
        # This is a separate training-context intervention, never passed off as
        # a natural prediction trace. An explicit replacement repairs it.
        extra['state_intervention']={'mutations':[
            {'slot':'frequency','kind':'wrong_prior_value','value':{'periods':3,'unit':values['frequency']['unit']}},
            {'slot':'target_unit','kind':'omitted_prior_value'}]}
        specs += [extra,{'facts':{'frequency':values['frequency'],'target_unit':values['target_unit']},
                  'correction':True,'behavior':'repair_with_fresh_evidence',
                  'prefix':'Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon.' if ur else 'Replace the incorrect earlier frequency; I am restating the unit too.'},correction,unknown]
    elif category=='lifecycle_dense':
        eligible=[s.slot_id for s in schema.slots if s.slot_id not in set(CORE)|{'intent','authentication_reference','timezone','seasonal_periods','prediction_interval_levels','target_column','time_column'}]
        offset=((i//10)*13+di*7)%len(eligible)
        chosen=(eligible[offset:]+eligible[:offset])[:12]
        specs += [extra,{'facts':{s:values[s] for s in chosen[:6]},'behavior':'lifecycle_bundle'},
                  {'facts':{s:values[s] for s in chosen[6:]},'behavior':'lifecycle_bundle'},correction,unknown]
    elif category=='target_contrast':
        profile=previous.PROFILE[row['domain']][-1]
        positive=values['target_description'].rsplit(' for ',1)[0]
        # Choose a genuinely different measure after target rotation. Otherwise
        # the old index-based choice can reject the very target just requested.
        variant=((i//10)*3+di+i%10)%len(profile)
        for step in range(1,len(profile)+1):
            other=profile[(variant+step)%len(profile)][0].split(', not ',1)[0]
            plain=re.sub(r'^(daily|hourly|weekly|monthly|quarterly)\s+','',other)
            if plain!=positive: break
        else: raise ValueError('No distinct target alternative in domain profile')
        specs[0]['suffix']=(f"{other} nahi chahiye." if ur else f'Do not substitute {other} as my requested target.')
        specs += [extra,{'facts':{'source_mode':values['source_mode'],'source_reference':values['source_reference'],'file_format':values['file_format']},'behavior':'source_details'},correction,unknown]
    elif category=='encoding_literal':
        # Safe literal strings, not credentials. Distinguish quoted strings from
        # embedded JSON booleans/numbers and retain percent/unit punctuation.
        specs += [{'facts':{'target_column':('2026','true','inflation (%)','value "net"')[i//10%4],
                            'time_column':values['time_column']},'behavior':'literal_identifier'},
                  {'facts':{'contains_sensitive_data':bool((i//10+di)%2),'allow_negative_values':values['allow_negative_values']},'behavior':'explicit_boolean'},correction,unknown]
    else:
        specs[0]['suffix']=('Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.' if ur else 'Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.')
        specs[0]['forbidden_slots']=['frequency','prediction_frequency']
        specs += [{'facts':{'frequency':values['frequency'],'prediction_frequency':values['prediction_frequency']},'behavior':'cadence_clarified',
                   'prefix':('Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain.' if ur else
                             'The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules.')},extra,correction,unknown]
    # One independently rotated intent boundary per ten-case source family.
    # This controls regression to create_forecast for every possible user turn.
    if i%10==(i//10+di)%10:
        specs.append({'facts':{},'behavior':'explicit_nonforecasting','intent':'not_forecasting',
                      'prefix':(f"Nayi request: {row['domain'].replace('_',' ')} ki definition samjha dein. Forecast nahi chahiye."
                                if ur else f"For a separate new request, explain the definition of {row['domain'].replace('_',' ')}. No forecast is requested.")})
    state=create_initial_state(schema); turns=[]
    for number,spec in enumerate(specs,1):
        intervention=spec.get('state_intervention')
        if intervention:
            intervene(state,intervention)
        turn=make_turn(row,number,spec,state,schema)
        admission=policy.parse(dumps(turn['gold_extraction']),'extract')
        if not admission.admitted: raise ValueError('Gold contract failure: '+str(admission.error_code))
        state=apply_extraction(state,admission.to_model('extract'),schema,number,turn['message'])
        state.turns.append(DialogueTurn(turn_number=number,user_message=turn['message']))
        turn['expected_state_after']=state_snapshot(state); turns.append(turn)
    return {**row,'cluster_id':row['entity_group'],'corpus_version':row['scenario_id'].split('/')[0],
            'schema_version':schema.version,'prompt_version':'v5-all-schema-1',
            'origin':'new_deterministic_fact_plan_with_controlled_language',
            'reviewer_status':STATUS,'turns':turns,'gold_intent':state.intent.value,
            'gold_final_slots':{s:v['value'] for s,v in state_snapshot(state).items()},
            'gold_final_statuses':{s:v['status'] for s,v in state_snapshot(state).items()},
            'state_interventions_are_synthetic':category=='explicit_state_repair'}


def state_for_turn(turn,schema):
    state=restore_state(turn['context_state'],schema,turn['established_intent'])
    for number,msg in enumerate(turn['prior_user_messages'],1):
        state.turns.append(DialogueTurn(turn_number=number,user_message=msg))
    return state


def intervene(state,intervention):
    for change in intervention['mutations']:
        slot=change['slot']
        if change['kind']=='omitted_prior_value':
            state.slots[slot]=SlotState(slot_id=slot)
        elif change['kind']=='wrong_prior_value':
            state.slots[slot].value=deepcopy(change['value'])
            state.slots[slot].evidence_text='Seeded synthetic training-context error'
        else:
            raise ValueError('Unknown context intervention')


def sft_examples(scenario,schema=None):
    schema=schema or load_schema()
    for turn in scenario['turns']:
        yield {'messages':[{'role':'system','content':build_v5_extractor_instructions()},
                {'role':'user','content':build_v5_extractor_input(turn['message'],state_for_turn(turn,schema),schema)},
                {'role':'assistant','content':dumps(turn['gold_extraction'])}],
              'metadata':{k:scenario[k] for k in ('scenario_id','split','category','domain','domain_family','language','entity_group','contrast_group','reviewer_status')}
                  | {'task':'extract','turn_id':turn['turn_id'],'behavior':turn['behavior'],'corpus_version':scenario['corpus_version'],
                     'state_intervention':turn['state_intervention']}}


def validate_scenario(scenario,schema,policy):
    if scenario['reviewer_status']!=STATUS: raise ValueError('Generator cannot claim human review')
    if scenario['cluster_id']!=scenario['contrast_group'] or scenario['entity_group']!=scenario['cluster_id']:
        raise ValueError('Broken group identity')
    state=create_initial_state(schema)
    for number,turn in enumerate(scenario['turns'],1):
        if turn['turn_id']!=f't{number}': raise ValueError('Broken turn order')
        if turn['parent_id']!=(scenario['scenario_id'] if number==1 else f"{scenario['scenario_id']}/t{number-1}"):
            raise ValueError('Broken trajectory parent')
        change=turn['state_intervention']
        if change:
            if scenario['category']!='explicit_state_repair' or any(c['slot'] not in state.slots for c in change['mutations']): raise ValueError('Invalid intervention')
            intervene(state,change)
        if state_snapshot(state)!=turn['context_state']: raise ValueError('Incorrect prior state ledger')
        if turn['prior_user_messages']!=[t.user_message for t in state.turns]: raise ValueError('History mismatch')
        admitted=policy.parse(dumps(turn['gold_extraction']),'extract')
        if not admitted.admitted: raise ValueError('Gold rejected')
        slots=[u['slot_id'] for u in admitted.predicted['updates']]
        if len(set(slots))!=len(slots) or set(slots)&set(turn['forbidden_slots']): raise ValueError('Duplicate or forbidden supervision')
        if len(slots)!=len(turn['facts']) or len(slots)!=len(turn['evidence_spans']): raise ValueError('Unpaired fact')
        for fact,span,update in zip(turn['facts'],turn['evidence_spans'],admitted.predicted['updates']):
            if fact['fact_id']!=span['fact_id'] or span['slot_id']!=update['slot_id'] or fact['slot_id']!=update['slot_id']:
                raise ValueError('Fact identity mismatch')
            if turn['message'][span['start']:span['end']]!=span['text'] or not span['text'].strip() or span['text']!=update['evidence_text']:
                raise ValueError('Evidence is not a current exact span')
            if dumps(fact['value'])!=dumps(update['candidate_value']) or fact['status']!=update['status']:
                raise ValueError('Fact value/status mismatch')
            canonical_check(fact['slot_id'],fact['value'],schema)
        if turn['behavior']=='unknown_omission' and slots: raise ValueError('Unknown turn supplies a value')
        state=apply_extraction(state,admitted.to_model('extract'),schema,number,turn['message'])
        state.turns.append(DialogueTurn(turn_number=number,user_message=turn['message']))
        if state_snapshot(state)!=turn['expected_state_after']: raise ValueError('Reducer replay mismatch')
        if any(v.status.value=='invalid' for v in state.slots.values()): raise ValueError('Invalid reducer state')
    if {s:v['value'] for s,v in state_snapshot(state).items()}!=scenario['gold_final_slots']:
        raise ValueError('Final state mismatch')


def development_audit(cases,plan,schema,policy):
    assignments={r['scenario_id']:r for r in plan['assignments']}
    split_ids=defaultdict(set); groups=defaultdict(set); exact={}; normalized={}
    counts=Counter(); positive=defaultdict(Counter); snippets=[]
    for case in cases:
        row=assignments[case['scenario_id']]
        if any(case[k]!=row[k] for k in row): raise ValueError('Frozen assignment changed')
        validate_scenario(case,schema,policy)
        groups[case['entity_group']].add(case['split']); split_ids[case['split']].add(case['scenario_id'])
        counts[('scenario',case['split'])]+=1; counts[('language',case['split'],case['language'])]+=1
        counts[('family',case['split'],case['domain_family'])]+=1
        for turn,example in zip(case['turns'],sft_examples(case,schema)):
            text=dumps(example['messages'][:2])
            for table,key in ((exact,digest(text)),(normalized,digest(normalized_input(text)))):
                if key in table: raise ValueError('Exact or normalized duplicate model input')
                table[key]=[case['scenario_id'],turn['turn_id']]
            counts[('example',case['split'])]+=1
            counts[('example_language',case['split'],case['language'])]+=1
            counts[('behavior',turn['behavior'])]+=1
            counts[('density',str(len(turn['facts'])))]+=1
            for fact in turn['facts']: positive[case['split']][fact['slot_id']]+=1
        snippets.append({'scenario_id':case['scenario_id'],'split':case['split'],'tokens':set(normalized_input(case['turns'][0]['message']).split())})
    if any(len(v)>1 for v in groups.values()): raise ValueError('Cross split group leakage')
    for split in ('train','validation'):
        expected={r['scenario_id'] for r in plan['assignments'] if r['split']==split}
        if split_ids[split]!=expected: raise ValueError('Development inventory differs from frozen split')
        for required in [s.slot_id for s in schema.slots if s.requiredness.value=='required' and s.slot_id!='intent']:
            if not positive[split][required]: raise ValueError('Missing required-slot coverage')
    # All-pairs representative Jaccard within the development package, not a
    # claim about every follow-up prompt or semantic overlap with final labels.
    train=[s for s in snippets if s['split']=='train']; validation=[s for s in snippets if s['split']=='validation']
    bins=Counter(); flagged=[]
    for val in validation:
        best=(-1,None)
        for source in train:
            score=len(val['tokens']&source['tokens'])/len(val['tokens']|source['tokens'])
            bins['>=0.8' if score>=.8 else '>=0.6' if score>=.6 else '<0.6']+=1
            if score>best[0]: best=(score,source['scenario_id'])
        if best[0]>=.6: flagged.append({'validation':val['scenario_id'],'nearest_train':best[1],'Jaccard':best[0],'review_status':'pending'})
    return {'development_scenarios':dict((s,counts[('scenario',s)]) for s in ('train','validation')),
            'development_sft_examples':dict((s,counts[('example',s)]) for s in ('train','validation')),
            'languages_by_split':{s:{l:counts[('language',s,l)] for l in ('en','ur','mixed')} for s in ('train','validation')},
            'example_languages_by_split':{s:{l:counts[('example_language',s,l)] for l in ('en','ur','mixed')} for s in ('train','validation')},
            'domain_families_by_split':{s:{f:counts[('family',s,f)] for f in ('weather','economics','combined')} for s in ('train','validation')},
            'positive_slots_by_split':{s:dict(positive[s]) for s in ('train','validation')},
            'behavior_turns':{k[1]:v for k,v in counts.items() if k[0]=='behavior'},
            'update_density':{k[1]:v for k,v in counts.items() if k[0]=='density'},
            'exact_input_duplicates':0,'normalized_input_duplicates':0,'cross_split_groups':0,
            'positive_slot_exclusion':{'authentication_reference':'Redacted in prompt; no positive credential-reference labels', 'intent':'Top-level intent is supervised; no redundant intent slot update'},
            'overlap':{'representative_pairs_checked':len(train)*len(validation),'Jaccard_bins':dict(bins),
                       'flagged_validation_representatives':len(flagged),'human_reviewed':0,
                       'zero_semantic_leakage_claimed':False,'scope':'initial user message representatives, train vs validation only',
                       'shared_clause_and_semantic_templates':'present; reserved outer variants do not establish independent natural language'}},flagged


def benchmark_exclusion(cases):
    paths=[ROOT/'evaluation/comparison-policy-20261006/primary-natural.jsonl',
           ROOT/'evaluation/comparison-policy-20261006/reviewed-candidates.jsonl']
    old=set(); hashes={}
    for path in paths:
        hashes[path.relative_to(ROOT).as_posix()]=bytes_record(path)
        for line in path.read_text(encoding='utf-8').splitlines():
            case=json.loads(line)
            for turn in case['turns']: old.add(normalized_input(turn['message']))
    matches=[]
    for case in cases:
        for turn in case['turns']:
            if normalized_input(turn['message']) in old: matches.append([case['scenario_id'],turn['turn_id']])
    if matches: raise ValueError('Recorded development utterance copied into v7')
    return {'protected_cohorts':hashes,'normalized_utterance_matches':0,'old_cases_imported_as_training':False,
            'scope':'Exact normalized utterance exclusion only; prior failures informed design, and semantic independence is not claimed'}


def reviewed_semantic_checks(case):
    """Additional regression checks motivated by the r4 agent review.

    These detect specific contradictions; they do not certify natural language.
    """
    initial=next(f['value'] for f in case['turns'][0]['facts'] if f['slot_id']=='target_description')
    scope=initial.rsplit(' for ',1)[1]
    if case['category']=='target_contrast':
        message=case['turns'][0]['message']
        match=re.search(r'Do not substitute (.*?) as my requested target\.',message) or re.search(r'\. ([^.]+) nahi chahiye\.',message)
        if not match: raise ValueError('Missing explicit target contrast')
        alternative=re.sub(r'^(daily|hourly|weekly|monthly|quarterly)\s+','',match.group(1))
        if alternative==initial.rsplit(' for ',1)[0]: raise ValueError('Positive target explicitly rejected in the same message')
    for turn in case['turns']:
        for fact in turn['facts']:
            slot=fact['slot_id']; old=turn['context_state'].get(slot)
            if old and old['value']==fact['value'] and fact['status']=='provided':
                raise ValueError('Unchanged prior fact repeated as a new provided update')
            if slot in {'target_description','problem_statement'} and ', not ' in fact['value']:
                raise ValueError('Rejected alternative included in positive target value')
            if slot in {'business_goal','decision_supported','success_criteria'} and scope not in fact['value']:
                raise ValueError('Requirement refers to a different source scope')
            if fact['status']=='confirmed' and not (old and old['value']==fact['value']):
                raise ValueError('Confirmation does not match prior value')


def build_artifacts(output,per_domain=200):
    """Write only development data. Never render, open or hash final labels."""
    output=Path(output).resolve()
    if output.exists(): raise ValueError('Immutable output exists; use a new revision')
    if output.name!=VERSION: raise ValueError('Use the reviewed development revision name')
    schema=load_schema(); policy=ComparisonPolicy(); plan=freeze_plan(per_domain,output.name)
    plan['final_rendering']='not_performed_development_only'
    # Filtering happens BEFORE build_scenario: no final labels are regenerated.
    cases=[build_scenario(row,schema,policy) for row in plan['assignments'] if row['split']!='final']
    for case in cases: reviewed_semantic_checks(case)
    stats,overlaps=development_audit(cases,plan,schema,policy)
    protected=benchmark_exclusion(cases)
    stats['planned_source_scenarios']=len(plan['assignments'])
    stats['rendered_source_scenarios']=len(cases)
    stats['planned_scenarios_by_split']=dict(Counter(r['split'] for r in plan['assignments']))
    stats['planned_languages_by_split']={s:dict(Counter(r['language'] for r in plan['assignments'] if r['split']==s)) for s in ('train','validation','final')}
    stats['schema_slots']=len(schema.slots); stats['training_tasks']=['extract']
    output.mkdir(parents=True); files={}
    for split in ('train','validation'):
        subset=[c for c in cases if c['split']==split]
        files[f'splits/{split}.jsonl.gz']=write_gzip(output/'splits'/f'{split}.jsonl.gz',subset)
        files[f'sft/{split}.jsonl.gz']=write_gzip(output/'sft'/f'{split}.jsonl.gz',(e for c in subset for e in sft_examples(c,schema)))
    sample=[]; seen=set()
    for case in cases:
        key=(case['domain'],case['language'],case['category'])
        if key not in seen: sample.append(case); seen.add(key)
    files['review-sample.jsonl.gz']=write_gzip(output/'review-sample.jsonl.gz',sample)
    files['review-queue.jsonl.gz']=write_gzip(output/'review-queue.jsonl.gz',(
        {'scenario_id':c['scenario_id'],'split':c['split'],'language':c['language'],'domain':c['domain'],
         'category':c['category'],'review_status':'pending','reviewer':None,
         'reasons':['agent_revised_candidate_requires_human_review']} for c in cases))
    files['overlap-review-queue.jsonl.gz']=write_gzip(output/'overlap-review-queue.jsonl.gz',overlaps)
    names=['local_slm_lab/corpus_v7.py','local_slm_lab/corpus_v7_reviewed_r7.py','local_slm_lab/corpus_v6.py',
           'local_slm_lab/corpus_v5.py','local_slm_lab/v5_prompts.py','local_slm_lab/comparison_policy.py']
    ancillary={'split-freeze.json':plan,'statistics.json':stats,'benchmark-exclusion.json':protected,
        'overlap-summary.json':stats['overlap'],'schema.json':schema.model_dump(mode='json'),
        'build-status.json':{'status':'complete_pending_human','human_review':'pending',
                            'final_status':'not_rendered_development_only','training_started':False,
                            'tokenizer_preflight':'pending','independent_unseen_evaluation':'pending'},
        'source-lock.json':{'fpy_commit':FPY_COMMIT,'parser_policy_sha256':policy.fingerprint,
            'schema_version':schema.version,'prompt_version':'v5-all-schema-1','model_revision':REVISION,
            'source_files':{name:source_sha256(ROOT/name) for name in names}}}
    for name,value in ancillary.items(): write_json(output/name,value); files[name]=bytes_record(output/name)
    manifest={'corpus_version':output.name,'build_status':'complete_pending_human','statistics':stats,
        'parser_policy_sha256':policy.fingerprint,'files':files,'sealed_files':{},
        'supersedes_development_candidate':'v7-20261008-r4','agent_review':'corpus-v7/agent-reviews/v7-20261008-r4-20261009',
        'final_status':'not_rendered_development_only',
        'limits':['Agent review is not independent human approval',
                  'Controlled synthetic clauses and semantic templates are shared across development splits',
                  'No final labels generated or accessed; r4 sealed labels are not a matching r5 final benchmark',
                  'No positive credentials, dont_care, conflict, known-value withdrawal or STT training',
                  'v5 prompt unchanged: confirmation and PS/target annotation conventions still require human adjudication',
                  'No measured model improvement; tokenizer preflight is a separate receipt']}
    write_json(output/'manifest.json',manifest)
    write_json(output/'manifest.sha256.json',{'manifest.json':bytes_record(output/'manifest.json')})
    return manifest


def verify_artifacts(output):
    from local_slm_lab.corpus_v7 import verify_artifacts as frozen_verifier
    result=frozen_verifier(output)
    for split in ('train','validation'):
        for case in read_gzip(Path(output)/'splits'/f'{split}.jsonl.gz'): reviewed_semantic_checks(case)
    result['agent_semantic_regressions']='pass'
    result['final_labels_generated']=False
    return result


