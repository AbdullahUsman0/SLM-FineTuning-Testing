"""Verify development labels and SFT; never deserialize final labels."""
import argparse
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.corpus_v7 import verify_artifacts

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--sealed-output',type=Path)
    a=p.parse_args(); print(json.dumps(verify_artifacts(a.output,a.sealed_output),indent=2))
