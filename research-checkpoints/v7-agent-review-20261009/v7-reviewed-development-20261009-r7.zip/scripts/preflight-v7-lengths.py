"""Measure every development SFT example with the pinned tokenizer, no weights.

Use the training environment (transformers==5.15.0). Defaults to cached files
only. Never open final labels or truncate an example.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import importlib.util
from importlib.metadata import version
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REVISION='15852e8c16360a2fea060d615a32b45270f8a8fc'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def preflight(corpus,output,allow_download=False,limit=4096):
    from transformers import AutoTokenizer
    if version('transformers')!='5.15.0': raise ValueError('Use transformers==5.15.0 for measured training preflight')
    if output.exists(): raise FileExistsError('Preflight is immutable; choose another output')
    manifest=json.loads((corpus/'manifest.json').read_bytes())
    lock=json.loads((corpus/'manifest.sha256.json').read_bytes())
    if sha(corpus/'manifest.json')!=lock['manifest.json']['sha256']: raise ValueError('Manifest changed')
    spec=importlib.util.spec_from_file_location('v7_training_helpers',ROOT/'training/train_lora.py')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    tokenizer=AutoTokenizer.from_pretrained('Qwen/Qwen3.5-2B',revision=REVISION,local_files_only=not allow_download)
    results={}; keyed=[]
    for split in ('train','validation'):
        path=corpus/'sft'/f'{split}.jsonl.gz'
        if sha(path)!=manifest['files'][f'sft/{split}.jsonl.gz']['sha256']: raise ValueError('SFT changed')
        lengths=[]; histogram=Counter(); examples_above=[]
        with gzip.open(path,'rt',encoding='utf-8') as stream:
            for line in stream:
                example=json.loads(line); count=module.token_length(tokenizer,example['messages'])
                lengths.append(count); histogram[str((count//256)*256)]+=1
                metadata=example['metadata']
                if count>limit: examples_above.append({'scenario_id':metadata['scenario_id'],'turn_id':metadata['turn_id'],'tokens':count})
                keyed.append([split,metadata['scenario_id'],metadata['turn_id'],count])
        ordered=sorted(lengths)
        results[split]={'examples':len(lengths),'max_tokens':max(lengths),'p50_tokens':ordered[len(ordered)//2],
                        'p95_tokens':ordered[min(len(ordered)-1,int(len(ordered)*.95))],
                        'over_limit':len(examples_above),'histogram_256':dict(histogram),'over_limit_examples':examples_above}
        print(f'{split}: {len(lengths)} examples, maximum {max(lengths)}, over {limit}: {len(examples_above)}',flush=True)
    result={'corpus_version':manifest['corpus_version'],'corpus_manifest_sha256':sha(corpus/'manifest.json'),
            'model':'Qwen/Qwen3.5-2B','revision':REVISION,'transformers':version('transformers'),
            'tokenizers':version('tokenizers'),'chat_template_kwargs':{'enable_thinking':False},
            'tokenizer_class':type(tokenizer).__name__,'chat_template_sha256':hashlib.sha256(tokenizer.chat_template.encode()).hexdigest(),
            'trainer_token_length_helper_sha256':sha(ROOT/'training/train_lora.py'),
            'max_length':limit,'truncation':False,'results':results,'keyed_lengths_sha256':hashlib.sha256(json.dumps(keyed).encode()).hexdigest(),
            'status':'pass' if all(v['over_limit']==0 for v in results.values()) else 'fail_over_length',
            'final_labels_accessed':False,'model_weights_loaded':False,'training_started':False}
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x',encoding='utf-8',newline='\n') as stream: json.dump(result,stream,indent=2); stream.write('\n')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--corpus',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--max-length',type=int,default=4096); p.add_argument('--allow-tokenizer-download',action='store_true')
    a=p.parse_args(); result=preflight(a.corpus,a.output,a.allow_tokenizer_download,a.max_length)
    print(json.dumps({'status':result['status'],'max_length':result['max_length']},indent=2))
    if result['status']!='pass': raise SystemExit(1)
