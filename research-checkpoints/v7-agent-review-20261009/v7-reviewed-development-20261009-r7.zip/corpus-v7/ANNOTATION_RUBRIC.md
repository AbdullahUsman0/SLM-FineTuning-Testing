# V7 annotation rubric

Version v7-fact-ledger-rubric-1. Candidate labels are machine validated and await
human review. This is a training annotation contract; it does not change any
earlier comparison policy, gold files or measured scores.

## Grounding and values

1. Extract the facts explicitly stated in the current user message. Prior state
   and assistant text give context but are not current evidence. Every update
   points to a fact ID and an exact, nonempty current-message span.
2. A meaningful target in an explicit prediction request supports both
   problem_statement and target_description, with the same exact noun phrase.
   Do not add the introductory verb or invent a target column, goal or decision.
   This follows R1 of the reviewed development rubric.
3. Preserve free text exactly, including units, punctuation and quoted/numeric
   identifiers. Durations are objects with numeric periods and singular unit.
   Do not change months into days, percent into basis points or a financial
   target into a related series without explicit user specification.
4. All wire candidate_value fields are JSON strings containing one JSON-encoded
   value. Decode exactly once. Literal string `2026` is encoded as `"2026"` inside
   the envelope, not as the number 2026. Gold is never malformed assistant text.
5. Include every stated fact even if the selected slot asks about another field.
   A filename alone gives a source reference. It does not establish upload mode,
   actual file contents, time/target columns, credentials or privacy status.
   V7 deliberately includes source-reference-only initial turns followed by
   explicit mode and format additions. Do not assume CSV format from a suffix in
   those negative-inference training cases; review this conservative convention.

## Status and context

6. Explicit new facts and replacement corrections are provided. An explicit
   affirmation of the already stated value is confirmed. A replacement sets
   correction_detected=true and changes only the named requirements.
7. The pinned reducer may retain provided status even when an extractor emits a
   confirmed update; extraction-status accuracy and application-state status are
   distinct. V7 stores and replays the actual reducer state rather than claiming
   that it automatically implements a separate confirmation controller.
8. Unknown, undecided and unavailable information gives no update. This includes
   timezone, seasonal periods, prediction interval levels and access references
   when unset. Do not store the unknown sentence as a value, emit null/defaults,
   or label indifference without an explicit user statement of indifference.
9. These unknown controls refer to unset values. Withdrawal/deletion of a known
   value, unresolved conflicting values and explicit dont_care semantics are
   outside this candidate's new training contract. They need separately reviewed
   fixtures and a regression evaluation; absence here is not proof of support.
10. Distinguish native observation frequency, forecast generation cadence,
    source refresh, retraining and output row resolution. An explicitly unresolved
    “every hour” mention gives no arbitrary cadence update. The subsequent user
    clarification supplies the appropriate facts.
11. Domain contrast text may name a rejected alternative. Only the positive
    requested target is a candidate value. Preserve CPI level versus inflation,
    real versus nominal GDP, raw versus adjusted price, FX quote direction,
    crypto spot versus perpetuals and historical versus known-future covariates.
12. The model cannot repair an omitted old fact from nowhere. Seeded training
    contexts transparently contain an incorrect frequency and omitted unit;
    the next user explicitly restates both. Only this new evidence repairs them.
    These interventions are not measured model errors or natural rollout traces.
13. Explicit non-forecasting definitions are not_forecasting with no invented
    requirement updates. Most other turns retain established forecasting intent.

## Human review

Read the twenty domain review files and record the decisions in decisions.csv.
Check both false-positive and missing labels against the sentence, not a model's
prediction. Check multilingual meaning, rejected alternatives, duration roles,
source-only cases and structured lifecycle objects. The sample is stratified by
domain, language and behavior, not a random unbiased accuracy sample.

Review all flagged representative overlaps separately. Shared clause structures
are disclosed even when token Jaccard is low. No reviewer should sign “zero
leakage” based on this audit. The original 31-case study is protected against exact
normalized copying; its known failure themes informed development.

If a label or wording is rejected, document why and produce a new immutable
corpus revision. Do not change old study labels or create a blanket approval for
pending cases. Approval must state the actual sample/full scope, reviewer/date,
decision ledger hash, rubric hash and corpus manifest hash. The training
materializer checks these records but cannot itself authenticate a human review.
