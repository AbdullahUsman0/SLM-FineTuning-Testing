# V7 review examples for corporate_finance

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r7-dev/corporate_finance/0000
Split: train

### t1 initial_multislot

I need forecasts of recognized sales revenue for Merlow corporate finance site 2700. Measure the target in thousands of USD. The observations are recorded every 1 month. The forecast should extend 4 months ahead. Use the data source https://inputs.example/corporate_finance/2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Merlow corporate finance site 2700",
    "evidence": "I need forecasts of recognized sales revenue for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Merlow corporate finance site 2700",
    "evidence": "I need forecasts of recognized sales revenue for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measure the target in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "The forecast should extend 4 months ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Use the data source https://inputs.example/corporate_finance/2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called recognized_revenue. The timestamp column is observed_time. Access the input through an API. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "The target column is called recognized_revenue."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 7 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "The forecast should extend 7 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow corporate finance site 2700",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r7-dev/corporate_finance/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/corporate_finance/2700. Access the input through an API. I need the next 11 months predicted. There is one observed data point every 1 month. The target values are in thousands of USD. The quantity to predict is operating expenditure for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "The source is https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "I need the next 11 months predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is operating expenditure for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is operating expenditure for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column operating_expense as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "Use column operating_expense as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per month. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Return forecasts with resolution one prediction row per month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 14 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "I need the next 14 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r7-dev/corporate_finance/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict working-capital change for Merlow corporate finance site 2700. Keep the measurement unit as thousands of USD. The native sampling interval is 1 month. The forecast horizon is 18 months. Access the input through an API. Read the observations from https://inputs.example/corporate_finance/2700. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2700",
    "evidence": "Please predict working-capital change for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2700",
    "evidence": "Please predict working-capital change for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Keep the measurement unit as thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 18 months."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Read the observations from https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is working_capital_change. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "The target field name is working_capital_change."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 21 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 21 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 months. Read the observations from https://revised.example/corporate_finance/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 2 months."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/corporate_finance/2",
    "evidence": "Read the observations from https://revised.example/corporate_finance/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r7-dev/corporate_finance/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. Mera source reference https://inputs.example/corporate_finance/2700 hai. Access the input through an API. 8 mahinay ka horizon rakhein. Source observations arrive every 1 month. Target ko thousands of USD mein measure karein. My prediction target is net operating cash flow for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Mera source reference https://inputs.example/corporate_finance/2700 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "8 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ko thousands of USD mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow for Merlow corporate finance site 2700",
    "evidence": "My prediction target is net operating cash flow for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow for Merlow corporate finance site 2700",
    "evidence": "My prediction target is net operating cash flow for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. forecast type ki requirement probabilistic hai. I do not expect a repeating seasonal pattern. Timezone Europe/London use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Timezone Europe/London use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is observed_time. Target values field operating_cash_flow se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "Target values field operating_cash_flow se lein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 11 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 11 months."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r7-dev/corporate_finance/0004
Split: train

### t1 initial_multislot

I need forecasts of recognized sales revenue for Merlow corporate finance site 2700. Measure the target in thousands of USD. The observations are recorded every 1 month. The forecast should extend 15 months ahead. Access the input through an API. Use the data source https://inputs.example/corporate_finance/2700. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Merlow corporate finance site 2700",
    "evidence": "I need forecasts of recognized sales revenue for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Merlow corporate finance site 2700",
    "evidence": "I need forecasts of recognized sales revenue for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measure the target in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "The forecast should extend 15 months ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Use the data source https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 15 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 15 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 18 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "The forecast should extend 18 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 18 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 18 months ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r7-dev/corporate_finance/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/corporate_finance/2700. Access the input through an API. I need the next 5 months predicted. There is one observed data point every 1 month. The target values are in thousands of USD. The quantity to predict is operating expenditure for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "The source is https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "month"
    },
    "evidence": "I need the next 5 months predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is operating expenditure for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is operating expenditure for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column operating_expense as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "Use column operating_expense as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in thousands of USD. There is one observed data point every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 8 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "month"
    },
    "evidence": "I need the next 8 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r7-dev/corporate_finance/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict working-capital change for Merlow corporate finance site 2700. Keep the measurement unit as thousands of USD. The native sampling interval is 1 month. The forecast horizon is 12 months. Access the input through an API. Read the observations from https://inputs.example/corporate_finance/2700. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2700",
    "evidence": "Please predict working-capital change for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2700",
    "evidence": "Please predict working-capital change for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Keep the measurement unit as thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 12 months."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Read the observations from https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is working_capital_change. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "The target field name is working_capital_change."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The maximum response time is 8 seconds. Serialize the results as json. Deliver completed forecasts to https://planning.example/corporate_finance/2700. The source contains confidential synthetic records. Enforce these privacy restrictions: synthetic data only, no external redistribution. The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t3/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "second"
    },
    "evidence": "The maximum response time is 8 seconds."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t3/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "json",
    "evidence": "Serialize the results as json."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t3/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/corporate_finance/2700",
    "evidence": "Deliver completed forecasts to https://planning.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t3/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "Enforce these privacy restrictions: synthetic data only, no external redistribution."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t3/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "The source data usage license is synthetic examples released under CC0-1.0; no provider data redistributed."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Detailed data lineage is required. The required explanation level is feature_level. Human approval before modeling is required. Our operational goal is to prepare a planning reserve for Merlow corporate finance site 2700. My role in this project is financial planning analyst. This forecast will inform the decision to set the contingency allowance for Merlow corporate finance site 2700.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t4/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": true,
    "evidence": "Detailed data lineage is required."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t4/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "feature_level",
    "evidence": "The required explanation level is feature_level."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t4/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": true,
    "evidence": "Human approval before modeling is required."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow corporate finance site 2700",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t4/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "financial planning analyst",
    "evidence": "My role in this project is financial planning analyst."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t4/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Merlow corporate finance site 2700",
    "evidence": "This forecast will inform the decision to set the contingency allowance for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 15 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 15 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r7-dev/corporate_finance/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 19 months. Source observations arrive every 1 month. Use thousands of USD as the target unit. My prediction target is net operating cash flow for Merlow corporate finance site 2700. Do not substitute recognized sales revenue as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 19 months."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Use thousands of USD as the target unit."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow for Merlow corporate finance site 2700",
    "evidence": "My prediction target is net operating cash flow for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow for Merlow corporate finance site 2700",
    "evidence": "My prediction target is net operating cash flow for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field operating_cash_flow.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "Read target values from field operating_cash_flow."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is parquet. My source reference is https://inputs.example/corporate_finance/2700. Access the input through an API.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "My source reference is https://inputs.example/corporate_finance/2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 22 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 22 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of corporate finance. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r7-dev/corporate_finance/0008
Split: train

### t1 initial_multislot

Mujhe recognized sales revenue for Merlow corporate finance site 2700 ka forecast chahiye. Target ki unit thousands of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 9 mahinay tak chahiye. Input API ke zariye lein. Data source https://inputs.example/corporate_finance/2700 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Merlow corporate finance site 2700",
    "evidence": "Mujhe recognized sales revenue for Merlow corporate finance site 2700 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Merlow corporate finance site 2700",
    "evidence": "Mujhe recognized sales revenue for Merlow corporate finance site 2700 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Forecast aglay 9 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2700",
    "evidence": "Data source https://inputs.example/corporate_finance/2700 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein confidential synthetic records hain. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 12 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast aglay 12 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/corporate_finance/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 16 months predicted. The target values are in thousands of USD. The quantity to predict is operating expenditure for Merlow corporate finance site 2700. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "I need the next 16 months predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is operating expenditure for Merlow corporate finance site 2700."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2700",
    "evidence": "The quantity to predict is operating expenditure for Merlow corporate finance site 2700."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 month.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field observed_time. Use column operating_expense as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "Use column operating_expense as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 19 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "I need the next 19 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r7-dev/corporate_finance/0023
Split: train

### t1 initial_multislot

For my request,  The supplied data format is xlsx. The source is https://inputs.example/corporate_finance/2702. Select the source from the data catalog. I need the next 13 months predicted. There is one observed data point every 1 month. The target values are in thousands of USD. The quantity to predict is operating expenditure for Orven corporate finance site 2702.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2702",
    "evidence": "The source is https://inputs.example/corporate_finance/2702."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "I need the next 13 months predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Orven corporate finance site 2702",
    "evidence": "The quantity to predict is operating expenditure for Orven corporate finance site 2702."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Orven corporate finance site 2702",
    "evidence": "The quantity to predict is operating expenditure for Orven corporate finance site 2702."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. I do not expect a repeating seasonal pattern. Times are in Asia/Karachi.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "Times are in Asia/Karachi."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates are stored in field recorded_at. Use column operating_expense as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "Use column operating_expense as the target."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 16 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0023/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "I need the next 16 months predicted."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/corporate_finance/0029
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 4 months. Target ko thousands of USD mein measure karein. My prediction target is net operating cash flow for Orven corporate finance site 2702. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 4 months."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ko thousands of USD mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow for Orven corporate finance site 2702",
    "evidence": "My prediction target is net operating cash flow for Orven corporate finance site 2702."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow for Orven corporate finance site 2702",
    "evidence": "My prediction target is net operating cash flow for Orven corporate finance site 2702."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Produce new forecasts every 3 days. Source observations har 1 mahina aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Produce new forecasts every 3 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations har 1 mahina aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The time field name is recorded_at. Target values field operating_cash_flow se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "Target values field operating_cash_flow se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 7 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0029/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 7 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of corporate finance. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r7-dev/corporate_finance/0040
Split: train

### t1 initial_multislot

Mujhe recognized sales revenue for Talven corporate finance site 2704 ka forecast chahiye. Target ki unit thousands of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 14 mahinay tak chahiye. Data source https://inputs.example/corporate_finance/2704 use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Talven corporate finance site 2704",
    "evidence": "Mujhe recognized sales revenue for Talven corporate finance site 2704 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Talven corporate finance site 2704",
    "evidence": "Mujhe recognized sales revenue for Talven corporate finance site 2704 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "month"
    },
    "evidence": "Forecast aglay 14 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2704",
    "evidence": "Data source https://inputs.example/corporate_finance/2704 use karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam recognized_revenue hai. Timestamp column observed_time hai. Input API ke zariye lein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "Target column ka naam recognized_revenue hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 17 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Forecast aglay 17 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Talven corporate finance site 2704 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0040/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Talven corporate finance site 2704",
    "evidence": "business goal ki requirement prepare a planning reserve for Talven corporate finance site 2704 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r7-dev/corporate_finance/0048
Split: train

### t1 initial_multislot

I need forecasts of recognized sales revenue for Talven corporate finance site 2704. Measure the target in thousands of USD. The observations are recorded every 1 month. The forecast should extend 19 months ahead. Access the input through an API. Use the data source https://inputs.example/corporate_finance/2704. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Talven corporate finance site 2704",
    "evidence": "I need forecasts of recognized sales revenue for Talven corporate finance site 2704."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Talven corporate finance site 2704",
    "evidence": "I need forecasts of recognized sales revenue for Talven corporate finance site 2704."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measure the target in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The observations are recorded every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "The forecast should extend 19 months ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2704",
    "evidence": "Use the data source https://inputs.example/corporate_finance/2704."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is observed_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 22 months ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0048/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "The forecast should extend 22 months ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r7-dev/corporate_finance/0055
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target recognized sales revenue for Virelo corporate finance site 2705 hai. Measurement unit thousands of USD rakhein. Asli data ka sampling interval 1 mahina hai. Forecast horizon 9 mahinay hai. Input database se read karein. Observations https://inputs.example/corporate_finance/2705 se lein. Input ko json ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Virelo corporate finance site 2705",
    "evidence": "Prediction ka target recognized sales revenue for Virelo corporate finance site 2705 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Virelo corporate finance site 2705",
    "evidence": "Prediction ka target recognized sales revenue for Virelo corporate finance site 2705 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "month"
    },
    "evidence": "Forecast horizon 9 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2705",
    "evidence": "Observations https://inputs.example/corporate_finance/2705 se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input ko json ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field recognized_revenue hai. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "Target field recognized_revenue hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Asli data ka sampling interval 1 mahina hai. Measurement unit thousands of USD rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Asli data ka sampling interval 1 mahina hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 12 mahinay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0055/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "month"
    },
    "evidence": "Forecast horizon 12 mahinay hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r7-dev/corporate_finance/0067
Split: train

### t1 initial_multislot

Meri request yeh hai.  Aglay 17 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values thousands of USD mein hain. operating expenditure for Weslin corporate finance site 2706 predict karna hai. working-capital change nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Aglay 17 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target values thousands of USD mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Weslin corporate finance site 2706",
    "evidence": "operating expenditure for Weslin corporate finance site 2706 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Weslin corporate finance site 2706",
    "evidence": "operating expenditure for Weslin corporate finance site 2706 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field recorded_at mein hain. Column operating_expense ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates field recorded_at mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "Column operating_expense ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Diye hue data ka format xlsx hai. Source https://inputs.example/corporate_finance/2706 hai. Source data catalog se select karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Diye hue data ka format xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2706",
    "evidence": "Source https://inputs.example/corporate_finance/2706 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 20 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0067/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "Aglay 20 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r7-dev/corporate_finance/0072
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source corporate_finance_archive_2707.csv hai. Main data upload karunga. Aglay 10 mahinay predict karein. Har 1 mahina aik observed data point milta hai. Target values thousands of USD mein hain. net operating cash flow for Yarven corporate finance site 2707 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "corporate_finance_archive_2707.csv",
    "evidence": "Source corporate_finance_archive_2707.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Aglay 10 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target values thousands of USD mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow for Yarven corporate finance site 2707",
    "evidence": "net operating cash flow for Yarven corporate finance site 2707 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow for Yarven corporate finance site 2707",
    "evidence": "net operating cash flow for Yarven corporate finance site 2707 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field sample_date mein hain. Column operating_cash_flow ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates field sample_date mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "Column operating_cash_flow ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 13 mahinay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Aglay 13 mahinay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Source https://revised.example/corporate_finance/72 hai. Har 2 mahinay aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/corporate_finance/72",
    "evidence": "Source https://revised.example/corporate_finance/72 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0072/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Har 2 mahinay aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r7-dev/corporate_finance/0074
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. Mera source reference corporate_finance_archive_2707.csv hai. I will upload the data. 7 mahinay ka horizon rakhein. Source observations arrive every 1 month. Target ko thousands of USD mein measure karein. My prediction target is operating expenditure for Yarven corporate finance site 2707.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "corporate_finance_archive_2707.csv",
    "evidence": "Mera source reference corporate_finance_archive_2707.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "7 mahinay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Source observations arrive every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ko thousands of USD mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Yarven corporate finance site 2707",
    "evidence": "My prediction target is operating expenditure for Yarven corporate finance site 2707."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Yarven corporate finance site 2707",
    "evidence": "My prediction target is operating expenditure for Yarven corporate finance site 2707."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. Predict a horizon of 7 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 7,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. Predict a horizon of 7 months."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 10 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "Predict a horizon of 10 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. Predict a horizon of 10 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0074/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 10,
      "unit": "month"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. Predict a horizon of 10 months."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of corporate finance. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r7-dev/corporate_finance/0084
Split: train

### t1 initial_multislot

Mujhe recognized sales revenue for Merlow corporate finance site 2708 ka forecast chahiye. Target ki unit thousands of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 18 mahinay tak chahiye. Input API ke zariye lein. Data source https://inputs.example/corporate_finance/2708 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Merlow corporate finance site 2708",
    "evidence": "Mujhe recognized sales revenue for Merlow corporate finance site 2708 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Merlow corporate finance site 2708",
    "evidence": "Mujhe recognized sales revenue for Merlow corporate finance site 2708 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Forecast aglay 18 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2708",
    "evidence": "Data source https://inputs.example/corporate_finance/2708 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast aglay 18 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast aglay 18 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 21 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "Forecast aglay 21 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast aglay 21 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0084/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 21,
      "unit": "month"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast aglay 21 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r7-dev/corporate_finance/0086
Split: train

### t1 initial_multislot

Here is what I need.  Please predict working-capital change for Merlow corporate finance site 2708. Measurement unit thousands of USD rakhein. The native sampling interval is 1 month. Forecast horizon 15 mahinay hai. Access the input through an API. Observations https://inputs.example/corporate_finance/2708 se lein. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2708",
    "evidence": "Please predict working-capital change for Merlow corporate finance site 2708."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Merlow corporate finance site 2708",
    "evidence": "Please predict working-capital change for Merlow corporate finance site 2708."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Forecast horizon 15 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2708",
    "evidence": "Observations https://inputs.example/corporate_finance/2708 se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is working_capital_change. Timestamps ke liye column observed_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "The target field name is working_capital_change."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamps ke liye column observed_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

I expect a repeating seasonal pattern. Weekends aur non-business days exclude na karein. Use these fictional holiday calendars: synthetic reporting holiday. special events ki requirement [{"date": "2026-10-05", "name": "synthetic scheduled data release"}] hai. These regressors are observed only through the cutoff: lagged_target. known future covariates ki requirement announced_calendar_event hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t3/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Weekends aur non-business days exclude na karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t3/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "Use these fictional holiday calendars: synthetic reporting holiday."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t3/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "special events ki requirement [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t3/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "These regressors are observed only through the cutoff: lagged_target."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t3/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "known future covariates ki requirement announced_calendar_event hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The fixed attributes of each series are scope_sector. covariate availability ki requirement [{"available": "announced before cutoff", "name": "announced_calendar_event"}] hai. The external regressor source mappings are [{"name": "announced_calendar_event", "source": "synthetic_calendar"}]. forecast type ki requirement probabilistic hai. Return forecast quantiles at probabilities 0.1, 0.5, 0.9. scenario forecasts ki requirement [{"description": "synthetic planning sensitivity", "name": "stress"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t4/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_sector"
    ],
    "evidence": "The fixed attributes of each series are scope_sector."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t4/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "covariate availability ki requirement [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t4/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "The external regressor source mappings are [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}]."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t4/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t4/quantiles",
    "slot_id": "quantiles",
    "status": "provided",
    "value": [
      0.1,
      0.5,
      0.9
    ],
    "evidence": "Return forecast quantiles at probabilities 0.1, 0.5, 0.9."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t4/scenario_forecasts",
    "slot_id": "scenario_forecasts",
    "status": "provided",
    "value": [
      {
        "description": "synthetic planning sensitivity",
        "name": "stress"
      }
    ],
    "evidence": "scenario forecasts ki requirement [{\"description\": \"synthetic planning sensitivity\", \"name\": \"stress\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 18 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0086/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 18 months."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r7-dev/corporate_finance/0095
Split: train

### t1 initial_multislot

Here is what I need.  Please predict recognized sales revenue for Norelia corporate finance site 2709. Measurement unit thousands of USD rakhein. The native sampling interval is 1 month. Forecast horizon 19 mahinay hai. Read the input from a database. Observations https://inputs.example/corporate_finance/2709 se lein. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Norelia corporate finance site 2709",
    "evidence": "Please predict recognized sales revenue for Norelia corporate finance site 2709."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Norelia corporate finance site 2709",
    "evidence": "Please predict recognized sales revenue for Norelia corporate finance site 2709."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "month"
    },
    "evidence": "Forecast horizon 19 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2709",
    "evidence": "Observations https://inputs.example/corporate_finance/2709 se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is recognized_revenue. Timestamps ke liye column measurement_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "The target field name is recognized_revenue."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamps ke liye column measurement_time use karein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "month"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The native sampling interval is 1 month. Measurement unit thousands of USD rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "The native sampling interval is 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Measurement unit thousands of USD rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 22 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0095/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "month"
    },
    "evidence": "The forecast horizon is 22 months."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r7-dev/corporate_finance/0146
Split: train

### t1 initial_multislot

Mujhe recognized sales revenue for Weslin corporate finance site 2714 ka forecast chahiye. Target ki unit thousands of USD hai. Observations har 1 mahina record hoti hain. Forecast aglay 13 mahinay tak chahiye. Source data catalog se select karein. Data source https://inputs.example/corporate_finance/2714 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "recognized sales revenue for Weslin corporate finance site 2714",
    "evidence": "Mujhe recognized sales revenue for Weslin corporate finance site 2714 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "recognized sales revenue for Weslin corporate finance site 2714",
    "evidence": "Mujhe recognized sales revenue for Weslin corporate finance site 2714 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Observations har 1 mahina record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Forecast aglay 13 mahinay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2714",
    "evidence": "Data source https://inputs.example/corporate_finance/2714 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam recognized_revenue hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "recognized_revenue",
    "evidence": "Target column ka naam recognized_revenue hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

primary metric ki requirement mase hai. secondary metrics ki requirement rmse, smape hai. validation strategy ki requirement rolling_origin hai. backtest folds ki requirement 4 hai. holdout window length 3 mahinay hai. baseline model ki requirement naive hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t3/primary_metric",
    "slot_id": "primary_metric",
    "status": "provided",
    "value": "mase",
    "evidence": "primary metric ki requirement mase hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t3/secondary_metrics",
    "slot_id": "secondary_metrics",
    "status": "provided",
    "value": [
      "rmse",
      "smape"
    ],
    "evidence": "secondary metrics ki requirement rmse, smape hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t3/validation_strategy",
    "slot_id": "validation_strategy",
    "status": "provided",
    "value": "rolling_origin",
    "evidence": "validation strategy ki requirement rolling_origin hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t3/backtest_folds",
    "slot_id": "backtest_folds",
    "status": "provided",
    "value": 4,
    "evidence": "backtest folds ki requirement 4 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t3/test_window",
    "slot_id": "test_window",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "month"
    },
    "evidence": "holdout window length 3 mahinay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t3/baseline_model",
    "slot_id": "baseline_model",
    "status": "provided",
    "value": "naive",
    "evidence": "baseline model ki requirement naive hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

acceptable error ki requirement {"maximum": 5, "metric": "mae"} hai. inference mode ki requirement online hai. Naya forecast har 3 din banayein. Model har 1 mahina retrain karein. maximum response time 23 second hai. output format ki requirement xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t4/acceptable_error",
    "slot_id": "acceptable_error",
    "status": "provided",
    "value": {
      "maximum": 5,
      "metric": "mae"
    },
    "evidence": "acceptable error ki requirement {\"maximum\": 5, \"metric\": \"mae\"} hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t4/inference_mode",
    "slot_id": "inference_mode",
    "status": "provided",
    "value": "online",
    "evidence": "inference mode ki requirement online hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t4/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Naya forecast har 3 din banayein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t4/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Model har 1 mahina retrain karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t4/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "second"
    },
    "evidence": "maximum response time 23 second hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t4/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "output format ki requirement xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 16 mahinay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0146/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "Forecast aglay 16 mahinay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r7-dev/corporate_finance/0147
Split: train

### t1 initial_multislot

For my request,  I need the next 20 months predicted. Har 1 mahina aik observed data point milta hai. The target values are in thousands of USD. operating expenditure for Weslin corporate finance site 2714 predict karna hai. Do not substitute working-capital change as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "I need the next 20 months predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Har 1 mahina aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "The target values are in thousands of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Weslin corporate finance site 2714",
    "evidence": "operating expenditure for Weslin corporate finance site 2714 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Weslin corporate finance site 2714",
    "evidence": "operating expenditure for Weslin corporate finance site 2714 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field recorded_at. Column operating_expense ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "Column operating_expense ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is xlsx. Source https://inputs.example/corporate_finance/2714 hai. Select the source from the data catalog.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2714",
    "evidence": "Source https://inputs.example/corporate_finance/2714 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 23 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0147/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "month"
    },
    "evidence": "I need the next 23 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r7-dev/corporate_finance/0152
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for net operating cash flow for Yarven corporate finance site 2715. Target measurements ki unit thousands of USD hai. Each observed record covers 1 month. Future coverage 13 mahinay chahiye. I will upload the data. Diya hua source identifier corporate_finance_archive_2715.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "net operating cash flow for Yarven corporate finance site 2715",
    "evidence": "We need an outlook for net operating cash flow for Yarven corporate finance site 2715."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "net operating cash flow for Yarven corporate finance site 2715",
    "evidence": "We need an outlook for net operating cash flow for Yarven corporate finance site 2715."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target measurements ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "month"
    },
    "evidence": "Future coverage 13 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "corporate_finance_archive_2715.csv",
    "evidence": "Diya hua source identifier corporate_finance_archive_2715.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column operating_cash_flow. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_cash_flow",
    "evidence": "The response variable is stored in column operating_cash_flow."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 16 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 16 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. Each observed record covers 2 months. Diya hua source identifier https://revised.example/corporate_finance/152 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Each observed record covers 2 months."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0152/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/corporate_finance/152",
    "evidence": "Diya hua source identifier https://revised.example/corporate_finance/152 hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of corporate finance. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r7-dev/corporate_finance/0161
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. Source https://inputs.example/corporate_finance/2716 hai. Access the input through an API. Aglay 17 mahinay predict karein. There is one observed data point every 1 month. Target values thousands of USD mein hain. The quantity to predict is operating expenditure for Merlow corporate finance site 2716.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2716",
    "evidence": "Source https://inputs.example/corporate_finance/2716 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "month"
    },
    "evidence": "Aglay 17 mahinay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "There is one observed data point every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target values thousands of USD mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2716",
    "evidence": "The quantity to predict is operating expenditure for Merlow corporate finance site 2716."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "operating expenditure for Merlow corporate finance site 2716",
    "evidence": "The quantity to predict is operating expenditure for Merlow corporate finance site 2716."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Column operating_expense ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "operating_expense",
    "evidence": "Column operating_expense ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per month. Har 2 ghantay naya source update lein. Refit the forecasting model every 1 month. Predictions har 2 din refresh karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per month",
    "evidence": "Return forecasts with resolution one prediction row per month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghantay naya source update lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Predictions har 2 din refresh karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 20 months predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0161/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "month"
    },
    "evidence": "I need the next 20 months predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261009-r7-dev/corporate_finance/0180
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for working-capital change for Orven corporate finance site 2718. Target measurements ki unit thousands of USD hai. Each observed record covers 1 month. Future coverage 15 mahinay chahiye. The supplied source identifier is https://inputs.example/corporate_finance/2718.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "working-capital change for Orven corporate finance site 2718",
    "evidence": "We need an outlook for working-capital change for Orven corporate finance site 2718."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "working-capital change for Orven corporate finance site 2718",
    "evidence": "We need an outlook for working-capital change for Orven corporate finance site 2718."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "thousands of USD",
    "evidence": "Target measurements ki unit thousands of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Each observed record covers 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "month"
    },
    "evidence": "Future coverage 15 mahinay chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/corporate_finance/2718",
    "evidence": "The supplied source identifier is https://inputs.example/corporate_finance/2718."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column working_capital_change. Input timestamp identifier recorded_at hai. Select the source from the data catalog. Input container xlsx use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "working_capital_change",
    "evidence": "The response variable is stored in column working_capital_change."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input container xlsx use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 18 months.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "month"
    },
    "evidence": "The requested future coverage is 18 months."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Orven corporate finance site 2718.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/corporate_finance/0180/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven corporate finance site 2718",
    "evidence": "Our operational goal is to prepare a planning reserve for Orven corporate finance site 2718."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
