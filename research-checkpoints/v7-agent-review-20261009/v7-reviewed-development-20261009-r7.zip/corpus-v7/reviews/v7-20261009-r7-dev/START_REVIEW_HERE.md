# Human review of the current v7 development candidate

Read `docs/research/V7_AGENT_REVIEW_2026-10-09.md` and
`corpus-v7/ANNOTATION_RUBRIC.md` first. This folder is for
`v7-20261009-r7-dev` only. All human decisions are currently pending.

1. Review the domain `.md` files. For each sampled conversation, compare the
   user sentence with all expected values, status, evidence and state changes.
   Check missing labels as well as unwanted labels. Pay attention to exact
   financial target definitions and the meaning of multilingual text.
2. Record a genuine decision for each of the 524 sampled rows in `decisions.csv`,
   including reviewer, UTC time and substantive reason. Rejected/unclear cases
   require correction and a new immutable candidate; do not mass-approve rows.
3. Examine the 14 current overlap representatives in
   `corpus-v7/agent-reviews/v7-20261009-r7-dev-20261009/overlap-agent-decisions.json`.
   Record your own decisions and reasons separately. Shared synthetic templates
   remain even for pairs below the token-overlap threshold.
4. Explicitly adjudicate the six policy questions in the agent report. The
   existing prompt is unchanged; confirmation is a policy exception that still
   needs review. If a prompt change is needed, use a new revision and document
   the comparison effect.
5. After review, bind approval to the exact corpus, rubric, decision ledger and
   tokenizer receipt. The false template is not an approval. A review of the
   sample does not mean that all 3,400 development conversations were read.

Do not inspect or regenerate final labels for this task. No r7 final-label files
exist. Keep the old r4 sealed final as an archive, not a matching r7 benchmark.

No training, API comparison or teacher paper claim should describe this agent
review as independent human validation.
