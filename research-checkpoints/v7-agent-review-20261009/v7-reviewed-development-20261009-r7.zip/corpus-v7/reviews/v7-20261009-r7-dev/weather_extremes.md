# V7 review examples for weather_extremes

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## en core_recall

Scenario: v7-20261009-r7-dev/weather_extremes/0000
Split: train

### t1 initial_multislot

I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500. Measure the target in 0 or 1. The observations are recorded every 1 day. The forecast should extend 19 days ahead. Use the data source https://inputs.example/weather_extremes/1500.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500",
    "evidence": "I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500",
    "evidence": "I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Measure the target in 0 or 1."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "The forecast should extend 19 days ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "Use the data source https://inputs.example/weather_extremes/1500."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called heavy_rain_flag. The timestamp column is observed_time. Access the input through an API. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heavy_rain_flag",
    "evidence": "The target column is called heavy_rain_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 22 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "day"
    },
    "evidence": "The forecast should extend 22 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow weather extremes site 1500.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow weather extremes site 1500",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow weather extremes site 1500."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r7-dev/weather_extremes/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. Source https://inputs.example/weather_extremes/1500 hai. Access the input through an API. Aglay 9 haftay predict karein. There is one observed data point every 1 week. Target values days mein hain. The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "Source https://inputs.example/weather_extremes/1500 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "week"
    },
    "evidence": "Aglay 9 haftay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "There is one observed data point every 1 week."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "days",
    "evidence": "Target values days mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500",
    "evidence": "The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500",
    "evidence": "The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Column frost_days ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "frost_days",
    "evidence": "Column frost_days ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per week. Har 2 ghantay naya source update lein. Refit the forecasting model every 1 month. Predictions har 1 din refresh karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per week",
    "evidence": "Return forecasts with resolution one prediction row per week."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghantay naya source update lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Predictions har 1 din refresh karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 12 weeks predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "week"
    },
    "evidence": "I need the next 12 weeks predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r7-dev/weather_extremes/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500. Keep the measurement unit as 0 or 1. The native sampling interval is 1 day. The forecast horizon is 16 days. Access the input through an API. Read the observations from https://inputs.example/weather_extremes/1500. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500",
    "evidence": "Please predict high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500",
    "evidence": "Please predict high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Keep the measurement unit as 0 or 1."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 16 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "Read the observations from https://inputs.example/weather_extremes/1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is gust_flag. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_flag",
    "evidence": "The target field name is gust_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 19 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 19 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 days. Read the observations from https://revised.example/weather_extremes/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 2 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/weather_extremes/2",
    "evidence": "Read the observations from https://revised.example/weather_extremes/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r7-dev/weather_extremes/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is parquet. My source reference is https://inputs.example/weather_extremes/1500. Access the input through an API. Predict a horizon of 6 days. Source observations arrive every 1 day. Use 0 or 1 as the target unit. My prediction target is heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "My source reference is https://inputs.example/weather_extremes/1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 6 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Use 0 or 1 as the target unit."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500",
    "evidence": "My prediction target is heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500",
    "evidence": "My prediction target is heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. I do not expect a repeating seasonal pattern. Use timezone Europe/London.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "I do not expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Use timezone Europe/London."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is observed_time. Read target values from field heatwave_flag.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heatwave_flag",
    "evidence": "Read target values from field heatwave_flag."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 9 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 9 days."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r7-dev/weather_extremes/0004
Split: train

### t1 initial_multislot

I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500. Measure the target in 0 or 1. The observations are recorded every 1 day. The forecast should extend 13 days ahead. Access the input through an API. Use the data source https://inputs.example/weather_extremes/1500. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500",
    "evidence": "I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500",
    "evidence": "I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Measure the target in 0 or 1."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "The forecast should extend 13 days ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "Use the data source https://inputs.example/weather_extremes/1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 13 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 13 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 16 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "The forecast should extend 16 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 16 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 16 days ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r7-dev/weather_extremes/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/weather_extremes/1500. Access the input through an API. I need the next 20 weeks predicted. There is one observed data point every 1 week. The target values are in days. The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "The source is https://inputs.example/weather_extremes/1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "week"
    },
    "evidence": "I need the next 20 weeks predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "There is one observed data point every 1 week."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "days",
    "evidence": "The target values are in days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500",
    "evidence": "The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500",
    "evidence": "The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column frost_days as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "frost_days",
    "evidence": "Use column frost_days as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "week"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in days. There is one observed data point every 1 week.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "days",
    "evidence": "The target values are in days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "There is one observed data point every 1 week."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 23 weeks predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "week"
    },
    "evidence": "I need the next 23 weeks predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of weather extremes. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r7-dev/weather_extremes/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500. Keep the measurement unit as 0 or 1. The native sampling interval is 1 day. The forecast horizon is 10 days. Access the input through an API. Read the observations from https://inputs.example/weather_extremes/1500. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500",
    "evidence": "Please predict high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500",
    "evidence": "Please predict high-wind indicator defined as gust speed above 25 metres per second for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Keep the measurement unit as 0 or 1."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 10 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "Read the observations from https://inputs.example/weather_extremes/1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is gust_flag. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_flag",
    "evidence": "The target field name is gust_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

These regressors are observed only through the cutoff: lagged_target. These regressors are known for future periods: announced_calendar_event. The fixed attributes of each series are scope_elevation. The future regressor availability records are [{"available": "announced before cutoff", "name": "announced_calendar_event"}]. The external regressor source mappings are [{"name": "announced_calendar_event", "source": "synthetic_calendar"}]. The requested forecast output type is probabilistic.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t3/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "These regressors are observed only through the cutoff: lagged_target."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t3/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "These regressors are known for future periods: announced_calendar_event."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t3/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_elevation"
    ],
    "evidence": "The fixed attributes of each series are scope_elevation."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t3/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "The future regressor availability records are [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}]."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t3/external_covariate_sources",
    "slot_id": "external_covariate_sources",
    "status": "provided",
    "value": [
      {
        "name": "announced_calendar_event",
        "source": "synthetic_calendar"
      }
    ],
    "evidence": "The external regressor source mappings are [{\"name\": \"announced_calendar_event\", \"source\": \"synthetic_calendar\"}]."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Return forecast quantiles at probabilities 0.1, 0.5, 0.9. The alternative future scenarios are [{"description": "synthetic planning sensitivity", "name": "stress"}]. Round the output according to {"decimal_places": 2}. Make the result granularity one prediction row per day. Rank forecasts by the primary metric mase. Also report accuracy using rmse, smape.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t4/quantiles",
    "slot_id": "quantiles",
    "status": "provided",
    "value": [
      0.1,
      0.5,
      0.9
    ],
    "evidence": "Return forecast quantiles at probabilities 0.1, 0.5, 0.9."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t4/scenario_forecasts",
    "slot_id": "scenario_forecasts",
    "status": "provided",
    "value": [
      {
        "description": "synthetic planning sensitivity",
        "name": "stress"
      }
    ],
    "evidence": "The alternative future scenarios are [{\"description\": \"synthetic planning sensitivity\", \"name\": \"stress\"}]."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t4/rounding_rule",
    "slot_id": "rounding_rule",
    "status": "provided",
    "value": {
      "decimal_places": 2
    },
    "evidence": "Round the output according to {\"decimal_places\": 2}."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t4/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Make the result granularity one prediction row per day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t4/primary_metric",
    "slot_id": "primary_metric",
    "status": "provided",
    "value": "mase",
    "evidence": "Rank forecasts by the primary metric mase."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t4/secondary_metrics",
    "slot_id": "secondary_metrics",
    "status": "provided",
    "value": [
      "rmse",
      "smape"
    ],
    "evidence": "Also report accuracy using rmse, smape."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 13 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 13 days."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r7-dev/weather_extremes/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 17 days. Source observations arrive every 1 day. Use 0 or 1 as the target unit. My prediction target is heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500. Do not substitute daily heavy-rain indicator defined as rainfall above 50 millimetres as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 17 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Source observations arrive every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Use 0 or 1 as the target unit."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500",
    "evidence": "My prediction target is heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500",
    "evidence": "My prediction target is heatwave indicator defined as maximum temperature above 35 Celsius for Merlow weather extremes site 1500."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field heatwave_flag.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heatwave_flag",
    "evidence": "Read target values from field heatwave_flag."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is parquet. My source reference is https://inputs.example/weather_extremes/1500. Access the input through an API.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "My source reference is https://inputs.example/weather_extremes/1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 20 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Predict a horizon of 20 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r7-dev/weather_extremes/0008
Split: train

### t1 initial_multislot

Mujhe heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500 ka forecast chahiye. Target ki unit 0 or 1 hai. Observations har 1 din record hoti hain. Forecast aglay 7 din tak chahiye. Input API ke zariye lein. Data source https://inputs.example/weather_extremes/1500 use karein. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500",
    "evidence": "Mujhe heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500",
    "evidence": "Mujhe heavy-rain indicator defined as rainfall above 50 millimetres for Merlow weather extremes site 1500 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Forecast aglay 7 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1500",
    "evidence": "Data source https://inputs.example/weather_extremes/1500 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target column ka naam 2026 hai. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "Target column ka naam 2026 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein confidential synthetic records hain. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 10 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Forecast aglay 10 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/weather_extremes/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 14 weeks predicted. The target values are in days. The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "week"
    },
    "evidence": "I need the next 14 weeks predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "days",
    "evidence": "The target values are in days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500",
    "evidence": "The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500",
    "evidence": "The quantity to predict is count of frost days defined as minimum temperature below 0 Celsius for Merlow weather extremes site 1500."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 week.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "There is one observed data point every 1 week."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field observed_time. Use column frost_days as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "frost_days",
    "evidence": "Use column frost_days as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 weeks predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "week"
    },
    "evidence": "I need the next 17 weeks predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r7-dev/weather_extremes/0010
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format json hai. Source https://inputs.example/weather_extremes/1501 hai. Input database se read karein. Aglay 13 din predict karein. Har 1 din aik observed data point milta hai. Target values 0 or 1 mein hain. heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Diye hue data ka format json hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1501",
    "evidence": "Source https://inputs.example/weather_extremes/1501 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "day"
    },
    "evidence": "Aglay 13 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har 1 din aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target values 0 or 1 mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501",
    "evidence": "heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501",
    "evidence": "heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field measurement_time mein hain. Column heatwave_flag ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heatwave_flag",
    "evidence": "Column heatwave_flag ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Aglay 16 din predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Aglay 16 din predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Norelia weather extremes site 1501 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia weather extremes site 1501",
    "evidence": "business goal ki requirement prepare a planning reserve for Norelia weather extremes site 1501 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r7-dev/weather_extremes/0011
Split: train

### t1 initial_multislot

Here is what I need.  Please predict heavy-rain indicator defined as rainfall above 50 millimetres for Norelia weather extremes site 1501. Keep the measurement unit as 0 or 1. The native sampling interval is 1 day. The forecast horizon is 20 days. Read the input from a database. Read the observations from https://inputs.example/weather_extremes/1501. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Norelia weather extremes site 1501",
    "evidence": "Please predict heavy-rain indicator defined as rainfall above 50 millimetres for Norelia weather extremes site 1501."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Norelia weather extremes site 1501",
    "evidence": "Please predict heavy-rain indicator defined as rainfall above 50 millimetres for Norelia weather extremes site 1501."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Keep the measurement unit as 0 or 1."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 20 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1501",
    "evidence": "Read the observations from https://inputs.example/weather_extremes/1501."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is heavy_rain_flag. Use column measurement_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heavy_rain_flag",
    "evidence": "The target field name is heavy_rain_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Use column measurement_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Run forecast generation once every 2 days. Training should be repeated every 2 months. The input source refresh schedule is every 3 hours. Make the result granularity one prediction row per day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training should be repeated every 2 months."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Make the result granularity one prediction row per day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 23 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0011/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 23 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r7-dev/weather_extremes/0013
Split: train

### t1 initial_multislot

I need forecasts of high-wind indicator defined as gust speed above 25 metres per second for Norelia weather extremes site 1501. Target ki unit 0 or 1 hai. The observations are recorded every 1 day. Forecast aglay 17 din tak chahiye. Read the input from a database. Data source https://inputs.example/weather_extremes/1501 use karein. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Norelia weather extremes site 1501",
    "evidence": "I need forecasts of high-wind indicator defined as gust speed above 25 metres per second for Norelia weather extremes site 1501."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Norelia weather extremes site 1501",
    "evidence": "I need forecasts of high-wind indicator defined as gust speed above 25 metres per second for Norelia weather extremes site 1501."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "day"
    },
    "evidence": "Forecast aglay 17 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1501",
    "evidence": "Data source https://inputs.example/weather_extremes/1501 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

The timestamp timezone is UTC. Repeating seasonal pattern expect karta hoon. The seasonal cycles in observation periods are 7, 365. forecast type ki requirement probabilistic hai. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "The timestamp timezone is UTC."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      7,
      365
    ],
    "evidence": "The seasonal cycles in observation periods are 7, 365."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target column is called gust_flag. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_flag",
    "evidence": "The target column is called gust_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 20 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "The forecast should extend 20 days ahead."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r7-dev/weather_extremes/0018
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. The source is https://inputs.example/weather_extremes/1501. Read the input from a database. I need the next 18 days predicted. There is one observed data point every 1 day. The target values are in 0 or 1. The quantity to predict is heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1501",
    "evidence": "The source is https://inputs.example/weather_extremes/1501."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "I need the next 18 days predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "The target values are in 0 or 1."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501",
    "evidence": "The quantity to predict is heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501",
    "evidence": "The quantity to predict is heatwave indicator defined as maximum temperature above 35 Celsius for Norelia weather extremes site 1501."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Dates are stored in field measurement_time. Use column true as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "true",
    "evidence": "Use column true as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Negative target values are not valid. The source contains no personal, confidential, or regulated data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 21 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0018/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "I need the next 21 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r7-dev/weather_extremes/0022
Split: train

### t1 initial_multislot

I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Orven weather extremes site 1502. Target ki unit 0 or 1 hai. The observations are recorded every 1 day. Forecast aglay 4 din tak chahiye. Select the source from the data catalog. Data source https://inputs.example/weather_extremes/1502 use karein. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Orven weather extremes site 1502",
    "evidence": "I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Orven weather extremes site 1502."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Orven weather extremes site 1502",
    "evidence": "I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Orven weather extremes site 1502."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "day"
    },
    "evidence": "Forecast aglay 4 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1502",
    "evidence": "Data source https://inputs.example/weather_extremes/1502 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called heavy_rain_flag. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heavy_rain_flag",
    "evidence": "The target column is called heavy_rain_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 7 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "The forecast should extend 7 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The observations are recorded every 2 days. Data source https://revised.example/weather_extremes/22 use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 2 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0022/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/weather_extremes/22",
    "evidence": "Data source https://revised.example/weather_extremes/22 use karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r7-dev/weather_extremes/0024
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target high-wind indicator defined as gust speed above 25 metres per second for Orven weather extremes site 1502 hai. Measurement unit 0 or 1 rakhein. Asli data ka sampling interval 1 din hai. Forecast horizon 18 din hai. Source data catalog se select karein. Observations https://inputs.example/weather_extremes/1502 se lein. Input ko xlsx ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Orven weather extremes site 1502",
    "evidence": "Prediction ka target high-wind indicator defined as gust speed above 25 metres per second for Orven weather extremes site 1502 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Orven weather extremes site 1502",
    "evidence": "Prediction ka target high-wind indicator defined as gust speed above 25 metres per second for Orven weather extremes site 1502 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Measurement unit 0 or 1 rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Forecast horizon 18 din hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1502",
    "evidence": "Observations https://inputs.example/weather_extremes/1502 se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input ko xlsx ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 18 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 18 din hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 21 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "Forecast horizon 21 din hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 21 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0024/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 21 din hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r7-dev/weather_extremes/0033
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503 hai. Measurement unit 0 or 1 rakhein. Asli data ka sampling interval 1 din hai. Forecast horizon 5 din hai. Main data upload karunga. Observations weather_extremes_archive_1503.csv se lein. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503",
    "evidence": "Prediction ka target heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503",
    "evidence": "Prediction ka target heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Measurement unit 0 or 1 rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Asli data ka sampling interval 1 din hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "Forecast horizon 5 din hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_extremes_archive_1503.csv",
    "evidence": "Observations weather_extremes_archive_1503.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Timestamps ko Europe/London ke mutabiq samjhein. Repeating seasonal pattern expect karta hoon. seasonal periods ki requirement 7, 365 hai. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "Timestamps ko Europe/London ke mutabiq samjhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      7,
      365
    ],
    "evidence": "seasonal periods ki requirement 7, 365 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Target field heavy_rain_flag hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heavy_rain_flag",
    "evidence": "Target field heavy_rain_flag hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 8 din hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0033/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "Forecast horizon 8 din hai."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r7-dev/weather_extremes/0037
Split: train

### t1 initial_multislot

Here is what I need.  Please predict heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503. Measurement unit 0 or 1 rakhein. The native sampling interval is 1 day. Forecast horizon 16 din hai. Do not substitute weekly count of frost days defined as minimum temperature below 0 Celsius as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503",
    "evidence": "Please predict heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503",
    "evidence": "Please predict heavy-rain indicator defined as rainfall above 50 millimetres for Pelmar weather extremes site 1503."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Measurement unit 0 or 1 rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "day"
    },
    "evidence": "Forecast horizon 16 din hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is heavy_rain_flag. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heavy_rain_flag",
    "evidence": "The target field name is heavy_rain_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

I will upload the data. Observations weather_extremes_archive_1503.csv se lein. Read the input as csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_extremes_archive_1503.csv",
    "evidence": "Observations weather_extremes_archive_1503.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Read the input as csv."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 19 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0037/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 19 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r7-dev/weather_extremes/0042
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein high-wind indicator defined as gust speed above 25 metres per second for Talven weather extremes site 1504 ka outlook chahiye. Target measurements ki unit 0 or 1 hai. Har observed record 1 din cover karta hai. Future coverage 9 din chahiye. Input API ke zariye lein. Diya hua source identifier https://inputs.example/weather_extremes/1504 hai. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Talven weather extremes site 1504",
    "evidence": "Hamein high-wind indicator defined as gust speed above 25 metres per second for Talven weather extremes site 1504 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Talven weather extremes site 1504",
    "evidence": "Hamein high-wind indicator defined as gust speed above 25 metres per second for Talven weather extremes site 1504 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target measurements ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Future coverage 9 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1504",
    "evidence": "Diya hua source identifier https://inputs.example/weather_extremes/1504 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column gust_flag mein hai. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_flag",
    "evidence": "Response variable column gust_flag mein hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 12 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Future coverage 12 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Har observed record 2 din cover karta hai. Diya hua source identifier https://revised.example/weather_extremes/42 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Har observed record 2 din cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0042/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/weather_extremes/42",
    "evidence": "Diya hua source identifier https://revised.example/weather_extremes/42 hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r7-dev/weather_extremes/0055
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505 ka outlook chahiye. Target measurements ki unit 0 or 1 hai. Har observed record 1 din cover karta hai. Future coverage 7 din chahiye. Input database se read karein. Diya hua source identifier https://inputs.example/weather_extremes/1505 hai. Input container json use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505",
    "evidence": "Hamein heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505",
    "evidence": "Hamein heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target measurements ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "day"
    },
    "evidence": "Future coverage 7 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1505",
    "evidence": "Diya hua source identifier https://inputs.example/weather_extremes/1505 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input container json use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column heavy_rain_flag mein hai. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heavy_rain_flag",
    "evidence": "Response variable column heavy_rain_flag mein hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Har observed record 1 din cover karta hai. Target measurements ki unit 0 or 1 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Har observed record 1 din cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target measurements ki unit 0 or 1 hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 10 din chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0055/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "day"
    },
    "evidence": "Future coverage 10 din chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/weather_extremes/0059
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505. Target measurements ki unit 0 or 1 hai. The requested future coverage is 18 days. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505",
    "evidence": "We need an outlook for heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505",
    "evidence": "We need an outlook for heavy-rain indicator defined as rainfall above 50 millimetres for Virelo weather extremes site 1505."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target measurements ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 18 days."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Each observed record covers 1 day. Naye forecasts har 3 din issue karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Naye forecasts har 3 din issue karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The response variable is stored in column heavy_rain_flag. Input timestamp identifier measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heavy_rain_flag",
    "evidence": "The response variable is stored in column heavy_rain_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Input timestamp identifier measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 21 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0059/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 21 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r7-dev/weather_extremes/0064
Split: train

### t1 initial_multislot

Here is what I need.  Please predict high-wind indicator defined as gust speed above 25 metres per second for Weslin weather extremes site 1506. Measurement unit 0 or 1 rakhein. The native sampling interval is 1 day. Forecast horizon 11 din hai. Select the source from the data catalog. Observations https://inputs.example/weather_extremes/1506 se lein. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Weslin weather extremes site 1506",
    "evidence": "Please predict high-wind indicator defined as gust speed above 25 metres per second for Weslin weather extremes site 1506."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Weslin weather extremes site 1506",
    "evidence": "Please predict high-wind indicator defined as gust speed above 25 metres per second for Weslin weather extremes site 1506."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Measurement unit 0 or 1 rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The native sampling interval is 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "Forecast horizon 11 din hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1506",
    "evidence": "Observations https://inputs.example/weather_extremes/1506 se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast horizon is 11 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 11,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast horizon is 11 days."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 14 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "The forecast horizon is 14 days."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast horizon is 14 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0064/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 14,
      "unit": "day"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast horizon is 14 days."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r7-dev/weather_extremes/0067
Split: train

### t1 initial_multislot

Meri request yeh hai.  Aglay 15 haftay predict karein. Har 1 hafta aik observed data point milta hai. Target values days mein hain. count of frost days defined as minimum temperature below 0 Celsius for Weslin weather extremes site 1506 predict karna hai. daily high-wind indicator defined as gust speed above 25 metres per second nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "week"
    },
    "evidence": "Aglay 15 haftay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Har 1 hafta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "days",
    "evidence": "Target values days mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Weslin weather extremes site 1506",
    "evidence": "count of frost days defined as minimum temperature below 0 Celsius for Weslin weather extremes site 1506 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Weslin weather extremes site 1506",
    "evidence": "count of frost days defined as minimum temperature below 0 Celsius for Weslin weather extremes site 1506 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field recorded_at mein hain. Column frost_days ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates field recorded_at mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "frost_days",
    "evidence": "Column frost_days ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Diye hue data ka format xlsx hai. Source https://inputs.example/weather_extremes/1506 hai. Source data catalog se select karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Diye hue data ka format xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1506",
    "evidence": "Source https://inputs.example/weather_extremes/1506 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 18 haftay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0067/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "week"
    },
    "evidence": "Aglay 18 haftay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r7-dev/weather_extremes/0071
Split: train

### t1 initial_multislot

Mujhe high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1507 ka forecast chahiye. Target ki unit 0 or 1 hai. Observations har 1 din record hoti hain. Forecast aglay 18 din tak chahiye. Main data upload karunga. Data source weather_extremes_archive_1507.csv use karein. Input file format csv hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1507",
    "evidence": "Mujhe high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1507 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1507",
    "evidence": "Mujhe high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1507 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "day"
    },
    "evidence": "Forecast aglay 18 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_extremes_archive_1507.csv",
    "evidence": "Data source weather_extremes_archive_1507.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input file format csv hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam gust_flag hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_flag",
    "evidence": "Target column ka naam gust_flag hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Naya forecast har 2 din banayein. Model har 2 mahinay retrain karein. Source data har 5 ghantay refresh karein. Output resolution one prediction row per day chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Naya forecast har 2 din banayein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Model har 2 mahinay retrain karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Source data har 5 ghantay refresh karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per day",
    "evidence": "Output resolution one prediction row per day chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 21 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0071/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "day"
    },
    "evidence": "Forecast aglay 21 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r7-dev/weather_extremes/0076
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. Source weather_extremes_archive_1507.csv hai. I will upload the data. Aglay 19 din predict karein. There is one observed data point every 1 day. Target values 0 or 1 mein hain. The quantity to predict is heatwave indicator defined as maximum temperature above 35 Celsius for Yarven weather extremes site 1507.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_extremes_archive_1507.csv",
    "evidence": "Source weather_extremes_archive_1507.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "day"
    },
    "evidence": "Aglay 19 din predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "There is one observed data point every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target values 0 or 1 mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Yarven weather extremes site 1507",
    "evidence": "The quantity to predict is heatwave indicator defined as maximum temperature above 35 Celsius for Yarven weather extremes site 1507."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heatwave indicator defined as maximum temperature above 35 Celsius for Yarven weather extremes site 1507",
    "evidence": "The quantity to predict is heatwave indicator defined as maximum temperature above 35 Celsius for Yarven weather extremes site 1507."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Column heatwave_flag ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "heatwave_flag",
    "evidence": "Column heatwave_flag ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

I will consider the result useful if it meets MAE no more than 0.15 0 or 1 for Yarven weather extremes site 1507. decision supported ki requirement set the contingency allowance for Yarven weather extremes site 1507 hai. My role in this project is resilience planning analyst. business goal ki requirement prepare a planning reserve for Yarven weather extremes site 1507 hai. Human approval before modeling is not required. explainability level ki requirement none hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 0.15 0 or 1 for Yarven weather extremes site 1507",
    "evidence": "I will consider the result useful if it meets MAE no more than 0.15 0 or 1 for Yarven weather extremes site 1507."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Yarven weather extremes site 1507",
    "evidence": "decision supported ki requirement set the contingency allowance for Yarven weather extremes site 1507 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "resilience planning analyst",
    "evidence": "My role in this project is resilience planning analyst."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Yarven weather extremes site 1507",
    "evidence": "business goal ki requirement prepare a planning reserve for Yarven weather extremes site 1507 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Human approval before modeling is not required."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t3/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "none",
    "evidence": "explainability level ki requirement none hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Do not use observations after 2026-09-30T00:00:00+00:00. forecast start ki requirement 2026-10-01T00:00:00+00:00 hai. Use ordinary calendar days. aggregation method ki requirement mean hai. Negative target values are not valid. target bounds ki requirement {"max": 1, "min": 0} hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t4/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "Do not use observations after 2026-09-30T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "forecast start ki requirement 2026-10-01T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Use ordinary calendar days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "mean",
    "evidence": "aggregation method ki requirement mean hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t4/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1,
      "min": 0
    },
    "evidence": "target bounds ki requirement {\"max\": 1, \"min\": 0} hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 22 days predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0076/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "day"
    },
    "evidence": "I need the next 22 days predicted."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r7-dev/weather_extremes/0096
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format json hai. Mera source reference https://inputs.example/weather_extremes/1509 hai. Input database se read karein. 7 haftay ka horizon rakhein. Source observations har 1 hafta aati hain. Target ko days mein measure karein. count of frost days defined as minimum temperature below 0 Celsius for Norelia weather extremes site 1509 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Source serialization format json hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1509",
    "evidence": "Mera source reference https://inputs.example/weather_extremes/1509 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "week"
    },
    "evidence": "7 haftay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "week"
    },
    "evidence": "Source observations har 1 hafta aati hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "days",
    "evidence": "Target ko days mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Norelia weather extremes site 1509",
    "evidence": "count of frost days defined as minimum temperature below 0 Celsius for Norelia weather extremes site 1509 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "count of frost days defined as minimum temperature below 0 Celsius for Norelia weather extremes site 1509",
    "evidence": "count of frost days defined as minimum temperature below 0 Celsius for Norelia weather extremes site 1509 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam measurement_time hai. Target values field frost_days se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Time field ka naam measurement_time hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "frost_days",
    "evidence": "Target values field frost_days se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

invalid value policy ki requirement reject hai. outlier policy ki requirement cap hai. duplicate policy ki requirement reject hai. missing target policy ki requirement reject hai. missing timestamp policy ki requirement reject hai. known regime changes ki requirement [{"date": "2025-01-01", "description": "synthetic measurement methodology change"}] hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t3/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "invalid value policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t3/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "outlier policy ki requirement cap hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t3/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "duplicate policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t3/missing_target_policy",
    "slot_id": "missing_target_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "missing target policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t3/missing_timestamp_policy",
    "slot_id": "missing_timestamp_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "missing timestamp policy ki requirement reject hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t3/known_regime_changes",
    "slot_id": "known_regime_changes",
    "status": "provided",
    "value": [
      {
        "date": "2025-01-01",
        "description": "synthetic measurement methodology change"
      }
    ],
    "evidence": "known regime changes ki requirement [{\"date\": \"2025-01-01\", \"description\": \"synthetic measurement methodology change\"}] hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

past covariates ki requirement lagged_target hai. special events ki requirement [{"date": "2026-10-05", "name": "synthetic weather alert"}] hai. holidays ki requirement synthetic reporting holiday hai. Weekends aur non-business days exclude na karein. Repeating seasonal pattern expect karta hoon. minimum coverage ki requirement 96 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t4/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "past covariates ki requirement lagged_target hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t4/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic weather alert"
      }
    ],
    "evidence": "special events ki requirement [{\"date\": \"2026-10-05\", \"name\": \"synthetic weather alert\"}] hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t4/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "holidays ki requirement synthetic reporting holiday hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t4/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Weekends aur non-business days exclude na karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t4/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t4/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 96,
    "evidence": "minimum coverage ki requirement 96 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. 10 haftay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0096/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "week"
    },
    "evidence": "10 haftay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r7-dev/weather_extremes/0115
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for high-wind indicator defined as gust speed above 25 metres per second for Pelmar weather extremes site 1511. Target measurements ki unit 0 or 1 hai. Each observed record covers 1 day. Future coverage 5 din chahiye. I will upload the data. Diya hua source identifier weather_extremes_archive_1511.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Pelmar weather extremes site 1511",
    "evidence": "We need an outlook for high-wind indicator defined as gust speed above 25 metres per second for Pelmar weather extremes site 1511."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Pelmar weather extremes site 1511",
    "evidence": "We need an outlook for high-wind indicator defined as gust speed above 25 metres per second for Pelmar weather extremes site 1511."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target measurements ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "day"
    },
    "evidence": "Future coverage 5 din chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_extremes_archive_1511.csv",
    "evidence": "Diya hua source identifier weather_extremes_archive_1511.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column gust_flag. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_flag",
    "evidence": "The response variable is stored in column gust_flag."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "day"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Each observed record covers 1 day. Target measurements ki unit 0 or 1 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Each observed record covers 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target measurements ki unit 0 or 1 hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 8 days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0115/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "day"
    },
    "evidence": "The requested future coverage is 8 days."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r7-dev/weather_extremes/0128
Split: train

### t1 initial_multislot

I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Talven weather extremes site 1512. Target ki unit 0 or 1 hai. The observations are recorded every 1 day. Forecast aglay 20 din tak chahiye. Access the input through an API. Data source https://inputs.example/weather_extremes/1512 use karein. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Talven weather extremes site 1512",
    "evidence": "I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Talven weather extremes site 1512."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "heavy-rain indicator defined as rainfall above 50 millimetres for Talven weather extremes site 1512",
    "evidence": "I need forecasts of heavy-rain indicator defined as rainfall above 50 millimetres for Talven weather extremes site 1512."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "The observations are recorded every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "day"
    },
    "evidence": "Forecast aglay 20 din tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_extremes/1512",
    "evidence": "Data source https://inputs.example/weather_extremes/1512 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 23 days ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0128/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "day"
    },
    "evidence": "The forecast should extend 23 days ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/weather_extremes/0159
Split: train

### t1 initial_multislot

Mujhe high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1515 ka forecast chahiye. Target ki unit 0 or 1 hai. Forecast aglay 9 din tak chahiye. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1515",
    "evidence": "Mujhe high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1515 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1515",
    "evidence": "Mujhe high-wind indicator defined as gust speed above 25 metres per second for Yarven weather extremes site 1515 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "0 or 1",
    "evidence": "Target ki unit 0 or 1 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "day"
    },
    "evidence": "Forecast aglay 9 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Observations har 1 din record hoti hain. Naya forecast har 1 din banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Observations har 1 din record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naya forecast har 1 din banayein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Target column ka naam gust_flag hai. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gust_flag",
    "evidence": "Target column ka naam gust_flag hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 12 din tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_extremes/0159/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "day"
    },
    "evidence": "Forecast aglay 12 din tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
