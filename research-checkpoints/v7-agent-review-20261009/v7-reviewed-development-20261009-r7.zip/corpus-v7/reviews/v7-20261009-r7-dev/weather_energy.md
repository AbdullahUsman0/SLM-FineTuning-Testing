# V7 review examples for weather_energy

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## ur core_recall

Scenario: v7-20261009-r7-dev/weather_energy/0000
Split: train

### t1 initial_multislot

Mujhe natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800 ka forecast chahiye. Target ki unit MMBtu hai. Observations har 1 ghanta record hoti hain. Forecast aglay 7 ghantay tak chahiye. Input database se read karein. Data source https://inputs.example/weather_energy/2800 use karein. Input file format json hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800",
    "evidence": "Mujhe natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800",
    "evidence": "Mujhe natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "MMBtu",
    "evidence": "Target ki unit MMBtu hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 7 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "Data source https://inputs.example/weather_energy/2800 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input file format json hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam gas_demand hai. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gas_demand",
    "evidence": "Target column ka naam gas_demand hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 10 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 10 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Merlow weather energy site 2800 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow weather energy site 2800",
    "evidence": "business goal ki requirement prepare a planning reserve for Merlow weather energy site 2800 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r7-dev/weather_energy/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. The source is https://inputs.example/weather_energy/2800. Read the input from a database. I need the next 14 hours predicted. There is one observed data point every 1 hour. The target values are in megawatts. The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "The source is https://inputs.example/weather_energy/2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "I need the next 14 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "The target values are in megawatts."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Merlow weather energy site 2800",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Merlow weather energy site 2800",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Use column solar_mw as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "solar_mw",
    "evidence": "Use column solar_mw as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per hour. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Return forecasts with resolution one prediction row per hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 17 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "I need the next 17 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r7-dev/weather_energy/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict electricity demand with weather covariates for Merlow weather energy site 2800. Keep the measurement unit as megawatts. The native sampling interval is 1 hour. The forecast horizon is 4 hours. Read the input from a database. Read the observations from https://inputs.example/weather_energy/2800. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Merlow weather energy site 2800",
    "evidence": "Please predict electricity demand with weather covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Merlow weather energy site 2800",
    "evidence": "Please predict electricity demand with weather covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Keep the measurement unit as megawatts."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 4 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "Read the observations from https://inputs.example/weather_energy/2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is load_mw. Use column measurement_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "load_mw",
    "evidence": "The target field name is load_mw."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Use column measurement_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 7 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 7 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 hours. Read the observations from https://revised.example/weather_energy/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 2 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/weather_energy/2",
    "evidence": "Read the observations from https://revised.example/weather_energy/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r7-dev/weather_energy/0003
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is json. My source reference is https://inputs.example/weather_energy/2800. Read the input from a database. Predict a horizon of 11 hours. Source observations arrive every 1 hour. Use USD per MWh as the target unit. My prediction target is electricity spot price with temperature covariates for Merlow weather energy site 2800.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "My source reference is https://inputs.example/weather_energy/2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 11 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MWh",
    "evidence": "Use USD per MWh as the target unit."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Merlow weather energy site 2800",
    "evidence": "My prediction target is electricity spot price with temperature covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Merlow weather energy site 2800",
    "evidence": "My prediction target is electricity spot price with temperature covariates for Merlow weather energy site 2800."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. The requested forecast output type is probabilistic. The seasonal cycles in observation periods are 24, 168. I expect a repeating seasonal pattern. Use timezone UTC.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "The seasonal cycles in observation periods are 24, 168."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Use timezone UTC."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The time field name is measurement_time. Read target values from field power_price.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "power_price",
    "evidence": "Read target values from field power_price."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 14 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 14 hours."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r7-dev/weather_energy/0004
Split: train

### t1 initial_multislot

I need forecasts of natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800. Measure the target in MMBtu. The observations are recorded every 1 hour. The forecast should extend 18 hours ahead. Read the input from a database. Use the data source https://inputs.example/weather_energy/2800. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800",
    "evidence": "I need forecasts of natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800",
    "evidence": "I need forecasts of natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "MMBtu",
    "evidence": "Measure the target in MMBtu."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 18 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "Use the data source https://inputs.example/weather_energy/2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 18 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 18 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 21 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 21 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 21 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 21 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r7-dev/weather_energy/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is json. The source is https://inputs.example/weather_energy/2800. Read the input from a database. I need the next 8 hours predicted. There is one observed data point every 1 hour. The target values are in megawatts. The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The supplied data format is json."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "The source is https://inputs.example/weather_energy/2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "I need the next 8 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "The target values are in megawatts."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Merlow weather energy site 2800",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Merlow weather energy site 2800",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field measurement_time. Use column solar_mw as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "solar_mw",
    "evidence": "Use column solar_mw as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in megawatts. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "The target values are in megawatts."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 11 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "I need the next 11 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r7-dev/weather_energy/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict electricity demand with weather covariates for Merlow weather energy site 2800. Keep the measurement unit as megawatts. The native sampling interval is 1 hour. The forecast horizon is 15 hours. Read the input from a database. Read the observations from https://inputs.example/weather_energy/2800. Read the input as json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Merlow weather energy site 2800",
    "evidence": "Please predict electricity demand with weather covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Merlow weather energy site 2800",
    "evidence": "Please predict electricity demand with weather covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Keep the measurement unit as megawatts."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 15 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "Read the observations from https://inputs.example/weather_energy/2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Read the input as json."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is load_mw. Use column measurement_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "load_mw",
    "evidence": "The target field name is load_mw."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Use column measurement_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

The required explanation level is feature_level. Human approval before modeling is not required. Our operational goal is to prepare a planning reserve for Merlow weather energy site 2800. My role in this project is energy planning analyst. This forecast will inform the decision to set the contingency allowance for Merlow weather energy site 2800. I will consider the result useful if it meets MAE no more than 1 megawatts for Merlow weather energy site 2800.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t3/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "feature_level",
    "evidence": "The required explanation level is feature_level."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Human approval before modeling is not required."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow weather energy site 2800",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "energy planning analyst",
    "evidence": "My role in this project is energy planning analyst."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Merlow weather energy site 2800",
    "evidence": "This forecast will inform the decision to set the contingency allowance for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 1 megawatts for Merlow weather energy site 2800",
    "evidence": "I will consider the result useful if it meets MAE no more than 1 megawatts for Merlow weather energy site 2800."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Valid target bounds are {"max": 1000000, "min": 0}. Negative target values are not valid. Aggregate observations using last. Use ordinary calendar days. The first forecast period begins at 2026-10-01T00:00:00+00:00. Do not use observations after 2026-09-30T00:00:00+00:00.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t4/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "Valid target bounds are {\"max\": 1000000, \"min\": 0}."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "Aggregate observations using last."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Use ordinary calendar days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "The first forecast period begins at 2026-10-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t4/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "Do not use observations after 2026-09-30T00:00:00+00:00."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 18 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 18 hours."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r7-dev/weather_energy/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 5 hours. Source observations har 1 ghanta aati hain. Use USD per MWh as the target unit. electricity spot price with temperature covariates for Merlow weather energy site 2800 ke liye prediction bana dein. Do not substitute natural-gas demand with heating-degree-day covariates as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 5 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MWh",
    "evidence": "Use USD per MWh as the target unit."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Merlow weather energy site 2800",
    "evidence": "electricity spot price with temperature covariates for Merlow weather energy site 2800 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Merlow weather energy site 2800",
    "evidence": "electricity spot price with temperature covariates for Merlow weather energy site 2800 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is measurement_time. Target values field power_price se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The time field name is measurement_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "power_price",
    "evidence": "Target values field power_price se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is json. Mera source reference https://inputs.example/weather_energy/2800 hai. Read the input from a database.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The source serialization format is json."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "Mera source reference https://inputs.example/weather_energy/2800 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 8 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 8 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r7-dev/weather_energy/0008
Split: train

### t1 initial_multislot

I need forecasts of natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800. Measure the target in MMBtu. The observations are recorded every 1 hour. The forecast should extend 12 hours ahead. Read the input from a database. Use the data source https://inputs.example/weather_energy/2800. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800",
    "evidence": "I need forecasts of natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800",
    "evidence": "I need forecasts of natural-gas demand with heating-degree-day covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "MMBtu",
    "evidence": "Measure the target in MMBtu."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 12 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2800",
    "evidence": "Use the data source https://inputs.example/weather_energy/2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is measurement_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The timestamp column is measurement_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 15 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 15 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of weather energy. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/weather_energy/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 19 hours predicted. The target values are in megawatts. The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "I need the next 19 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "The target values are in megawatts."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Merlow weather energy site 2800",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Merlow weather energy site 2800",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Merlow weather energy site 2800."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field measurement_time. Use column solar_mw as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates are stored in field measurement_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "solar_mw",
    "evidence": "Use column solar_mw as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 22 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "hour"
    },
    "evidence": "I need the next 22 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en core_recall

Scenario: v7-20261009-r7-dev/weather_energy/0010
Split: train

### t1 initial_multislot

For my request,  The source is https://inputs.example/weather_energy/2801. I need the next 18 hours predicted. There is one observed data point every 1 hour. The target values are in USD per MWh. The quantity to predict is electricity spot price with temperature covariates for Norelia weather energy site 2801.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2801",
    "evidence": "The source is https://inputs.example/weather_energy/2801."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "I need the next 18 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MWh",
    "evidence": "The target values are in USD per MWh."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Norelia weather energy site 2801",
    "evidence": "The quantity to predict is electricity spot price with temperature covariates for Norelia weather energy site 2801."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Norelia weather energy site 2801",
    "evidence": "The quantity to predict is electricity spot price with temperature covariates for Norelia weather energy site 2801."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The supplied data format is xlsx. Select the source from the data catalog. Dates are stored in field recorded_at. Use column power_price as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The supplied data format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Dates are stored in field recorded_at."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "power_price",
    "evidence": "Use column power_price as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 21 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "I need the next 21 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Norelia weather energy site 2801.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0010/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Norelia weather energy site 2801",
    "evidence": "Our operational goal is to prepare a planning reserve for Norelia weather energy site 2801."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r7-dev/weather_energy/0011
Split: train

### t1 initial_multislot

Here is what I need.  Please predict natural-gas demand with heating-degree-day covariates for Norelia weather energy site 2801. Measurement unit MMBtu rakhein. The native sampling interval is 1 hour. Forecast horizon 8 ghantay hai. Select the source from the data catalog. Observations https://inputs.example/weather_energy/2801 se lein. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Norelia weather energy site 2801",
    "evidence": "Please predict natural-gas demand with heating-degree-day covariates for Norelia weather energy site 2801."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Norelia weather energy site 2801",
    "evidence": "Please predict natural-gas demand with heating-degree-day covariates for Norelia weather energy site 2801."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "MMBtu",
    "evidence": "Measurement unit MMBtu rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 8 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2801",
    "evidence": "Observations https://inputs.example/weather_energy/2801 se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is gas_demand. Timestamps ke liye column recorded_at use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "gas_demand",
    "evidence": "The target field name is gas_demand."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamps ke liye column recorded_at use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Run forecast generation once every 2 days. Training har 2 mahinay repeat karein. The input source refresh schedule is every 3 hours. Result granularity one prediction row per hour banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Run forecast generation once every 2 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Training har 2 mahinay repeat karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "hour"
    },
    "evidence": "The input source refresh schedule is every 3 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Result granularity one prediction row per hour banayein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 11 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0011/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 11 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r7-dev/weather_energy/0017
Split: train

### t1 initial_multislot

Mujhe electricity demand with weather covariates for Norelia weather energy site 2801 ka forecast chahiye. Target ki unit megawatts hai. Observations har 1 ghanta record hoti hain. Forecast aglay 16 ghantay tak chahiye. electricity spot price with temperature covariates nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Norelia weather energy site 2801",
    "evidence": "Mujhe electricity demand with weather covariates for Norelia weather energy site 2801 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Norelia weather energy site 2801",
    "evidence": "Mujhe electricity demand with weather covariates for Norelia weather energy site 2801 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target ki unit megawatts hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 16 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam load_mw hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "load_mw",
    "evidence": "Target column ka naam load_mw hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Source data catalog se select karein. Data source https://inputs.example/weather_energy/2801 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2801",
    "evidence": "Data source https://inputs.example/weather_energy/2801 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 19 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0017/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 19 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r7-dev/weather_energy/0025
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is csv. Mera source reference weather_energy_archive_2802.csv hai. I will upload the data. 13 ghantay ka horizon rakhein. Source observations arrive every 1 hour. Target ko USD per MWh mein measure karein. My prediction target is electricity spot price with temperature covariates for Orven weather energy site 2802.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The source serialization format is csv."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_energy_archive_2802.csv",
    "evidence": "Mera source reference weather_energy_archive_2802.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "13 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MWh",
    "evidence": "Target ko USD per MWh mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Orven weather energy site 2802",
    "evidence": "My prediction target is electricity spot price with temperature covariates for Orven weather energy site 2802."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Orven weather energy site 2802",
    "evidence": "My prediction target is electricity spot price with temperature covariates for Orven weather energy site 2802."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is sample_date. Target values field power_price se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "The time field name is sample_date."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "power_price",
    "evidence": "Target values field power_price se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. Use USD per MWh as the target unit. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MWh",
    "evidence": "Use USD per MWh as the target unit."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 16 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0025/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 16 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r7-dev/weather_energy/0027
Split: train

### t1 initial_multislot

For my request,  I need the next 10 hours predicted. There is one observed data point every 1 hour. The target values are in megawatts. The quantity to predict is solar generation with irradiance covariates for Orven weather energy site 2802. Do not substitute electricity demand with weather covariates as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "I need the next 10 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "The target values are in megawatts."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Orven weather energy site 2802",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Orven weather energy site 2802."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Orven weather energy site 2802",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Orven weather energy site 2802."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Use column solar_mw as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "solar_mw",
    "evidence": "Use column solar_mw as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The supplied data format is csv. The source is weather_energy_archive_2802.csv. I will upload the data.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_energy_archive_2802.csv",
    "evidence": "The source is weather_energy_archive_2802.csv."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 13 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0027/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "I need the next 13 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r7-dev/weather_energy/0028
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target electricity demand with weather covariates for Orven weather energy site 2802 hai. Measurement unit megawatts rakhein. Asli data ka sampling interval 1 ghanta hai. Forecast horizon 17 ghantay hai. Main data upload karunga. Observations weather_energy_archive_2802.csv se lein. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Orven weather energy site 2802",
    "evidence": "Prediction ka target electricity demand with weather covariates for Orven weather energy site 2802 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Orven weather energy site 2802",
    "evidence": "Prediction ka target electricity demand with weather covariates for Orven weather energy site 2802 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Measurement unit megawatts rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 1 ghanta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 17 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_energy_archive_2802.csv",
    "evidence": "Observations weather_energy_archive_2802.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Target field inflation (%) hai. Timestamps ke liye column sample_date use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "inflation (%)",
    "evidence": "Target field inflation (%) hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamps ke liye column sample_date use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein personal ya confidential data nahi hai. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 20 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0028/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 20 ghantay hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r7-dev/weather_energy/0041
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format json hai. Source https://inputs.example/weather_energy/2804 hai. Input database se read karein. Aglay 7 ghantay predict karein. Har 1 ghanta aik observed data point milta hai. Target values megawatts mein hain. solar generation with irradiance covariates for Talven weather energy site 2804 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Diye hue data ka format json hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2804",
    "evidence": "Source https://inputs.example/weather_energy/2804 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "Aglay 7 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target values megawatts mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Talven weather energy site 2804",
    "evidence": "solar generation with irradiance covariates for Talven weather energy site 2804 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Talven weather energy site 2804",
    "evidence": "solar generation with irradiance covariates for Talven weather energy site 2804 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field measurement_time mein hain. Column solar_mw ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Dates field measurement_time mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "solar_mw",
    "evidence": "Column solar_mw ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Forecast resolution one prediction row per hour rakhein. Har 2 ghantay naya source update lein. Forecasting model har 1 mahina refit karein. Predictions har 2 din refresh karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Forecast resolution one prediction row per hour rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghantay naya source update lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Forecasting model har 1 mahina refit karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Predictions har 2 din refresh karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Aglay 10 ghantay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0041/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Aglay 10 ghantay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels aur access details ka faisla baqi hai. Unspecified rakhein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r7-dev/weather_energy/0048
Split: train

### t1 initial_multislot

I need forecasts of natural-gas demand with heating-degree-day covariates for Talven weather energy site 2804. Target ki unit MMBtu hai. The observations are recorded every 1 hour. Forecast aglay 5 ghantay tak chahiye. Read the input from a database. Data source https://inputs.example/weather_energy/2804 use karein. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Talven weather energy site 2804",
    "evidence": "I need forecasts of natural-gas demand with heating-degree-day covariates for Talven weather energy site 2804."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "natural-gas demand with heating-degree-day covariates for Talven weather energy site 2804",
    "evidence": "I need forecasts of natural-gas demand with heating-degree-day covariates for Talven weather energy site 2804."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "MMBtu",
    "evidence": "Target ki unit MMBtu hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 5 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2804",
    "evidence": "Data source https://inputs.example/weather_energy/2804 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains no personal, confidential, or regulated data. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "The source contains no personal, confidential, or regulated data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 8 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0048/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 8 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r7-dev/weather_energy/0052
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format xlsx hai. Mera source reference https://inputs.example/weather_energy/2805 hai. Source data catalog se select karein. 8 ghantay ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko megawatts mein measure karein. solar generation with irradiance covariates for Virelo weather energy site 2805 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Source serialization format xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2805",
    "evidence": "Mera source reference https://inputs.example/weather_energy/2805 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "8 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target ko megawatts mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Virelo weather energy site 2805",
    "evidence": "solar generation with irradiance covariates for Virelo weather energy site 2805 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Virelo weather energy site 2805",
    "evidence": "solar generation with irradiance covariates for Virelo weather energy site 2805 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam recorded_at hai. Target values field solar_mw se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Time field ka naam recorded_at hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "solar_mw",
    "evidence": "Target values field solar_mw se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. 11 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "11 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Mera source reference https://revised.example/weather_energy/52 hai. Source observations har 2 ghantay aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/weather_energy/52",
    "evidence": "Mera source reference https://revised.example/weather_energy/52 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0052/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Source observations har 2 ghantay aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r7-dev/weather_energy/0056
Split: train

### t1 initial_multislot

Please record this.  The source serialization format is xlsx. Mera source reference https://inputs.example/weather_energy/2805 hai. Select the source from the data catalog. 19 ghantay ka horizon rakhein. Source observations arrive every 1 hour. Target ko megawatts mein measure karein. My prediction target is solar generation with irradiance covariates for Virelo weather energy site 2805.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The source serialization format is xlsx."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2805",
    "evidence": "Mera source reference https://inputs.example/weather_energy/2805 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "19 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target ko megawatts mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Virelo weather energy site 2805",
    "evidence": "My prediction target is solar generation with irradiance covariates for Virelo weather energy site 2805."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Virelo weather energy site 2805",
    "evidence": "My prediction target is solar generation with irradiance covariates for Virelo weather energy site 2805."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is recorded_at. Target values field solar_mw se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "The time field name is recorded_at."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "solar_mw",
    "evidence": "Target values field solar_mw se lein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Valid target bounds are {"max": 1000000, "min": 0}. success criteria ki requirement MAE no more than 1 megawatts for Virelo weather energy site 2805 hai. This forecast will inform the decision to set the contingency allowance for Virelo weather energy site 2805. stakeholder role ki requirement energy planning analyst hai. Our operational goal is to prepare a planning reserve for Virelo weather energy site 2805. Modeling se pehle human approval required hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t3/target_bounds",
    "slot_id": "target_bounds",
    "status": "provided",
    "value": {
      "max": 1000000,
      "min": 0
    },
    "evidence": "Valid target bounds are {\"max\": 1000000, \"min\": 0}."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t3/success_criteria",
    "slot_id": "success_criteria",
    "status": "provided",
    "value": "MAE no more than 1 megawatts for Virelo weather energy site 2805",
    "evidence": "success criteria ki requirement MAE no more than 1 megawatts for Virelo weather energy site 2805 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t3/decision_supported",
    "slot_id": "decision_supported",
    "status": "provided",
    "value": "set the contingency allowance for Virelo weather energy site 2805",
    "evidence": "This forecast will inform the decision to set the contingency allowance for Virelo weather energy site 2805."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t3/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "energy planning analyst",
    "evidence": "stakeholder role ki requirement energy planning analyst hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t3/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Virelo weather energy site 2805",
    "evidence": "Our operational goal is to prepare a planning reserve for Virelo weather energy site 2805."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t3/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": true,
    "evidence": "Modeling se pehle human approval required hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

The lead time is 1 hour. data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai. The first forecast period begins at 2026-10-01T00:00:00+00:00. Aam calendar ke din use karein. Aggregate observations using last. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t4/lead_time",
    "slot_id": "lead_time",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The lead time is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t4/data_cutoff",
    "slot_id": "data_cutoff",
    "status": "provided",
    "value": "2026-09-30T00:00:00+00:00",
    "evidence": "data cutoff ki requirement 2026-09-30T00:00:00+00:00 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t4/forecast_start",
    "slot_id": "forecast_start",
    "status": "provided",
    "value": "2026-10-01T00:00:00+00:00",
    "evidence": "The first forecast period begins at 2026-10-01T00:00:00+00:00."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t4/calendar_type",
    "slot_id": "calendar_type",
    "status": "provided",
    "value": "calendar",
    "evidence": "Aam calendar ke din use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t4/aggregation_method",
    "slot_id": "aggregation_method",
    "status": "provided",
    "value": "last",
    "evidence": "Aggregate observations using last."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t4/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 22 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0056/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 22 hours."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r7-dev/weather_energy/0063
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. Source weather_energy_archive_2806.csv hai. I will upload the data. Aglay 9 ghantay predict karein. There is one observed data point every 1 hour. Target values megawatts mein hain. The quantity to predict is solar generation with irradiance covariates for Weslin weather energy site 2806.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_energy_archive_2806.csv",
    "evidence": "Source weather_energy_archive_2806.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Aglay 9 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target values megawatts mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Weslin weather energy site 2806",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Weslin weather energy site 2806."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "solar generation with irradiance covariates for Weslin weather energy site 2806",
    "evidence": "The quantity to predict is solar generation with irradiance covariates for Weslin weather energy site 2806."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

I do not know the timezone, seasonal cycle lengths, interval coverage levels or access details. Leave those unset and do not guess.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Use prediction interval coverage percentages 80, 95. forecast type ki requirement probabilistic hai. The seasonal cycles in observation periods are 24, 168. Repeating seasonal pattern expect karta hoon. Times are in UTC.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "The seasonal cycles in observation periods are 24, 168."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "Repeating seasonal pattern expect karta hoon."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Times are in UTC."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Dates are stored in field sample_date. Column solar_mw ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "solar_mw",
    "evidence": "Column solar_mw ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 12 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0063/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "I need the next 12 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur confirmation_status

Scenario: v7-20261009-r7-dev/weather_energy/0064
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target electricity demand with weather covariates for Weslin weather energy site 2806 hai. Measurement unit megawatts rakhein. Asli data ka sampling interval 1 ghanta hai. Forecast horizon 16 ghantay hai. Main data upload karunga. Observations weather_energy_archive_2806.csv se lein. Input ko csv ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Weslin weather energy site 2806",
    "evidence": "Prediction ka target electricity demand with weather covariates for Weslin weather energy site 2806 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Weslin weather energy site 2806",
    "evidence": "Prediction ka target electricity demand with weather covariates for Weslin weather energy site 2806 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Measurement unit megawatts rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 1 ghanta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 16 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_energy_archive_2806.csv",
    "evidence": "Observations weather_energy_archive_2806.csv se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input ko csv ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 16 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 16 ghantay hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 19 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 19 ghantay hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 19 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0064/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "Main pehle se recorded horizon ki tasdeeq karta hoon. Forecast horizon 19 ghantay hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

Nayi request: weather energy ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/weather_energy/0079
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein electricity demand with weather covariates for Yarven weather energy site 2807 ka outlook chahiye. Target measurements ki unit megawatts hai. Future coverage 11 ghantay chahiye. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Yarven weather energy site 2807",
    "evidence": "Hamein electricity demand with weather covariates for Yarven weather energy site 2807 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Yarven weather energy site 2807",
    "evidence": "Hamein electricity demand with weather covariates for Yarven weather energy site 2807 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target measurements ki unit megawatts hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Future coverage 11 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Har observed record 1 ghanta cover karta hai. Naye forecasts har 2 din issue karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har observed record 1 ghanta cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "day"
    },
    "evidence": "Naye forecasts har 2 din issue karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Response variable column load_mw mein hai. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "load_mw",
    "evidence": "Response variable column load_mw mein hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 14 ghantay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0079/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Future coverage 14 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r7-dev/weather_energy/0093
Split: train

### t1 initial_multislot

Mujhe electricity demand with weather covariates for Norelia weather energy site 2809 ka forecast chahiye. Target ki unit megawatts hai. Observations har 1 ghanta record hoti hain. Forecast aglay 8 ghantay tak chahiye. Source data catalog se select karein. Data source https://inputs.example/weather_energy/2809 use karein. Input file format xlsx hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Norelia weather energy site 2809",
    "evidence": "Mujhe electricity demand with weather covariates for Norelia weather energy site 2809 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Norelia weather energy site 2809",
    "evidence": "Mujhe electricity demand with weather covariates for Norelia weather energy site 2809 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target ki unit megawatts hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 8 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/weather_energy/2809",
    "evidence": "Data source https://inputs.example/weather_energy/2809 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input file format xlsx hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

Timestamps ki timezone UTC hai. Repeating seasonal pattern expect nahi karta. forecast type ki requirement probabilistic hai. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "UTC",
    "evidence": "Timestamps ki timezone UTC hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Target column ka naam load_mw hai. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "load_mw",
    "evidence": "Target column ka naam load_mw hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 11 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0093/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 11 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed core_recall

Scenario: v7-20261009-r7-dev/weather_energy/0100
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for electricity demand with weather covariates for Orven weather energy site 2810. Target measurements ki unit megawatts hai. Each observed record covers 1 hour. Future coverage 15 ghantay chahiye. I will upload the data. Diya hua source identifier weather_energy_archive_2810.csv hai. The input container uses csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Orven weather energy site 2810",
    "evidence": "We need an outlook for electricity demand with weather covariates for Orven weather energy site 2810."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Orven weather energy site 2810",
    "evidence": "We need an outlook for electricity demand with weather covariates for Orven weather energy site 2810."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target measurements ki unit megawatts hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Future coverage 15 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_energy_archive_2810.csv",
    "evidence": "Diya hua source identifier weather_energy_archive_2810.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input container uses csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column load_mw. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "load_mw",
    "evidence": "The response variable is stored in column load_mw."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 18 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 18 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Orven weather energy site 2810.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0100/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven weather energy site 2810",
    "evidence": "Our operational goal is to prepare a planning reserve for Orven weather energy site 2810."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r7-dev/weather_energy/0145
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format csv hai. Mera source reference weather_energy_archive_2814.csv hai. Main data upload karunga. 9 ghantay ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko USD per MWh mein measure karein. electricity spot price with temperature covariates for Weslin weather energy site 2814 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Source serialization format csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "weather_energy_archive_2814.csv",
    "evidence": "Mera source reference weather_energy_archive_2814.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "9 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MWh",
    "evidence": "Target ko USD per MWh mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Weslin weather energy site 2814",
    "evidence": "electricity spot price with temperature covariates for Weslin weather energy site 2814 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity spot price with temperature covariates for Weslin weather energy site 2814",
    "evidence": "electricity spot price with temperature covariates for Weslin weather energy site 2814 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam sample_date hai. Target values field power_price se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Time field ka naam sample_date hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "power_price",
    "evidence": "Target values field power_price se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target ko USD per MWh mein measure karein. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per MWh",
    "evidence": "Target ko USD per MWh mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. 12 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0145/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "12 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/weather_energy/0159
Split: train

### t1 initial_multislot

I need forecasts of electricity demand with weather covariates for Yarven weather energy site 2815. Target ki unit megawatts hai. The forecast should extend 14 hours ahead. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "electricity demand with weather covariates for Yarven weather energy site 2815",
    "evidence": "I need forecasts of electricity demand with weather covariates for Yarven weather energy site 2815."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "electricity demand with weather covariates for Yarven weather energy site 2815",
    "evidence": "I need forecasts of electricity demand with weather covariates for Yarven weather energy site 2815."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "megawatts",
    "evidence": "Target ki unit megawatts hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 14 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. The observations are recorded every 1 hour. Naya forecast har 1 din banayein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naya forecast har 1 din banayein."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

The target column is called load_mw. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "load_mw",
    "evidence": "The target column is called load_mw."
  },
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 17 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/weather_energy/0159/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 17 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending
