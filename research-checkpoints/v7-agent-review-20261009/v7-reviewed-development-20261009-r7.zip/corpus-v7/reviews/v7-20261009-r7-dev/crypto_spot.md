# V7 review examples for crypto_spot

All decisions pending. Check wording, facts, scope, values, status, evidence and state transitions.

## mixed core_recall

Scenario: v7-20261009-r7-dev/crypto_spot/0000
Split: train

### t1 initial_multislot

I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300. Target ki unit ETH hai. The observations are recorded every 1 hour. Forecast aglay 9 ghantay tak chahiye. Use the data source https://inputs.example/crypto_spot/2300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "ETH",
    "evidence": "Target ki unit ETH hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 9 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "Use the data source https://inputs.example/crypto_spot/2300."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called eth_volume. Timestamp column observed_time hai. Access the input through an API. Input file format parquet hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eth_volume",
    "evidence": "The target column is called eth_volume."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input file format parquet hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 12 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 12 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Merlow crypto spot site 2300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0000/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Merlow crypto spot site 2300",
    "evidence": "Our operational goal is to prepare a planning reserve for Merlow crypto spot site 2300."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en cadence_contrast

Scenario: v7-20261009-r7-dev/crypto_spot/0001
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/crypto_spot/2300. Access the input through an API. I need the next 16 hours predicted. There is one observed data point every 1 hour. The target values are in percent. The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "The source is https://inputs.example/crypto_spot/2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "I need the next 16 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD hourly log return for Merlow crypto spot site 2300",
    "evidence": "The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD hourly log return for Merlow crypto spot site 2300",
    "evidence": "The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column btc_log_return as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_log_return",
    "evidence": "Use column btc_log_return as the target."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Return forecasts with resolution one prediction row per hour. Fetch a new source update every 2 hours. Refit the forecasting model every 1 month. Refresh the predictions every 1 day.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Return forecasts with resolution one prediction row per hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Fetch a new source update every 2 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Refit the forecasting model every 1 month."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 19 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0001/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "I need the next 19 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en correction_chain

Scenario: v7-20261009-r7-dev/crypto_spot/0002
Split: train

### t1 initial_multislot

Here is what I need.  Please predict digital-asset market capitalization for Merlow crypto spot site 2300. Keep the measurement unit as millions of USD. The native sampling interval is 1 hour. The forecast horizon is 6 hours. Access the input through an API. Read the observations from https://inputs.example/crypto_spot/2300. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "digital-asset market capitalization for Merlow crypto spot site 2300",
    "evidence": "Please predict digital-asset market capitalization for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "digital-asset market capitalization for Merlow crypto spot site 2300",
    "evidence": "Please predict digital-asset market capitalization for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 6,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 6 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "Read the observations from https://inputs.example/crypto_spot/2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is crypto_market_cap. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crypto_market_cap",
    "evidence": "The target field name is crypto_market_cap."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 9 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 9 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The native sampling interval is 2 hours. Read the observations from https://revised.example/crypto_spot/2.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 2 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0002/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/crypto_spot/2",
    "evidence": "Read the observations from https://revised.example/crypto_spot/2."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur unknown_then_value

Scenario: v7-20261009-r7-dev/crypto_spot/0003
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format parquet hai. Mera source reference https://inputs.example/crypto_spot/2300 hai. Input API ke zariye lein. 13 ghantay ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko USD per BTC mein measure karein. BTC/USD spot closing price for Merlow crypto spot site 2300 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Source serialization format parquet hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "Mera source reference https://inputs.example/crypto_spot/2300 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "13 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Target ko USD per BTC mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD spot closing price for Merlow crypto spot site 2300",
    "evidence": "BTC/USD spot closing price for Merlow crypto spot site 2300 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD spot closing price for Merlow crypto spot site 2300",
    "evidence": "BTC/USD spot closing price for Merlow crypto spot site 2300 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

prediction interval levels ki requirement 80, 95 hai. forecast type ki requirement probabilistic hai. Repeating seasonal pattern expect nahi karta. Timezone Asia/Karachi use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "forecast type ki requirement probabilistic hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "Timezone Asia/Karachi use karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

Time field ka naam observed_time hai. Target values field btc_usd_close se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Time field ka naam observed_time hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_usd_close",
    "evidence": "Target values field btc_usd_close se lein."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. 16 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0003/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "16 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t6 explicit_nonforecasting

Nayi request: crypto spot ki definition samjha dein. Forecast nahi chahiye.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## en confirmation_status

Scenario: v7-20261009-r7-dev/crypto_spot/0004
Split: train

### t1 initial_multislot

I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300. Measure the target in ETH. The observations are recorded every 1 hour. The forecast should extend 20 hours ahead. Access the input through an API. Use the data source https://inputs.example/crypto_spot/2300. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "ETH",
    "evidence": "Measure the target in ETH."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 20 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "Use the data source https://inputs.example/crypto_spot/2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 20 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 20 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 23 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 23,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 23 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 23 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0004/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 23,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 23 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en explicit_state_repair

Scenario: v7-20261009-r7-dev/crypto_spot/0005
Split: train

### t1 initial_multislot

For my request,  The supplied data format is parquet. The source is https://inputs.example/crypto_spot/2300. Access the input through an API. I need the next 10 hours predicted. There is one observed data point every 1 hour. The target values are in percent. The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The supplied data format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "The source is https://inputs.example/crypto_spot/2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "I need the next 10 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD hourly log return for Merlow crypto spot site 2300",
    "evidence": "The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD hourly log return for Merlow crypto spot site 2300",
    "evidence": "The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field observed_time. Use column btc_log_return as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_log_return",
    "evidence": "Use column btc_log_return as the target."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The target values are in percent. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 13 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0005/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 13,
      "unit": "hour"
    },
    "evidence": "I need the next 13 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en lifecycle_dense

Scenario: v7-20261009-r7-dev/crypto_spot/0006
Split: train

### t1 initial_multislot

Here is what I need.  Please predict digital-asset market capitalization for Merlow crypto spot site 2300. Keep the measurement unit as millions of USD. The native sampling interval is 1 hour. The forecast horizon is 17 hours. Access the input through an API. Read the observations from https://inputs.example/crypto_spot/2300. Read the input as parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "digital-asset market capitalization for Merlow crypto spot site 2300",
    "evidence": "Please predict digital-asset market capitalization for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "digital-asset market capitalization for Merlow crypto spot site 2300",
    "evidence": "Please predict digital-asset market capitalization for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 17 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "Read the observations from https://inputs.example/crypto_spot/2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Read the input as parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is crypto_market_cap. Use column observed_time for the timestamps.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crypto_market_cap",
    "evidence": "The target field name is crypto_market_cap."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Use column observed_time for the timestamps."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

For duplicate observations, use the policy latest. For unusual values, use the policy cap. For invalid values, use the policy reject. Require non-missing coverage of at least 86 percent. I expect a repeating seasonal pattern. Do not exclude weekends or non-business days.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t3/duplicate_policy",
    "slot_id": "duplicate_policy",
    "status": "provided",
    "value": "latest",
    "evidence": "For duplicate observations, use the policy latest."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t3/outlier_policy",
    "slot_id": "outlier_policy",
    "status": "provided",
    "value": "cap",
    "evidence": "For unusual values, use the policy cap."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t3/invalid_value_policy",
    "slot_id": "invalid_value_policy",
    "status": "provided",
    "value": "reject",
    "evidence": "For invalid values, use the policy reject."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t3/minimum_coverage",
    "slot_id": "minimum_coverage",
    "status": "provided",
    "value": 86,
    "evidence": "Require non-missing coverage of at least 86 percent."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t3/business_days_only",
    "slot_id": "business_days_only",
    "status": "provided",
    "value": false,
    "evidence": "Do not exclude weekends or non-business days."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Use these fictional holiday calendars: synthetic reporting holiday. The known special events are [{"date": "2026-10-05", "name": "synthetic scheduled data release"}]. These regressors are observed only through the cutoff: lagged_target. These regressors are known for future periods: announced_calendar_event. The fixed attributes of each series are scope_sector. The future regressor availability records are [{"available": "announced before cutoff", "name": "announced_calendar_event"}].

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t4/holidays",
    "slot_id": "holidays",
    "status": "provided",
    "value": [
      "synthetic reporting holiday"
    ],
    "evidence": "Use these fictional holiday calendars: synthetic reporting holiday."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t4/special_events",
    "slot_id": "special_events",
    "status": "provided",
    "value": [
      {
        "date": "2026-10-05",
        "name": "synthetic scheduled data release"
      }
    ],
    "evidence": "The known special events are [{\"date\": \"2026-10-05\", \"name\": \"synthetic scheduled data release\"}]."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t4/past_covariates",
    "slot_id": "past_covariates",
    "status": "provided",
    "value": [
      "lagged_target"
    ],
    "evidence": "These regressors are observed only through the cutoff: lagged_target."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t4/known_future_covariates",
    "slot_id": "known_future_covariates",
    "status": "provided",
    "value": [
      "announced_calendar_event"
    ],
    "evidence": "These regressors are known for future periods: announced_calendar_event."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t4/static_features",
    "slot_id": "static_features",
    "status": "provided",
    "value": [
      "scope_sector"
    ],
    "evidence": "The fixed attributes of each series are scope_sector."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t4/covariate_availability",
    "slot_id": "covariate_availability",
    "status": "provided",
    "value": [
      {
        "available": "announced before cutoff",
        "name": "announced_calendar_event"
      }
    ],
    "evidence": "The future regressor availability records are [{\"available\": \"announced before cutoff\", \"name\": \"announced_calendar_event\"}]."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 20 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0006/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 20 hours."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en target_contrast

Scenario: v7-20261009-r7-dev/crypto_spot/0007
Split: train

### t1 initial_multislot

Please record this.  Predict a horizon of 7 hours. Source observations arrive every 1 hour. Use USD per BTC as the target unit. My prediction target is BTC/USD spot closing price for Merlow crypto spot site 2300. Do not substitute ETH/USD spot traded volume in base asset units as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 7 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations arrive every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Use USD per BTC as the target unit."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD spot closing price for Merlow crypto spot site 2300",
    "evidence": "My prediction target is BTC/USD spot closing price for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD spot closing price for Merlow crypto spot site 2300",
    "evidence": "My prediction target is BTC/USD spot closing price for Merlow crypto spot site 2300."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The time field name is observed_time. Read target values from field btc_usd_close.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The time field name is observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_usd_close",
    "evidence": "Read target values from field btc_usd_close."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

The source serialization format is parquet. My source reference is https://inputs.example/crypto_spot/2300. Access the input through an API.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The source serialization format is parquet."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "My source reference is https://inputs.example/crypto_spot/2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. Predict a horizon of 10 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0007/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "Predict a horizon of 10 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en encoding_literal

Scenario: v7-20261009-r7-dev/crypto_spot/0008
Split: train

### t1 initial_multislot

I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300. Measure the target in ETH. The observations are recorded every 1 hour. The forecast should extend 14 hours ahead. Access the input through an API. Use the data source https://inputs.example/crypto_spot/2300. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "ETH",
    "evidence": "Measure the target in ETH."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 14 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2300",
    "evidence": "Use the data source https://inputs.example/crypto_spot/2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. The timestamp column is observed_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "The timestamp column is observed_time."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values are not valid.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values are not valid."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 17 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0008/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 17 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/crypto_spot/0009
Split: train

### t1 initial_multislot

For my request,  I need the next 4 hours predicted. The target values are in percent. The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300. Every hour is mentioned in the brief, but it is not yet specified whether this is sampling or forecast generation.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "I need the next 4 hours predicted."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "The target values are in percent."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD hourly log return for Merlow crypto spot site 2300",
    "evidence": "The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD hourly log return for Merlow crypto spot site 2300",
    "evidence": "The quantity to predict is BTC/USD hourly log return for Merlow crypto spot site 2300."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

The earlier every-hour phrase was not an agreed requirement. These are the two agreed schedules. Refresh the predictions every 1 day. There is one observed data point every 1 hour.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Refresh the predictions every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Dates are stored in field observed_time. Use column btc_log_return as the target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Dates are stored in field observed_time."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_log_return",
    "evidence": "Use column btc_log_return as the target."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 7 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0009/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "I need the next 7 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en unknown_then_value

Scenario: v7-20261009-r7-dev/crypto_spot/0013
Split: train

### t1 initial_multislot

I need forecasts of digital-asset market capitalization for Norelia crypto spot site 2301. Measure the target in millions of USD. The observations are recorded every 1 hour. The forecast should extend 7 hours ahead. Read the input from a database. Use the data source https://inputs.example/crypto_spot/2301. The input file format is json.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "digital-asset market capitalization for Norelia crypto spot site 2301",
    "evidence": "I need forecasts of digital-asset market capitalization for Norelia crypto spot site 2301."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "digital-asset market capitalization for Norelia crypto spot site 2301",
    "evidence": "I need forecasts of digital-asset market capitalization for Norelia crypto spot site 2301."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Measure the target in millions of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 7,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 7 hours ahead."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Read the input from a database."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2301",
    "evidence": "Use the data source https://inputs.example/crypto_spot/2301."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "The input file format is json."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

The timestamp timezone is Europe/London. I expect a repeating seasonal pattern. The seasonal cycles in observation periods are 24, 168. The requested forecast output type is probabilistic. Use prediction interval coverage percentages 80, 95.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Europe/London",
    "evidence": "The timestamp timezone is Europe/London."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": true,
    "evidence": "I expect a repeating seasonal pattern."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t3/seasonal_periods",
    "slot_id": "seasonal_periods",
    "status": "provided",
    "value": [
      24,
      168
    ],
    "evidence": "The seasonal cycles in observation periods are 24, 168."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "Use prediction interval coverage percentages 80, 95."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The target column is called crypto_market_cap. The timestamp column is measurement_time.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crypto_market_cap",
    "evidence": "The target column is called crypto_market_cap."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "The timestamp column is measurement_time."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 10 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0013/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 10,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 10 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## ur target_contrast

Scenario: v7-20261009-r7-dev/crypto_spot/0017
Split: train

### t1 initial_multislot

Mujhe digital-asset market capitalization for Norelia crypto spot site 2301 ka forecast chahiye. Target ki unit millions of USD hai. Observations har 1 ghanta record hoti hain. Forecast aglay 18 ghantay tak chahiye. BTC/USD spot closing price nahi chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "digital-asset market capitalization for Norelia crypto spot site 2301",
    "evidence": "Mujhe digital-asset market capitalization for Norelia crypto spot site 2301 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "digital-asset market capitalization for Norelia crypto spot site 2301",
    "evidence": "Mujhe digital-asset market capitalization for Norelia crypto spot site 2301 ka forecast chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Observations har 1 ghanta record hoti hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 18 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target column ka naam crypto_market_cap hai. Timestamp column measurement_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crypto_market_cap",
    "evidence": "Target column ka naam crypto_market_cap hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "measurement_time",
    "evidence": "Timestamp column measurement_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Input database se read karein. Data source https://inputs.example/crypto_spot/2301 use karein. Input file format json hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "database",
    "evidence": "Input database se read karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2301",
    "evidence": "Data source https://inputs.example/crypto_spot/2301 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "json",
    "evidence": "Input file format json hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Forecast aglay 21 ghantay tak chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0017/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 21,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 21 ghantay tak chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## en core_recall

Scenario: v7-20261009-r7-dev/crypto_spot/0020
Split: train

### t1 initial_multislot

Here is what I need.  Please predict digital-asset market capitalization for Orven crypto spot site 2302. Keep the measurement unit as millions of USD. The native sampling interval is 1 hour. The forecast horizon is 14 hours. Read the observations from https://inputs.example/crypto_spot/2302.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "digital-asset market capitalization for Orven crypto spot site 2302",
    "evidence": "Please predict digital-asset market capitalization for Orven crypto spot site 2302."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "digital-asset market capitalization for Orven crypto spot site 2302",
    "evidence": "Please predict digital-asset market capitalization for Orven crypto spot site 2302."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Keep the measurement unit as millions of USD."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The native sampling interval is 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 14 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2302",
    "evidence": "Read the observations from https://inputs.example/crypto_spot/2302."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target field name is crypto_market_cap. Use column recorded_at for the timestamps. Select the source from the data catalog. Read the input as xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crypto_market_cap",
    "evidence": "The target field name is crypto_market_cap."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Use column recorded_at for the timestamps."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Read the input as xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast horizon is 17 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "The forecast horizon is 17 hours."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

Our operational goal is to prepare a planning reserve for Orven crypto spot site 2302.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0020/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven crypto spot site 2302",
    "evidence": "Our operational goal is to prepare a planning reserve for Orven crypto spot site 2302."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed lifecycle_dense

Scenario: v7-20261009-r7-dev/crypto_spot/0026
Split: train

### t1 initial_multislot

I need forecasts of ETH/USD spot traded volume in base asset units for Orven crypto spot site 2302. Target ki unit ETH hai. The observations are recorded every 1 hour. Forecast aglay 5 ghantay tak chahiye. Select the source from the data catalog. Data source https://inputs.example/crypto_spot/2302 use karein. The input file format is xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Orven crypto spot site 2302",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Orven crypto spot site 2302."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Orven crypto spot site 2302",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Orven crypto spot site 2302."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "ETH",
    "evidence": "Target ki unit ETH hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 5 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2302",
    "evidence": "Data source https://inputs.example/crypto_spot/2302 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input file format is xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called eth_volume. Timestamp column recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eth_volume",
    "evidence": "The target column is called eth_volume."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Timestamp column recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

Generate a new forecast every 3 days. Model har 1 mahina retrain karein. The maximum response time is 3 seconds. output format ki requirement xlsx hai. Deliver completed forecasts to https://planning.example/crypto_spot/2302. Source mein confidential synthetic records hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Generate a new forecast every 3 days."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Model har 1 mahina retrain karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t3/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "second"
    },
    "evidence": "The maximum response time is 3 seconds."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t3/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "output format ki requirement xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t3/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/crypto_spot/2302",
    "evidence": "Deliver completed forecasts to https://planning.example/crypto_spot/2302."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "Source mein confidential synthetic records hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

Enforce these privacy restrictions: synthetic data only, no external redistribution. license ki requirement synthetic examples released under CC0-1.0; no provider data redistributed hai. Detailed data lineage is required. explainability level ki requirement feature_level hai. Human approval before modeling is required. business goal ki requirement prepare a planning reserve for Orven crypto spot site 2302 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t4/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "Enforce these privacy restrictions: synthetic data only, no external redistribution."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t4/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "license ki requirement synthetic examples released under CC0-1.0; no provider data redistributed hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t4/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": true,
    "evidence": "Detailed data lineage is required."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t4/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "feature_level",
    "evidence": "explainability level ki requirement feature_level hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t4/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": true,
    "evidence": "Human approval before modeling is required."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Orven crypto spot site 2302",
    "evidence": "business goal ki requirement prepare a planning reserve for Orven crypto spot site 2302 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 8 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0026/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 8,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 8 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur ambiguous_then_clarified

Scenario: v7-20261009-r7-dev/crypto_spot/0029
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  9 ghantay ka horizon rakhein. Target ko USD per BTC mein measure karein. BTC/USD spot closing price for Orven crypto spot site 2302 ke liye prediction bana dein. Har ghantay chahiye; abhi yeh nahi bataya ke data ka interval hai ya forecast banane ka schedule.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "9 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Target ko USD per BTC mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD spot closing price for Orven crypto spot site 2302",
    "evidence": "BTC/USD spot closing price for Orven crypto spot site 2302 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD spot closing price for Orven crypto spot site 2302",
    "evidence": "BTC/USD spot closing price for Orven crypto spot site 2302 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 cadence_clarified

Pehli har-ghantay wali baat final requirement nahi thi. Ab yeh do schedules final hain. Har 3 din naye forecasts banayein. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t2/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "day"
    },
    "evidence": "Har 3 din naye forecasts banayein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t2/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: False

### t3 incremental_identifiers

Time field ka naam recorded_at hai. Target values field btc_usd_close se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t3/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Time field ka naam recorded_at hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t3/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_usd_close",
    "evidence": "Target values field btc_usd_close se lein."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. 12 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0029/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "12 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed cadence_contrast

Scenario: v7-20261009-r7-dev/crypto_spot/0031
Split: train

### t1 initial_multislot

I need forecasts of digital-asset market capitalization for Pelmar crypto spot site 2303. Target ki unit millions of USD hai. The observations are recorded every 1 hour. Forecast aglay 15 ghantay tak chahiye. I will upload the data. Data source crypto_spot_archive_2303.csv use karein. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "digital-asset market capitalization for Pelmar crypto spot site 2303",
    "evidence": "I need forecasts of digital-asset market capitalization for Pelmar crypto spot site 2303."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "digital-asset market capitalization for Pelmar crypto spot site 2303",
    "evidence": "I need forecasts of digital-asset market capitalization for Pelmar crypto spot site 2303."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 15,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 15 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_spot_archive_2303.csv",
    "evidence": "Data source crypto_spot_archive_2303.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called crypto_market_cap. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crypto_market_cap",
    "evidence": "The target column is called crypto_market_cap."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Generate a new forecast every 1 day. Model har 2 mahinay retrain karein. Refresh the source data every 5 hours. Output resolution one prediction row per hour chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Generate a new forecast every 1 day."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Model har 2 mahinay retrain karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 5,
      "unit": "hour"
    },
    "evidence": "Refresh the source data every 5 hours."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Output resolution one prediction row per hour chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 18 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0031/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 18,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 18 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, prediction interval levels and access details still need a decision. Keep them unspecified.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur core_recall

Scenario: v7-20261009-r7-dev/crypto_spot/0040
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein ETH/USD spot traded volume in base asset units for Talven crypto spot site 2304 ka outlook chahiye. Target measurements ki unit ETH hai. Har observed record 1 ghanta cover karta hai. Future coverage 19 ghantay chahiye. Diya hua source identifier https://inputs.example/crypto_spot/2304 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Talven crypto spot site 2304",
    "evidence": "Hamein ETH/USD spot traded volume in base asset units for Talven crypto spot site 2304 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Talven crypto spot site 2304",
    "evidence": "Hamein ETH/USD spot traded volume in base asset units for Talven crypto spot site 2304 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "ETH",
    "evidence": "Target measurements ki unit ETH hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har observed record 1 ghanta cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "Future coverage 19 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2304",
    "evidence": "Diya hua source identifier https://inputs.example/crypto_spot/2304 hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column eth_volume mein hai. Input timestamp identifier observed_time hai. Input API ke zariye lein. Input container parquet use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "eth_volume",
    "evidence": "Response variable column eth_volume mein hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t2/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t2/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input container parquet use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Future coverage 22 ghantay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "hour"
    },
    "evidence": "Future coverage 22 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t4 purpose_addition

business goal ki requirement prepare a planning reserve for Talven crypto spot site 2304 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0040/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Talven crypto spot site 2304",
    "evidence": "business goal ki requirement prepare a planning reserve for Talven crypto spot site 2304 hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels ya access reference agree nahi hua. Baad mein bataunga.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed target_contrast

Scenario: v7-20261009-r7-dev/crypto_spot/0047
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for BTC/USD spot closing price for Talven crypto spot site 2304. Target measurements ki unit USD per BTC hai. Each observed record covers 1 hour. Future coverage 17 ghantay chahiye. Do not substitute ETH/USD spot traded volume in base asset units as my requested target.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD spot closing price for Talven crypto spot site 2304",
    "evidence": "We need an outlook for BTC/USD spot closing price for Talven crypto spot site 2304."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD spot closing price for Talven crypto spot site 2304",
    "evidence": "We need an outlook for BTC/USD spot closing price for Talven crypto spot site 2304."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Target measurements ki unit USD per BTC hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Future coverage 17 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The response variable is stored in column btc_usd_close. Input timestamp identifier observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_usd_close",
    "evidence": "The response variable is stored in column btc_usd_close."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Input timestamp identifier observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 source_details

Access the input through an API. Diya hua source identifier https://inputs.example/crypto_spot/2304 hai. The input container uses parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t3/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t3/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2304",
    "evidence": "Diya hua source identifier https://inputs.example/crypto_spot/2304 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t3/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input container uses parquet."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 20 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0047/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 20 hours."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

No timezone, seasonal cycle lengths, interval coverage levels or access reference has been agreed. I will provide them later.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of crypto spot. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending

## ur cadence_contrast

Scenario: v7-20261009-r7-dev/crypto_spot/0061
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein BTC/USD spot closing price for Weslin crypto spot site 2306 ka outlook chahiye. Target measurements ki unit USD per BTC hai. Har observed record 1 ghanta cover karta hai. Future coverage 14 ghantay chahiye. Source data catalog se select karein. Diya hua source identifier https://inputs.example/crypto_spot/2306 hai. Input container xlsx use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD spot closing price for Weslin crypto spot site 2306",
    "evidence": "Hamein BTC/USD spot closing price for Weslin crypto spot site 2306 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD spot closing price for Weslin crypto spot site 2306",
    "evidence": "Hamein BTC/USD spot closing price for Weslin crypto spot site 2306 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Target measurements ki unit USD per BTC hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har observed record 1 ghanta cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "Future coverage 14 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2306",
    "evidence": "Diya hua source identifier https://inputs.example/crypto_spot/2306 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Input container xlsx use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Response variable column btc_usd_close mein hai. Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_usd_close",
    "evidence": "Response variable column btc_usd_close mein hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 cadence_roles

Naye forecasts har 1 din issue karein. Model har 1 mahina dobara estimate karein. Source ingestion har 4 ghantay repeat hoti hai. Prediction rows ki resolution one prediction row per hour hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t3/prediction_frequency",
    "slot_id": "prediction_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "day"
    },
    "evidence": "Naye forecasts har 1 din issue karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "month"
    },
    "evidence": "Model har 1 mahina dobara estimate karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t3/refresh_frequency",
    "slot_id": "refresh_frequency",
    "status": "provided",
    "value": {
      "periods": 4,
      "unit": "hour"
    },
    "evidence": "Source ingestion har 4 ghantay repeat hoti hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t3/output_granularity",
    "slot_id": "output_granularity",
    "status": "provided",
    "value": "one prediction row per hour",
    "evidence": "Prediction rows ki resolution one prediction row per hour hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 17 ghantay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0061/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Future coverage 17 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal periods aur prediction interval levels abhi decide nahi aur access reference bhi nahi hai. Fill karne ke bajaye pooch lein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed unknown_then_value

Scenario: v7-20261009-r7-dev/crypto_spot/0063
Split: validation

### t1 initial_multislot

The analyst request is as follows.  We need an outlook for BTC/USD hourly log return for Weslin crypto spot site 2306. Target measurements ki unit percent hai. Each observed record covers 1 hour. Future coverage 11 ghantay chahiye. Select the source from the data catalog. Diya hua source identifier https://inputs.example/crypto_spot/2306 hai. The input container uses xlsx.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD hourly log return for Weslin crypto spot site 2306",
    "evidence": "We need an outlook for BTC/USD hourly log return for Weslin crypto spot site 2306."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD hourly log return for Weslin crypto spot site 2306",
    "evidence": "We need an outlook for BTC/USD hourly log return for Weslin crypto spot site 2306."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target measurements ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Each observed record covers 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Future coverage 11 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Select the source from the data catalog."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2306",
    "evidence": "Diya hua source identifier https://inputs.example/crypto_spot/2306 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "The input container uses xlsx."
  }
]
```

Intent: create_forecast; correction: False

### t2 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t3 explicit_unknown_resolution

All observed times use the Asia/Karachi timezone. Repeating seasonal pattern expect nahi karta. The requested forecast output type is probabilistic. prediction interval levels ki requirement 80, 95 hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t3/timezone",
    "slot_id": "timezone",
    "status": "provided",
    "value": "Asia/Karachi",
    "evidence": "All observed times use the Asia/Karachi timezone."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t3/known_seasonality",
    "slot_id": "known_seasonality",
    "status": "provided",
    "value": false,
    "evidence": "Repeating seasonal pattern expect nahi karta."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t3/forecast_type",
    "slot_id": "forecast_type",
    "status": "provided",
    "value": "probabilistic",
    "evidence": "The requested forecast output type is probabilistic."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t3/prediction_interval_levels",
    "slot_id": "prediction_interval_levels",
    "status": "provided",
    "value": [
      80,
      95
    ],
    "evidence": "prediction interval levels ki requirement 80, 95 hai."
  }
]
```

Intent: create_forecast; correction: False

### t4 incremental_identifiers

The response variable is stored in column btc_log_return. Input timestamp identifier recorded_at hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t4/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_log_return",
    "evidence": "The response variable is stored in column btc_log_return."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t4/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Input timestamp identifier recorded_at hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The requested future coverage is 14 hours.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0063/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "The requested future coverage is 14 hours."
  }
]
```

Intent: create_forecast; correction: True

Human decision and rationale: pending

## mixed explicit_state_repair

Scenario: v7-20261009-r7-dev/crypto_spot/0075
Split: train

### t1 initial_multislot

I need forecasts of digital-asset market capitalization for Yarven crypto spot site 2307. Target ki unit millions of USD hai. The observations are recorded every 1 hour. Forecast aglay 19 ghantay tak chahiye. I will upload the data. Data source crypto_spot_archive_2307.csv use karein. The input file format is csv.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "digital-asset market capitalization for Yarven crypto spot site 2307",
    "evidence": "I need forecasts of digital-asset market capitalization for Yarven crypto spot site 2307."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "digital-asset market capitalization for Yarven crypto spot site 2307",
    "evidence": "I need forecasts of digital-asset market capitalization for Yarven crypto spot site 2307."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target ki unit millions of USD hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 19 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_spot_archive_2307.csv",
    "evidence": "Data source crypto_spot_archive_2307.csv use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The input file format is csv."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

The target column is called crypto_market_cap. Timestamp column sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crypto_market_cap",
    "evidence": "The target column is called crypto_market_cap."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Timestamp column sample_date hai."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Replace the incorrect earlier frequency; I am restating the unit too. The observations are recorded every 1 hour. Target ki unit millions of USD hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Target ki unit millions of USD hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 22 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0075/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 22,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 22 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur lifecycle_dense

Scenario: v7-20261009-r7-dev/crypto_spot/0076
Split: train

### t1 initial_multislot

Meri request yeh hai.  Diye hue data ka format csv hai. Source crypto_spot_archive_2307.csv hai. Main data upload karunga. Aglay 9 ghantay predict karein. Har 1 ghanta aik observed data point milta hai. Target values USD per BTC mein hain. BTC/USD spot closing price for Yarven crypto spot site 2307 predict karna hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Diye hue data ka format csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_spot_archive_2307.csv",
    "evidence": "Source crypto_spot_archive_2307.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Aglay 9 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har 1 ghanta aik observed data point milta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Target values USD per BTC mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD spot closing price for Yarven crypto spot site 2307",
    "evidence": "BTC/USD spot closing price for Yarven crypto spot site 2307 predict karna hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD spot closing price for Yarven crypto spot site 2307",
    "evidence": "BTC/USD spot closing price for Yarven crypto spot site 2307 predict karna hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates field sample_date mein hain. Column btc_usd_close ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates field sample_date mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_usd_close",
    "evidence": "Column btc_usd_close ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 lifecycle_bundle

privacy constraints ki requirement synthetic data only, no external redistribution hai. Source mein personal ya confidential data nahi hai. destination ki requirement https://planning.example/crypto_spot/2307 hai. output format ki requirement csv hai. maximum response time 3 second hai. Forecasting model har 2 mahinay refit karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t3/privacy_constraints",
    "slot_id": "privacy_constraints",
    "status": "provided",
    "value": [
      "synthetic data only",
      "no external redistribution"
    ],
    "evidence": "privacy constraints ki requirement synthetic data only, no external redistribution hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t3/destination",
    "slot_id": "destination",
    "status": "provided",
    "value": "https://planning.example/crypto_spot/2307",
    "evidence": "destination ki requirement https://planning.example/crypto_spot/2307 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t3/output_format",
    "slot_id": "output_format",
    "status": "provided",
    "value": "csv",
    "evidence": "output format ki requirement csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t3/latency_requirement",
    "slot_id": "latency_requirement",
    "status": "provided",
    "value": {
      "periods": 3,
      "unit": "second"
    },
    "evidence": "maximum response time 3 second hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t3/retraining_frequency",
    "slot_id": "retraining_frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "month"
    },
    "evidence": "Forecasting model har 2 mahinay refit karein."
  }
]
```

Intent: create_forecast; correction: False

### t4 lifecycle_bundle

stakeholder role ki requirement digital-asset research analyst hai. business goal ki requirement prepare a planning reserve for Yarven crypto spot site 2307 hai. Modeling se pehle human approval required nahi hai. explainability level ki requirement none hai. Detailed data lineage required nahi hai. license ki requirement synthetic examples released under CC0-1.0; no provider data redistributed hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t4/stakeholder_role",
    "slot_id": "stakeholder_role",
    "status": "provided",
    "value": "digital-asset research analyst",
    "evidence": "stakeholder role ki requirement digital-asset research analyst hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t4/business_goal",
    "slot_id": "business_goal",
    "status": "provided",
    "value": "prepare a planning reserve for Yarven crypto spot site 2307",
    "evidence": "business goal ki requirement prepare a planning reserve for Yarven crypto spot site 2307 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t4/human_approval_required",
    "slot_id": "human_approval_required",
    "status": "provided",
    "value": false,
    "evidence": "Modeling se pehle human approval required nahi hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t4/explainability_level",
    "slot_id": "explainability_level",
    "status": "provided",
    "value": "none",
    "evidence": "explainability level ki requirement none hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t4/provenance_required",
    "slot_id": "provenance_required",
    "status": "provided",
    "value": false,
    "evidence": "Detailed data lineage required nahi hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t4/license",
    "slot_id": "license",
    "status": "provided",
    "value": "synthetic examples released under CC0-1.0; no provider data redistributed",
    "evidence": "license ki requirement synthetic examples released under CC0-1.0; no provider data redistributed hai."
  }
]
```

Intent: create_forecast; correction: False

### t5 targeted_replacement

Pehla horizon replace kar dein. Aglay 12 ghantay predict karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0076/t5/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "Aglay 12 ghantay predict karein."
  }
]
```

Intent: create_forecast; correction: True

### t6 unknown_omission

Timezone, seasonal cycle lengths, prediction interval percentages ya credential reference abhi kisi ne nahi bataya.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur correction_chain

Scenario: v7-20261009-r7-dev/crypto_spot/0082
Split: train

### t1 initial_multislot

Yeh details note kar lein.  Prediction ka target digital-asset market capitalization for Merlow crypto spot site 2308 hai. Measurement unit millions of USD rakhein. Asli data ka sampling interval 1 ghanta hai. Forecast horizon 9 ghantay hai. Input API ke zariye lein. Observations https://inputs.example/crypto_spot/2308 se lein. Input ko parquet ke taur par read karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "digital-asset market capitalization for Merlow crypto spot site 2308",
    "evidence": "Prediction ka target digital-asset market capitalization for Merlow crypto spot site 2308 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "digital-asset market capitalization for Merlow crypto spot site 2308",
    "evidence": "Prediction ka target digital-asset market capitalization for Merlow crypto spot site 2308 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "millions of USD",
    "evidence": "Measurement unit millions of USD rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 1 ghanta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 9,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 9 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Input API ke zariye lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2308",
    "evidence": "Observations https://inputs.example/crypto_spot/2308 se lein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "Input ko parquet ke taur par read karein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Target field crypto_market_cap hai. Timestamps ke liye column observed_time use karein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "crypto_market_cap",
    "evidence": "Target field crypto_market_cap hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamps ke liye column observed_time use karein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Pehla horizon replace kar dein. Forecast horizon 12 ghantay hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 12,
      "unit": "hour"
    },
    "evidence": "Forecast horizon 12 ghantay hai."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Pehli settings badal dein. Asli data ka sampling interval 2 ghantay hai. Observations https://revised.example/crypto_spot/82 se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Asli data ka sampling interval 2 ghantay hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0082/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/crypto_spot/82",
    "evidence": "Observations https://revised.example/crypto_spot/82 se lein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed encoding_literal

Scenario: v7-20261009-r7-dev/crypto_spot/0088
Split: train

### t1 initial_multislot

I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2308. Target ki unit ETH hai. The observations are recorded every 1 hour. Forecast aglay 17 ghantay tak chahiye. Access the input through an API. Data source https://inputs.example/crypto_spot/2308 use karein. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2308",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2308."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2308",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Merlow crypto spot site 2308."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "ETH",
    "evidence": "Target ki unit ETH hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 17,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 17 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2308",
    "evidence": "Data source https://inputs.example/crypto_spot/2308 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

The target column is called 2026. Timestamp column observed_time hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "2026",
    "evidence": "The target column is called 2026."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "observed_time",
    "evidence": "Timestamp column observed_time hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

The source contains confidential synthetic records. Negative target values allowed nahi hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": true,
    "evidence": "The source contains confidential synthetic records."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": false,
    "evidence": "Negative target values allowed nahi hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 20 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0088/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 20,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 20 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

I cannot supply a timezone, seasonal cycle lengths, prediction interval coverage or authorized access reference at this stage.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur encoding_literal

Scenario: v7-20261009-r7-dev/crypto_spot/0118
Split: validation

### t1 initial_multislot

Analyst ki request yeh hai.  Hamein BTC/USD hourly log return for Pelmar crypto spot site 2311 ka outlook chahiye. Target measurements ki unit percent hai. Har observed record 1 ghanta cover karta hai. Future coverage 16 ghantay chahiye. Main data upload karunga. Diya hua source identifier crypto_spot_archive_2311.csv hai. Input container csv use karta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD hourly log return for Pelmar crypto spot site 2311",
    "evidence": "Hamein BTC/USD hourly log return for Pelmar crypto spot site 2311 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD hourly log return for Pelmar crypto spot site 2311",
    "evidence": "Hamein BTC/USD hourly log return for Pelmar crypto spot site 2311 ka outlook chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "percent",
    "evidence": "Target measurements ki unit percent hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Har observed record 1 ghanta cover karta hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Future coverage 16 ghantay chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "Main data upload karunga."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_spot_archive_2311.csv",
    "evidence": "Diya hua source identifier crypto_spot_archive_2311.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "Input container csv use karta hai."
  }
]
```

Intent: create_forecast; correction: False

### t2 literal_identifier

Response variable column value "net" mein hai. Input timestamp identifier sample_date hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "value \"net\"",
    "evidence": "Response variable column value \"net\" mein hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Input timestamp identifier sample_date hai."
  }
]
```

Intent: create_forecast; correction: False

### t3 explicit_boolean

Source mein personal ya confidential data nahi hai. Negative target values allowed hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t3/contains_sensitive_data",
    "slot_id": "contains_sensitive_data",
    "status": "provided",
    "value": false,
    "evidence": "Source mein personal ya confidential data nahi hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t3/allow_negative_values",
    "slot_id": "allow_negative_values",
    "status": "provided",
    "value": true,
    "evidence": "Negative target values allowed hain."
  }
]
```

Intent: create_forecast; correction: False

### t4 targeted_replacement

Pehla horizon replace kar dein. Future coverage 19 ghantay chahiye.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0118/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "Future coverage 19 ghantay chahiye."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Timezone, seasonal cycle lengths, interval coverage levels aur access details nahi pata. Khud se fill na karein.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed confirmation_status

Scenario: v7-20261009-r7-dev/crypto_spot/0124
Split: train

### t1 initial_multislot

I need forecasts of ETH/USD spot traded volume in base asset units for Talven crypto spot site 2312. Target ki unit ETH hai. The observations are recorded every 1 hour. Forecast aglay 16 ghantay tak chahiye. Access the input through an API. Data source https://inputs.example/crypto_spot/2312 use karein. The input file format is parquet.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Talven crypto spot site 2312",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Talven crypto spot site 2312."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "ETH/USD spot traded volume in base asset units for Talven crypto spot site 2312",
    "evidence": "I need forecasts of ETH/USD spot traded volume in base asset units for Talven crypto spot site 2312."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "ETH",
    "evidence": "Target ki unit ETH hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "The observations are recorded every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "Forecast aglay 16 ghantay tak chahiye."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "api",
    "evidence": "Access the input through an API."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2312",
    "evidence": "Data source https://inputs.example/crypto_spot/2312 use karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "parquet",
    "evidence": "The input file format is parquet."
  }
]
```

Intent: create_forecast; correction: False

### t2 explicit_confirmation

I explicitly confirm the previously recorded horizon. The forecast should extend 16 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t2/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 16,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 16 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. The forecast should extend 19 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "The forecast should extend 19 hours ahead."
  }
]
```

Intent: create_forecast; correction: True

### t4 confirmation_after_replacement

I explicitly confirm the previously recorded horizon. The forecast should extend 19 hours ahead.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0124/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "confirmed",
    "value": {
      "periods": 19,
      "unit": "hour"
    },
    "evidence": "I explicitly confirm the previously recorded horizon. The forecast should extend 19 hours ahead."
  }
]
```

Intent: create_forecast; correction: False

### t5 unknown_omission

Timezone, seasonal periods and prediction interval levels are undecided, and I have no access reference. Please ask rather than fill them.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## ur explicit_state_repair

Scenario: v7-20261009-r7-dev/crypto_spot/0145
Split: train

### t1 initial_multislot

Mujhe yeh chahiye.  Source serialization format xlsx hai. Mera source reference https://inputs.example/crypto_spot/2314 hai. Source data catalog se select karein. 11 ghantay ka horizon rakhein. Source observations har 1 ghanta aati hain. Target ko USD per BTC mein measure karein. BTC/USD spot closing price for Weslin crypto spot site 2314 ke liye prediction bana dein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "xlsx",
    "evidence": "Source serialization format xlsx hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://inputs.example/crypto_spot/2314",
    "evidence": "Mera source reference https://inputs.example/crypto_spot/2314 hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "catalog",
    "evidence": "Source data catalog se select karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "11 ghantay ka horizon rakhein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Target ko USD per BTC mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD spot closing price for Weslin crypto spot site 2314",
    "evidence": "BTC/USD spot closing price for Weslin crypto spot site 2314 ke liye prediction bana dein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD spot closing price for Weslin crypto spot site 2314",
    "evidence": "BTC/USD spot closing price for Weslin crypto spot site 2314 ke liye prediction bana dein."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Time field ka naam recorded_at hai. Target values field btc_usd_close se lein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "recorded_at",
    "evidence": "Time field ka naam recorded_at hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_usd_close",
    "evidence": "Target values field btc_usd_close se lein."
  }
]
```

Synthetic prior-state intervention: {"mutations": [{"kind": "wrong_prior_value", "slot": "frequency", "value": {"periods": 3, "unit": "hour"}}, {"kind": "omitted_prior_value", "slot": "target_unit"}]}

Intent: create_forecast; correction: False

### t3 repair_with_fresh_evidence

Ghalat purani frequency replace karein; unit bhi dobara bata raha hoon. Target ko USD per BTC mein measure karein. Source observations har 1 ghanta aati hain.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t3/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Target ko USD per BTC mein measure karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t3/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "Source observations har 1 ghanta aati hain."
  }
]
```

Intent: create_forecast; correction: True

### t4 targeted_replacement

Pehla horizon replace kar dein. 14 ghantay ka horizon rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0145/t4/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "14 ghantay ka horizon rakhein."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Abhi timezone, seasonal cycle lengths, prediction interval coverage ya authorized access reference nahi de sakta.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

Human decision and rationale: pending

## mixed correction_chain

Scenario: v7-20261009-r7-dev/crypto_spot/0192
Split: train

### t1 initial_multislot

For my request,  The supplied data format is csv. Source crypto_spot_archive_2319.csv hai. I will upload the data. Aglay 11 ghantay predict karein. There is one observed data point every 1 hour. Target values USD per BTC mein hain. The quantity to predict is BTC/USD spot closing price for Pelmar crypto spot site 2319.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t1/file_format",
    "slot_id": "file_format",
    "status": "provided",
    "value": "csv",
    "evidence": "The supplied data format is csv."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t1/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "crypto_spot_archive_2319.csv",
    "evidence": "Source crypto_spot_archive_2319.csv hai."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t1/source_mode",
    "slot_id": "source_mode",
    "status": "provided",
    "value": "upload",
    "evidence": "I will upload the data."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t1/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 11,
      "unit": "hour"
    },
    "evidence": "Aglay 11 ghantay predict karein."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t1/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 1,
      "unit": "hour"
    },
    "evidence": "There is one observed data point every 1 hour."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t1/target_unit",
    "slot_id": "target_unit",
    "status": "provided",
    "value": "USD per BTC",
    "evidence": "Target values USD per BTC mein hain."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t1/target_description",
    "slot_id": "target_description",
    "status": "provided",
    "value": "BTC/USD spot closing price for Pelmar crypto spot site 2319",
    "evidence": "The quantity to predict is BTC/USD spot closing price for Pelmar crypto spot site 2319."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t1/problem_statement",
    "slot_id": "problem_statement",
    "status": "provided",
    "value": "BTC/USD spot closing price for Pelmar crypto spot site 2319",
    "evidence": "The quantity to predict is BTC/USD spot closing price for Pelmar crypto spot site 2319."
  }
]
```

Intent: create_forecast; correction: False

### t2 incremental_identifiers

Dates are stored in field sample_date. Column btc_usd_close ko target rakhein.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t2/time_column",
    "slot_id": "time_column",
    "status": "provided",
    "value": "sample_date",
    "evidence": "Dates are stored in field sample_date."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t2/target_column",
    "slot_id": "target_column",
    "status": "provided",
    "value": "btc_usd_close",
    "evidence": "Column btc_usd_close ko target rakhein."
  }
]
```

Intent: create_forecast; correction: False

### t3 targeted_replacement

Replace the earlier horizon; leave every other requirement unchanged. I need the next 14 hours predicted.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t3/forecast_horizon",
    "slot_id": "forecast_horizon",
    "status": "provided",
    "value": {
      "periods": 14,
      "unit": "hour"
    },
    "evidence": "I need the next 14 hours predicted."
  }
]
```

Intent: create_forecast; correction: True

### t4 two_slot_replacement

Change only these two earlier settings. The source is https://revised.example/crypto_spot/192. Har 2 ghantay aik observed data point milta hai.

Expected decoded updates

```json
[
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t4/source_reference",
    "slot_id": "source_reference",
    "status": "provided",
    "value": "https://revised.example/crypto_spot/192",
    "evidence": "The source is https://revised.example/crypto_spot/192."
  },
  {
    "fact_id": "v7-20261009-r7-dev/crypto_spot/0192/t4/frequency",
    "slot_id": "frequency",
    "status": "provided",
    "value": {
      "periods": 2,
      "unit": "hour"
    },
    "evidence": "Har 2 ghantay aik observed data point milta hai."
  }
]
```

Intent: create_forecast; correction: True

### t5 unknown_omission

Nobody has specified the timezone, seasonal cycle lengths, prediction interval percentages or credential reference yet.

Expected decoded updates

```json
[]
```

Intent: create_forecast; correction: False

### t6 explicit_nonforecasting

For a separate new request, explain the definition of crypto spot. No forecast is requested.

Expected decoded updates

```json
[]
```

Intent: not_forecasting; correction: False

Human decision and rationale: pending
