"""Regression checks for semantic defects discovered in the v7 agent review."""
from copy import deepcopy
import importlib.util,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'runtime/fpy-v6-pinned/src'))
sys.path.append(str(ROOT/'.openai-deps'))
from forecasting_assistant.domain.schema import load_schema
from local_slm_lab.comparison_policy import ComparisonPolicy
from local_slm_lab import corpus_v7 as old
from local_slm_lab import corpus_v7_reviewed_r7 as new

class V7AgentReviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema=load_schema();cls.policy=ComparisonPolicy()
        cls.rows=[r for r in new.freeze_plan()['assignments'] if r['split']!='final']

    def case(self,category,domain='temperature'):
        r=next(r for r in self.rows if r['category']==category and r['domain']==domain)
        return new.build_scenario(r,self.schema,self.policy)

    def test_original_duplicate_is_detected(self):
        row=next(r for r in old.freeze_plan()['assignments'] if r['scenario_id'].endswith('/temperature/0006'))
        case=old.build_scenario(row,self.schema,self.policy)
        with self.assertRaises(ValueError):new.reviewed_semantic_checks(case)

    def test_new_dense_bundle_has_no_unchanged_provided_updates(self):
        for domain in ('temperature','inflation_prices','crypto_spot','weather_energy'):
            case=self.case('lifecycle_dense',domain)
            new.reviewed_semantic_checks(case);new.validate_scenario(case,self.schema,self.policy)
            for t in case['turns']:
                for f in t['facts']:
                    prior=t['context_state'].get(f['slot_id'])
                    self.assertFalse(prior and prior['value']==f['value'] and f['status']=='provided')

    def test_wrong_scope_cannot_pass_agent_checks(self):
        case=self.case('core_recall')
        purpose=next(t for t in case['turns'] if t['behavior']=='purpose_addition')
        purpose['facts'][0]['value']='prepare a reserve for the wrong location'
        with self.assertRaisesRegex(ValueError,'different source scope'):new.reviewed_semantic_checks(case)

    def test_horizon_numbers_vary_inside_every_domain_behavior_cell(self):
        cells={}
        for row in self.rows:
            key=(row['domain'],row['category'])
            cells.setdefault(key,set()).add(new.source_values(row,self.schema)['forecast_horizon']['periods'])
        self.assertEqual(len(cells),200)
        self.assertTrue(all(len(v)>1 for v in cells.values()))

    def test_provenance_and_approval_have_true_and_false_supervision(self):
        pools={s:set() for s in ('human_approval_required','provenance_required')}
        for row in self.rows:
            if row['category']!='lifecycle_dense':continue
            case=new.build_scenario(row,self.schema,self.policy)
            for t in case['turns']:
                for f in t['facts']:
                    if f['slot_id'] in pools:pools[f['slot_id']].add(f['value'])
        self.assertTrue(all(v=={True,False} for v in pools.values()))

    def test_target_contrasts_are_distinct_in_all_development_groups(self):
        for row in self.rows:
            if row['category']=='target_contrast':
                case=new.build_scenario(row,self.schema,self.policy)
                new.reviewed_semantic_checks(case)

    def test_positive_target_rejection_is_detected(self):
        case=self.case('target_contrast')
        value=next(f['value'] for f in case['turns'][0]['facts'] if f['slot_id']=='target_description').rsplit(' for ',1)[0]
        case['turns'][0]['message']=f'I need forecasts of {value}. Do not substitute {value} as my requested target.'
        with self.assertRaisesRegex(ValueError,'explicitly rejected'):new.reviewed_semantic_checks(case)

    def test_confirmation_is_grounded_in_the_old_value(self):
        case=self.case('confirmation_status')
        t=next(t for t in case['turns'] if t['behavior']=='explicit_confirmation')
        self.assertIn('confirm',t['message'].lower())
        t['facts'][0]['value']={'periods':999,'unit':'day'}
        with self.assertRaisesRegex(ValueError,'Confirmation'):new.reviewed_semantic_checks(case)

    def test_builder_never_renders_final_rows(self):
        plan=new.freeze_plan()
        selected=[next(r for r in plan['assignments'] if r['split']==s) for s in ('train','validation','final')]
        plan['assignments']=selected
        original=new.build_scenario;seen=[]
        def guard(row,*args):
            self.assertNotEqual(row['split'],'final');seen.append(row['split'])
            return original(row,*args)
        with tempfile.TemporaryDirectory() as tmp,patch.object(new,'freeze_plan',return_value=plan),\
             patch.object(new,'development_audit',return_value=({'overlap':{}},[])),\
             patch.object(new,'benchmark_exclusion',return_value={}),patch.object(new,'build_scenario',side_effect=guard):
            output=Path(tmp)/new.VERSION
            m=new.build_artifacts(output)
            self.assertEqual(seen,['train','validation']);self.assertEqual(m['sealed_files'],{})
            self.assertFalse((output/'splits/final.jsonl.gz').exists())

    def test_audit_empty_findings_does_not_count_sample_as_bad(self):
        path=ROOT/'corpus-v7/agent-reviews/v7-20261009-r7-dev-20261009/summary.json'
        if not path.exists():self.skipTest('Current agent audit required')
        summary=json.loads(path.read_bytes())
        self.assertEqual(summary['issue_occurrences'],{})
        self.assertEqual(summary['scenarios_with_issues'],0)
        self.assertEqual(summary['human_approvals_written'],0)
        self.assertFalse(summary['final_labels_accessed'])

    def test_rotated_combined_targets_keep_matching_historical_weather_feature(self):
        expected={'gas_demand':'observed_heating_degree_days','solar_mw':'observed_irradiance',
                  'yield_index':'observed_soil_moisture','crop_shipments':'observed_rainfall'}
        seen=set()
        for r in self.rows:
            if r['domain_family']!='combined':continue
            values=new.source_values(r,self.schema);column=values['target_column']
            if column not in expected:continue
            driver=expected[column];seen.add(column)
            self.assertEqual(values['past_covariates'],[driver])
            self.assertEqual(values['external_covariate_sources'][0]['name'],driver)
            self.assertNotIn(driver,values['known_future_covariates'])
        self.assertEqual(seen,set(expected))

    def test_binary_target_error_threshold_is_informative(self):
        for r in self.rows:
            values=new.source_values(r,self.schema)
            if values['target_unit']=='0 or 1':
                self.assertGreater(values['acceptable_error']['maximum'],0)
                self.assertLess(values['acceptable_error']['maximum'],1)

if __name__=='__main__':unittest.main()
