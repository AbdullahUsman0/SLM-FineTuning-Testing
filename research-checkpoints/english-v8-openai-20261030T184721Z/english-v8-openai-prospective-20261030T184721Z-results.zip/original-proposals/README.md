# English-only prospective evaluation preparation

This is a PREPARATION package, not evaluation results or certified gold labels.

Primary: 44 English single-target conversations, 205 turns (14 weather, 30 economics). Separate challenge: 3 joint-target conversations, 18 turns. Twelve Roman Urdu/mixed records are excluded at the author's request before inference; EXT-060 is truncated and quarantined without invented completion. Original IDs and messages are preserved. The original domain-balance target is no longer achieved.

`protocol.json` resolves representational conventions before predictions. Under-specified dates, vague horizons and unrepresentable event schedules are unresolved constraints, not invented slot values. The primary actionable-update endpoint does not measure coverage of all such constraints. Historical R4 scores remain a separate condition.

`AI_DRAFT_ANNOTATIONS.jsonl` and `draft-annotation-review.csv`, when present, contain AI-authored proposals for all 205 primary turns. These are not certified gold; structural validity does not establish completeness or semantic correctness. Check missing requirements, debatable text boundaries, repeated confirmations and unresolved constraints. `gold-annotation-worksheet.csv` is the original blank worksheet. No reviewer identities or human decisions are fabricated. `case-decision-register.jsonl` maps cases to policy. Hash-bound input/protocol snapshot is not a full model/source/gold freeze or external preregistration.

Grok model/version/settings are not supplied. Cases are externally generated synthetic fixed scripts curated by Codex. Every current case names a file; low exact overlap is not proof of semantic independence, authentic-user coverage or generalization.

No new inference, spending, training, review certification or performance claim is authorized by this package. READINESS.json states the remaining gates. Keep old API ledger and spending receipts intact.
