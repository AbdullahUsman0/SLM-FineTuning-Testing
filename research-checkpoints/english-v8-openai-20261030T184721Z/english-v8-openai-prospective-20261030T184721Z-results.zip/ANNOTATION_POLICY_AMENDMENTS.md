# AI checking decisions for genuine semantic review

This packet preserves the original 205 AI proposals and all original messages.
The first generated check attempt is retained in label-review/; the final
AI-checked candidate packet is label-review-r2/. Its 60 changed turns contain
129 field changes, each with before/after records and checker identity.
All 205 turns have context-specific check notes. This is Codex checking,
not independent human annotation or a signed gold approval.

The original capsule's S01-S16 rules remain the basis. COMMON_INSTRUCTIONS.txt
adds the actual reviewable conventions for both systems. Review these before
approving labels: exact target phrase boundaries; Keep/same versus ordinary
still/again confirmations; partial-entity substitutions; observation versus
output cadence; event schedules; literal units; crew/desk versus purpose versus
destination; and the limits of exact serialized numeric-value scoring.

Examples of corrections:

- EXT-009 t3: retain Mexico replacement and add explicit frequency/horizon
  confirmations. At t4 same columns confirms columns, not filename format.
- EXT-016 t4: a simple table does not establish point output.
- EXT-028 t1: monthly step is output granularity, not source observation frequency.
- EXT-044 t4: replacing an established filename is a correction even when split
  across a later message.
- EXT-051: daily maximum supports frequency/max aggregation; a morning table
  alone is not daily recurrence. Each morning at t5 does establish recurrence.
- EXT-058 t3: do not manufacture positive text domestic exports from a filename.
  Exclude re-exports remains a separately recorded constraint; the explicit
  positive target appears at t5.

UNREPRESENTED_REQUIREMENTS.jsonl retains whole-message verbatim evidence plus
case-specific notes about constraints outside the actionable labels. Those notes
are a qualitative accounting, not a certified exhaustive constraint metric.
Negative alternatives are not converted to positive target/covariate updates.

The ideal-state reducer in review_annotations.py is independent of application
normalization/recovery. Explicit semantic confirmations retain confirmed status
and confirmed_by_user=true. The frozen current application downgrades some such
updates to provided and independently infers upload mode from filenames. With
the corrected gold as a diagnostic input, there are 14 pre-recovery and 76
post-recovery state mismatches (63 involve source_mode). These are NOT candidate
responses or model F1. Their interpretation depends on approving the proposed
semantic state contract; do not silently redefine gold to match the application
or change recovery against observed candidate outputs.

Human checking must cover missing updates as well as proposed updates, current
evidence, status/confirmation, negative constraints, unresolved dates/schedules,
and every reference-state transition. Resolve disagreements and record actual
reviewer/adjudication provenance separately. Previous R4 review does not cover
these conversations. All human decision fields in human-review.csv are blank.
If revisions are needed, keep this packet immutable and create a new version
and executable freeze before inference. Do not edit any active candidate run.
