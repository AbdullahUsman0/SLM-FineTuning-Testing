"""No-inference follow-through: wait, replay, analyze, package and publish evidence."""
from collections import Counter
from copy import deepcopy
from datetime import datetime,timezone
import csv
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from common import REPO,atomic,bootstrap,digest,dumps,exclusive,read,rows,sha

def command(args,cwd=None):
    env=dict(os.environ);env.pop('OPENAI_API_KEY',None)
    env.update(GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never',PYTHONDONTWRITEBYTECODE='1')
    result=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if result.returncode:
        import re
        error=result.stderr.decode('utf-8',errors='replace')
        error=re.sub(r'(?i)(?:sk-(?:proj-)?[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})','[REDACTED]',error)
        atomic(ROOT/'POSTRUN_COMMAND_FAILURE.json',{'executable':str(args[0]),'exit_code':result.returncode,'stderr_sanitized':error[:4000]})
        raise RuntimeError('Command failed: '+str(args[0])+'; exit '+str(result.returncode)+'; see POSTRUN_COMMAND_FAILURE.json')
    return result.stdout

def replay(run):
    p=bootstrap()
    import runner
    from forecasting_assistant.domain.schema import load_schema,create_initial_state
    f=runner.validate_freeze();schema=load_schema()
    records=[read(path) for path in (run/'scored-calls').glob('*.json')]
    index={(r['arm'],r['track'],r['conversation_id'],r['key'][-1]):r for r in records}
    assert len(records)==820 and len(index)==820
    checked=0;component={}
    for track in ('component','rollout'):
        for case in rows(ROOT/'label-review-r2/CHECKED_CASES.jsonl'):
            for arm in ('v8','openai'):
                state=create_initial_state(schema)
                for turn in case['turns']:
                    rec=index[(arm,track,case['scenario_id'],turn['turn_id'])]
                    assert rec['fresh_in_this_run'] and rec['freeze_sha256']==sha(ROOT/'FREEZE_PROPOSAL.json')
                    if track=='component':state=p.restore(turn,schema)
                    context=p.extraction_context(state,turn['message'],schema)
                    assert context==rec['current_input']
                    assert digest([sha(ROOT/'FREEZE_PROPOSAL.json'),context,turn['gold_extraction'],turn['expected_state_after']])==rec['identity']
                    state,score=runner.score_call(p,schema,state,turn,rec,f['response_schema'])
                    for k in ('confusion','json_valid','schema_valid','raw_contract_admitted','state_before_recovery','state_after_recovery','exact_pipeline_state','correction_flag_correct'):
                        assert score[k]==rec[k],(rec['key'],k)
                    if track=='component':component.setdefault((case['scenario_id'],turn['turn_id']),{})[arm]=context
                    checked+=1
    assert checked==820 and all(v['v8']==v['openai'] for v in component.values())
    atomic(run/'OFFLINE_MATCHED_REPLAY.json',{'passed':True,'calls_replayed':checked,'component_inputs_identical_across_arms':205,'fresh_source_receipts':True,'no_generation_or_paid_calls':True,'raw_and_application_states_reproduced':True})
    return records

def publish(run,complete):
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    export=run/'export';assert not export.exists();export.mkdir()
    operations=export/'operations';operations.mkdir()
    for name in ['FREEZE_PROPOSAL.json','COMMON_INSTRUCTIONS.txt','ACTUAL_SCHEMA.json','DEPENDENCIES.json','MODEL_VERIFICATION.json','BASE_ALL_FILES_VERIFICATION.json','BASE_REMOTE_REVISION_VERIFICATION.json','INTAKE_VERIFICATION.json','LABEL_APPROVAL.json','USER_HUMAN_REVIEW_ATTESTATION.json','MODEL_AVAILABILITY.json','OFFLINE_TESTS.json','ANNOTATION_POLICY_AMENDMENTS.md','postrun_workflow.py','launch-background.ps1','record_user_review_and_launch.py']:
        shutil.copyfile(ROOT/name,export/name)
    for folder in ['code','fpy','label-review-r2','original-proposals','repository-source']:
        shutil.copytree(ROOT/folder,export/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.pytest_cache'))
    for name in ['BUDGET_AUTHORIZATION.json','NEW_BUDGET_AUTHORIZATION_EVIDENCE.json','API_COST_ESTIMATE.json']:
        shutil.copyfile(ROOT/name,operations/name)
    live=sqlite3.connect('file:'+str(ROOT/'control/spending.sqlite3').replace('\\','/')+'?mode=ro',uri=True)
    snapshot=sqlite3.connect(operations/'spending.sqlite3');live.backup(snapshot);snapshot.close();live.close()
    for name in ['launch-manifest.json','supervisor.json','worker-PID.json','progress.json','worker-failure.json','last-transport-error.json','local-runtime.json','completion.json','summary.json','paired-analysis.json','bootstrap-samples.json.gz','OFFLINE_MATCHED_REPLAY.json','stdout.log','stderr.log']:
        if (run/name).exists():shutil.copyfile(run/name,export/name)
    for folder in ['scored-calls','hosted-responses','hosted-requests']:
        if (run/folder).exists():shutil.copytree(run/folder,export/folder)
    # Human-review provenance is user attestation, not invented worksheet data.
    if complete:
        summary=read(run/'summary.json')
        with (export/'PAPER_TABLE.csv').open('w',encoding='utf-8',newline='') as out:
            writer=csv.DictWriter(out,fieldnames=['model','track','calls','precision','recall','exact_actionable_F1','JSON_valid','schema_valid','native_admitted','exact_final_states','final_state_denominator','median_seconds','p95_seconds']);writer.writeheader()
            for model in ('v8','openai'):
                for track in ('component','rollout'):
                    s=summary[model][track];m=s['raw_exact_actionable']
                    writer.writerow({'model':model,'track':track,'calls':s['calls'],'precision':m['precision'],'recall':m['recall'],'exact_actionable_F1':m['f1'],'JSON_valid':s['json_valid'],'schema_valid':s['schema_valid'],'native_admitted':s['native_admitted'],'exact_final_states':s['final_states']['exact'],'final_state_denominator':s['final_states']['denominator'],'median_seconds':s['latency_seconds']['median'],'p95_seconds':s['latency_seconds']['p95_nearest_rank']})
    handoff='''# Main-PC Codex handoff: prospective English comparison

Safely pull experiment/v5-grounded-20260919 in AbdullahUsman0/SLM-FineTuning-Testing;
preserve existing manuscript edits and verify this archive and its member manifest.
This is a separate prospective English condition, not a replacement for R4.
44 synthetic single-target conversations, 205 turns; 3 multi-target challenges
excluded from primary F1. Both candidate arms require fresh responses under the
same frozen contract. Component inputs use gold prior; rollouts use each arm's
own accepted prior. Raw extraction is scored before recovery; application states
are measured separately. Target/source/schema limits remain explicit.

The author attested independent human review complete and authorized inference
on 2026-10-30. See USER_HUMAN_REVIEW_ATTESTATION.json. Completed per-turn reviewer
worksheets, reviewer identities and agreement statistics were not returned to
this server. Do not invent them or describe AI corrections as human annotation.
The unchanged AI worksheets retain historical blank human fields.

COMPLETION_STATUS

Read completion.json, OFFLINE_MATCHED_REPLAY.json, summary.json, paired-analysis.json,
PAPER_TABLE.csv and raw responses/states when present. If incomplete, there is no
complete matched primary endpoint: report the blocker and actual call counts;
do not turn a partial or unmatched subset into the planned full comparison.

For complete results, back up the ACTUAL existing paper and update its relevant
tables/claims using both rows from this matched condition. Keep synthetic source,
generator/template dependence, exact raw-value/status scoring, decoder differences,
fixed scripted questions and reference-state policy explicit. Use the predeclared
paired conversation bootstrap and input-family sensitivity without a universal
winner/generalization claim. State the user-attested review provenance accurately.
Native summary key correct_raw_flag is the historical strict combined criterion:
correct correction flag AND exact actionable updates. Per-call
correction_flag_correct is flag-only; retain this distinction in reporting.
Legacy forbidden_slot_flags are unannotated here; use actual FP/extra tuples and
the qualitative unrepresented-constraint notes, not zero flags as a safety claim.

Operational cost/authorization/ledger files are kept for reproducibility. The user
instructed that financial figures and budget constraints must NOT appear anywhere
in the paper. Keep financial details out of manuscript text/tables. Report actual
completion status and supported denominators honestly. No new inference, training,
Grok, sealed labels, scope expansion or automatic recovery/label fixes are granted
by this evidence package. Report edited paper paths and build checks.
'''.replace('COMPLETION_STATUS','The full 820-call comparison completed and all saved raw/state evidence was replay-verified.' if complete else 'The evaluation stopped before full completion. Inspect worker-failure.json and progress.json. Do not report prospective main F1 as complete.')
    (export/'LOCAL_CODEX_HANDOFF.md').write_text(handoff,encoding='utf-8')
    atomic(export/'EVALUATION_STATUS.json',{'complete':complete,'new_condition':True,'run_name':run.name,'freeze_sha256':sha(ROOT/'FREEZE_PROPOSAL.json'),'review_provenance':'user attestation; worksheets/identities not supplied','financial_details_for_manuscript':False,'generated_at_UTC':datetime.now(timezone.utc).isoformat()})
    # Scan all readable data, including compressed bootstrap data. Exact public
    # redaction-test fixtures and provider opaque fields are narrowly recorded.
    fixture_source=read(REPO/'research-checkpoints/r4-paper-offline-supplement-20261029/supplement/CREDENTIAL_SCAN.json')
    fixtures={r['source_file_sha256']:(r['fixture_token_sha256'],r['occurrences']) for r in fixture_source['public_unit_test_fixture_exceptions']}
    import re
    pattern=re.compile(rb'(?i)(?<![A-Za-z0-9])(?:sk-(?:proj-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{24,}|(?:AKIA|ASIA)[A-Z0-9]{16})')
    exceptions=[]
    for path in export.rglob('*'):
        if not path.is_file():continue
        assert not path.name.startswith('.env') and path.suffix not in {'.safetensors','.pt','.bin','.pyc'}
        data=path.read_bytes();h=hashlib.sha256(data).hexdigest();view=gzip.decompress(data) if path.suffix=='.gz' else data
        if h in fixtures:
            wanted,count=fixtures[h];matches=list(pattern.finditer(view));assert len(matches)==count and all(hashlib.sha256(m.group()).hexdigest()==wanted for m in matches)
            view=pattern.sub(b'[HASH-VERIFIED PUBLIC UNIT FIXTURE]',view);exceptions.append({'path':path.relative_to(export).as_posix(),'sha256':h,'kind':'exact public test fixture'})
        if path.parent.name=='hosted-responses':
            obj=json.loads(view);changed=False
            for item in obj.get('response',{}).get('output',[]):
                if item.get('type')=='reasoning' and isinstance(item.get('encrypted_content'),str):item['encrypted_content']='[OPAQUE PROVIDER FIELD; SCAN VIEW ONLY]';changed=True
            if changed:view=dumps(obj).encode();exceptions.append({'path':path.relative_to(export).as_posix(),'sha256':h,'kind':'opaque provider reasoning field, scan view only; original bytes preserved'})
        assert not pattern.search(view),'Unadjudicated credential-shaped data; publication stopped'
    atomic(export/'CREDENTIAL_SCAN.json',{'passed':True,'narrow_hash_bound_exceptions':exceptions,'weights_caches_credentials_excluded':True})
    manifest={p.relative_to(export).as_posix():sha(p) for p in export.rglob('*') if p.is_file()}
    atomic(export/'ARCHIVE_MANIFEST.json',{'files_sha256':manifest,'status':'complete' if complete else 'partial'})
    archive=run/(run.name+'-results.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in export.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(export).as_posix())
    def verify(data):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            assert z.testzip() is None and set(z.namelist())==set(manifest)|{'ARCHIVE_MANIFEST.json'}
            for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
    verify(archive.read_bytes());archive_hash=sha(archive)
    archive.with_suffix('.zip.sha256').write_text(archive_hash+'  '+archive.name+'\n',encoding='ascii')
    downloads=Path.home()/'Downloads';target=downloads/archive.name;assert not target.exists();shutil.copyfile(archive,target);assert sha(target)==archive_hash
    # Publish only this bounded artifact in a clean detached worktree.
    branch='experiment/v5-grounded-20260919'
    command(['git','-c','credential.interactive=never','fetch','origin',branch],REPO)
    worktree=Path(r'D:\SLM\FYP-publications')/run.name;worktree.parent.mkdir(exist_ok=True)
    command(['git','worktree','add','--detach',str(worktree),'origin/'+branch],REPO)
    relative=Path('research-checkpoints')/('english-v8-openai-'+run.name.removeprefix('english-v8-openai-prospective-'))
    publication=worktree/relative;publication.mkdir(parents=True,exist_ok=False)
    for path in [archive,archive.with_suffix('.zip.sha256'),export/'LOCAL_CODEX_HANDOFF.md',export/'EVALUATION_STATUS.json']:
        shutil.copyfile(path,publication/path.name)
    (publication/'.gitattributes').write_text('* -text\n',encoding='ascii')
    command(['git','add','--',relative.as_posix()],worktree)
    command(['git','diff','--cached','--check'],worktree)
    command(['git','commit','--quiet','-m','Publish prospective English comparison '+('results' if complete else 'partial execution evidence')],worktree)
    commit=command(['git','rev-parse','HEAD'],worktree).decode().strip()
    command(['git','-c','credential.interactive=never','push','origin','HEAD:'+branch],worktree)
    url='https://raw.githubusercontent.com/AbdullahUsman0/SLM-FineTuning-Testing/'+commit+'/'+relative.as_posix()+'/'+archive.name
    with urllib.request.urlopen(url,timeout=60) as response:data=response.read()
    assert hashlib.sha256(data).hexdigest()==archive_hash;verify(data)
    receipt={'status':'published_GitHub_download_and_members_verified','commit':commit,'archive_url':url,'ZIP_sha256':archive_hash,'members':len(manifest)+1,'complete':complete,'Downloads_archive':str(target),'handoff_url':'https://github.com/AbdullahUsman0/SLM-FineTuning-Testing/blob/'+commit+'/'+relative.as_posix()+'/LOCAL_CODEX_HANDOFF.md'}
    atomic(publication/'PUBLICATION_VERIFICATION.json',receipt)
    command(['git','add','--',(relative/'PUBLICATION_VERIFICATION.json').as_posix()],worktree)
    command(['git','commit','--quiet','-m','Record verified GitHub download for English comparison'],worktree)
    command(['git','-c','credential.interactive=never','push','origin','HEAD:'+branch],worktree)
    receipt['verification_commit']=command(['git','rev-parse','HEAD'],worktree).decode().strip()
    atomic(run/'PUBLICATION_VERIFICATION.json',receipt)
    return receipt

def main():
    cfg=read(Path(r'D:\SLM\active-english-prospective-evaluation.json'));run=Path(cfg['run'])
    with exclusive(run/'postrun.lock'):
        atomic(run/'postrun-status.json',{'status':'waiting_for_worker','PID':os.getpid(),'run':str(run)})
        while True:
            supervisor=read(run/'supervisor.json') if (run/'supervisor.json').exists() else {}
            if supervisor.get('status') in {'worker_finished','worker_stopped_requires_audit'}:break
            time.sleep(15)
        complete=(run/'completion.json').exists() and read(run/'completion.json').get('status')=='complete'
        try:
            if complete:
                atomic(run/'postrun-status.json',{'status':'offline_replay_analysis','PID':os.getpid()})
                replay(run)
                output=command([sys.executable,str(ROOT/'code/analyze.py'),'--run',str(run)],ROOT)
                (run/'analysis.stdout.log').write_bytes(output)
            atomic(run/'postrun-status.json',{'status':'packaging_and_publication','complete':complete,'PID':os.getpid()})
            receipt=publish(run,complete)
            atomic(run/'postrun-status.json',receipt)
        except BaseException as e:
            atomic(run/'postrun-status.json',{'status':'followup_blocked_completed_work_preserved','complete_inference':complete,'error_type':type(e).__name__,'reason':str(e),'PID':os.getpid()})
            raise

if __name__=='__main__':main()
