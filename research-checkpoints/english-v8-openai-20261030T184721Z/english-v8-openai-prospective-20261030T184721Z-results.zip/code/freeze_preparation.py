"""Seal a reviewable source/prompt/AI-label proposal, not human readiness."""
import importlib.metadata
from pathlib import Path
import platform
import subprocess
from common import ROOT,REPO,DEPS,atomic,bootstrap,digest,dumps,read,rows,sha

CONVENTIONS='''Prospective English semantic conventions, disclosed identically to both models:
Keep native observation frequency distinct from forecast output granularity, forecast run cadence, ingestion cadence and model refitting.
Use an exact meaningful target noun phrase for both problem_statement and target_description; omit a separately stated leading cadence and rejected alternatives. Do not reconstruct absent positive target words from filenames. A narrower explicit noun phrase may clarify an earlier vague target without asserting an explicit correction.
Mean/average, maximum and total directly support mean, max and sum aggregation. A named crew/desk is stakeholder_role; a named dashboard is destination. No invented business purpose, output type or data source provider.
A named filename supports source_reference and suffix-inferred file_format; a replacement file with the same suffix does not confirm its format. Explicit format declarations are provided. Upload mode requires explicit upload wording, never a filename alone.
Explicit Keep/same affirmation of recorded attributes uses confirmed. Plain again/still restatements are omitted. A replacement of a previously supplied source/column/value is a correction; clarification of unresolved information need not be.
No numeric duration from an event-triggered release/session/decision schedule merely because the underlying series/release is monthly/quarterly. Explicit every/once-each numeric or named recurring day/week/quarter cadence supports duration; retain finer event/time-of-day constraints separately. A morning table alone supplies no daily recurrence. Twice a day is duration 12 hours as a declared average-cadence convention; exact spacing is not asserted.
On a monthly step/Daily steps is forecast output granularity, not proof of source observation cadence. Bare daily/hourly/monthly target or explicitly sampled/source-series cadence follows the stated native frequency convention.
Unit glossary: an explicit USD quote pair supports USD; explicit Percent ice cover supports percent; explicit named measurement units retain exact user text. Currency/measurement suffixes on files/columns do not provide units.
Do not invent precise dates, source timezones, numeric vague horizons or indifference from unknowns. Do not infer IANA zones from geography or UTC-like columns; forecast delivery time is not source time timezone. Point/path/table supplies point only when point is explicitly stated. Table/spreadsheet alone supplies no serialization format.
Raw exact actionable scoring uses native one-decode tuples of slot ID, decoded value serialized with the frozen JSON serializer, and status. No synonym, paraphrase or numeric repair after generation. JSON numeric spellings 1 and 1.0 remain distinct in this raw serialized-value endpoint. Intent/unmentioned/dont_care are excluded and separately counted. This is not complete coverage of unrepresentable constraints.
The ideal reference state preserves unrelated values and explicit semantic confirmations independently of application recovery. Confirmation persistence and filename recovery disagreements remain application findings, not adjusted labels.
'''

def main():
    if (ROOT/'FREEZE_PROPOSAL.json').exists():
        assert '--new-reviewed-proposal' in __import__('sys').argv,'Preserve existing freeze unless explicitly versioning a new pre-inference proposal'
        assert not (ROOT/'control/RUN_BINDING.json').exists(),'Never refreeze an existing candidate run'
        history=ROOT/'freeze-history'/sha(ROOT/'FREEZE_PROPOSAL.json');history.mkdir(parents=True,exist_ok=False)
        import shutil
        for name in ['FREEZE_PROPOSAL.json','LABEL_APPROVAL.json','BUDGET_AUTHORIZATION.json','OFFLINE_TESTS.json']:
            if (ROOT/name).exists():shutil.copyfile(ROOT/name,history/name)
    p=bootstrap();from forecasting_assistant.domain.schema import load_schema
    schema=load_schema()
    protocol=read(ROOT/'original-proposals/protocol.json')
    instructions=p.build_instructions(REPO)+'\n\n'+ '\n'.join(rule['id']+': '+rule['decision'] for rule in protocol['rules'])+'\n\n'+CONVENTIONS
    (ROOT/'COMMON_INSTRUCTIONS.txt').write_text(instructions,encoding='utf-8')
    atomic(ROOT/'ACTUAL_SCHEMA.json',schema.model_dump(mode='json'))
    versions={n:importlib.metadata.version(n) for n in ['torch','transformers','peft','openai','pydantic','jsonschema','pytest','numpy','tiktoken','tokenizers','huggingface-hub']}
    sources={}
    for folder in ['code','fpy/src','label-review-r2','original-proposals']:
        for path in (ROOT/folder).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':sources[path.relative_to(ROOT).as_posix()]=sha(path)
    for name in ['COMMON_INSTRUCTIONS.txt','ACTUAL_SCHEMA.json','MODEL_VERIFICATION.json','BASE_REMOTE_REVISION_VERIFICATION.json','INTAKE_VERIFICATION.json','launch-background.ps1']:sources[name]=sha(ROOT/name)
    repo_files={p.relative_to(REPO).as_posix():sha(p) for p in (REPO/'local_slm_lab').glob('*.py')}
    repo_files['corpus-v8/v8-final-20261018-r1/extractor-instructions.txt']=sha(REPO/'corpus-v8/v8-final-20261018-r1/extractor-instructions.txt')
    manifest={'version':'prospective-english-AI-reviewed-source-proposal-r1','status':'frozen review proposal; NOT approved evaluation gold','source_commit':'0729cd4a01c07cf724ccfa380e56a0cab6a0b0ae','instructions':instructions,'response_schema':p.wire_schema(),'planned_main_calls':820,'planned_per_model_track':205,'fresh_responses_both_arms':True,'workspace_files_sha256':sources,'repository_files_sha256':repo_files,'dependency_versions':versions,'python':platform.python_version(),'python_executable':str(Path(__import__('sys').executable).resolve()),'offline_dependency_path':str(DEPS),'hosted_model':'gpt-5-mini-2025-08-07','hosted_generation':{'max_output_tokens':2048,'reasoning_effort':'minimal','SDK_retries':0,'store':False},'local_generation':{'max_new_tokens':1024,'sampling':False,'seed':42,'thinking':False,'device':'cuda','dtype':'bfloat16'},'generation_budget_comparability':'Configured systems retain historical visible/tokenizer/decoder differences; not identical decoding algorithms. Hosted cap includes reasoning. No silent changes.','labels_human_review_complete':False,'primary_endpoint':'rollout exact actionable micro F1','reference_state_contract':'all non-null slots, exact values/status/confirmed_by_user incl intent; independently retained semantic confirmations; no recovery in oracle reducer','inference_started':False,'budget_authorized_USD':0,'bootstrap':{'resamples':10000,'seed':20261030,'cluster':'conversation','sensitivity':'preassigned input-topic narrative families; not independent contributor groups'}}
    manifest['version']='prospective-english-AI-reviewed-source-proposal-r2'
    if (ROOT/'NEW_BUDGET_AUTHORIZATION_EVIDENCE.json').exists():
        manifest['budget_authorized_USD']=1
        manifest['internal_dispatch_ceiling_USD']=.9
        manifest['financial_details_for_manuscript']=False
        sources['NEW_BUDGET_AUTHORIZATION_EVIDENCE.json']=sha(ROOT/'NEW_BUDGET_AUTHORIZATION_EVIDENCE.json')
    atomic(ROOT/'FREEZE_PROPOSAL.json',manifest)
    atomic(ROOT/'LABEL_APPROVAL.json',{'approved':False,'mode':None,'labels_sha256':sha(ROOT/'label-review-r2/CHECKED_CASES.jsonl'),'approval_evidence':None,'independent_human_review_complete':False,'note':'Do not populate as Codex approval. Genuine review or explicit separately authorized AI-labelled exploratory condition required.'})
    atomic(ROOT/'BUDGET_AUTHORIZATION.json',{'authorized':False,'authorized_nanousd':0,'dispatch_ceiling_nanousd':0,'max_hosted_attempts':410,'freeze_sha256':sha(ROOT/'FREEZE_PROPOSAL.json'),'approval_evidence':None,'note':'Old R4 funds/receipts grant no new authorization. Shared prospective ledger is condition-bound and cannot be renewed by changing key/run directory.'})
    evidence=ROOT/'NEW_BUDGET_AUTHORIZATION_EVIDENCE.json'
    if evidence.exists():
        b=read(evidence)
        assert b['authorized_nanousd']==1000000000 and b['dispatch_ceiling_nanousd']==900000000
        atomic(ROOT/'BUDGET_AUTHORIZATION.json',{'authorized':True,'authorized_nanousd':b['authorized_nanousd'],'dispatch_ceiling_nanousd':b['dispatch_ceiling_nanousd'],'max_hosted_attempts':410,'freeze_sha256':sha(ROOT/'FREEZE_PROPOSAL.json'),'approval_evidence':b['approval_evidence'],'budget_evidence_sha256':sha(evidence),'manuscript_financial_details':False,'note':'Applies only to this new condition. Earlier spending stays in its preserved historical ledgers. No budget reset on worker restart, changed key or changed run path. Stop before ceiling; no silent cohort/settings changes.'})
    atomic(ROOT/'DEPENDENCIES.json',{'versions':versions,'python':platform.python_version(),'source_package_locations':{n:str(importlib.metadata.distribution(n)._path) for n in versions},'installed_or_upgraded_packages':0})
    print(dumps({'freeze_sha256':sha(ROOT/'FREEZE_PROPOSAL.json'),'source_files':len(sources),'repo_files':len(repo_files),'human_label_gate':False,'spending_gate':read(ROOT/'BUDGET_AUTHORIZATION.json')['authorized'],'new_model_calls':0}))

if __name__=='__main__':main()
