"""Matched prospective summaries and predeclared paired cluster bootstrap."""
import argparse
from pathlib import Path
from common import atomic,read,sha

def paired_interval(a,b,groups,resamples=10000,seed=20261030):
    import numpy as np
    rng=np.random.Generator(np.random.PCG64(seed))
    names=sorted(set(groups));aa=[];bb=[]
    for group in names:
        aa.append([sum(a[i][j] for i,g in enumerate(groups) if g==group) for j in range(3)])
        bb.append([sum(b[i][j] for i,g in enumerate(groups) if g==group) for j in range(3)])
    aa=np.asarray(aa);bb=np.asarray(bb)
    samples=[]
    def f1(x):
        tp,fp,fn=x;return float(2*tp/(2*tp+fp+fn)) if 2*tp+fp+fn else 0.
    for _ in range(resamples):
        picks=rng.integers(0,len(names),size=len(names))
        samples.append(f1(aa[picks].sum(axis=0))-f1(bb[picks].sum(axis=0)))
    return {'clusters':len(names),'observed_difference':f1(aa.sum(axis=0))-f1(bb.sum(axis=0)),'percentile_95_interval':[float(x) for x in np.quantile(samples,[.025,.975])],'resamples':resamples,'seed':seed,'generator':'numpy.PCG64','samples':samples}

def main():
    p=argparse.ArgumentParser();p.add_argument('--run',required=True,type=Path);a=p.parse_args()
    completion=read(a.run/'completion.json')
    if completion['status']!='complete' or completion['fresh_calls']!=820:raise ValueError('No prospective scores from a partial comparison')
    records=[read(p) for p in (a.run/'scored-calls').glob('*.json')]
    assert len(records)==820 and all(r['fresh_in_this_run'] for r in records)
    results={};samples={}
    for track in ('component','rollout'):
        paired={arm:{(r['conversation_id'],r['key'][-1]):r for r in records if r['arm']==arm and r['track']==track} for arm in ('v8','openai')}
        assert set(paired['v8'])==set(paired['openai']) and len(paired['v8'])==205
        ids=sorted({k[0] for k in paired['v8']});assert len(ids)==44
        counts={arm:[[sum(r['confusion'][j] for key,r in paired[arm].items() if key[0]==cid) for j in range(3)] for cid in ids] for arm in ('v8','openai')}
        family=[next(r['family'] for r in paired['v8'].values() if r['conversation_id']==cid) for cid in ids]
        results[track]={}
        for name,groups in [('conversation',ids),('preassigned_narrative_family_sensitivity',family)]:
            result=paired_interval(counts['v8'],counts['openai'],groups)
            samples[track+'_'+name]=result.pop('samples');results[track][name]=result
    import gzip
    from common import dumps
    with gzip.open(a.run/'bootstrap-samples.json.gz','wt',encoding='utf-8') as f:f.write(dumps(samples))
    atomic(a.run/'paired-analysis.json',{'source_completion_sha256':sha(a.run/'completion.json'),'intervals':results,'limitation':'Conditional on related single-generator synthetic cases. Family groups are preassigned topic sensitivities, not independent human/contributor clusters. No universal winner or power guarantee.'})

if __name__=='__main__':main()
