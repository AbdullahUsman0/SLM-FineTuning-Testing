"""Shape and application diagnostics of AI-checked labels; not candidate inference."""
from copy import deepcopy
from common import ROOT,atomic,bootstrap,dumps,rows

def main():
    p=bootstrap()
    from forecasting_assistant.domain.models import ExtractorResult,SlotState
    from forecasting_assistant.domain.schema import load_schema
    from forecasting_assistant.application.normalization import normalize_value
    from forecasting_assistant.application.validation import validate_slot
    from forecasting_assistant.application.state_reducer import apply_extraction
    schema=load_schema();wire=p.wire_schema();cases=rows(ROOT/'label-review-r2/CHECKED_CASES.jsonl')
    native_errors=[];type_issues=[];oracle=[];count=0
    original={c['conversation_id']:c for c in rows(ROOT/'original-proposals/primary-cases.jsonl')}
    for case in cases:
        assert len(case['turns'])==len(original[case['scenario_id']]['turns'])
        for turn in case['turns']:
            count+=1;cid=case['scenario_id'];n=turn['turn_id']
            assert turn['message']==original[cid]['turns'][n-1]['user']
            extraction=ExtractorResult.model_validate_json(dumps(turn['gold_extraction']))
            assert len({u.slot_id for u in extraction.updates})==len(extraction.updates)
            for u in extraction.updates:
                assert u.evidence_text and u.evidence_text in turn['message']
                definition=schema.get(u.slot_id)
                value=normalize_value(definition,u.candidate_value)
                issues=validate_slot(definition,SlotState(slot_id=u.slot_id,value=value,status=u.status,evidence_text=u.evidence_text))
                if issues:type_issues.append({'case':cid,'turn':n,'slot':u.slot_id,'issues':[i.code for i in issues]})
            before=p.restore(turn,schema);reduced=None;after=None;trace=None
            try:
                reduced=p.snapshot(apply_extraction(before,extraction,schema,n,turn['message']))
                state,trace=p.run_pipeline(before,turn['message'],schema,{'raw_output':dumps(turn['gold_extraction']),'capped':False,'refused':False},wire)
                after=p.snapshot(state)
            except Exception as e:native_errors.append({'case':cid,'turn':n,'error_type':type(e).__name__})
            expected=turn['expected_state_after']
            oracle.append({'case':cid,'turn':n,'scope':'gold-label application diagnostic; NOT model inference or accuracy','before_recovery_equal_ideal':reduced==expected,'after_recovery_equal_ideal':after==expected,'different_keys_before':sorted(k for k in set(expected)|set(reduced or {}) if expected.get(k)!=(reduced or {}).get(k)),'different_keys_after':sorted(k for k in set(expected)|set(after or {}) if expected.get(k)!=(after or {}).get(k)),'recovery_ids':(trace or {}).get('recovered_slot_ids',[]),'expected_state':expected,'reducer_state':reduced,'application_state':after})
    assert count==205
    output=ROOT/'label-review-r2'
    (output/'GOLD_APPLICATION_DIAGNOSTIC.jsonl').write_text(''.join(dumps(x)+'\n' for x in oracle),encoding='utf-8')
    result={'turns':count,'shape_and_evidence_validated':count,'type_issues':type_issues,'native_contract_exceptions':native_errors,'oracle_before_recovery_mismatches':sum(not r['before_recovery_equal_ideal'] for r in oracle),'oracle_after_recovery_mismatches':sum(not r['after_recovery_equal_ideal'] for r in oracle),'human_review_complete':False,'no_candidate_model_calls':True,'ideal_state_generated_without_app_recovery':True,'policy_must_be_approved_before_inference':True}
    atomic(output/'LABEL_VALIDATION.json',result);print(dumps(result))

if __name__=='__main__':main()
