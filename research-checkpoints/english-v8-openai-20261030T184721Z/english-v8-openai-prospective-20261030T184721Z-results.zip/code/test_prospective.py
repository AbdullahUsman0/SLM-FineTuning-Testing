"""Artificial controls only. No candidate model, paid request or human approval."""
from copy import deepcopy
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace
from unittest.mock import patch
import pytest
from common import ROOT,MODEL,CallStore,Ledger,Stop,atomic,bootstrap,digest,dumps,read,request_bound,sha
import runner

P=bootstrap()
from forecasting_assistant.domain.schema import create_initial_state,load_schema
SCHEMA=load_schema();WIRE=P.wire_schema()

def extraction(value='air temperature',status='provided'):
    return {'intent':'create_forecast','intent_confidence':1.0,'updates':[{'slot_id':'target_description','candidate_value':json.dumps(value),'status':status,'confidence':1.0,'evidence_text':'air temperature'}],'correction_detected':False,'unsupported_claims':[]}

def turn(gold=None):return {'gold_extraction':gold or extraction(),'forbidden_slots':[],'message':'Forecast air temperature.','expected_state_after':{},'unknown_turn':False}
def record(obj=None,**extra):return {'raw_output':dumps(obj or extraction()),'capped':False,'refused':False,**extra}

def test_exact_positive_scoring():assert P.raw_score(record(),turn(),WIRE)['confusion']==[1,0,0]
def test_wrong_value_counts_fp_and_fn():assert P.raw_score(record(extraction('humidity')),turn(),WIRE)['confusion']==[0,1,1]
def test_wrong_status_counts_fp_and_fn():assert P.raw_score(record(extraction(status='inferred')),turn(),WIRE)['confusion']==[0,1,1]
def test_duplicate_is_not_set_collapsed():
    obj=extraction();obj['updates']*=2;r=P.raw_score(record(obj),turn(),WIRE)
    assert r['confusion']==[1,1,0] and r['duplicate_slots']
@pytest.mark.parametrize('flag',['capped','refused'])
def test_capped_or_refused_zero_tp(flag):assert P.raw_score(record(**{flag:True}),turn(),WIRE)['confusion']==[0,1,1]
def test_invalid_json_fn():
    r=P.raw_score({'raw_output':'{','capped':False,'refused':False},turn(),WIRE)
    assert not r['json_valid'] and r['confusion']==[0,0,1]
def test_unknown_slot_retained_fp():
    obj=extraction();obj['updates'][0]['slot_id']='invented_slot'
    assert P.raw_score(record(obj),turn(),WIRE)['confusion']==[0,1,1]
@pytest.mark.parametrize('status',['unmentioned','dont_care'])
def test_ignored_statuses_reported_separately(status):
    r=P.raw_score(record(extraction(status=status)),turn(),WIRE)
    assert r['confusion']==[0,0,1] and r['ignored_status_updates']==1
def test_numeric_serialization_is_declared_exact():
    assert P.tuples(extraction({'periods':1,'unit':'day'}))!=P.tuples(extraction({'periods':1.0,'unit':'day'}))
def test_raw_score_is_not_state_recovery():
    t=turn();state=create_initial_state(SCHEMA)
    _,m=runner.score_call(P,SCHEMA,state,t,record(),WIRE)
    assert m['confusion']==[1,0,0] and 'state_before_recovery' in m and 'state_after_recovery' in m
def test_empty_unknown_has_no_invented_update():
    obj=extraction();obj['updates']=[]
    t=turn(deepcopy(obj));r=P.raw_score(record(obj),t,WIRE)
    assert r['confusion']==[0,0,0] and r['unknown_no_updates']
def test_correction_requires_flag_and_exact_updates():
    obj=extraction();obj['correction_detected']=True
    assert P.raw_score(record(obj),turn(obj),WIRE)['correct_correction']
    assert not P.raw_score(record(),turn(obj),WIRE)['correct_correction']
def test_prf_recomputed_from_counts():
    r=P.prf([{'confusion':[2,1,3]},{'confusion':[3,2,1]}]);assert r['tp']==5 and r['fp']==3 and r['fn']==4 and r['f1']==10/17

def test_ledger_reservation_ceiling(tmp_path):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000)
    with pytest.raises(Stop):l.reserve('x','h',1,1)
    assert l.summary()['requests']==0;l.close()
def test_ledger_uncertainty_blocks_next_call(tmp_path):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000000);l.reserve('x','h',10,10);l.uncertain('x')
    with pytest.raises(Stop):l.reserve('y','h2',10,10)
    assert l.summary()['uncertain_nanousd']==22500;l.close()
def test_ledger_existing_dispatch_never_replayed(tmp_path):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000000);l.reserve('x','h',10,10)
    with pytest.raises(Stop):l.reserve('x','h',10,10)
    l.close()
def test_ledger_missing_usage_remains_unresolved(tmp_path):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000000);l.reserve('x','h',10,10)
    with pytest.raises(Stop):l.reconcile('x','h',{},'r')
    assert l.summary()['reserved_nanousd']>0;l.close()
def test_reconcile_is_idempotent_and_reasoning_not_double_counted(tmp_path):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000000);l.reserve('x','h',10,10)
    u={'input_tokens':5,'output_tokens':4,'output_tokens_details':{'reasoning_tokens':3}}
    assert l.reconcile('x','h',u,'r')==9250
    assert l.reconcile('x','h',u,'r')==9250 and l.summary()['reserved_nanousd']==0;l.close()
def test_changed_request_rejected_on_reconcile(tmp_path):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000000);l.reserve('x','h',10,10)
    with pytest.raises(Stop):l.reconcile('x','different',{'input_tokens':1,'output_tokens':1},'r')
    l.close()
@pytest.mark.parametrize('namespace,ceiling',[('changed',1000000),('unit-test',2000000)])
def test_restart_cannot_renew_budget(tmp_path,namespace,ceiling):
    path=tmp_path/'ledger.db';l=Ledger(path,'unit-test',1000000);l.close()
    with pytest.raises(Stop):Ledger(path,namespace,ceiling)
def test_restart_keeps_previous_usage(tmp_path):
    path=tmp_path/'ledger.db';l=Ledger(path,'unit-test',1000000);l.reserve('x','h',10,10);l.reconcile('x','h',{'input_tokens':5,'output_tokens':4},'r');l.close()
    l=Ledger(path,'unit-test',1000000);assert l.summary()['actual_nanousd']==9250;l.close()
def test_cache_discount_only_from_returned_usage(tmp_path):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000000);l.reserve('x','h',100,10)
    l.reconcile('x','h',{'input_tokens':100,'output_tokens':4,'input_tokens_details':{'cached_tokens':80}},'r')
    assert l.summary()['actual_nanousd']==15000;l.close()
@pytest.mark.parametrize('cached',[-1,101,True,1.5])
def test_invalid_cached_usage_not_reconciled(tmp_path,cached):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000000);l.reserve('x','h',100,10)
    with pytest.raises(Stop):l.reconcile('x','h',{'input_tokens':100,'output_tokens':4,'input_tokens_details':{'cached_tokens':cached}},'r')
    assert l.summary()['reserved_nanousd']>0;l.close()
def test_receipt_overrun_stops_further_work(tmp_path):
    l=Ledger(tmp_path/'ledger.db','unit-test',1000000);l.reserve('x','h',1,1)
    with pytest.raises(Stop):l.reconcile('x','h',{'input_tokens':2,'output_tokens':2},'r')
    assert l.summary()['actual_nanousd']==4500;l.close()
def test_conservative_input_bound_includes_utf8_and_overhead():
    assert request_bound({'input':'é'})==len(dumps({'input':'é'}).encode())+16384

def test_store_restart_no_duplicate_calls(tmp_path):
    path=tmp_path/'calls.db';s=CallStore(path,'f');s.put(['x'],'i',{'result':'unit'});s.close()
    s=CallStore(path,'f');assert s.get(['x'],'i')=={'result':'unit'};s.put(['x'],'i',{'result':'unit'});assert len(s.all())==1;s.close()
def test_store_changed_input_rejected(tmp_path):
    s=CallStore(tmp_path/'calls.db','f');s.put(['x'],'i',{});
    with pytest.raises(Stop):s.get(['x'],'changed')
    s.close()
def test_store_changed_record_rejected(tmp_path):
    s=CallStore(tmp_path/'calls.db','f');s.put(['x'],'i',{});
    with pytest.raises(Stop):s.put(['x'],'i',{'changed':True})
    s.close()
def test_store_corruption_detected(tmp_path):
    s=CallStore(tmp_path/'calls.db','f');s.put(['x'],'i',{});s.db.execute("UPDATE calls SET record='{}x'")
    with pytest.raises((Stop,json.JSONDecodeError)):s.get(['x'],'i')
    s.close()

def hosted_fixture(tmp_path,client):
    f={'instructions':'Artificial unit test, not an evaluation input','response_schema':WIRE,'hosted_generation':{'max_output_tokens':2048}}
    h=runner.Hosted.__new__(runner.Hosted);h.f=f;h.run=tmp_path;h.client=client;h.ledger=Ledger(tmp_path/'ledger.db','UNIT_TEST_NOT_HUMAN_OR_PAID',100000000)
    return h
class FakeClient:
    def __init__(self,fail=False):self.calls=0;self.fail=fail;self.responses=self
    def create(self,**kwargs):
        self.calls+=1
        if self.fail:raise TimeoutError('UNIT TEST')
        body={'model':MODEL,'usage':{'input_tokens':10,'output_tokens':10},'id':'UNIT_TEST_RESPONSE','status':'completed','output':[]}
        return SimpleNamespace(output_text=dumps(extraction()),model_dump=lambda **kw:body)
def test_hosted_response_receipt_reused_after_journal_gap(tmp_path):
    client=FakeClient();h=hosted_fixture(tmp_path,client);key=['UNIT_TEST'];one=h.generate(key,'UNIT_TEST_CONTEXT');two=h.generate(key,'UNIT_TEST_CONTEXT')
    assert one==two and client.calls==1 and h.ledger.summary()['requests']==1;h.ledger.close()
def test_hosted_changed_context_never_replayed(tmp_path):
    client=FakeClient();h=hosted_fixture(tmp_path,client);h.generate(['UNIT_TEST'],'one')
    with pytest.raises(Stop):h.generate(['UNIT_TEST'],'two')
    assert client.calls==1;h.ledger.close()
def test_hosted_timeout_retains_uncertain_no_retry(tmp_path):
    client=FakeClient(True);h=hosted_fixture(tmp_path,client)
    with pytest.raises(Stop):h.generate(['UNIT_TEST'],'one')
    with pytest.raises(Stop):h.generate(['UNIT_TEST'],'one')
    assert client.calls==1 and h.ledger.summary()['uncertain_nanousd']>0;h.ledger.close()

def test_readiness_never_treats_ai_check_as_human_approval():
    with patch('runner.read',return_value={'approved':False}):
        with pytest.raises(Stop,match='label review'):runner.readiness({})
def test_no_paid_budget_carried_from_old_work():
    a={'approved':True,'labels_sha256':'h','mode':'explicitly_authorized_AI_labelled_exploratory','approval_evidence':'UNIT_TEST_ONLY'}
    def fake_read(path):
        n=Path(path).name
        return a if n=='LABEL_APPROVAL.json' else {'passed':True,'freeze_sha256':'h'} if n=='OFFLINE_TESTS.json' else {'both_metadata_checks_passed':True,'model':MODEL} if n=='MODEL_AVAILABILITY.json' else {'authorized':False}
    with patch('runner.read',side_effect=fake_read),patch('runner.sha',return_value='h'):
        with pytest.raises(Stop,match='spending'):runner.readiness({})
def test_model_substitution_gate_rejected():
    a={'approved':True,'labels_sha256':'h','mode':'independent_human_reviewed','approval_evidence':'UNIT_TEST_ONLY'}
    def fake_read(path):
        n=Path(path).name
        return a if n=='LABEL_APPROVAL.json' else {'passed':True,'freeze_sha256':'h'} if n=='OFFLINE_TESTS.json' else {'both_metadata_checks_passed':True,'model':'different'}
    with patch('runner.read',side_effect=fake_read),patch('runner.sha',return_value='h'):
        with pytest.raises(Stop,match='snapshot'):runner.readiness({})
def test_bootstrap_interval_reproducible():
    from analyze import paired_interval
    a=[[1,0,0],[2,1,1]];b=[[1,1,0],[1,1,2]]
    assert paired_interval(a,b,['A','B'],100)==paired_interval(a,b,['A','B'],100)
def test_bootstrap_paired_identical_zero():
    from analyze import paired_interval
    a=[[1,0,1],[2,1,1]];r=paired_interval(a,a,['A','B'],100)
    assert r['observed_difference']==0 and r['percentile_95_interval']==[0,0]

def test_all_primary_messages_unchanged_and_review_fields_blank():
    checked=__import__('common').rows(ROOT/'label-review-r2/CHECKED_CASES.jsonl')
    original={c['conversation_id']:c for c in __import__('common').rows(ROOT/'original-proposals/primary-cases.jsonl')}
    assert len(checked)==44 and sum(len(c['turns']) for c in checked)==205
    for c in checked:
        assert [t['message'] for t in c['turns']]==[t['user'] for t in original[c['scenario_id']]['turns']]
        assert c['human_review_complete'] is False
def test_independent_reference_confirms_without_app_reducer():
    checked=__import__('common').rows(ROOT/'label-review-r2/CHECKED_CASES.jsonl')
    c=next(c for c in checked if c['scenario_id']=='EXT-009')
    assert c['turns'][2]['expected_state_after']['frequency']['confirmed_by_user'] is True
    assert c['turns'][2]['expected_state_after']['frequency']['status']=='confirmed'
def test_filename_does_not_establish_gold_upload():
    c=next(c for c in __import__('common').rows(ROOT/'label-review-r2/CHECKED_CASES.jsonl') if c['scenario_id']=='EXT-004')
    assert 'source_mode' not in c['turns'][1]['expected_state_after']
def test_multitarget_challenges_excluded():
    ids={c['scenario_id'] for c in __import__('common').rows(ROOT/'label-review-r2/CHECKED_CASES.jsonl')}
    assert not ids & {'EXT-010','EXT-020','EXT-050','EXT-060'}

def scheduler_control(tmp_path,inject_failure):
    """Exercise actual scheduler/recovery with separate artificial text fixtures."""
    from contextlib import ExitStack
    root=tmp_path/'UNIT_TEST_ONLY';root.mkdir();run=root/'run'
    f={'instructions':'UNIT_TEST_NOT_HUMAN_OR_PAID','response_schema':WIRE,'planned_main_calls':8}
    atomic(root/'FREEZE_PROPOSAL.json',f);atomic(root/'LABEL_APPROVAL.json',{'UNIT_TEST_ONLY':True})
    g=extraction();empty=extraction();empty['updates']=[]
    state={'target_description':{'value':'air temperature','status':'provided','confirmed_by_user':False},'intent':{'value':'create_forecast','status':'provided','confirmed_by_user':False}}
    t1={'turn_id':1,'message':'Forecast air temperature.','gold_extraction':g,'expected_state_after':state,'context_state':{},'established_intent':'ambiguous','prior_user_messages':[]}
    t2={'turn_id':2,'message':'I do not know.','gold_extraction':empty,'expected_state_after':state,'context_state':state,'established_intent':'create_forecast','prior_user_messages':[t1['message']]}
    cases=[{'scenario_id':'CTRL-ARTIFICIAL','domain':'weather','language':'en','family':'UNIT_TEST','turns':[t1,t2]}]
    called=[]
    class FakeBackend:
        def __init__(self,*args):pass
        def generate(self,key,context):
            called.append(key)
            return {'raw_output':dumps(g if key[-1]==1 else empty),'capped':False,'refused':False,'fresh_in_this_run':True,'latency_seconds':0.001,'response_model':'UNIT_TEST_CONTROL'}
    with ExitStack() as stack:
        for name,value in [('ROOT',root),('validate_freeze',lambda:f),('readiness',lambda f:{'dispatch_ceiling_nanousd':100000000}),('rows',lambda path:cases),('Local',FakeBackend),('Hosted',FakeBackend)]:stack.enter_context(patch.object(runner,name,value))
        if inject_failure:
            with patch.object(runner,'score_call',side_effect=Stop('UNIT TEST injected crash after raw response persisted')):
                with pytest.raises(Stop):runner.evaluate(run)
            assert len(called)==1
        runner.evaluate(run);assert len(called)==8
        runner.evaluate(run);assert len(called)==8
        assert read(run/'completion.json')['fresh_calls']==8
        assert read(run/'progress.json')['status']=='complete'
        with pytest.raises(Stop,match='SAME directory'):runner.evaluate(root/'different-run')
def test_end_to_end_scheduler_resume_no_repeat(tmp_path):scheduler_control(tmp_path,False)
def test_end_to_end_crash_after_raw_save_resume_no_repeat(tmp_path):scheduler_control(tmp_path,True)
