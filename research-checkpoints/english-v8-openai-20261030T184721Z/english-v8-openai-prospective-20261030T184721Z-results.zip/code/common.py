"""Prospective study primitives; no historical budget authorization is imported."""
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys

ROOT=Path(__file__).resolve().parents[1]
REPO=Path(r'D:\SLM\SLM-FineTuning-Testing')
DEPS=Path(r'D:\SLM\FYP-evaluation-runs\current-pipeline-v8-openai-20261028T094502Z-r4-1-native\offline-deps')
MODEL='gpt-5-mini-2025-08-07'

def bootstrap():
    for p in (DEPS,REPO,ROOT/'fpy/src'):
        if str(p) not in sys.path:sys.path.insert(0,str(p))
    import historical_pipeline as p
    p.configure(ROOT/'fpy',REPO)
    return p

def dumps(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,allow_nan=False,default=str)
def digest(x):return hashlib.sha256(dumps(x).encode()).hexdigest()
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def rows(path):return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()]
def atomic(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.tmp')
    with temp.open('w',encoding='utf-8',newline='\n') as f:f.write(dumps(obj)+'\n');f.flush();os.fsync(f.fileno())
    os.replace(temp,path)

@contextmanager
def exclusive(path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as f:
        f.seek(0,2)
        if f.tell()==0:f.write(b'0');f.flush();os.fsync(f.fileno())
        f.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:yield
        finally:
            f.seek(0)
            if os.name=='nt':msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(f.fileno(),fcntl.LOCK_UN)

def load_worker_key():
    """New worker explicitly refreshes Windows user key; no dotenv/log lookup."""
    key=None;source='not_configured'
    if os.name=='nt':
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,'Environment') as k:
                value,_=winreg.QueryValueEx(k,'OPENAI_API_KEY')
                if isinstance(value,str) and value.strip():key=value.strip();source='Windows_user_environment'
        except (FileNotFoundError,OSError):pass
    if not key:
        key=os.environ.get('OPENAI_API_KEY','').strip() or None
        if key:source='process_environment'
    return key,source

class Stop(RuntimeError):pass

class Ledger:
    """Permanent per-condition ledger. Changed credentials never renew ceilings.

    Uncertain or reserved requests block new dispatch. Response receipt written
    before reconcile permits safe continuation without another generation call.
    """
    def __init__(self,path,namespace,ceiling_nanousd):
        self.db=sqlite3.connect(path,timeout=5,isolation_level=None)
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS requests (key TEXT PRIMARY KEY,request_sha TEXT NOT NULL,bound INTEGER NOT NULL,actual INTEGER,state TEXT NOT NULL,receipt_sha TEXT,usage_json TEXT)')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            for k,v in {'namespace':namespace,'ceiling_nanousd':str(ceiling_nanousd)}.items():
                old=self.db.execute('SELECT value FROM meta WHERE key=?',(k,)).fetchone()
                if old and old[0]!=v:raise Stop('Ledger namespace or authorization ceiling changed; do not reset')
                self.db.execute('INSERT OR IGNORE INTO meta VALUES (?,?)',(k,v))
            self.db.execute('COMMIT')
        except BaseException:self.db.execute('ROLLBACK');self.db.close();raise
        self.ceiling=ceiling_nanousd
    def summary(self):
        data=self.db.execute('SELECT bound,actual,state FROM requests').fetchall()
        return {'actual_nanousd':sum(r[1] or 0 for r in data),'reserved_nanousd':sum(r[0] for r in data if r[2]=='reserved'),'uncertain_nanousd':sum(r[0] for r in data if r[2]=='uncertain'),'requests':len(data),'ceiling_nanousd':self.ceiling}
    def reserve(self,key,request_sha,input_upper,max_output):
        bound=input_upper*250+max_output*2000
        self.db.execute('BEGIN IMMEDIATE')
        try:
            if self.db.execute('SELECT 1 FROM requests WHERE key=?',(key,)).fetchone():raise Stop('Request already reserved/dispatched; reconcile receipt, never replay')
            s=self.summary()
            if s['requests']>=410:raise Stop('410 main hosted attempts exhausted; pilots/retries are not authorized here')
            if s['reserved_nanousd'] or s['uncertain_nanousd']:raise Stop('Earlier dispatch unresolved; paid dispatch stopped')
            if s['actual_nanousd']+bound>self.ceiling:raise Stop('Approved dispatch ceiling insufficient for next conservative reservation')
            self.db.execute('INSERT INTO requests VALUES (?,?,?,?,?,?,?)',(key,request_sha,bound,None,'reserved',None,None));self.db.execute('COMMIT')
        except BaseException:self.db.execute('ROLLBACK');raise
        return bound
    def uncertain(self,key):self.db.execute("UPDATE requests SET state='uncertain' WHERE key=? AND state='reserved'",(key,))
    def reconcile(self,key,request_sha,usage,receipt_sha):
        if not isinstance(usage,dict) or any(type(usage.get(k)) is not int or usage[k]<0 for k in ('input_tokens','output_tokens')):raise Stop('Missing/non-integer usage; keep reservation unresolved')
        details=usage.get('input_tokens_details') or {}
        cached=details.get('cached_tokens',0)
        if type(cached) is not int or not 0<=cached<=usage['input_tokens']:raise Stop('Invalid cached token accounting; keep reservation unresolved')
        actual=(usage['input_tokens']-cached)*250+cached*25+usage['output_tokens']*2000
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row=self.db.execute('SELECT request_sha,bound,actual,state,receipt_sha FROM requests WHERE key=?',(key,)).fetchone()
            if not row or row[0]!=request_sha:raise Stop('Request ledger/receipt identity mismatch')
            if row[3]=='reconciled' and (row[2]!=actual or row[4]!=receipt_sha):raise Stop('Changed usage or response receipt')
            self.db.execute("UPDATE requests SET actual=?,state='reconciled',receipt_sha=?,usage_json=? WHERE key=?",(actual,receipt_sha,dumps(usage),key));self.db.execute('COMMIT')
        except BaseException:self.db.execute('ROLLBACK');raise
        if actual>row[1]:raise Stop('Usage exceeded conservative reservation; receipt preserved, stop for accounting audit')
        return actual
    def close(self):self.db.close()

def request_bound(request):return len(dumps(request).encode('utf-8'))+16384

class CallStore:
    def __init__(self,path,freeze):
        self.db=sqlite3.connect(path,isolation_level=None,timeout=5)
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS meta (freeze TEXT NOT NULL)')
        old=self.db.execute('SELECT freeze FROM meta').fetchall()
        if old and old!=[(freeze,)]:raise Stop('Run freeze changed; existing run preserved')
        if not old:self.db.execute('INSERT INTO meta VALUES (?)',(freeze,))
        self.db.execute('CREATE TABLE IF NOT EXISTS calls (key TEXT PRIMARY KEY,identity TEXT NOT NULL,record TEXT NOT NULL,record_sha TEXT NOT NULL)')
    def get(self,key,identity):
        r=self.db.execute('SELECT identity,record,record_sha FROM calls WHERE key=?',(dumps(key),)).fetchone()
        if not r:return None
        if r[0]!=identity:raise Stop('Resume input/prompt/gold/source drift')
        value=json.loads(r[1])
        if digest(value)!=r[2]:raise Stop('Stored response checksum mismatch')
        return value
    def put(self,key,identity,record):
        old=self.get(key,identity)
        if old is not None:
            if old!=record:raise Stop('Attempted overwrite of a completed fresh call')
            return
        self.db.execute('INSERT INTO calls VALUES (?,?,?,?)',(dumps(key),identity,dumps(record),digest(record)))
    def all(self):return [json.loads(r[0]) for r in self.db.execute('SELECT record FROM calls ORDER BY key')]
    def close(self):self.db.close()
