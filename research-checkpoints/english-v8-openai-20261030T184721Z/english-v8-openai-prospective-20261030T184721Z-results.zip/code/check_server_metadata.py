"""Two read-only metadata checks; no generation or secret output."""
import json
import os
import re
import urllib.error
import urllib.request
from common import ROOT,MODEL,atomic,load_worker_key

def safe(value):return value if isinstance(value,str) and re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',value) else None

def main():
    key,source=load_worker_key();checks=[]
    if key:
        for endpoint in ('/v1/models','/v1/models/'+MODEL):
            request=urllib.request.Request('https://api.openai.com'+endpoint,headers={'Authorization':'Bearer '+key})
            try:
                with urllib.request.urlopen(request,timeout=30) as r:
                    body=json.load(r)
                    checks.append({'endpoint':endpoint,'status':r.status,'request_id':safe(r.headers.get('x-request-id')),'exact_model_id_matches':body.get('id')==MODEL if endpoint.endswith(MODEL) else None})
            except urllib.error.HTTPError as e:
                try:error=json.loads(e.read()).get('error',{})
                except Exception:error={}
                checks.append({'endpoint':endpoint,'status':e.code,'error_code':safe(error.get('code')),'error_type':safe(error.get('type')),'request_id':safe(e.headers.get('x-request-id'))})
                break
            except Exception as e:
                checks.append({'endpoint':endpoint,'status':None,'error_type':type(e).__name__});break
    result={'model':MODEL,'credential_source':source,'credential_present':bool(key),'checks':checks,'both_metadata_checks_passed':len(checks)==2 and all(c['status']==200 for c in checks) and checks[-1].get('exact_model_id_matches') is True,'generation_billing_readiness_established':False,'generation_requests':0,'provider':'https://api.openai.com','dotenv_read':False,'override_variables_present':{k:bool(os.environ.get(k)) for k in ('OPENAI_BASE_URL','OPENAI_ORG_ID','OPENAI_PROJECT_ID')},'project_organization_overrides_sent':False}
    atomic(ROOT/'MODEL_AVAILABILITY.json',result)
    print(json.dumps(result))

if __name__=='__main__':main()
