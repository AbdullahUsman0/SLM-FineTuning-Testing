"""Fresh matched English evaluation. Execution blocked until real approvals exist."""
import argparse
from copy import deepcopy
from datetime import datetime,timezone
import importlib.metadata
import math
import os
from pathlib import Path
import statistics
import time
from common import ROOT,REPO,MODEL,Stop,Ledger,CallStore,atomic,bootstrap,digest,dumps,exclusive,load_worker_key,read,request_bound,rows,sha

def utc():return datetime.now(timezone.utc).isoformat()

def validate_freeze():
    f=read(ROOT/'FREEZE_PROPOSAL.json')
    for rel,h in f['workspace_files_sha256'].items():
        if sha(ROOT/rel)!=h:raise Stop('Frozen workspace drift: '+rel)
    for rel,h in f['repository_files_sha256'].items():
        if sha(REPO/rel)!=h:raise Stop('Frozen provider/source drift: '+rel)
    for name,version in f['dependency_versions'].items():
        if importlib.metadata.version(name)!=version:raise Stop('Dependency version drift: '+name)
    return f

def readiness(f,paid=True):
    approval=read(ROOT/'LABEL_APPROVAL.json')
    if approval.get('approved') is not True or approval.get('labels_sha256')!=sha(ROOT/'label-review-r2/CHECKED_CASES.jsonl'):raise Stop('Genuine label review/explicit exploratory approval pending')
    if approval.get('mode') not in {'independent_human_reviewed','explicitly_authorized_AI_labelled_exploratory'} or not approval.get('approval_evidence'):raise Stop('Approval evidence/mode missing; AI checking is not human approval')
    if not read(ROOT/'OFFLINE_TESTS.json').get('passed'):raise Stop('Offline test gate failed')
    if read(ROOT/'OFFLINE_TESTS.json').get('freeze_sha256')!=sha(ROOT/'FREEZE_PROPOSAL.json'):raise Stop('Tests are not bound to this freeze')
    a=read(ROOT/'MODEL_AVAILABILITY.json')
    if not a.get('both_metadata_checks_passed') or a.get('model')!=MODEL:raise Stop('Exact hosted snapshot availability unverified on server')
    if paid:
        b=read(ROOT/'BUDGET_AUTHORIZATION.json')
        if b.get('authorized') is not True or b.get('freeze_sha256')!=sha(ROOT/'FREEZE_PROPOSAL.json') or not b.get('approval_evidence'):raise Stop('New explicit bounded spending authorization pending')
        if type(b.get('dispatch_ceiling_nanousd')) is not int or not 0<b['dispatch_ceiling_nanousd']<=b.get('authorized_nanousd',0):raise Stop('Invalid new budget ceiling')
        if b.get('max_hosted_attempts')!=410:raise Stop('Main call count changed; separate pilots/retries need amended authorization')
        return b
    return None

def hosted_request(f,context):
    return {'model':MODEL,'instructions':f['instructions'],'input':context,'text':{'format':{'type':'json_schema','name':'ExtractorResult','strict':True,'schema':f['response_schema']}},'max_output_tokens':f['hosted_generation']['max_output_tokens'],'reasoning':{'effort':'minimal'},'store':False}

class Hosted:
    def __init__(self,run,f,ledger):
        from openai import OpenAI
        key,source=load_worker_key()
        if not key:raise Stop('No securely configured credential; do not recover from old logs')
        self.client=OpenAI(api_key=key,base_url='https://api.openai.com/v1',max_retries=0,timeout=90)
        self.f=f;self.run=run;self.ledger=ledger
        atomic(run/'credential-source.json',{'source':source,'explicit_provider':'https://api.openai.com/v1','organization_project_overrides_forwarded':False,'dotenv_read':False,'credential_printed':False})
    def generate(self,key,context):
        request=hosted_request(self.f,context);h=digest(request);dispatch=dumps(key)
        receipt=self.run/'hosted-responses'/(digest(key)+'.json')
        if receipt.exists():
            saved=read(receipt)
            if saved['request_sha256']!=h:raise Stop('Saved hosted request changed')
        else:
            self.ledger.reserve(dispatch,h,request_bound(request),request['max_output_tokens'])
            atomic(self.run/'hosted-requests'/(digest(key)+'.json'),{'key':key,'request_sha256':h,'request':request,'input_upper_bound':request_bound(request)})
            start=time.perf_counter()
            try:response=self.client.responses.create(**request)
            except BaseException as e:
                self.ledger.uncertain(dispatch)
                atomic(self.run/'last-transport-error.json',{'key':key,'type':type(e).__name__,'http_status':getattr(e,'status_code',None),'reservation_retained':True,'retry':False})
                raise Stop('Hosted request uncertain/failed; no automatic retry; reconcile durable reservation') from None
            body=response.model_dump(mode='json')
            saved={'request_sha256':h,'response':body,'record':{'raw_output':response.output_text,'latency_seconds':time.perf_counter()-start,'capped':body.get('status')=='incomplete','refused':any(part.get('type')=='refusal' for output in body.get('output',[]) for part in output.get('content',[])),'response_model':body.get('model'),'usage':body.get('usage'),'response_id':body.get('id'),'fresh_in_this_run':True}}
            atomic(receipt,saved)
        self.ledger.reconcile(dispatch,h,saved['response'].get('usage'),sha(receipt))
        if saved['record'].get('response_model')!=MODEL:raise Stop('Hosted model mismatch; no substitution')
        return saved['record']

class Local:
    def __init__(self,run,f,schema):
        os.environ['HF_HOME']=r'D:\SLM\hf-cache'
        os.environ['HF_HUB_OFFLINE']='1'
        os.environ['TRANSFORMERS_OFFLINE']='1'
        import torch
        from local_slm_lab.peft_provider import PeftInferenceConfig
        from local_slm_lab.v5_provider import V5TransformersProvider
        if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported():raise Stop('Required CUDA BF16 unavailable')
        m=read(ROOT/'MODEL_VERIFICATION.json')
        for n,h in m['adapter_sha256'].items():
            if sha(Path(m['adapter'])/n)!=h:raise Stop('Adapter hash changed')
        for n,info in m['base_files'].items():
            if sha(Path(m['base_snapshot'])/n)!=info['sha256']:raise Stop('Base cache hash changed')
        torch.set_num_threads(4)
        self.provider=V5TransformersProvider(PeftInferenceConfig(base_model=m['base_model'],revision=m['revision'],variant='custom',adapter_path=Path(m['adapter']),device='cuda',dtype='bfloat16',max_new_tokens=1024),schema)
        model=self.provider._model
        devices=sorted({str(p.device) for p in model.parameters()})
        if not model.active_adapters or getattr(model.config,'_commit_hash',None)!=m['revision'] or devices!=['cuda:0']:raise Stop('Actual model identity/adapter/device mismatch')
        self.torch=torch;self.f=f
        atomic(run/'local-runtime.json',{'gpu':torch.cuda.get_device_name(0),'devices':devices,'dtype':str(next(model.parameters()).dtype),'active_adapters':model.active_adapters,'revision':getattr(model.config,'_commit_hash',None),'base_model_class':type(model.get_base_model()).__name__,'chat_template_sha256':self.provider.chat_template_sha256,'unscored_generation_warmups':0})
    def generate(self,key,context):
        self.torch.cuda.synchronize();start=time.perf_counter()
        raw,prompt,completion,capped=self.provider._generate_raw(self.f['instructions'],context)
        self.torch.cuda.synchronize()
        return {'raw_output':raw,'prompt_tokens':prompt,'completion_tokens':completion,'capped':capped,'refused':False,'latency_seconds':time.perf_counter()-start,'fresh_in_this_run':True,'response_model':'Qwen/Qwen3.5-2B+final-step-v8'}

def score_call(p,schema,state,turn,record,wire):
    from forecasting_assistant.application.state_reducer import apply_extraction
    metrics=p.raw_score(record,{**turn,'forbidden_slots':turn.get('forbidden_slots',[])},wire)
    try:
        import json
        emitted=json.loads(record['raw_output'])
        metrics['correction_flag_correct']=isinstance(emitted,dict) and emitted.get('correction_detected') is turn['gold_extraction']['correction_detected'] and metrics['raw_contract_admitted']
    except Exception:metrics['correction_flag_correct']=False
    before=p.snapshot(state);reduced=deepcopy(before);error=None
    try:
        extraction=p.admit(record['raw_output'],wire,record.get('capped',False),record.get('refused',False))
        reduced=p.snapshot(apply_extraction(state,extraction,schema,len(state.turns)+1,turn['message']))
    except Exception as e:error=type(e).__name__
    after,trace=p.run_pipeline(state,turn['message'],schema,record,wire)
    actual=p.snapshot(after);expected=turn['expected_state_after']
    return after,{**metrics,'reducer_admitted_without_recovery':error is None,'reducer_error_type':error,'state_before':before,'state_before_recovery':reduced,'state_after_recovery':actual,'expected_state':expected,'exact_pipeline_state':actual==expected,'exact_reducer_state':reduced==expected,'provenance':trace,'gold_correction':turn['gold_extraction']['correction_detected'],'unknown_turn':turn.get('unknown_turn',False),'unknown_abstention_expected':turn.get('unknown_abstention_expected',False),'unknown_state_preserved':{k:v for k,v in before.items() if k!='intent'}=={k:v for k,v in actual.items() if k!='intent'}}

def summary(items,p):
    def group(rs):
        times=sorted(r['latency_seconds'] for r in rs)
        final=[r for r in rs if r['final_turn']]
        unknown=[r for r in rs if r['unknown_turn']]
        abstain=[r for r in rs if r['unknown_abstention_expected']]
        corrections=[r for r in rs if r['gold_correction']]
        return {'calls':len(rs),'raw_exact_actionable':p.prf(rs),'json_valid':sum(r['json_valid'] for r in rs),'schema_valid':sum(r['schema_valid'] for r in rs),'native_admitted':sum(r['raw_contract_admitted'] for r in rs),'reducer_admitted_without_recovery':sum(r['reducer_admitted_without_recovery'] for r in rs),'exact_pipeline_turns':sum(r['exact_pipeline_state'] for r in rs),'final_states':{'exact':sum(r['exact_pipeline_state'] for r in final),'denominator':len(final)},'extra_slot_flags':sum(r['extra_slot_flags'] for r in rs),'forbidden_slot_flags':sum(r['forbidden_slot_flags'] for r in rs),'duplicate_slot_calls':sum(r['duplicate_slots'] for r in rs),'corrections':{'denominator':len(corrections),'correct_raw_flag':sum(r['correct_correction'] for r in corrections),'exact_application_state':sum(r['exact_pipeline_state'] for r in corrections)},'unknown':{'information_turns':len(unknown),'abstention_expected_denominator':len(abstain),'correct_no_actionable_output':sum(r['unknown_no_updates'] for r in abstain),'prior_preserved_on_abstention_turns':sum(r['unknown_state_preserved'] for r in abstain)},'latency_seconds':{'median':statistics.median(times) if times else None,'p95_nearest_rank':times[max(0,math.ceil(.95*len(times))-1)] if times else None},'recovery_calls':sum(bool(r['provenance']['recovered_slot_ids']) for r in rs)}
    return {arm:{track:group([r for r in items if r['arm']==arm and r['track']==track]) for track in ('component','rollout')} for arm in ('v8','openai')}

def evaluate(run):
    p=bootstrap()
    from forecasting_assistant.domain.schema import load_schema,create_initial_state
    f=validate_freeze();budget=readiness(f)
    schema=load_schema();cases=rows(ROOT/'label-review-r2/CHECKED_CASES.jsonl')
    run=Path(run).resolve();run.mkdir(parents=True,exist_ok=True)
    freeze=sha(ROOT/'FREEZE_PROPOSAL.json')
    control=ROOT/'control';control.mkdir(exist_ok=True)
    with exclusive(control/'worker.lock'):
        binding=control/'RUN_BINDING.json'
        current={'run_directory':str(run),'freeze_sha256':freeze}
        if binding.exists() and read(binding)!=current:raise Stop('This condition already has a run; resume SAME directory, never reset budget or restart elsewhere')
        if not binding.exists():atomic(binding,current)
        store=CallStore(run/'calls.sqlite3',freeze)
        ledger=Ledger(control/'spending.sqlite3',freeze,budget['dispatch_ceiling_nanousd'])
        generators={};results=[]
        try:
            for track in ('component','rollout'):
                for ci,case in enumerate(cases):
                    states={arm:create_initial_state(schema) for arm in ('v8','openai')}
                    for ti,turn in enumerate(case['turns']):
                        contexts={}
                        for arm in (('v8','openai') if (ci+ti)%2==0 else ('openai','v8')):
                            if track=='component':states[arm]=p.restore(turn,schema)
                            state=states[arm]
                            context=p.extraction_context(state,turn['message'],schema);contexts[arm]=context
                            if track=='component' and len(contexts)==2 and contexts['v8']!=contexts['openai']:raise Stop('Unmatched component inputs')
                            key=[freeze,arm,track,case['scenario_id'],turn['turn_id']]
                            identity=digest([freeze,context,turn['gold_extraction'],turn['expected_state_after']])
                            record=store.get(key,identity)
                            if record is None:
                                if arm not in generators:generators[arm]=Local(run,f,schema) if arm=='v8' else Hosted(run,f,ledger)
                                # Recheck all prompt/source/gold files before dispatch.
                                validate_freeze()
                                record=generators[arm].generate(key,context)
                                record.update(key=key,identity=identity,current_input=context,instructions_sha256=digest(f['instructions']),freeze_sha256=freeze,at_UTC=utc())
                                store.put(key,identity,record)
                            if record.get('fresh_in_this_run') is not True:raise Stop('Historical/reused records forbidden')
                            states[arm],scored=score_call(p,schema,state,turn,record,f['response_schema'])
                            item={**record,**scored,'arm':arm,'track':track,'conversation_id':case['scenario_id'],'domain':case['domain'],'family':case['family'],'final_turn':ti==len(case['turns'])-1}
                            atomic(run/'scored-calls'/(digest(key)+'.json'),item);results.append(item)
                            atomic(run/'progress.json',{'status':'running','PID':os.getpid(),'at_UTC':utc(),'completed':len(results),'planned':f['planned_main_calls'],'per_model_track':{a:{t:sum(r['arm']==a and r['track']==t for r in results) for t in ('component','rollout')} for a in ('v8','openai')},'spending':ledger.summary(),'freeze_sha256':freeze})
                            print(dumps({'completed':len(results),'planned':f['planned_main_calls'],'arm':arm,'track':track,'case':case['scenario_id'],'turn':turn['turn_id']}),flush=True)
            planned=f['planned_main_calls']
            if len(results)!=planned or len({tuple(r['key']) for r in results})!=planned:raise Stop('Incomplete or duplicate main calls')
            atomic(run/'summary.json',summary(results,p))
            atomic(run/'completion.json',{'status':'complete','fresh_calls':len(results),'planned_per_model_track':sum(len(c['turns']) for c in cases),'freeze_sha256':freeze,'summary_sha256':sha(run/'summary.json'),'spending':ledger.summary(),'new_condition_not_historical_R4':True,'label_approval':read(ROOT/'LABEL_APPROVAL.json'),'at_UTC':utc()})
            atomic(run/'progress.json',{'status':'complete','completed':len(results),'planned':f['planned_main_calls'],'at_UTC':utc(),'freeze_sha256':freeze,'spending':ledger.summary()})
        except BaseException as e:
            atomic(run/'worker-failure.json',{'error_type':type(e).__name__,'sanitized_reason':str(e) if isinstance(e,Stop) else 'Unexpected processing error; preserved receipts require audit','completed_this_replay':len(results),'at_UTC':utc(),'spending':ledger.summary()})
            raise
        finally:store.close();ledger.close()

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check',action='store_true');parser.add_argument('--run',type=Path);a=parser.parse_args()
    bootstrap();f=validate_freeze()
    if a.check:
        try:readiness(f)
        except Stop as e:print(dumps({'ready':False,'blocker':str(e),'paid_dispatch':False}));raise SystemExit(2)
        print(dumps({'ready':True,'dispatch_performed':False}));return
    if not a.run:parser.error('Choose --check or --run NEW-or-matching-run-directory')
    evaluate(a.run)

if __name__=='__main__':main()
