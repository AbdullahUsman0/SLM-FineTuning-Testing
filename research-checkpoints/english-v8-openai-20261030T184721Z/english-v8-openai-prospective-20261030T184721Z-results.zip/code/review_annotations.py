"""Codex semantic checking before candidate outputs. NOT independent human review."""
from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'original-proposals'

# Each entry was written after reading the entire conversation, current message
# and proposed updates. U: records requirements outside actionable slot labels.
# These are AI checker notes, never reviewer attestations.
NOTES={
'001': ['Average supports mean aggregation; airport is explicit geography.', 'Hourly observation cadence and 48-hour horizon are distinct.', 'Uploaded file and named columns explicit. U: January 2018/last month lack full timestamps.', 'Six-hour forecast runs, knots and staffing goal explicit. U: table layout and no public bulletins.'],
'002': ['Rainfall and Ghent explicit.', 'Total rainfall refines target; sum explicit. Drainage crew is a role, not a business goal.', 'Ten-day horizon; file and ordered columns explicit.', 'No actionable update. U: year-only history and exclusion of humidity/wind.', 'CSV, every morning and millimetres explicit. U: output column layout.'],
'004': ['Index cash-closing target explicit.', 'Daily source closes stay observation cadence; filename alone not upload.', 'Weekly close is output granularity, not source cadence; first explicit output-granularity value is not a correction to a prior value.', 'Eight-week horizon explicit. U: year-only history.', 'Point and every Friday support point/week. U: exact after-cash-session trigger.'],
'005': ['Target noun excludes daily cadence; USD is explicit quote unit, not inferred from file suffix.', 'File and ordered columns explicit. U: mid-2020 history unresolved.', 'Point explicit; medium term not numeric. U: no signals.', 'Calendar-day run cadence explicit. U: 00:30 UTC delivery does not establish source timezone; volume exclusion.'],
'007': ['Prices and Lisbon plus grocery planning purpose explicit.', 'Food CPI is clarification of vague prices; do not mark automatic correction. U: exclude other components.', 'Monthly source, file and columns explicit.', 'Twelve-month horizon. U: year-only history.', 'No revision-policy value known. U: take stored values, revision uncertainty.', 'Release-triggered runs have no fixed interval merely because release is monthly. U: spreadsheet unspecified format and release event.'],
'008': ['Monthly observations and twelve-month horizon explicit.', 'Uploaded source and columns explicit; no unit from _pct.', 'Point explicit. U: year-only history and no fan chart.', 'Again is restatement, not confirmation. Monthly steps explicitly output granularity. U: MPC trigger; ALM goal stated.'],
'009': ['Real GDP target excludes quarterly cadence. U: chain-linked and seasonally adjusted qualifications.', 'Quarter horizon, workbook suffix and ordered columns explicit.', 'Geography replaced; keep frequency and horizon are explicit confirmations.', 'Filename replaced. Same column names confirms both columns, not suffix format. U: history year.', 'Once each quarter explicit. U: release timing and table layout.'],
'011': ['Snow-depth target and harbour explicit.', 'Daily observations, horizon, file, columns explicit.', 'Horizon correction; Keep daily and same file affirm unchanged attributes.', 'No actionable update. U: winter history; exclude air temperature.', 'One morning table does not establish recurring daily run. Centimetres and clearing goal explicit. U: layout/time.'],
'012': ['Dew point target excludes hourly cadence.', 'Horizon and named source explicit; valid_utc not timezone.', 'Fahrenheit explicit. U: year-only/last-week history.', 'Twelve-hour forecast refresh has forecasting context. U: no public product; goal explicit.'],
'015': ['LME cash-copper benchmark and daily cadence explicit.', 'File/columns explicit; do not derive USD/t from suffix. U: history year.', 'Fifteen trading-day horizon and point. U: no inventory commentary.', 'Metal/file replacements; Keep daily and horizon plus same columns are confirmations. Bare metal replacement cannot silently reconstruct a new free-text phrase.', 'No numeric interval from after each weekday session. U: event trigger/output columns.'],
'016': ['House-price index description and Dublin explicit.', 'Monthly observation series and source explicit.', 'Twelve-month horizon. U: history year.', 'Simple table does not explicitly request point forecasts. U: CSO release trigger/layout. Still monthly is restatement.'],
'017': ['Retail-sales target; negative ex-auto qualifier retained separately. U: excluded motor vehicles.', 'Monthly source, filename and columns explicit.', 'Keep ex-auto definition is no new positive target value. U: near-term horizon, excluded total retail.', 'No actionable update. U: year-only history and output columns.', 'Merchandise planning goal explicit. U: release trigger.'],
'018': ['Export target and Vietnam geography explicit.', 'Clarification: merchandise goods exports, monthly, million USD. U: services/crude oil exclusions.', 'Source and columns explicit. U: history year.', 'Nine-month horizon and point. U: no country split.', 'No numeric interval from customs-release event. U: trigger/output columns.'],
'019': ['Bund benchmark contains national instrument qualifier; daily source explicit.', 'Source and columns explicit. U: history year.', 'Twenty trading-day horizon; missing covariate not dont_care. U: no breakeven series.', 'Tenor/file changed; Keep daily confirms frequency. Germany first explicitly named as geography. Same columns confirm both.', 'Still is restatement, not calendar confirmation; point and ALM explicit. U: business-morning schedule, no trade ideas.'],
'021': ['Visibility, Scheldt geography and scheduling goal explicit.', 'Hourly and metres explicit; rejected daily minimum not a value.', 'Horizon, source and columns explicit. U: history year; valid_utc not timezone.', 'Three-hour forecast refresh explicit. U: output layout.', 'No new actionable values. U: operations-only, no public warning.'],
'022': ['Mean soil temperature excludes daily cadence; mean aggregation and fixed depth explicit.', 'Ten-day horizon and named columns explicit.', 'Depth, file and target column corrected. Same farm/still clauses do not create new values; same suffix not confirmation.', 'CSV explicit. Morning CSV alone not recurring daily. U: year-only history and delivery timing.'],
'023': ['Irradiance target excludes hourly; preserve outside Almeria geography qualifier.', 'Horizon/source/columns explicit; no timezone from valid_utc.', 'Watts per square metre explicit. U: imprecise history bounds.', 'Twice a day normalized under declared duration glossary; inverter goal explicit. U: unspecified clock spacing, no trading.'],
'024': ['Cash index target explicit.', 'Daily observation series, source and columns explicit. U: history year.', 'Point explicit. U: reporting season is not a numeric horizon; no constituents.', 'No interval inferred from cash-session event. U: cash-not-futures constraint.', 'Internal dashboard is a destination, not business goal. U: no market call.'],
'026': ['EUR/NOK target; receivables desk is stakeholder role.', '4pm London mid refines quote benchmark, not source timezone. Daily explicit. U: reject bid/Oslo fixing.', 'Twelve trading-day horizon, filename and columns explicit. U: history year.', 'Point explicit. Monday morning lacks explicit every-week interval. U: run time, no hedge recommendation.'],
'027': ['Consumer prices, Seoul and monthly explicit.', 'All-items CPI clarifies target; file and columns explicit. U: history year.', 'Unknown base year supplies no value. U: keep stored index basis.', 'Six-month horizon and point. U: KOSTAT release trigger.', 'Still clauses are restatements. U: spreadsheet format unspecified and output layout.'],
'028': ['Monthly step explicitly output cadence, not observations; six-month horizon explicit.', 'Source/columns explicit; _pct not unit. U: history year.', 'Point explicit. U: no Board-language prediction.', 'Again/restatement not confirmation; ALM purpose. U: decision trigger.'],
'029': ['Real GDP target, quarterly source and literal local currency explicit. U: seasonal adjustment.', 'Horizon/source/columns explicit.', 'Horizon correction; Keep geography/frequency/same file confirms them.', 'No actionable update. U: history year and output layout.', 'Each quarter supports quarterly run; second-estimate timing unresolved. Planning goal explicit.'],
'032': ['Wind gust target excludes hourly cadence.', '36-hour horizon, knots, source/columns explicit.', 'No actionable update. U: imprecise history and excluded mean wind.', 'Six-hour refresh and stand-allocation goal explicit. U: layout.'],
'033': ['Frost-hour counts excludes daily cadence; count definition remains separate.', 'File/columns explicit. U: frost-hour threshold definition cannot become target bound on counts.', 'Fourteen-day horizon. U: year-only history.', 'Geography/file correction; same columns confirm columns, not suffix format. U: retain frost-hour definition.', 'Morning table alone not daily refresh. Heater-fuel goal explicit. U: no min-temperature target.'],
'034': ['National unemployment target; geography exact possessive text available.', 'Monthly/source/columns explicit. U: seasonal adjustment.', 'Nine-month horizon. U: history year.', 'Headline rate is same existing unemployment target, not a replacement. U: participation/count exclusions.', 'Briefing-pack goal explicit. U: INE release trigger/layout.'],
'035': ['Cotton contract benchmark and daily cadence explicit.', 'Source/columns explicit. U: history year; no unit from suffix.', 'No new source or column invented from nearby clarification. U: unknown contract splicing; retain stored nearby series.', 'Trading sessions mapped to day-count trading calendar; point explicit. U: settlement trigger/no planting advice.'],
'036': ['Second-hand asking prices, Barcelona and monthly explicit. U: square-metre index definition not currency.', 'File and columns explicit. U: history year.', 'Horizon/point explicit; city-wide is aggregation level. U: no district split.', 'Ordinary repetition not confirmation.', 'Housing-note goal explicit. U: portal-dump event/no valuation.'],
'037': ['Department-store index excludes monthly cadence.', 'Eight-month horizon and named source explicit. U: history year.', 'Channel/file correction. Keep horizon/geography and same columns are explicit confirmations.', 'No adjustment/calendar inferred from stored series. U: unavailable calendar.', 'Planning goal explicit. U: KOSTAT event/output columns.'],
'038': ['Exports and Bangladesh explicit.', 'Ready-made garment exports excludes monthly; unit explicit. U: exclude total merchandise/services.', 'Horizon/source/columns explicit. U: history year.', 'Point explicit. U: EPB release trigger/no buyer split.'],
'039': ['South African bond benchmark and daily source explicit.', 'Source/columns explicit. U: history year; no unit from _pct.', 'Trading-day horizon; unavailable inflation-linked covariate no value.', 'Point and ALM goal explicit. U: business-morning timing/no duration call.', 'Keep 10-year generic confirms existing target, same file/horizon affirm unchanged values. U: reject 5-year.'],
'041': ['Relative humidity excludes hourly cadence; location explicit.', 'Horizon, percent, named source explicit; valid_local does not establish timezone.', 'No actionable update. U: history year/exclude temperature.', 'Twelve-hour run cadence and setpoint goal explicit. U: output layout.'],
'042': ['Wave-height target and platform geography explicit.', 'Hourly observations, metres, horizon and source explicit.', 'Observation step/file correction; same columns confirm columns, not suffix format.', 'No actionable update. U: year-only history/no component split.', 'Six-hour forecast cadence and crane-lift goal explicit. U: no routing.'],
'044': ['Closing index target excludes daily cadence.', 'Horizon/trading calendar and source explicit. U: history year.', 'Market target correction; Keep daily/horizon explicitly confirms them.', 'New file replaces a previous reference, so correction flag true; same columns confirm columns. Point explicit.', 'No interval from cash-close event. U: layout/no stock picks.', 'Still restatements not new calendar confirmation.'],
'045': ['ETH-USD daily close benchmark; USD explicit in pair. No unit from filename.', 'Named source/columns. U: history year.', 'Calendar-day horizon. Unknown timestamp convention cannot establish timezone.', 'Point/daily run explicit. U: delivery UTC clock not source timezone; no staking/fees.'],
'046': ['USD/INR target and payables purpose explicit.', 'Reference rate refines target; daily/source/columns explicit. U: history year.', 'Trading-day horizon and point explicit. U: no cone.', 'Business-days-only explicit; Indian market holidays literal named calendar constraint. Monday refresh interval ambiguous.', 'Cash-planning purpose refines earlier purpose; no explicit correction. U: output layout.'],
'048': ['Monthly series, policy-rate target and horizon explicit.', 'Source/columns explicit. U: history year; no unit from suffix.', 'Point explicit. U: missing deposit-rate data must not be invented.', 'Restatements not confirmations; desk-memo goal. U: decision event.'],
'049': ['Nominal GDP excludes quarterly cadence; geography/unit explicit.', 'Horizon/source/columns explicit. U: history year.', 'Real GDP, source and target-column correction; Keep country/cadence/horizon confirms them.', 'Unknown rebase supplies no value. U: stored-series basis.', 'Quarterly-release event does not itself establish fixed run interval. U: event/layout.'],
'051': ['Maximum temperature excludes daily; daily observation and max aggregation stated.', 'Source/columns plus explicit output daily steps; unchanged frequency omitted. U: history year.', 'No numeric hot-month horizon or recurring daily run from morning table. U: seasonal coverage/layout.', 'Celsius first explicitly stated; not unit from _c. U: no warning product.', 'Each morning now explicitly daily run; permit-planning goal stated.'],
'052': ['Sea-ice concentration excludes daily; geography explicit.', 'Percent is unit, not whole Percent ice cover phrase; horizon/source explicit.', 'No actionable update. U: winter history, missing thickness not indifference.', 'Daily run and scheduling goal explicit. U: local clock not IANA/source timezone.'],
'053': ['Rainfall/geography explicit.', 'Areal catchment rainfall and basin clarify request, not automatically correction. U: reject city gauge.', 'Monthly totals, unit, sum and named source explicit. U: history year.', 'Six-month horizon and point explicit.', 'Unknown areal-average construction supplies no method. U: use stored series.', 'Month-end close is event trigger, not fixed numeric run interval. Storage goal explicit.'],
'054': ['Seasonally adjusted target qualifier, country and monthly explicit.', 'Source/columns explicit. U: history year; no percent from suffix.', 'Twelve-month horizon; headline rate denotes same target, not a replacement.', 'Point explicit; still clauses omit repeated values. U: HLFS event.', 'Labour-market-note goal explicit. U: no wage recommendation.'],
'056': ['Average asking-price target supports mean aggregation; geography/monthly explicit. U: per-area metric no currency guessed.', 'Horizon/source/columns explicit. U: year-only history; no PLN from column.', 'City-wide explicitly aggregation level. U: existing-only, no rents/new-build.', 'Research-note goal explicit. U: snapshot event/no appraisal.'],
'058': ['Goods exports, Singapore, monthly and unit explicit.', 'Horizon/source/columns explicit. U: history year.', 'File/column correction and Keep cadence/country/horizon confirmations. Domestic exports is absent as positive message text; do not derive label from filename. U: exclude re-exports.', 'Point explicit. U: trade-release event/no partner split.', 'Domestic exports first explicit positive noun phrase here; supplied, not confirmation of invented prior text.'],
'059': ['BTP benchmark, Italy and daily source explicit.', 'Source/columns explicit. U: history year.', 'Point explicit. U: short horizon not quantified; missing spread series.', 'ALM purpose explicit. U: business-morning schedule not numeric duration; still clauses restatement.'],
}

def dumps(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,allow_nan=False)
def digest(x):return hashlib.sha256(dumps(x).encode()).hexdigest()
def write(path,x):path.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def main():
    output=ROOT/'label-review-r2';assert not output.exists();output.mkdir()
    cases=[json.loads(s) for s in (SOURCE/'AI_DRAFT_ANNOTATIONS.jsonl').read_text(encoding='utf-8').splitlines()]
    originals=deepcopy(cases);by={c['conversation_id'][-3:]:c for c in cases};changes=[]
    def turn(case,n):return by[case]['turns'][n-1]
    def edit(case,n,sid,value=None,status='provided',remove=False,reason=''):
        t=turn(case,n);updates=t['draft_extraction']['updates'];old=next((deepcopy(x) for x in updates if x['slot_id']==sid),None)
        updates[:]=[x for x in updates if x['slot_id']!=sid]
        new=None if remove else {'slot_id':sid,'candidate_value':deepcopy(value),'status':status,'confidence':1.0,'evidence_text':t['message']}
        if new is not None:updates.append(new)
        if old!=new:changes.append({'conversation_id':'EXT-'+case,'turn_id':n,'field':'updates.'+sid,'before':old,'after':deepcopy(new),'reason':reason,'checker':'Codex AI semantic check; not human review'})
    def setv(c,n,s,v,status='provided',reason='Literal supported value or corrected role under S03/S09/S10/S11'):
        edit(c,n,s,v,status,reason=reason)
    def drop(c,n,s,reason):edit(c,n,s,remove=True,reason=reason)
    def target(c,n,v):
        for sid in ('problem_statement','target_description'):setv(c,n,sid,v,reason='S10 exact meaningful target phrase; cadence separately represented and rejected alternatives excluded')
    def flag(c,n,v,reason):
        t=turn(c,n);old=t['draft_extraction']['correction_detected']
        if old!=v:changes.append({'conversation_id':'EXT-'+c,'turn_id':n,'field':'correction_detected','before':old,'after':v,'reason':reason,'checker':'Codex AI semantic check; not human review'})
        t['draft_extraction']['correction_detected']=v
    def confirm(c,n,*slots):
        for sid in slots:
            prior={}
            for t in by[c]['turns'][:n-1]:
                for u in t['draft_extraction']['updates']:prior[u['slot_id']]=u['candidate_value']
            assert sid in prior,(c,n,sid)
            setv(c,n,sid,prior[sid],'confirmed','S11 explicit Keep/same affirmation of this recorded value; not ordinary still/restatement')

    # These are explicit per-case semantic decisions, not output-driven repairs.
    setv('001',1,'aggregation_method','mean')
    target('002',2,'total rainfall');drop('002',2,'business_goal','A crew is a stakeholder role, not an operational objective');setv('002',2,'stakeholder_role','drainage crew')
    target('005',1,'closing price for Solana');setv('005',1,'target_unit','USD')
    setv('007',1,'business_goal',"small grocery chain's planning meeting")
    drop('007',6,'prediction_frequency','S06 release-triggered schedule is not a fixed duration; monthly describes the release')
    setv('008',4,'output_granularity','monthly steps')
    target('009',1,'real GDP');confirm('009',3,'frequency','forecast_horizon')
    drop('009',4,'file_format','S08 replacement filename suffix alone is not explicit confirmation');confirm('009',4,'time_column','target_column')
    confirm('011',3,'frequency','source_reference');drop('011',5,'prediction_frequency','One morning table is not a recurring daily schedule')
    target('012',1,'dew point')
    drop('015',4,'file_format','S08 filename-only suffix, same inferred value omitted');confirm('015',4,'frequency','forecast_horizon','time_column','target_column')
    drop('016',4,'forecast_type','S13 simple table does not specify point versus probabilistic forecast')
    target('017',1,'retail sales, seasonally adjusted')
    drop('019',4,'file_format','S08 suffix not confirmation');setv('019',4,'geography',['Germany']);confirm('019',4,'frequency','time_column','target_column')
    drop('019',5,'calendar_type','S11 Still is a restatement, not explicit confirmation')
    target('022',1,'mean soil temperature');setv('022',1,'aggregation_method','mean')
    drop('022',3,'file_format','S08 suffix not confirmation');drop('022',4,'prediction_frequency','Morning CSV alone gives time of day, not a recurring daily interval')
    target('023',1,'global horizontal irradiance');setv('023',1,'geography',['outside Almería'])
    drop('024',5,'business_goal','Dashboard is destination system, not business purpose');setv('024',5,'destination','Internal dashboard')
    drop('026',1,'business_goal','Receivables desk is stakeholder role');setv('026',1,'stakeholder_role','Nordic receivables desk')
    target('026',2,'4pm London mid');drop('026',4,'prediction_frequency','Monday morning alone does not explicitly say every week')
    drop('028',1,'frequency','S03 monthly step refers to forecast output rather than native source observation cadence');setv('028',1,'output_granularity','monthly step')
    target('029',1,'real GDP');confirm('029',3,'geography','frequency','source_reference');setv('029',5,'prediction_frequency',{'periods':1,'unit':'quarter'})
    target('032',1,'wind gusts');target('033',1,'frost-hour counts')
    drop('033',4,'file_format','S08 suffix not confirmation');confirm('033',4,'time_column','target_column');drop('033',5,'prediction_frequency','Morning table alone is not daily recurrence')
    setv('036',3,'aggregation_level','city-wide')
    target('037',1,'department-store sales index');drop('037',3,'file_format','S08 suffix not confirmation');confirm('037',3,'geography','forecast_horizon','time_column','target_column')
    target('038',2,'ready-made garment exports')
    confirm('039',5,'problem_statement','target_description','source_reference','forecast_horizon')
    target('041',1,'relative humidity');drop('042',3,'file_format','S08 suffix not confirmation');confirm('042',3,'time_column','target_column')
    target('044',1,'closing level of the Bovespa index');confirm('044',3,'frequency','forecast_horizon')
    drop('044',4,'file_format','S08 suffix not confirmation');confirm('044',4,'time_column','target_column');flag('044',4,True,'New source_reference replaces prior ibov_daily.csv')
    drop('044',6,'calendar_type','Still restatement not explicit confirmation')
    setv('045',1,'target_unit','USD')
    target('046',2,'reference rate');setv('046',4,'holidays',['Indian market holidays'])
    drop('046',4,'prediction_frequency','Monday refresh has no explicit every-week interval')
    target('049',1,'nominal GDP');drop('049',3,'file_format','S08 suffix not confirmation');confirm('049',3,'geography','frequency','forecast_horizon')
    target('051',1,'maximum temperature');setv('051',1,'frequency',{'periods':1,'unit':'day'});setv('051',1,'aggregation_method','max')
    drop('051',2,'frequency','Unchanged daily cadence omitted; explicit Daily steps is output granularity');setv('051',2,'output_granularity','Daily steps')
    drop('051',3,'prediction_frequency','Morning table does not establish repeat interval');setv('051',5,'prediction_frequency',{'periods':1,'unit':'day'})
    target('052',1,'sea-ice concentration');setv('052',2,'target_unit','percent',reason='Declared case-insensitive percentage-unit glossary: Percent -> percent; ice cover is target description')
    drop('053',6,'prediction_frequency','S06 month-end close is event trigger, not an explicit fixed numeric interval')
    setv('056',1,'aggregation_method','mean');setv('056',3,'aggregation_level','City-wide')
    drop('058',3,'file_format','S08 suffix not confirmation')
    for s in ('problem_statement','target_description'):drop('058',3,s,'S08/S10 domestic exports is not a positive noun phrase in this message; filename does not supply domain meaning. Exclude re-exports retained separately.')
    confirm('058',3,'geography','frequency','forecast_horizon');target('058',5,'domestic exports')

    unknown_keys={('005',3),('007',5),('017',3),('019',3),('024',3),('027',3),('035',3),('037',4),('039',3),('045',3),('049',4),('051',3),('053',5),('059',3)}
    records=[];review_rows=[];corrected=[];unresolved=[];families=[]
    for case,original in zip(cases,originals):
        cid=case['conversation_id'];key=cid[-3:];assert len(NOTES[key])==len(case['turns'])
        state={};prior=[];turns=[]
        for t,ot,note in zip(case['turns'],original['turns'],NOTES[key]):
            extraction=deepcopy(t['draft_extraction']);before=deepcopy(state)
            # Independent semantic reducer: NO app/recovery imports. Explicit
            # confirmation is retained as confirmed in the ideal state, even if
            # the application under test downgrades it. Disagreement is reported.
            for u in extraction['updates']:
                if u['status'] in {'unmentioned','dont_care'}:continue
                state[u['slot_id']]={'value':deepcopy(u['candidate_value']),'status':u['status'],'confirmed_by_user':u['status']=='confirmed'}
            state.setdefault('intent',{'value':'create_forecast','status':'provided','confirmed_by_user':False})
            typed=deepcopy(extraction)
            for u in typed['updates']:u['candidate_value']=json.dumps(u['candidate_value'],ensure_ascii=False)
            turn_changes=[r for r in changes if r['conversation_id']==cid and r['turn_id']==t['turn_id']]
            rec={'conversation_id':cid,'turn_id':t['turn_id'],'message':t['message'],'checker_identity':'Codex AI semantic checker','independent_human_review':False,'semantic_note':note,'original_proposal':deepcopy(ot),'checked_extraction_typed':extraction,'checked_extraction_wire':typed,'ideal_state_before':before,'ideal_state_after':deepcopy(state),'changes':turn_changes,'human_decision':None}
            records.append(rec)
            if 'U:' in note:unresolved.append({'conversation_id':cid,'turn_id':t['turn_id'],'evidence_text':t['message'],'requirement_note':note.split('U:',1)[1].strip(),'disposition':'separate non-actionable/unrepresented requirement; human check pending'})
            review_rows.append({'conversation_id':cid,'turn_id':t['turn_id'],'prior_user_messages_json':dumps(prior),'message':t['message'],'original_extraction_json':dumps(ot['draft_extraction']),'checked_extraction_json':dumps(extraction),'ideal_before_json':dumps(before),'ideal_after_json':dumps(state),'AI_check_note':note,'changes_count':len(turn_changes),'human_reviewer_id':'','human_decision':'','human_corrections_json':'','human_reason':'','adjudicator_id':'','adjudication':''})
            turns.append({'turn_id':t['turn_id'],'message':t['message'],'established_intent':'ambiguous' if not prior else 'create_forecast','context_state':before,'prior_user_messages':deepcopy(prior),'gold_extraction':typed,'expected_state_after':deepcopy(state),'AI_semantic_note':note,'unknown_turn':(key,t['turn_id']) in unknown_keys,'unknown_abstention_expected':(key,t['turn_id']) in unknown_keys and not extraction['updates'],'human_review_complete':False})
            prior.append(t['message'])
        # Preassigned from input meanings before any candidate outputs. This is a
        # narrative-family sensitivity, not an assertion of independent sources.
        text=case['turns'][0]['message'].lower()
        family=next((v for words,v in [(('gdp',),'gdp'),(('exports','export'),'exports'),(('yield',),'sovereign_yields'),(('rate',),'policy_or_fx_rates'),(('index','closing level','close'),'index_or_crypto'),(('sales',),'retail_sales'),(('unemployment',),'labour'),(('house','asking','flats'),'housing')] if any(w in text for w in words)), 'weather' if case['domain']=='weather' else 'other_economics')
        families.append({'conversation_id':cid,'family':family,'basis':'input-only narrative topic; single synthetic generator remains shared dependence'})
        corrected.append({'scenario_id':cid,'domain':case['domain'],'language':'en','category':'prospective_english_synthetic','family':family,'turns':turns,'human_review_complete':False,'AI_semantic_check_complete':True})
    assert len(corrected)==44 and len(records)==205
    for filename,data in [('CHECKED_ANNOTATIONS.jsonl',records),('CHECKED_CASES.jsonl',corrected),('ANNOTATION_CHANGES.jsonl',changes),('UNREPRESENTED_REQUIREMENTS.jsonl',unresolved),('PREASSIGNED_FAMILIES.jsonl',families)]:
        (output/filename).write_text(''.join(dumps(x)+'\n' for x in data),encoding='utf-8')
    with (output/'human-review.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(review_rows[0]));writer.writeheader();writer.writerows(review_rows)
    changed_turns={(r['conversation_id'],r['turn_id']) for r in changes}
    write(output/'AI_SEMANTIC_REVIEW.json',{'checker':'Codex AI, not an independent human','conversations_read':44,'turns_read_with_context':205,'changed_turns':len(changed_turns),'field_changes':len(changes),'turns_with_separately_recorded_constraints':len(unresolved),'original_proposals_preserved':True,'candidate_outputs_inspected':0,'labels_human_approved':False,'label_status':'AI-checked proposals for human review; not certified gold','state_contract':'Independent semantic state retains confirmation status and confirmed_by_user; app downgrading is a measured discrepancy, not silently mirrored into ideal labels','policy_version':'external-english-actionable-protocol-20261030-AI-check-r2','files_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir() if p.is_file()}})
    print(dumps({'conversations':44,'turns':205,'changed_turns':len(changed_turns),'field_changes':len(changes),'human_review_complete':False}))

if __name__=='__main__':main()
