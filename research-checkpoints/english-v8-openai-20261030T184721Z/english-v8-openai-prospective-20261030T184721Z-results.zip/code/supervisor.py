"""Detached supervisor: durable logs/status, resume same run, no automatic replay."""
import argparse
from datetime import datetime,timezone
import os
from pathlib import Path
import subprocess
import sys
from common import ROOT,atomic,exclusive

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',required=True,type=Path);a=parser.parse_args()
    run=a.run.resolve();run.mkdir(parents=True,exist_ok=True)
    with exclusive(ROOT/'control/supervisor.lock'):
        atomic(run/'supervisor.json',{'status':'starting','PID':os.getpid(),'run':str(run),'at_UTC':datetime.now(timezone.utc).isoformat()})
        with (run/'stdout.log').open('ab',buffering=0) as out,(run/'stderr.log').open('ab',buffering=0) as err:
            worker=subprocess.Popen([sys.executable,str(Path(__file__).with_name('runner.py')),'--run',str(run)],stdout=out,stderr=err)
            atomic(run/'worker-PID.json',{'PID':worker.pid,'supervisor_PID':os.getpid()})
            code=worker.wait()
        atomic(run/'supervisor.json',{'status':'worker_finished' if code==0 else 'worker_stopped_requires_audit','PID':os.getpid(),'worker_exit_code':code,'run':str(run),'automatic_transport_retries':0,'at_UTC':datetime.now(timezone.utc).isoformat()})

if __name__=='__main__':main()
