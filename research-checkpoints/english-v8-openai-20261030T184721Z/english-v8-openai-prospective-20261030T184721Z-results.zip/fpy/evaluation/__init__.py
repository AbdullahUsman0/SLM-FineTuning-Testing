"""Deterministic FYP evaluation assets."""
