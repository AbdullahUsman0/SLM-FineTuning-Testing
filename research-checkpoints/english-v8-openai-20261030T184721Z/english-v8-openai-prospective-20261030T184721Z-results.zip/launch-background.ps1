param([Parameter(Mandatory=$true)][string]$RunDirectory)
$ErrorActionPreference='Stop'
$python='D:\SLM\FYP-environments\v8-final-20261018T230255Z\Scripts\python.exe'
$root=$PSScriptRoot
# This check is offline and fails closed before creating a GPU/API worker.
& $python "$root\code\runner.py" --check
if($LASTEXITCODE -ne 0){throw 'Readiness check failed'}
$approval=Get-Content -LiteralPath "$root\LABEL_APPROVAL.json" -Raw | ConvertFrom-Json
$budget=Get-Content -LiteralPath "$root\BUDGET_AUTHORIZATION.json" -Raw | ConvertFrom-Json
if(-not $approval.approved -or -not $budget.authorized){throw 'Real label/budget approvals remain required'}
$resolved=[System.IO.Path]::GetFullPath($RunDirectory)
New-Item -ItemType Directory -Path $resolved -Force | Out-Null
$process=Start-Process -FilePath $python -ArgumentList @('"'+$root+'\code\supervisor.py"','--run','"'+$resolved+'"') -WindowStyle Hidden -PassThru -RedirectStandardOutput "$resolved\supervisor.stdout.log" -RedirectStandardError "$resolved\supervisor.stderr.log"
Write-Output "Supervisor PID $($process.Id); inspect progress.json for actual completed calls."
