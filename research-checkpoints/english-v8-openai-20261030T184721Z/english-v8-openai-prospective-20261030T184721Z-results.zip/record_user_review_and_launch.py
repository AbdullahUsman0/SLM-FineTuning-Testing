"""Record the user's review attestation; do not invent returned review worksheets."""
from datetime import datetime,timezone
from pathlib import Path
import shutil
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from common import atomic,read,sha

def main():
    assert not (ROOT/'control/RUN_BINDING.json').exists(),'Resume existing run rather than initialize another'
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    prior=ROOT/'approval-history'/stamp;prior.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(ROOT/'LABEL_APPROVAL.json',prior/'LABEL_APPROVAL.before.json')
    quote='continuewith inference, I have done independent human review too'
    evidence={'source':'user message in this session','user_quote':quote,'client_date':'2026-10-30','recorded_at_UTC':datetime.now(timezone.utc).isoformat(),'scope':'Prepared immutable English follow-up packet: 44 conversations, 205 turns; current AI-corrected labels and proposed reference-state contract','labels_sha256':sha(ROOT/'label-review-r2/CHECKED_CASES.jsonl'),'freeze_sha256':sha(ROOT/'FREEZE_PROPOSAL.json'),'review_completion_user_attested':True,'reviewer_names_invented':False,'per_turn_human_worksheets_returned_to_server':False,'note':'The user reports independent human review complete and authorizes inference. No new human identities, signed worksheets, correction decisions or measured agreement are fabricated.'}
    atomic(ROOT/'USER_HUMAN_REVIEW_ATTESTATION.json',evidence)
    atomic(ROOT/'LABEL_APPROVAL.json',{'approved':True,'mode':'independent_human_reviewed','labels_sha256':evidence['labels_sha256'],'approval_evidence':'User message on 2026-10-30: '+quote,'approval_evidence_file':'USER_HUMAN_REVIEW_ATTESTATION.json','approval_evidence_sha256':sha(ROOT/'USER_HUMAN_REVIEW_ATTESTATION.json'),'independent_human_review_complete':True,'provenance':'User-attested completion; no per-turn human worksheets returned to this server. Preserve this qualification in the research handoff.'})
    run=Path(r'D:\SLM\FYP-evaluation-runs')/('english-v8-openai-prospective-'+stamp)
    assert not run.exists();run.mkdir()
    config={'workspace':str(ROOT),'run':str(run),'python':sys.executable,'freeze_sha256':sha(ROOT/'FREEZE_PROPOSAL.json'),'shared_ledger':str(ROOT/'control/spending.sqlite3'),'authorized_API_USD':1,'internal_dispatch_ceiling_USD':.9,'financial_details_for_paper':False,'review_provenance':'user-attested independent human review; returned worksheets absent','source_commit':'0729cd4a01c07cf724ccfa380e56a0cab6a0b0ae','created_at_UTC':datetime.now(timezone.utc).isoformat()}
    atomic(run/'launch-manifest.json',config);atomic(Path(r'D:\SLM\active-english-prospective-evaluation.json'),config)
    print(str(run))

if __name__=='__main__':main()
